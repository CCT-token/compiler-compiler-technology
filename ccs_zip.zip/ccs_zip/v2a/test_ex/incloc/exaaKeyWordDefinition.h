/////////////////////////////////////////////////////////////////////
//  exaaKeyWordDefinition.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_exaa_KEYWORDDEFINITION_H_
#define  _CPPCC_exaa_KEYWORDDEFINITION_H_

#include "CommonRoutines.h"

namespace cppcc {
namespace exaa {

enum KeyWords
{
  // 0
  KW_WRONG_KEY_WORD
  // 1
  ,KW_IDENTIFIER
  // 2
  ,KW_STRINGTOKEN
  // 3
  ,KW_INTEGERTOKEN
  // 4
  ,KW_FLOATTOKEN
  // 5
  ,KW_TEXTTOKEN
  // 6
  ,KW_TERMTOKEN
  // 7
  ,KW_TERMINALTOKENOFRULE
  // 8
  ,KW_QUOTETERMTOKEN
  // 9
  ,KW_APOSTROPHETERMTOKEN
  // 10
  ,KW_LEFTPARENTHESISTERMTOKEN
  // 11
  ,KW_RIGHTPARENTHESISTERMTOKEN
  // 12
  ,KW_LESSTHENTERMTOKEN
  // 13
  ,KW_EQUALTERMTOKEN
  // 14
  ,KW_GREATERTHENTERMTOKEN
  // 15
  ,KW_LEFTSQUAREBRACKETTERMTOKEN
  // 16
  ,KW_RIGHTSQUAREBRACKETTERMTOKEN
  // 17
  ,KW_VERTICALBARTERMTOKEN
  // 18
  ,KW_LEFTBRACETERMTOKEN
  // 19
  ,KW_RIGHTBRACETERMTOKEN
  // 20
  ,KW_DEFISTERMTOKEN
  // 21
  ,KW_COLONMARKTERMTOKEN
  // 22
  ,KW_QUESTIONMARKTERMTOKEN
  // 23
  ,KW_SLASHMARKTERMTOKEN
  // 24
  ,KW_XMLENDTERMTOKEN
  // 25
  ,KW_COMMATERMTOKEN
  // 26
  ,KW_SEMICOLONTERMTOKEN
  // 27
  ,KW_EDGEOPTERMTOKEN
  // 28
  ,KW_D
  // 29
  ,KW_PROG
  // 30
  ,KW_ST
  // 31
  ,KW_A
  // 32
  ,KW_B
  // 33
  ,KW_C
  // 34
  ,KW_D2
  // 35 -- Total
  ,KW_KEYWORDS_TOTAL
};

cppcc::com::KeyWordsContainer makeKeyWordsContainer();

}
}

#endif


/////////////////////////////////////////////////////////////////////
//  exaaGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "exaaParser.h"
#include "exaaKeyWordDefinition.h"
#include "exaaGenerator.h"

namespace cppcc {
namespace exaa {

void
exaaGeneratorBinary::generate(const std::string& filename)
{
}

}
}

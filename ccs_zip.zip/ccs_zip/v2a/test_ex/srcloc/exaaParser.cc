/////////////////////////////////////////////////////////////////////
//  exaaParser.cc 
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "exaaParser.h"
#include "exaaKeyWordDefinition.h"

namespace cppcc {
namespace exaa {

void
exaaParser::compile
  (const char *sour, const char *list)
{
  CPPCC_LOG_INFO(logger_,
    << "exaaParser::compile() "
    << " source:" << "'" << std::string(sour?sour:"") << "'"
    << " listing:" << "'" << std::string(list?list:"") << "'"
  )

  filename_ = sour?sour:"";
  tokenizer_.start(sour, list);

  prog(axiom_);

  tokenizer_.erfini();
}

void
exaaParser::compile
    (const std::string& filename
    ,const std::string& sourceString
  ,bool         isListing)
{
  filename_ = filename;
  tokenizer_.start(sourceString, isListing);

  prog(axiom_);

  tokenizer_.erfini();
}

void
exaaParser::prog(cppcc::scr::tag::Long& tag)
/*
(prog::=0 ="  METAACTBEG();"=st 0 ="  METAACTEND();"=)
*/
{
  TagVector f(1);

  METAACTBEG();

  st(f[0]);

  crefixe(KW_PROG,f,&tag);
  METAACTEND();


}

void
exaaParser::st(cppcc::scr::tag::Long& tag)
/*
(st::={<a>|<b>|c|d2})
*/
{
  TagVector d;
  char Ya=0;
  char Yb=0;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_A) {
      if(Ya) {edberkwsdf(KW_A);return;}
      Ya=1;
	    d.push_back(0);
	    a(d.back());
    }
    if(kword() == KW_B) {
      if(Yb) {edberkwsdf(KW_B);return;}
      Yb=1;
      d.push_back(0);
      b(d.back());
    }
    if(kword() == KW_C) {
      d.push_back(0);
      c(d.back());
    }
    if(kword() == KW_D) {
      d.push_back(0);
      d2(d.back());
    }
    else break;

  }

  crelasdyn(KW_ST,d,&tag);

}

void
exaaParser::a(cppcc::scr::tag::Long& tag)
/*
(a::='a' identifier)
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_A,f[0]);

  identifier(f[1]);
  crefixe(KW_A,f,&tag);


}

void
exaaParser::b(cppcc::scr::tag::Long& tag)
/*
(b::='b' integerToken)
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_B,f[0]);

  integerToken(f[1]);
  crefixe(KW_B,f,&tag);


}

void
exaaParser::c(cppcc::scr::tag::Long& tag)
/*
(c::='c' stringToken)
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_C,f[0]);

  stringToken(f[1]);
  crefixe(KW_C,f,&tag);


}

void
exaaParser::d2(cppcc::scr::tag::Long& tag)
/*
(d2::='d' stringToken)
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_D,f[0]);

  stringToken(f[1]);
  crefixe(KW_D2,f,&tag);


}

}

namespace com {
cppcc::syn::Parser* 
makeParser(cppcc::cmp::Compiler& compiler)
{
  CPPCC_LOG_INFO((*compiler.shell_.logger_),
    << "com::makeParser() started..."
    << " tokensSetID:" << compiler.shell_.tokensSetID_
  )

  return
    new cppcc::exaa
      ::exaaParser
      ((*compiler.shell_.logger_)
      ,compiler.keyWords_
      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_Meta
      ,cppcc::lex::TokenizerReader_File)
    ;
}
}

}

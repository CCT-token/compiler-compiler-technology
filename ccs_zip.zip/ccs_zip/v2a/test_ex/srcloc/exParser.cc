/////////////////////////////////////////////////////////////////////
//  exParser.cc 
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "exParser.h"
#include "exKeyWordDefinition.h"

namespace cppcc {
namespace ex {

void
exParser::compile
  (const char *sour, const char *list)
{
  CPPCC_LOG_INFO(logger_,
    << "exParser::compile() "
    << " source:" << "'" << std::string(sour?sour:"") << "'"
    << " listing:" << "'" << std::string(list?list:"") << "'"
  )

  filename_ = sour?sour:"";
  tokenizer_.start(sour, list);

  prog(axiom_);

  tokenizer_.erfini();
}

void
exParser::compile
    (const std::string& filename
    ,const std::string& sourceString
  ,bool         isListing)
{
  filename_ = filename;
  tokenizer_.start(sourceString, isListing);

  prog(axiom_);

  tokenizer_.erfini();
}

void
exParser::prog(cppcc::scr::tag::Long& tag)
/*
( prog ::= 0 = "  METAACTBEG();"= st  0 = "  METAACTEND();"= ) 
*/
{
  TagVector f(1);

  METAACTBEG();

  st(f[0]);

  crefixe(KW_PROG,f,&tag);
  METAACTEND();


}

void
exParser::st(cppcc::scr::tag::Long& tag)
/*
( st ::= { < a2 > | < b2 > | c2 | d2 } ) 
*/
{
  TagVector d;
  char Ya2=0;
  char Yb2=0;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_A) {
      if(Ya2) {edberkwsdf(KW_A2);return;}
      Ya2=1;
	    d.push_back(0);
	    a2(d.back());
    }
    else if(kword() == KW_B) {
      if(Yb2) {edberkwsdf(KW_B2);return;}
      Yb2=1;
      d.push_back(0);
      b2(d.back());
    }
    else if(kword() == KW_C) {
      d.push_back(0);
      c2(d.back());
    }
    else if(kword() == KW_D) {
      d.push_back(0);
      d2(d.back());
    }
    else break;

  }

  crelasdyn(KW_ST,d,&tag);

}

void
exParser::a2(cppcc::scr::tag::Long& tag)
/*
( a2 ::= 'a' identifier ) 
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_A,f[0]);

  identifier(f[1]);
  crefixe(KW_A2,f,&tag);


}

void
exParser::b2(cppcc::scr::tag::Long& tag)
/*
( b2 ::= 'b' integerToken ) 
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_B,f[0]);

  integerToken(f[1]);
  crefixe(KW_B2,f,&tag);


}

void
exParser::c2(cppcc::scr::tag::Long& tag)
/*
( c2 ::= 'c' stringToken ) 
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_C,f[0]);

  stringToken(f[1]);
  crefixe(KW_C2,f,&tag);


}

void
exParser::d2(cppcc::scr::tag::Long& tag)
/*
( d2 ::= 'd' integerToken ) 
*/
{
  TagVector f(2);

  skipKeyWordTerm(KW_D,f[0]);

  integerToken(f[1]);
  crefixe(KW_D2,f,&tag);


}

}

namespace com {
cppcc::syn::Parser* 
makeParser(cppcc::cmp::Compiler& compiler)
{
  CPPCC_LOG_INFO((*compiler.shell_.logger_),
    << "com::makeParser() started..."
    << " tokensSetID:" << compiler.shell_.tokensSetID_
  )

  return
    new cppcc::ex
      ::exParser
      ((*compiler.shell_.logger_)
      ,compiler.keyWords_
      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_Meta
      ,cppcc::lex::TokenizerReader_File)
    ;
}
}

}

/////////////////////////////////////////////////////////////////////
//  exMakeGenerators.cc
//
//      Change history:
//              2010.06.12              - Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "exParser.h"
#include "exKeyWordDefinition.h"
#include "exGenerator.h"

namespace cppcc {


namespace com {

cppcc::gen::GeneratorRuntime*
makeRuntimeGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::ex
    ::exGeneratorRuntime(generator);
}

cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::ex
    ::exGeneratorBinary(generator);
}
}

}

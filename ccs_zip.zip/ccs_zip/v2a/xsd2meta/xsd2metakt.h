/* xsd2metakt.h                version of 09.01.91 */

char *KeyTab[]=
{

	/*   0*/  "WrongKeyWord"
	/*   1*/, "xsd"
	/*   2*/, "xsd2meta"
	/*   3*/, "greaterthanTermToken"
	/*   4*/, "floatToken"
	/*   5*/, "equalTermToken"
	/*   6*/, "xmlEndTermToken"
	/*   7*/, "integerToken"
	/*   8*/, "stringToken"
	/*   9*/, "grammar"
	/*  10*/, "identifier"
	/*  11*/, "colonTermToken"
	/*  12*/, "attribute"
	/*  13*/, "attributes"
	/*  14*/, "attributeExtention"
	/*  15*/, "slashdivideTermToken"
	/*  16*/, "quastionmarkTermToken"
	/*  17*/, "lessthanTermToken"
	/*  18*/, "xsdTag"
	/*  19*/, "xsdTags"
	/*  20*/, "xsdTagSimple"
	/*  21*/, "xsdTagsList"
	/*  22*/, "xsdTagEnd"
	/*  23*/, "xsdTagCompound"
	/*  24*/, "xmlToken"
	/*  25*/, "xmlVersion"
	/*  26*/, "xmlVersionAttributes"
	/*  27*/, "termTokenofrule"
	/*  28*/, "termToken"
	/*  28*/, "quotationTermToken"
	/*  29*/, "sharpTermToken"
	/*  30*/, "ampersandTermToken"
	/*  31*/, "apostropheTermToken"
	/*  32*/, "leftparenthesisTermToken"
	/*  33*/, "rightparenthesisTermToken"
	/*  34*/, "starmultiplyTermToken"
	/*  35*/, "plusTermToken"
	/*  36*/, "commaTermToken"
	/*  37*/, "hyphenminusTermToken"
	/*  38*/, "dotpointperiodTermToken"
	/*  39*/, "semicolonTermToken"
	/*  40*/, "underlineTermToken"
	/*  41*/, "verticalbarTermToken"
	/*  42*/, "exclamationmarkTermToken"
	/*  43*/, "dollarTermToken"
	/*  44*/, "percentTermToken"
	/*  45*/, "commercialatTermToken"
	/*  46*/, "leftsquarebracketTermToken"
	/*  47*/, "leftbackslashTermToken"
	/*  48*/, "rightsquarebracketTermToken"
	/*  49*/, "circumflexTermToken"
	/*  50*/, "graveaccentTermToken"
	/*  51*/, "leftbraceTermToken"
	/*  52*/, "rightbraceTermToken"
	/*  53*/, "tildeTermToken"
	/*  54*/, "arrowTermToken"
	/*  55*/, "doublestarexponentiateTermToken"
	/*  56*/, "variableassignmentTermToken"
	/*  57*/, "inequalityTermToken"
	/*  58*/, "greaterthanorequalTermToken"
	/*  59*/, "lessthanorequalsignalassignmentTermToken"
	/*  60*/, "boxTermToken"
	/*  61*/, "defisTermToken"
};

struct tableItemTermToken tableTermToken[LENTABLETERMTOKEN]={
	{KW_QUOTATIONTERMTOKEN,"\""},
	{KW_SHARPTERMTOKEN,"#"},
	{KW_AMPERSANDTERMTOKEN,"&"},
	{KW_APOSTROPHETERMTOKEN,"'"},
	{KW_LEFTPARENTHESISTERMTOKEN,"("},
	{KW_RIGHTPARENTHESISTERMTOKEN,")"},
	{KW_STARMULTIPLYTERMTOKEN,"*"},
	{KW_PLUSTERMTOKEN,"+"},
	{KW_COMMATERMTOKEN,","},
	{KW_HYPHENMINUSTERMTOKEN,"-"},
	{KW_DOTPOINTPERIODTERMTOKEN,"."},
	{KW_SLASHDIVIDETERMTOKEN,"/"},
	{KW_COLONTERMTOKEN,":"},
	{KW_SEMICOLONTERMTOKEN,";"},
	{KW_LESSTHANTERMTOKEN,"<"},
	{KW_EQUALTERMTOKEN,"="},
	{KW_GREATERTHANTERMTOKEN,">"},
	{KW_UNDERLINETERMTOKEN,"_"},
	{KW_VERTICALBARTERMTOKEN,"|"},
	{KW_EXCLAMATIONMARKTERMTOKEN,"!"},
	{KW_DOLLARTERMTOKEN,"$"},
	{KW_PERCENTTERMTOKEN,"%"},
	{KW_QUASTIONMARKTERMTOKEN,"?"},
	{KW_COMMERCIALATTERMTOKEN,"@"},
	{KW_LEFTSQUAREBRACKETTERMTOKEN,"["},
	{KW_LEFTBACKSLASHTERMTOKEN,"\\"},
	{KW_RIGHTSQUAREBRACKETTERMTOKEN,"]"},
	{KW_CIRCUMFLEXTERMTOKEN,"^"},
	{KW_GRAVEACCENTTERMTOKEN,"`"},
	{KW_LEFTBRACETERMTOKEN,"{"},
	{KW_RIGHTBRACETERMTOKEN,"}"},
	{KW_TILDETERMTOKEN,"~"},
	{KW_ARROWTERMTOKEN,"=>"},
	{KW_DOUBLESTAREXPONENTIATETERMTOKEN,"**"},
	{KW_VARIABLEASSIGNMENTTERMTOKEN,":="},
	{KW_INEQUALITYTERMTOKEN,"/="},
	{KW_GREATERTHANOREQUALTERMTOKEN,">="},
	{KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN,"<="},
	{KW_BOXTERMTOKEN,"<>"},
	{KW_DEFISTERMTOKEN,"::="},
	{KW_XMLENDTERMTOKEN,"</"}
};
int KeyTabkeyword[LENTABLEKEYWORD]= {
	KW_XSD
};

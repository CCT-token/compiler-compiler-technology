/*	pdbts.h			version of 26.06.91 */

/*				version of 27.06.91 */
/*				version of 28.06.91 */

/*				version of 01.07.91 */
/*				version of 04.07.91 */
/*				version of 22.07.91 */

/*				version of 14.08.91 */

/*				version of 12.09.91 */
/*				version of 23.09.91 */


/* lexical level for vhdl       version of 19.11.91 */

/*				version of 26.11.91 */

/* metantmType,metagrmType 	version of 13.01.92 */


/* VLAN,MLAN			version of 23.09.92 */

/* SLLAN			version of 15.03.93 */

/*
  type definition for PDB internal representation
*/

/* dynamic array item type for PDB internal representation */
#if XMLLAN
typedef	long long	ptrType;
#else
typedef	long	ptrType;
#endif

/* pointer of PDB internal representation */
typedef	ptrType* inrType;

/* head of dynamic array with its context */
struct contextType {
  long		cntlen;		/* total length				*/
  long		cntcur;		/* current index:0 ... cntlen - 1	*/

  long 		cntbeg;		/* axiom:struct edftdType		*/

  long		cntnid;		/* total number of identifiers		*/
  ptrType	cntdid;		/* dynamic array of identifiers map:	*/
                                /*   sequantial number to ptrType	*/

  long		cntnkw;		/* total number of kwn's		*/
  ptrType	cntdkw;		/* dynamic array of kwn's map:	*/
                                /*   sequantial number to ptrType	*/

};

#define SOFCNT \
(sizeof(struct contextType)+sizeof(ptrType)-1)/sizeof(ptrType)

/* head of kwn representation */
struct kwnirType {
  long		l;		/* total number of kwn occurense 	*/
  enum KeyNum	k;		/* key number  of kwn		 	*/
  ptrType	d;		/* begin of kwn occurensies 		*/
};

#define KWNIRNULL (struct kwnirType *)0

#define SOFKWN \
(sizeof(struct kwnirType)+sizeof(ptrType)-1)/sizeof(ptrType)



/* head of edp representation */
struct edpirType {
  int		fl;		/* number of items of fixe part		*/
  int		dl;		/* number of items of dynamic		*/
  ptrType	d;		/* begin of edp occurensies 		*/
};

#define EDPIRNULL (struct edpirType *)0

#define SOFEDP \
(sizeof(struct edpirType)+sizeof(ptrType)-1)/sizeof(ptrType)


#if XMLLAN
struct edftdType {
  unsigned	long	t;	/* enum KeyNum */ 
  unsigned	long 	d;	/* edp number  */ 
};
#else
struct edftdType {
  unsigned	int	t:10;	/* enum KeyNum */ 
  unsigned	int	d:22;	/* edp number  */ 
};
#endif


#define SOFEDFTD \
(sizeof(struct edftdType)+sizeof(ptrType)-1)/sizeof(ptrType)

#define EDFTDNULL (struct edftdType *)0

/*
  macros for convert unsigned int tt,ddd -> struct edftdType / long
*/
/*
  long *ll;
  unsigned int tt;
  unsigned int dd;
*/
#define setedflong(ll,tt,dd) \
(((struct edftdType*)(ll))->t)=(tt);\
(((struct edftdType*)(ll))->d)=(dd)

/*
  long *ll;
  unsigned int tt;
  unsigned int dd;
*/
#define setlongedf(ll,tt,dd) \
(tt)=(((struct edftdType*)(ll))->t);\
(dd)=(((struct edftdType*)(ll))->d)



/* macros for identifier number map to its adress */
/* sequantial order 				  */
/* 
  inrType r;
  long	  i;
*/
#define ptrids(r,i) \
(char*)((r)+(*((r)+(((struct contextType*)(r))->cntdid)+(i))))


/* macros for identifier number map to its adress */
/* alphabetic order 				  */
/* 
  inrType r;
  long	  i;
*/
#define ptridn(r,i) \
(char*)((r)+(*((r)+(((struct contextType*)(r))->cntnid)+\
(((struct contextType*)(r))->cntdid)+(2*i))))


#define ptridnum(r,i) \
(long)(*((r)+(((struct contextType*)(r))->cntnid)+\
(((struct contextType*)(r))->cntdid)+(2*i+1)))


/* macros for kwn number map to its adress */
/* 
  inrType r;
  long	  i;
*/
#define ptrkwn(r,i) \
((struct kwnirType*)((r)+(((struct contextType*)(r))->cntdkw)+(i*SOFKWN)))

/*
((struct kwnirType*)((r)+(((struct contextType*)(r))->cntdkw))+(i))
*/



/* macros for edp number map to its adress */
/* 
  inrType r;
  struct kwnirType	*i;
  long	  j;
*/
#define ptredp(r,i,j) \
((struct edpirType*)((r)+((i)->d)+(j*SOFEDP)))

/*
((struct edpirType*)((r)+(ptrkwn(r,i)->d)+(j*SOFEDP)))
*/

/*
((struct edpirType*)((r)+(ptrkwn(r,i)->d))+(j))
*/

/* macros for convert ptrType to (char*) */
/* 
  inrType	 r;
  ptrType	 d;
*/
#define ptrchar(r,d) \
(char*)((r)+(d))

/* length of fixe or dynamic part */
/*
  int e;
*/
#define lenofedp(e) ((e)*SOFEDFTD)

/* alignment of characters */
/*
  int e;
*/
#define lenofedpchar(e)\
((e)+sizeof(ptrType)-1)/sizeof(ptrType)

/* length of internal representation */
#define lenofir(r) \
((((struct contextType *)(r))->cntlen)*sizeof(ptrType))




/* edp - rule grammer representation */
struct ruleType {
  struct edftdType	*f;	/* fixe    part of rule 	*/
  struct edftdType	*d;	/* dynamic part of rule 	*/
};


/* macro for creating a ruleType variable */
/* 
  inrType ppr;
  struct kwnirType	*ppk;
  struct edpirType	*ppd;
  struct ruleType	ppu;
*/
#define	setptrrule(ppr,ppk,ppd,ppu) \
((ppu).f)=EDFTDNULL;\
if(((ppd)->fl))\
{((ppu).f)=(struct edftdType*)((ppr)+((ppd)->d));}\
((ppu).d)=EDFTDNULL;\
if(((ppd)->dl))\
{((ppu).d)=(struct edftdType*)((ppr)+((ppd)->d)+((ppd)->fl));}

/*
#define	setptrrule(ppr,ppk,ppd,ppu) \
((ppu).f)=EDFTDNULL;\
if(lenofedp((ppd)->fl))\
{((ppu).f)=(struct edftdType*)((ppr)+((ppd)->d));}\
((ppu).d)=EDFTDNULL;\
if(lenofedp((ppd)->dl))\
{((ppu).d)=(struct edftdType*)((ppr)+((ppd)->d)+lenofedp((ppd)->fl));}
*/


/* macro for searching & creating a kwnType descriptor by its enum number */
/*
  inrType ppr;
  enum KeyNum ppkw;
  struct kwnirType	*ppk;
*/
#define setptrkwn(ppr,ppkw,ppk) \
{register int i,y;\
for(i=0;i<(((struct contextType*)(ppr))->cntnkw);i++){\
ppk=ptrkwn((ppr),i);\
if(y=(((ppk)->k)==ppkw))break;\
}\
if(!y){ppk=KWNIRNULL;}\
}



/* initialization of fixe part array */
#define pdbinitf(f) \
{register int n;\
for(n=0;n<(sizeof((f))/sizeof(long));n++) f[n]=(long)0;}





#define crenxtedp(kwr) \
i++;\
if(i == MAXDBUF) {\
if(!sh) {\
y= 1;\
if(s= celedpfst(0,(kwr),l,f,sizeof(f)/sizeof(long))) return(s);\
}\
else {\
if(s= celedpfnd(l)) return(s);\
}\
if(s= edfeptd(d,i,sh*MAXDBUF)) return(s);\
i= 0;\
sh++;\
}


#define crenxtdyn(kwr) \
i++;\
if(i == MAXDBUF) {\
if(!sh) {\
y= 1;\
if(s= celedpfst(0,(kwr),l,NULLLONG,0)) return(s);\
}\
else {\
if(s= celedpfnd(l)) return(s);\
}\
if(s= edfeptd(d,i,sh*MAXDBUF)) return(s);\
i= 0;\
sh++;\
}


#define crelasedp(kwr)\
if(!y) {\
if(s= celedpfst(0,(kwr),l,f,sizeof(f)/sizeof(long))) return(s);\
}\
else {\
if(s= celedpfnd(l)) return(s);\
}\
\
if(i > 0) {\
if(s= edfeptd(d,i,sh*MAXDBUF)) return(s);\
}



#define crelasdyn(kwr)\
if(!y) {\
if(s= celedpfst(0,(kwr),l,NULLLONG,0)) return(s);\
}\
else {\
if(s= celedpfnd(l)) return(s);\
}\
\
if(i > 0) {\
if(s= edfeptd(d,i,sh*MAXDBUF)) return(s);\
}


#define crefixe(kwr)\
if(s=celedpfst(1,(kwr),l,f,sizeof(f)/sizeof(long))) return(s)

/* skip . . . */
/* old !!!!! *****************************
#define skipleftTermToken(f)	\
  if(!isleftTermToken()) edberkwmis(KW_LEFTTERMTOKEN);\
  flleftTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_LEFTTERMTOKEN)


#define skiprighTermToken(f)	\
  if(!isrighTermToken()) edberkwmis(KW_RIGHTERMTOKEN);\
  flrighTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTERMTOKEN)



#define	skipdefisTermToken(f)	\
  if(!isdefisTermToken()) edberkwmis(KW_DEFISTERMTOKEN);\
  fldefisTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_DEFISTERMTOKEN)


#define	skipcolonTermToken(f)	\
  if(!iscolonTermToken()) edberkwmis(KW_COLONTERMTOKEN);\
  flcolonTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_COLONTERMTOKEN)


#define	skipequalTermToken(f)	\
  if(!isequalTermToken()) edberkwmis(KW_EQUALTERMTOKEN);\
  flequalTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_EQUALTERMTOKEN)



#define	skipvbarTermToken(f)	\
  if(!isvbarTermToken()) edberkwmis(KW_VBARTERMTOKEN);\
  flvbarTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_VBARTERMTOKEN)





#define skiprleftTermToken(f)	\
  if(!isrleftTermToken()) edberkwmis(KW_RLEFTTERMTOKEN);\
  flrleftTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_RLEFTTERMTOKEN)


#define skiprrighTermToken(f)	\
  if(!isrrighTermToken()) edberkwmis(KW_RRIGHTERMTOKEN);\
  flrrighTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_RRIGHTERMTOKEN)




#define skipaleftTermToken(f)	\
  if(!isaleftTermToken()) edberkwmis(KW_ALEFTTERMTOKEN);\
  flaleftTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_ALEFTTERMTOKEN)


#define skiparighTermToken(f)	\
  if(!isarighTermToken()) edberkwmis(KW_ARIGHTERMTOKEN);\
  flarighTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_ARIGHTERMTOKEN)




#define skipfleftTermToken(f)	\
  if(!isfleftTermToken()) edberkwmis(KW_FLEFTTERMTOKEN);\
  flfleftTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_FLEFTTERMTOKEN)


#define skipfrighTermToken(f)	\
  if(!isfrighTermToken()) edberkwmis(KW_FRIGHTERMTOKEN);\
  flfrighTermToken();\
  setedflong((f),KW_TERMTOKEN,KW_FRIGHTERMTOKEN)

************************************************************/





#define skipkw(f,k)	\
  if(Kword != (k)) edberkwmis((k));\
  setedflong((f),KW_TERMTOKEN,KW_LEFTTERMTOKEN);\
  setedflong(((f)+1),KW_TERMTOKEN,(k))



/* 14.08.91 */
/* set key words pointers */
/*
  inrType rrr;
  struct kwnirType *kkk[KW_ENDOFKEYWORDS];
*/
#define setkeywor(rrr,kkk)	\
{register int ii;\
for(ii=0;ii<KW_ENDOFKEYWORDS;ii++){\
setptrkwn((rrr),ii,((kkk)[ii]));}\
}





/* skip . . . */
/* 19.11.91   */

/*if(s= getNextToken()) return(s)*/
#define    getkw() \
{register int s;if(s= getNextToken()) return(s);}

#define    getllkw() getkw() 





#if VLAN || XMLLAN

#define    skipquotationTermToken(f)	\
/*  if(!isquotationTermToken()) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  flquotationTermToken(); */\
  if(Kword != KW_QUOTATIONTERMTOKEN) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUOTATIONTERMTOKEN);\
  getkw()

#define    skipsharpTermToken(f)	\
/*  if(!issharpTermToken()) edberkwmis(KW_SHARPTERMTOKEN);\
  flsharpTermToken(); */\
  if(Kword != KW_SHARPTERMTOKEN) edberkwmis(KW_SHARPTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SHARPTERMTOKEN);\
  getkw()

#define    skipampersandTermToken(f)	\
/*  if(!isampersandTermToken()) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  flampersandTermToken(); */\
  if(Kword != KW_AMPERSANDTERMTOKEN) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDTERMTOKEN);\
  getkw()

#define    skipapostropheTermToken(f)	\
/*  if(!isapostropheTermToken()) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  flapostropheTermToken(); */\
  if(Kword != KW_APOSTROPHETERMTOKEN) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_APOSTROPHETERMTOKEN);\
  getkw()

#define    skipleftparenthesisTermToken(f)	\
/*  if(!isleftparenthesisTermToken()) edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  flleftparenthesisTermToken(); */\
  if(Kword != KW_LEFTPARENTHESISTERMTOKEN) \
edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTPARENTHESISTERMTOKEN);\
  getkw()

#define    skiprightparenthesisTermToken(f)	\
/*if(!isrightparenthesisTermToken()) edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  flrightparenthesisTermToken(); */\
  if(Kword != KW_RIGHTPARENTHESISTERMTOKEN) \
edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTPARENTHESISTERMTOKEN);\
  getkw()

#define    skipstarmultiplyTermToken(f)	\
/*  if(!isstarmultiplyTermToken()) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  flstarmultiplyTermToken(); */\
  if(Kword != KW_STARMULTIPLYTERMTOKEN) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_STARMULTIPLYTERMTOKEN);\
  getkw()

#define    skipplusTermToken(f)	\
/*  if(!isplusTermToken()) edberkwmis(KW_PLUSTERMTOKEN);\
  flplusTermToken(); */\
  if(Kword != KW_PLUSTERMTOKEN) edberkwmis(KW_PLUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSTERMTOKEN);\
  getkw()

#define    skipcommaTermToken(f)	\
/*  if(!iscommaTermToken()) edberkwmis(KW_COMMATERMTOKEN);\
  flcommaTermToken(); */\
  if(Kword != KW_COMMATERMTOKEN) edberkwmis(KW_COMMATERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMATERMTOKEN);\
  getkw()

#define    skiphyphenminusTermToken(f)	\
/*  if(!ishyphenminusTermToken()) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  flhyphenminusTermToken(); */\
  if(Kword != KW_HYPHENMINUSTERMTOKEN) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSTERMTOKEN);\
  getkw()

#define    skipdotpointperiodTermToken(f)	\
/*  if(!isdotpointperiodTermToken()) edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  fldotpointperiodTermToken(); */\
  if(Kword != KW_DOTPOINTPERIODTERMTOKEN) \
edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOTPOINTPERIODTERMTOKEN);\
  getkw()

#define    skipslashdivideTermToken(f)	\
/*  if(!isslashdivideTermToken()) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  flslashdivideTermToken(); */\
  if(Kword != KW_SLASHDIVIDETERMTOKEN) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SLASHDIVIDETERMTOKEN);\
  getkw()

#define    skipcolonTermToken(f)	\
/*  if(!iscolonTermToken()) edberkwmis(KW_COLONTERMTOKEN);\
  flcolonTermToken(); */\
  if(Kword != KW_COLONTERMTOKEN) edberkwmis(KW_COLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COLONTERMTOKEN);\
  getkw()

#define    skipsemicolonTermToken(f)	\
/*  if(!issemicolonTermToken()) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  flsemicolonTermToken(); */\
  if(Kword != KW_SEMICOLONTERMTOKEN) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SEMICOLONTERMTOKEN);\
  getkw()

#define    skiplessthanTermToken(f)	\
/*  if(!islessthanTermToken()) edberkwmis(KW_LESSTHANTERMTOKEN);\
  fllessthanTermToken(); */\
  if(Kword != KW_LESSTHANTERMTOKEN) edberkwmis(KW_LESSTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANTERMTOKEN);\
  getkw()
 
#define    skipequalTermToken(f)	\
/*  if(!isequalTermToken()) edberkwmis(KW_EQUALTERMTOKEN);\
  flequalTermToken(); */\
  if(Kword != KW_EQUALTERMTOKEN) edberkwmis(KW_EQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EQUALTERMTOKEN);\
  getkw()

#if VLAN
#define    skipgreaterthanTermToken(f)	\
/*  if(!isgreaterthanTermToken()) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  flgreaterthanTermToken(); */\
  if(Kword != KW_GREATERTHANTERMTOKEN) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);\
  getkw()
#else
#define    skipgreaterthanTermToken(f)	\
/*  if(!isgreaterthanTermToken()) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  flgreaterthanTermToken(); */\
  if(Kword != KW_GREATERTHANTERMTOKEN) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  processGreaterThanAndXmlTermToken(f);\
  getkw()
#endif

#define    skipunderlineTermToken(f)	\
/*  if(!isunderlineTermToken()) edberkwmis(KW_UNDERLINETERMTOKEN);\
  flunderlineTermToken(); */\
  if(Kword != KW_UNDERLINETERMTOKEN) edberkwmis(KW_UNDERLINETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_UNDERLINETERMTOKEN);\
  getkw()

#define    skipverticalbarTermToken(f)	\
/*  if(!isverticalbarTermToken()) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  flverticalbarTermToken(); */\
  if(Kword != KW_VERTICALBARTERMTOKEN) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBARTERMTOKEN);\
  getkw()

#define    skipexclamationmarkTermToken(f)	\
/*  if(!isexclamationmarkTermToken()) edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  flexclamationmarkTermToken(); */\
  if(Kword != KW_EXCLAMATIONMARKTERMTOKEN) \
edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EXCLAMATIONMARKTERMTOKEN);\
  getkw()

#define    skipdollarTermToken(f)	\
/*  if(!isdollarTermToken()) edberkwmis(KW_DOLLARTERMTOKEN);\
  fldollarTermToken(); */\
  if(Kword != KW_DOLLARTERMTOKEN) edberkwmis(KW_DOLLARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOLLARTERMTOKEN);\
  getkw()

#define    skippercentTermToken(f)	\
/*  if(!ispercentTermToken()) edberkwmis(KW_PERCENTTERMTOKEN);\
  flpercentTermToken(); */\
  if(Kword != KW_PERCENTTERMTOKEN) edberkwmis(KW_PERCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PERCENTTERMTOKEN);\
  getkw()

#define    skipquastionmarkTermToken(f)	\
/*  if(!isquastionmarkTermToken()) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  flquastionmarkTermToken(); */\
  if(Kword != KW_QUASTIONMARKTERMTOKEN) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUASTIONMARKTERMTOKEN);\
  getkw()

#define    skipcommercialatTermToken(f)	\
/*  if(!iscommercialatTermToken()) edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  flcommercialatTermToken(); */\
  if(Kword != KW_COMMERCIALATTERMTOKEN) \
edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMERCIALATTERMTOKEN);\
  getkw()

#define    skipleftsquarebracketTermToken(f)	\
/*  if(!isleftsquarebracketTermToken()) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  flleftsquarebracketTermToken(); */\
  if(Kword != KW_LEFTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTSQUAREBRACKETTERMTOKEN);\
  getkw()

#define    skipleftbackslashTermToken(f)	\
/*  if(!isleftbackslashTermToken()) edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  flleftbackslashTermToken(); */\
  if(Kword != KW_LEFTBACKSLASHTERMTOKEN) \
edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBACKSLASHTERMTOKEN);\
  getkw()

#define    skiprightsquarebracketTermToken(f)	\
/*  if(!isrightsquarebracketTermToken()) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN); \
  flrightsquarebracketTermToken(); */\
  if(Kword != KW_RIGHTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  getkw()

#define    skipcircumflexTermToken(f)	\
/*  if(!iscircumflexTermToken()) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  flcircumflexTermToken(); */\
  if(Kword != KW_CIRCUMFLEXTERMTOKEN) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_CIRCUMFLEXTERMTOKEN);\
  getkw()

#define    skipgraveaccentTermToken(f)	\
/*  if(!isgraveaccentTermToken()) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  flgraveaccentTermToken(); */\
  if(Kword != KW_GRAVEACCENTTERMTOKEN) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GRAVEACCENTTERMTOKEN);\
  getkw()

#define    skipleftbraceTermToken(f)	\
/*  if(!isleftbraceTermToken()) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  flleftbraceTermToken(); */\
  if(Kword != KW_LEFTBRACETERMTOKEN) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBRACETERMTOKEN);\
  getkw()

#define    skiprightbraceTermToken(f)	\
/*  if(!isrightbraceTermToken()) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  flrightbraceTermToken(); */\
  if(Kword != KW_RIGHTBRACETERMTOKEN) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTBRACETERMTOKEN);\
  getkw()

#define    skiptildeTermToken(f)	\
/*  if(!istildeTermToken()) edberkwmis(KW_TILDETERMTOKEN);\
  fltildeTermToken(); */\
  if(Kword != KW_TILDETERMTOKEN) edberkwmis(KW_TILDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_TILDETERMTOKEN);\
  getkw()



#define    skiparrowTermToken(f)	\
/*  if(!isarrowTermToken()) edberkwmis(KW_ARROWTERMTOKEN);\
  flarrowTermToken(); */\
  if(Kword != KW_ARROWTERMTOKEN) edberkwmis(KW_ARROWTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_ARROWTERMTOKEN);\
  getkw()

#define    skipdoublestarexponentiateTermToken(f)	\
/*  if(!isdoublestarexponentiateTermToken()) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  fldoublestarexponentiateTermToken(); */\
  if(Kword != KW_DOUBLESTAREXPONENTIATETERMTOKEN) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  getkw()

#define    skipvariableassignmentTermToken(f)	\
/*  if(!isvariableassignmentTermToken()) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  flvariableassignmentTermToken(); */\
  if(Kword != KW_VARIABLEASSIGNMENTTERMTOKEN) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VARIABLEASSIGNMENTTERMTOKEN);\
  getkw()

#define    skipinequalityTermToken(f)	\
/*  if(!isinequalityTermToken()) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  flinequalityTermToken(); */\
  if(Kword != KW_INEQUALITYTERMTOKEN) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_INEQUALITYTERMTOKEN);\
  getkw()

#define    skipgreaterthanorequalTermToken(f)	\
/*  if(!isgreaterthanorequalTermToken()) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  flgreaterthanorequalTermToken(); */\
  if(Kword != KW_GREATERTHANOREQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANOREQUALTERMTOKEN);\
  getkw()

#define    skiplessthanorequalsignalassignmentTermToken(f)	\
/*  if(!islessthanorequalsignalassignmentTermToken()) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  fllessthanorequalsignalassignmentTermToken(); */\
  if(Kword != KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  getkw()

#define    skipboxTermToken(f)	\
/* if(!isboxTermToken()) edberkwmis(KW_BOXTERMTOKEN);\
  flboxTermToken(); */\
  if(Kword != KW_BOXTERMTOKEN) edberkwmis(KW_BOXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_BOXTERMTOKEN);\
  getkw()



#define    skipdefisTermToken(f)	\
/*  if(!isdefisTermToken()) edberkwmis(KW_DEFISTERMTOKEN);\
  fldefisTermToken(); */\
  if(Kword != KW_DEFISTERMTOKEN) edberkwmis(KW_DEFISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DEFISTERMTOKEN);\
  getkw()

#define    skipxmlEndTermToken(f)     \
  if(Kword != KW_XMLENDTERMTOKEN) edberkwmis(KW_XMLENDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_XMLENDTERMTOKEN);\
  getkw()

#endif





#if MLAN

#define    skipquotationTermToken(f)	\
/*  if(!isquotationTermToken()) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  flquotationTermToken(); */\
  if(Kword != KW_QUOTATIONTERMTOKEN) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUOTATIONTERMTOKEN);\
  getkw()

#define    skipsharpTermToken(f)	\
/*  if(!issharpTermToken()) edberkwmis(KW_SHARPTERMTOKEN);\
  flsharpTermToken(); */\
  if(Kword != KW_SHARPTERMTOKEN) edberkwmis(KW_SHARPTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SHARPTERMTOKEN);\
  getkw()



#define    skipampersandTermToken(f)	\
/*  if(!isampersandTermToken()) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  flampersandTermToken(); */\
  if(Kword != KW_AMPERSANDTERMTOKEN) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDTERMTOKEN);\
  getkw()

#define    skipampersandequalTermToken(f)	\
  if(Kword != KW_AMPERSANDEQUALTERMTOKEN) \
edberkwmis(KW_AMPERSANDEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDEQUALTERMTOKEN);\
  getkw()

#define    skipampersandampersandTermToken(f)	\
  if(Kword != KW_AMPERSANDAMPERSANDTERMTOKEN) \
edberkwmis(KW_AMPERSANDAMPERSANDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDAMPERSANDTERMTOKEN);\
  getkw()



#define    skipapostropheTermToken(f)	\
/*  if(!isapostropheTermToken()) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  flapostropheTermToken(); */\
  if(Kword != KW_APOSTROPHETERMTOKEN) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_APOSTROPHETERMTOKEN);\
  getkw()

#define    skipleftparenthesisTermToken(f)	\
/*  if(!isleftparenthesisTermToken()) edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  flleftparenthesisTermToken(); */\
  if(Kword != KW_LEFTPARENTHESISTERMTOKEN) \
edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTPARENTHESISTERMTOKEN);\
  getkw()

#define    skiprightparenthesisTermToken(f)	\
/*if(!isrightparenthesisTermToken()) edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  flrightparenthesisTermToken(); */\
  if(Kword != KW_RIGHTPARENTHESISTERMTOKEN) \
edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTPARENTHESISTERMTOKEN);\
  getkw()





#define    skipstarmultiplyTermToken(f)	\
/*  if(!isstarmultiplyTermToken()) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  flstarmultiplyTermToken(); */\
  if(Kword != KW_STARMULTIPLYTERMTOKEN) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_STARMULTIPLYTERMTOKEN);\
  getkw()

#define    skipstarmultiplyequalTermToken(f)	\
  if(Kword != KW_STARMULTIPLYEQUALTERMTOKEN) \
edberkwmis(KW_STARMULTIPLYEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_STARMULTIPLYEQUALTERMTOKEN);\
  getkw()



#define    skipplusTermToken(f)	\
/*  if(!isplusTermToken()) edberkwmis(KW_PLUSTERMTOKEN);\
  flplusTermToken(); */\
  if(Kword != KW_PLUSTERMTOKEN) edberkwmis(KW_PLUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSTERMTOKEN);\
  getkw()

#define    skipplusplusTermToken(f)	\
  if(Kword != KW_PLUSPLUSTERMTOKEN) edberkwmis(KW_PLUSPLUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSPLUSTERMTOKEN);\
  getkw()

#define    skipplusequalTermToken(f)	\
  if(Kword != KW_PLUSEQUALTERMTOKEN) edberkwmis(KW_PLUSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSEQUALTERMTOKEN);\
  getkw()



#define    skipcommaTermToken(f)	\
/*  if(!iscommaTermToken()) edberkwmis(KW_COMMATERMTOKEN);\
  flcommaTermToken(); */\
  if(Kword != KW_COMMATERMTOKEN) edberkwmis(KW_COMMATERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMATERMTOKEN);\
  getkw()



#define    skiphyphenminusTermToken(f)	\
/*  if(!ishyphenminusTermToken()) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  flhyphenminusTermToken(); */\
  if(Kword != KW_HYPHENMINUSTERMTOKEN) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSTERMTOKEN);\
  getkw()

#define    skiphyphenminusequalTermToken(f)	\
  if(Kword != KW_HYPHENMINUSEQUALTERMTOKEN) \
edberkwmis(KW_HYPHENMINUSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSEQUALTERMTOKEN);\
  getkw()

#define    skiphyphenminusminusTermToken(f)	\
  if(Kword != KW_HYPHENMINUSMINUSTERMTOKEN) \
edberkwmis(KW_HYPHENMINUSMINUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSMINUSTERMTOKEN);\
  getkw()

#define    skiphyphenminusmoreTermToken(f)	\
  if(Kword != KW_HYPHENMINUSMORETERMTOKEN) \
edberkwmis(KW_HYPHENMINUSMORETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSMORETERMTOKEN);\
  getkw()



#define    skipdotpointperiodTermToken(f)	\
/*  if(!isdotpointperiodTermToken()) edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  fldotpointperiodTermToken(); */\
  if(Kword != KW_DOTPOINTPERIODTERMTOKEN) \
edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOTPOINTPERIODTERMTOKEN);\
  getkw()



#define    skipslashdivideTermToken(f)	\
/*  if(!isslashdivideTermToken()) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  flslashdivideTermToken(); */\
  if(Kword != KW_SLASHDIVIDETERMTOKEN) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SLASHDIVIDETERMTOKEN);\
  getkw()

#define    skipslashdivideequalTermToken(f)	\
  if(Kword != KW_SLASHDIVIDEEQUALTERMTOKEN) \
edberkwmis(KW_SLASHDIVIDEEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SLASHDIVIDEEQUALTERMTOKEN);\
  getkw()



#define    skipcolonTermToken(f)	\
/*  if(!iscolonTermToken()) edberkwmis(KW_COLONTERMTOKEN);\
  flcolonTermToken(); */\
  if(Kword != KW_COLONTERMTOKEN) edberkwmis(KW_COLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COLONTERMTOKEN);\
  getkw()

#define    skipsemicolonTermToken(f)	\
/*  if(!issemicolonTermToken()) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  flsemicolonTermToken(); */\
  if(Kword != KW_SEMICOLONTERMTOKEN) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SEMICOLONTERMTOKEN);\
  getkw()



#define    skiplessthanTermToken(f)	\
/*  if(!islessthanTermToken()) edberkwmis(KW_LESSTHANTERMTOKEN);\
  fllessthanTermToken(); */\
  if(Kword != KW_LESSTHANTERMTOKEN) edberkwmis(KW_LESSTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANTERMTOKEN);\
  getkw()

#define    skiplessthanequalTermToken(f)	\
  if(Kword != KW_LESSTHANEQUALTERMTOKEN) \
edberkwmis(KW_LESSTHANEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANEQUALTERMTOKEN);\
  getkw()

#define    skiplessthanlessTermToken(f)	\
  if(Kword != KW_LESSTHANLESSTERMTOKEN) \
edberkwmis(KW_LESSTHANLESSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANLESSTERMTOKEN);\
  getkw()

#define    skiplessthanlessequalTermToken(f)	\
  if(Kword != KW_LESSTHANLESSEQUALTERMTOKEN) \
edberkwmis(KW_LESSTHANLESSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANLESSEQUALTERMTOKEN);\
  getkw()



#define    skipequalTermToken(f)	\
/*  if(!isequalTermToken()) edberkwmis(KW_EQUALTERMTOKEN);\
  flequalTermToken(); */\
  if(Kword != KW_EQUALTERMTOKEN) edberkwmis(KW_EQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EQUALTERMTOKEN);\
  getkw()


#define    skipequalequalTermToken(f)	\
  if(Kword != KW_EQUALEQUALTERMTOKEN) \
edberkwmis(KW_EQUALEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EQUALEQUALTERMTOKEN);\
  getkw()




#define    skipgreaterthanTermToken(f)	\
/*  if(!isgreaterthanTermToken()) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  flgreaterthanTermToken(); */\
  if(Kword != KW_GREATERTHANTERMTOKEN) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);\
  getkw()

#define    skipgreaterthanequalTermToken(f)	\
  if(Kword != KW_GREATERTHANEQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANEQUALTERMTOKEN);\
  getkw()

#define    skipgreaterthangreaterTermToken(f)	\
  if(Kword != KW_GREATERTHANGREATERTERMTOKEN) \
edberkwmis(KW_GREATERTHANGREATERTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANGREATERTERMTOKEN);\
  getkw()

#define    skipgreaterthangreaterequalTermToken(f)	\
  if(Kword != KW_GREATERTHANGREATEREQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANGREATEREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANGREATEREQUALTERMTOKEN);\
  getkw()



#define    skipunderlineTermToken(f)	\
/*  if(!isunderlineTermToken()) edberkwmis(KW_UNDERLINETERMTOKEN);\
  flunderlineTermToken(); */\
  if(Kword != KW_UNDERLINETERMTOKEN) edberkwmis(KW_UNDERLINETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_UNDERLINETERMTOKEN);\
  getkw()



#define    skipverticalbarTermToken(f)	\
/*  if(!isverticalbarTermToken()) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  flverticalbarTermToken(); */\
  if(Kword != KW_VERTICALBARTERMTOKEN) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBARTERMTOKEN);\
  getkw()

#define    skipverticalbarbarTermToken(f)	\
  if(Kword != KW_VERTICALBARBARTERMTOKEN) \
edberkwmis(KW_VERTICALBARBARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBARBARTERMTOKEN);\
  getkw()

#define    skipverticalbarequalTermToken(f)	\
  if(Kword != KW_VERTICALBAREQUALTERMTOKEN) \
edberkwmis(KW_VERTICALBAREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBAREQUALTERMTOKEN);\
  getkw()



#define    skipexclamationmarkTermToken(f)	\
/*  if(!isexclamationmarkTermToken()) edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  flexclamationmarkTermToken(); */\
  if(Kword != KW_EXCLAMATIONMARKTERMTOKEN) \
edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EXCLAMATIONMARKTERMTOKEN);\
  getkw()


#define    skipexclamationmarkequalTermToken(f)	\
  if(Kword != KW_EXCLAMATIONMARKEQUALTERMTOKEN) \
edberkwmis(KW_EXCLAMATIONMARKEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EXCLAMATIONMARKEQUALTERMTOKEN);\
  getkw()

#define    skipdollarTermToken(f)	\
/*  if(!isdollarTermToken()) edberkwmis(KW_DOLLARTERMTOKEN);\
  fldollarTermToken(); */\
  if(Kword != KW_DOLLARTERMTOKEN) edberkwmis(KW_DOLLARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOLLARTERMTOKEN);\
  getkw()


#define    skippercentTermToken(f)	\
/*  if(!ispercentTermToken()) edberkwmis(KW_PERCENTTERMTOKEN);\
  flpercentTermToken(); */\
  if(Kword != KW_PERCENTTERMTOKEN) edberkwmis(KW_PERCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PERCENTTERMTOKEN);\
  getkw()

#define    skippercentequalTermToken(f)	\
  if(Kword != KW_PERCENTEQUALTERMTOKEN) \
edberkwmis(KW_PERCENTEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PERCENTEQUALTERMTOKEN);\
  getkw()



#define    skipquastionmarkTermToken(f)	\
/*  if(!isquastionmarkTermToken()) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  flquastionmarkTermToken(); */\
  if(Kword != KW_QUASTIONMARKTERMTOKEN) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUASTIONMARKTERMTOKEN);\
  getkw()

#define    skipquastionmarkcolonTermToken(f)	\
  if(Kword != KW_QUASTIONMARKCOLONTERMTOKEN) \
edberkwmis(KW_QUASTIONMARKCOLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUASTIONMARKCOLONTERMTOKEN);\
  getkw()



#define    skipcommercialatTermToken(f)	\
/*  if(!iscommercialatTermToken()) edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  flcommercialatTermToken(); */\
  if(Kword != KW_COMMERCIALATTERMTOKEN) \
edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMERCIALATTERMTOKEN);\
  getkw()

#define    skipleftsquarebracketTermToken(f)	\
/*  if(!isleftsquarebracketTermToken()) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  flleftsquarebracketTermToken(); */\
  if(Kword != KW_LEFTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTSQUAREBRACKETTERMTOKEN);\
  getkw()

#define    skipleftbackslashTermToken(f)	\
/*  if(!isleftbackslashTermToken()) edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  flleftbackslashTermToken(); */\
  if(Kword != KW_LEFTBACKSLASHTERMTOKEN) \
edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBACKSLASHTERMTOKEN);\
  getkw()

#define    skiprightsquarebracketTermToken(f)	\
/*  if(!isrightsquarebracketTermToken()) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN); \
  flrightsquarebracketTermToken(); */\
  if(Kword != KW_RIGHTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  getkw()


#define    skipcircumflexTermToken(f)	\
/*  if(!iscircumflexTermToken()) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  flcircumflexTermToken(); */\
  if(Kword != KW_CIRCUMFLEXTERMTOKEN) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_CIRCUMFLEXTERMTOKEN);\
  getkw()

#define    skipcircumflexequalTermToken(f)	\
  if(Kword != KW_CIRCUMFLEXEQUALTERMTOKEN) \
edberkwmis(KW_CIRCUMFLEXEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_CIRCUMFLEXEQUALTERMTOKEN);\
  getkw()



/*#define    skipgraveaccentTermToken(f)	\*/
/*  if(!isgraveaccentTermToken()) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  flgraveaccentTermToken(); */ 
/*
  if(Kword != KW_GRAVEACCENTTERMTOKEN) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GRAVEACCENTTERMTOKEN);\
  getkw()
*/

#define    skipleftbraceTermToken(f)	\
/*  if(!isleftbraceTermToken()) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  flleftbraceTermToken(); */\
  if(Kword != KW_LEFTBRACETERMTOKEN) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBRACETERMTOKEN);\
  getkw()

#define    skiprightbraceTermToken(f)	\
/*  if(!isrightbraceTermToken()) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  flrightbraceTermToken(); */\
  if(Kword != KW_RIGHTBRACETERMTOKEN) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTBRACETERMTOKEN);\
  getkw()



#define    skiptildeTermToken(f)	\
/*  if(!istildeTermToken()) edberkwmis(KW_TILDETERMTOKEN);\
  fltildeTermToken(); */\
  if(Kword != KW_TILDETERMTOKEN) edberkwmis(KW_TILDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_TILDETERMTOKEN);\
  getkw()

#define    skiptildeequalTermToken(f)	\
  if(Kword != KW_TILDEEQUALTERMTOKEN) \
edberkwmis(KW_TILDEEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_TILDEEQUALTERMTOKEN);\
  getkw()



/*#define    skiparrowTermToken(f)	*/
/*  if(!isarrowTermToken()) edberkwmis(KW_ARROWTERMTOKEN);\
  flarrowTermToken(); */
/*
  if(Kword != KW_ARROWTERMTOKEN) edberkwmis(KW_ARROWTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_ARROWTERMTOKEN);\
  getkw()
*/

/* #define    skipdoublestarexponentiateTermToken(f)	*/
/*  if(!isdoublestarexponentiateTermToken()) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  fldoublestarexponentiateTermToken(); */
/*
  if(Kword != KW_DOUBLESTAREXPONENTIATETERMTOKEN) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  getkw()
*/

/*
#define    skipvariableassignmentTermToken(f)	
*/
/*  if(!isvariableassignmentTermToken()) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  flvariableassignmentTermToken(); 
*/
/*
  if(Kword != KW_VARIABLEASSIGNMENTTERMTOKEN) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VARIABLEASSIGNMENTTERMTOKEN);\
  getkw()
*/

/*
#define    skipinequalityTermToken(f)	\
*/
/*  if(!isinequalityTermToken()) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  flinequalityTermToken(); 
*/
/*
  if(Kword != KW_INEQUALITYTERMTOKEN) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_INEQUALITYTERMTOKEN);\
  getkw()
*/

/*
#define    skipgreaterthanorequalTermToken(f)	\
*/
/*  if(!isgreaterthanorequalTermToken()) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  flgreaterthanorequalTermToken(); 
*/
/*
  if(Kword != KW_GREATERTHANOREQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANOREQUALTERMTOKEN);\
  getkw()
*/

/*
#define    skiplessthanorequalsignalassignmentTermToken(f)	
*/
/*  if(!islessthanorequalsignalassignmentTermToken()) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  fllessthanorequalsignalassignmentTermToken(); */
/*
  if(Kword != KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  getkw()
*/

/*
#define    skipboxTermToken(f)	
*/
/* if(!isboxTermToken()) edberkwmis(KW_BOXTERMTOKEN);\
  flboxTermToken(); */
/*
  if(Kword != KW_BOXTERMTOKEN) edberkwmis(KW_BOXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_BOXTERMTOKEN);\
  getkw()
*/


#define    skipdefisTermToken(f)	\
/*  if(!isdefisTermToken()) edberkwmis(KW_DEFISTERMTOKEN);\
  fldefisTermToken(); */\
  if(Kword != KW_DEFISTERMTOKEN) edberkwmis(KW_DEFISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DEFISTERMTOKEN);\
  getkw()


#endif







/* 15.03.93 */


#if SLLAN

#define    skipquotationTermToken(f)	\
/*  if(!isquotationTermToken()) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  flquotationTermToken(); */\
  if(Kword != KW_QUOTATIONTERMTOKEN) edberkwmis(KW_QUOTATIONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUOTATIONTERMTOKEN);\
  getkw()

#define    skipsharpTermToken(f)	\
/*  if(!issharpTermToken()) edberkwmis(KW_SHARPTERMTOKEN);\
  flsharpTermToken(); */\
  if(Kword != KW_SHARPTERMTOKEN) edberkwmis(KW_SHARPTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SHARPTERMTOKEN);\
  getkw()



#define    skipampersandTermToken(f)	\
/*  if(!isampersandTermToken()) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  flampersandTermToken(); */\
  if(Kword != KW_AMPERSANDTERMTOKEN) edberkwmis(KW_AMPERSANDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDTERMTOKEN);\
  getkw()

#define    skipampersandequalTermToken(f)	\
  if(Kword != KW_AMPERSANDEQUALTERMTOKEN) \
edberkwmis(KW_AMPERSANDEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDEQUALTERMTOKEN);\
  getkw()

#define    skipampersandampersandTermToken(f)	\
  if(Kword != KW_AMPERSANDAMPERSANDTERMTOKEN) \
edberkwmis(KW_AMPERSANDAMPERSANDTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_AMPERSANDAMPERSANDTERMTOKEN);\
  getkw()



#define    skipapostropheTermToken(f)	\
/*  if(!isapostropheTermToken()) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  flapostropheTermToken(); */\
  if(Kword != KW_APOSTROPHETERMTOKEN) edberkwmis(KW_APOSTROPHETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_APOSTROPHETERMTOKEN);\
  getkw()

#define    skipleftparenthesisTermToken(f)	\
/*  if(!isleftparenthesisTermToken()) edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  flleftparenthesisTermToken(); */\
  if(Kword != KW_LEFTPARENTHESISTERMTOKEN) \
edberkwmis(KW_LEFTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTPARENTHESISTERMTOKEN);\
  getkw()

#define    skiprightparenthesisTermToken(f)	\
/*if(!isrightparenthesisTermToken()) edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  flrightparenthesisTermToken(); */\
  if(Kword != KW_RIGHTPARENTHESISTERMTOKEN) \
edberkwmis(KW_RIGHTPARENTHESISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTPARENTHESISTERMTOKEN);\
  getkw()





#define    skipstarmultiplyTermToken(f)	\
/*  if(!isstarmultiplyTermToken()) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  flstarmultiplyTermToken(); */\
  if(Kword != KW_STARMULTIPLYTERMTOKEN) edberkwmis(KW_STARMULTIPLYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_STARMULTIPLYTERMTOKEN);\
  getkw()

#define    skipstarmultiplyequalTermToken(f)	\
  if(Kword != KW_STARMULTIPLYEQUALTERMTOKEN) \
edberkwmis(KW_STARMULTIPLYEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_STARMULTIPLYEQUALTERMTOKEN);\
  getkw()



#define    skipplusTermToken(f)	\
/*  if(!isplusTermToken()) edberkwmis(KW_PLUSTERMTOKEN);\
  flplusTermToken(); */\
  if(Kword != KW_PLUSTERMTOKEN) edberkwmis(KW_PLUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSTERMTOKEN);\
  getkw()

#define    skipplusplusTermToken(f)	\
  if(Kword != KW_PLUSPLUSTERMTOKEN) edberkwmis(KW_PLUSPLUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSPLUSTERMTOKEN);\
  getkw()

#define    skipplusequalTermToken(f)	\
  if(Kword != KW_PLUSEQUALTERMTOKEN) edberkwmis(KW_PLUSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PLUSEQUALTERMTOKEN);\
  getkw()



#define    skipcommaTermToken(f)	\
/*  if(!iscommaTermToken()) edberkwmis(KW_COMMATERMTOKEN);\
  flcommaTermToken(); */\
  if(Kword != KW_COMMATERMTOKEN) edberkwmis(KW_COMMATERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMATERMTOKEN);\
  getkw()



#define    skiphyphenminusTermToken(f)	\
/*  if(!ishyphenminusTermToken()) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  flhyphenminusTermToken(); */\
  if(Kword != KW_HYPHENMINUSTERMTOKEN) edberkwmis(KW_HYPHENMINUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSTERMTOKEN);\
  getkw()

#define    skiphyphenminusequalTermToken(f)	\
  if(Kword != KW_HYPHENMINUSEQUALTERMTOKEN) \
edberkwmis(KW_HYPHENMINUSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSEQUALTERMTOKEN);\
  getkw()

#define    skiphyphenminusminusTermToken(f)	\
  if(Kword != KW_HYPHENMINUSMINUSTERMTOKEN) \
edberkwmis(KW_HYPHENMINUSMINUSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSMINUSTERMTOKEN);\
  getkw()

#define    skiphyphenminusmoreTermToken(f)	\
  if(Kword != KW_HYPHENMINUSMORETERMTOKEN) \
edberkwmis(KW_HYPHENMINUSMORETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_HYPHENMINUSMORETERMTOKEN);\
  getkw()



#define    skipdotpointperiodTermToken(f)	\
/*  if(!isdotpointperiodTermToken()) edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  fldotpointperiodTermToken(); */\
  if(Kword != KW_DOTPOINTPERIODTERMTOKEN) \
edberkwmis(KW_DOTPOINTPERIODTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOTPOINTPERIODTERMTOKEN);\
  getkw()



#define    skipslashdivideTermToken(f)	\
/*  if(!isslashdivideTermToken()) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  flslashdivideTermToken(); */\
  if(Kword != KW_SLASHDIVIDETERMTOKEN) edberkwmis(KW_SLASHDIVIDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SLASHDIVIDETERMTOKEN);\
  getkw()

#define    skipslashdivideequalTermToken(f)	\
  if(Kword != KW_SLASHDIVIDEEQUALTERMTOKEN) \
edberkwmis(KW_SLASHDIVIDEEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SLASHDIVIDEEQUALTERMTOKEN);\
  getkw()



#define    skipcolonTermToken(f)	\
/*  if(!iscolonTermToken()) edberkwmis(KW_COLONTERMTOKEN);\
  flcolonTermToken(); */\
  if(Kword != KW_COLONTERMTOKEN) edberkwmis(KW_COLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COLONTERMTOKEN);\
  getkw()

#define    skipsemicolonTermToken(f)	\
/*  if(!issemicolonTermToken()) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  flsemicolonTermToken(); */\
  if(Kword != KW_SEMICOLONTERMTOKEN) edberkwmis(KW_SEMICOLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_SEMICOLONTERMTOKEN);\
  getkw()



#define    skiplessthanTermToken(f)	\
/*  if(!islessthanTermToken()) edberkwmis(KW_LESSTHANTERMTOKEN);\
  fllessthanTermToken(); */\
  if(Kword != KW_LESSTHANTERMTOKEN) edberkwmis(KW_LESSTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANTERMTOKEN);\
  getkw()

#define    skiplessthanequalTermToken(f)	\
  if(Kword != KW_LESSTHANEQUALTERMTOKEN) \
edberkwmis(KW_LESSTHANEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANEQUALTERMTOKEN);\
  getkw()

#define    skiplessthanlessTermToken(f)	\
  if(Kword != KW_LESSTHANLESSTERMTOKEN) \
edberkwmis(KW_LESSTHANLESSTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANLESSTERMTOKEN);\
  getkw()

#define    skiplessthanlessequalTermToken(f)	\
  if(Kword != KW_LESSTHANLESSEQUALTERMTOKEN) \
edberkwmis(KW_LESSTHANLESSEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANLESSEQUALTERMTOKEN);\
  getkw()



#define    skipequalTermToken(f)	\
/*  if(!isequalTermToken()) edberkwmis(KW_EQUALTERMTOKEN);\
  flequalTermToken(); */\
  if(Kword != KW_EQUALTERMTOKEN) edberkwmis(KW_EQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EQUALTERMTOKEN);\
  getkw()


#define    skipequalequalTermToken(f)	\
  if(Kword != KW_EQUALEQUALTERMTOKEN) \
edberkwmis(KW_EQUALEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EQUALEQUALTERMTOKEN);\
  getkw()




#define    skipgreaterthanTermToken(f)	\
/*  if(!isgreaterthanTermToken()) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  flgreaterthanTermToken(); */\
  if(Kword != KW_GREATERTHANTERMTOKEN) edberkwmis(KW_GREATERTHANTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);\
  getkw()

#define    skipgreaterthanequalTermToken(f)	\
  if(Kword != KW_GREATERTHANEQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANEQUALTERMTOKEN);\
  getkw()

#define    skipgreaterthangreaterTermToken(f)	\
  if(Kword != KW_GREATERTHANGREATERTERMTOKEN) \
edberkwmis(KW_GREATERTHANGREATERTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANGREATERTERMTOKEN);\
  getkw()

#define    skipgreaterthangreaterequalTermToken(f)	\
  if(Kword != KW_GREATERTHANGREATEREQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANGREATEREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANGREATEREQUALTERMTOKEN);\
  getkw()



#define    skipunderlineTermToken(f)	\
/*  if(!isunderlineTermToken()) edberkwmis(KW_UNDERLINETERMTOKEN);\
  flunderlineTermToken(); */\
  if(Kword != KW_UNDERLINETERMTOKEN) edberkwmis(KW_UNDERLINETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_UNDERLINETERMTOKEN);\
  getkw()



#define    skipverticalbarTermToken(f)	\
/*  if(!isverticalbarTermToken()) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  flverticalbarTermToken(); */\
  if(Kword != KW_VERTICALBARTERMTOKEN) edberkwmis(KW_VERTICALBARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBARTERMTOKEN);\
  getkw()

#define    skipverticalbarbarTermToken(f)	\
  if(Kword != KW_VERTICALBARBARTERMTOKEN) \
edberkwmis(KW_VERTICALBARBARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBARBARTERMTOKEN);\
  getkw()

#define    skipverticalbarequalTermToken(f)	\
  if(Kword != KW_VERTICALBAREQUALTERMTOKEN) \
edberkwmis(KW_VERTICALBAREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VERTICALBAREQUALTERMTOKEN);\
  getkw()



#define    skipexclamationmarkTermToken(f)	\
/*  if(!isexclamationmarkTermToken()) edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  flexclamationmarkTermToken(); */\
  if(Kword != KW_EXCLAMATIONMARKTERMTOKEN) \
edberkwmis(KW_EXCLAMATIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EXCLAMATIONMARKTERMTOKEN);\
  getkw()


#define    skipexclamationmarkequalTermToken(f)	\
  if(Kword != KW_EXCLAMATIONMARKEQUALTERMTOKEN) \
edberkwmis(KW_EXCLAMATIONMARKEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_EXCLAMATIONMARKEQUALTERMTOKEN);\
  getkw()

#define    skipdollarTermToken(f)	\
/*  if(!isdollarTermToken()) edberkwmis(KW_DOLLARTERMTOKEN);\
  fldollarTermToken(); */\
  if(Kword != KW_DOLLARTERMTOKEN) edberkwmis(KW_DOLLARTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOLLARTERMTOKEN);\
  getkw()


#define    skippercentTermToken(f)	\
/*  if(!ispercentTermToken()) edberkwmis(KW_PERCENTTERMTOKEN);\
  flpercentTermToken(); */\
  if(Kword != KW_PERCENTTERMTOKEN) edberkwmis(KW_PERCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PERCENTTERMTOKEN);\
  getkw()

#define    skippercentequalTermToken(f)	\
  if(Kword != KW_PERCENTEQUALTERMTOKEN) \
edberkwmis(KW_PERCENTEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_PERCENTEQUALTERMTOKEN);\
  getkw()



#define    skipquastionmarkTermToken(f)	\
/*  if(!isquastionmarkTermToken()) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  flquastionmarkTermToken(); */\
  if(Kword != KW_QUASTIONMARKTERMTOKEN) edberkwmis(KW_QUASTIONMARKTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUASTIONMARKTERMTOKEN);\
  getkw()

#define    skipquastionmarkcolonTermToken(f)	\
  if(Kword != KW_QUASTIONMARKCOLONTERMTOKEN) \
edberkwmis(KW_QUASTIONMARKCOLONTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_QUASTIONMARKCOLONTERMTOKEN);\
  getkw()



#define    skipcommercialatTermToken(f)	\
/*  if(!iscommercialatTermToken()) edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  flcommercialatTermToken(); */\
  if(Kword != KW_COMMERCIALATTERMTOKEN) \
edberkwmis(KW_COMMERCIALATTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_COMMERCIALATTERMTOKEN);\
  getkw()

#define    skipleftsquarebracketTermToken(f)	\
/*  if(!isleftsquarebracketTermToken()) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  flleftsquarebracketTermToken(); */\
  if(Kword != KW_LEFTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTSQUAREBRACKETTERMTOKEN);\
  getkw()

#define    skipleftbackslashTermToken(f)	\
/*  if(!isleftbackslashTermToken()) edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  flleftbackslashTermToken(); */\
  if(Kword != KW_LEFTBACKSLASHTERMTOKEN) \
edberkwmis(KW_LEFTBACKSLASHTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBACKSLASHTERMTOKEN);\
  getkw()

#define    skiprightsquarebracketTermToken(f)	\
/*  if(!isrightsquarebracketTermToken()) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN); \
  flrightsquarebracketTermToken(); */\
  if(Kword != KW_RIGHTSQUAREBRACKETTERMTOKEN) \
edberkwmis(KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTSQUAREBRACKETTERMTOKEN);\
  getkw()


#define    skipcircumflexTermToken(f)	\
/*  if(!iscircumflexTermToken()) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  flcircumflexTermToken(); */\
  if(Kword != KW_CIRCUMFLEXTERMTOKEN) edberkwmis(KW_CIRCUMFLEXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_CIRCUMFLEXTERMTOKEN);\
  getkw()

#define    skipcircumflexequalTermToken(f)	\
  if(Kword != KW_CIRCUMFLEXEQUALTERMTOKEN) \
edberkwmis(KW_CIRCUMFLEXEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_CIRCUMFLEXEQUALTERMTOKEN);\
  getkw()



/*#define    skipgraveaccentTermToken(f)	\*/
/*  if(!isgraveaccentTermToken()) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  flgraveaccentTermToken(); */ 
/*
  if(Kword != KW_GRAVEACCENTTERMTOKEN) edberkwmis(KW_GRAVEACCENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GRAVEACCENTTERMTOKEN);\
  getkw()
*/

#define    skipleftbraceTermToken(f)	\
/*  if(!isleftbraceTermToken()) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  flleftbraceTermToken(); */\
  if(Kword != KW_LEFTBRACETERMTOKEN) edberkwmis(KW_LEFTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LEFTBRACETERMTOKEN);\
  getkw()

#define    skiprightbraceTermToken(f)	\
/*  if(!isrightbraceTermToken()) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  flrightbraceTermToken(); */\
  if(Kword != KW_RIGHTBRACETERMTOKEN) edberkwmis(KW_RIGHTBRACETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_RIGHTBRACETERMTOKEN);\
  getkw()



#define    skiptildeTermToken(f)	\
/*  if(!istildeTermToken()) edberkwmis(KW_TILDETERMTOKEN);\
  fltildeTermToken(); */\
  if(Kword != KW_TILDETERMTOKEN) edberkwmis(KW_TILDETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_TILDETERMTOKEN);\
  getkw()

#define    skiptildeequalTermToken(f)	\
  if(Kword != KW_TILDEEQUALTERMTOKEN) \
edberkwmis(KW_TILDEEQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_TILDEEQUALTERMTOKEN);\
  getkw()



/*#define    skiparrowTermToken(f)	*/
/*  if(!isarrowTermToken()) edberkwmis(KW_ARROWTERMTOKEN);\
  flarrowTermToken(); */
/*
  if(Kword != KW_ARROWTERMTOKEN) edberkwmis(KW_ARROWTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_ARROWTERMTOKEN);\
  getkw()
*/

/* #define    skipdoublestarexponentiateTermToken(f)	*/
/*  if(!isdoublestarexponentiateTermToken()) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  fldoublestarexponentiateTermToken(); */
/*
  if(Kword != KW_DOUBLESTAREXPONENTIATETERMTOKEN) \
edberkwmis(KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DOUBLESTAREXPONENTIATETERMTOKEN);\
  getkw()
*/

/*
#define    skipvariableassignmentTermToken(f)	
*/
/*  if(!isvariableassignmentTermToken()) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  flvariableassignmentTermToken(); 
*/
/*
  if(Kword != KW_VARIABLEASSIGNMENTTERMTOKEN) \
edberkwmis(KW_VARIABLEASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_VARIABLEASSIGNMENTTERMTOKEN);\
  getkw()
*/

/*
#define    skipinequalityTermToken(f)	\
*/
/*  if(!isinequalityTermToken()) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  flinequalityTermToken(); 
*/
/*
  if(Kword != KW_INEQUALITYTERMTOKEN) edberkwmis(KW_INEQUALITYTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_INEQUALITYTERMTOKEN);\
  getkw()
*/

/*
#define    skipgreaterthanorequalTermToken(f)	\
*/
/*  if(!isgreaterthanorequalTermToken()) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  flgreaterthanorequalTermToken(); 
*/
/*
  if(Kword != KW_GREATERTHANOREQUALTERMTOKEN) \
edberkwmis(KW_GREATERTHANOREQUALTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_GREATERTHANOREQUALTERMTOKEN);\
  getkw()
*/

/*
#define    skiplessthanorequalsignalassignmentTermToken(f)	
*/
/*  if(!islessthanorequalsignalassignmentTermToken()) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  fllessthanorequalsignalassignmentTermToken(); */
/*
  if(Kword != KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN) \
edberkwmis(KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN);\
  getkw()
*/

/*
#define    skipboxTermToken(f)	
*/
/* if(!isboxTermToken()) edberkwmis(KW_BOXTERMTOKEN);\
  flboxTermToken(); */
/*
  if(Kword != KW_BOXTERMTOKEN) edberkwmis(KW_BOXTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_BOXTERMTOKEN);\
  getkw()
*/


#define    skipdefisTermToken(f)	\
/*  if(!isdefisTermToken()) edberkwmis(KW_DEFISTERMTOKEN);\
  fldefisTermToken(); */\
  if(Kword != KW_DEFISTERMTOKEN) edberkwmis(KW_DEFISTERMTOKEN);\
  setedflong((f),KW_TERMTOKEN,KW_DEFISTERMTOKEN);\
  getkw()

#endif

/* 15.03.93 */







/* 22.01.92 */

#define    skipkeywordTermToken(f,t)	\
  if(Kword != (t)) edberkwmis((t));\
  setedflong((f),KW_TERMTOKEN,(t));\
  getkw()




/* 26.11.91 */
struct pdbiriType {
  inrType 			r;
  struct	kwnirType	**k;
};


/* 13.01.92 */
/* first & follow representation */

struct	metantmType	{
  int	nterm;
  int	firlen;
  int	*firval;
  int	follen;
  int	*folval;
};


struct	metagrmType	{
  struct	metantmType	*rulval;	/* all nonterminals	*/
  /*	MAP {nterm} -> {rule} */
  int	ntmlen;		/* 0..ntmlen-1   - numbers of nonterminals 	*/
  int	*ntmrul;	/* rule numbers of  nonterminals 		*/
};



#define		MAXTERMFIR	256

/* metalex.c            version of 16.07.91 */

/*                      version of 22.07.91 */
/*                      version of 19.08.91 */

/*                      version of 19.11.91 */
/*                      version of 21.11.91 */


/*                      version of 16.01.92 */


/* getint:sign!!!       version of 23.01.92 */


/* version 3:VLAN, MLAN version of 14.09.92 */
/* version 3:VLAN, MLAN version of 23.09.92 */

/* version WRSCH 	version of 01.10.92 */

/* comment: / * . . * / 	version of 05.10.92 */

/*                      version of 30.10.92 */

/*    getid: _. . .             version of 13.11.92 */


/* version SLLAN 		version of 15.03.93 */

/* 				version of 03/06/96 */

/* sic! */
/* XMLLAN 		version of 2010.05.31 */

/* LEXICAL LEVEL */
#include <stdlib.h>

#include "metaer.h"
#include "metalc.h"
#include "metalv.h"
#include "metakw.h"
#include "metakt.h"
#include "metaarts.h"

#include "pdbts.h"

/* 2010.05.31 ::: */
#if XMLLAN
long 	CurXmlToken;
int		xmlTokenFlag = 0;
int		xmlTokenStart = 0;
#endif
/* 2010.05.31 ... */

long 	CurString;
int	ApostropheMode= 0;	/* meta mode	*/


/* 2010.05.31 ::: */
#if XMLLAN

void xmlTokenOff()
{
	xmlTokenFlag = 0;
	/*fprintf(Fls, "xmlTokenOff:%ld\n", xmlTokenFlag);*/
}

void xmlTokenOn()
{
	xmlTokenFlag = 1;
	/*fprintf(Fls, "xmlTokenOn:%ld\n", xmlTokenFlag);*/
}

/*
 * xml token is between:
 * '<' 'xsd' ':' identifier '>' xmlToken '</' 'xsd' ':' identifier '>'
 * 
 */
int
getxmltoken(l)
long *l;
{
  register int i,j,s,sh=0;
  register int chc;

  /*flushbl();
  if(!isquota()) edber(STISMI);
  */
  /*
  if (!xmlTokenFlag) {
	pdbmess("here must be xmltoken token between <tag> ... </tag>");
	edber(WRLEXE);
  }
  */

  Npos = xmlTokenStart;
  getchr();
  i= -1;

  if(l)
    {
/**/
      /*if(s= edfepst(KW_STRINGTOKEN,l)) return(s);*/
      if(s= edfepst(KW_XMLTOKEN,l)) return(s);
/**/	
    }
	
  for(;;)
  {
      if(iseof()) {
        pdbmess("here must be xmltoken token between <tag> ... </tag>");
	    edber(WRLEXE);
      }
      
      i++;
      if(i == LENSTR)
      {
    	  if(!l) edber(TOLOST);
/**/
    	  if(s= edfepfx(XmlToken,i,sh*LENSTR)) return(s);
/**/
    	  i= 0;
    	  sh++;
      }

      if(isxmlEndTermToken()) break;

      XmlToken [i]= Ch;
	  getchr();

  }

  XmlToken [i]= '\0';
  /* flquota(); */
  
/*  Kword= KW_STRINGTOKEN; */

  if(l)
    {
/**/
      if(s= edfepfx(XmlToken,i+1,sh*LENSTR)) return(s);
/**/
    }

/*d*   if(Fls)
	{
		fprintf(Fls,"XmlToken=%s\n",XmlToken);
	}
/***/

  return(0);
}

#endif
/* 2010.05.31 ... */


void	pdbsetApostropheMode(m)
int m;
{	
  ApostropheMode= m;	/* meta mode	*/
}

edberr(e)
enum	METretcod e;
{
  char st[INLINEL+30];
  register int i;

  Ercn++;
  if(Ercn == MAXERC)
    {
      edberfini();
      abort();
    }

  Errn= e;
  Erset [e]= 2;

  for(i=0; i<5; i++) 	st[i]= '*';
  for(i=5; i<Epos+5; i++)	st[i]= ' ';
  st [Epos+5]= '\0';

  /* lis */
  if(Fls) fprintf(Fls,"%s $ %1d ERROR\n",st,e);
  flush();	
  Erflag = 1;
  Ergl = 1;

  return(e);

}


edbmess(e)
char *e;
{

  if(Fls) fprintf(Fls,"%s\n",e);

}

edbmes(e)
enum	METretcod e;
{
  char st [INLINEL+30];
  register int i;

  Warn= 1;
  Erset [e]= 1;

  for(i=0; i<5; i++) 	st[i]= '*';
  for(i=5; i<Epos+5; i++)	st[i]= ' ';
  st [Epos+5]= '\0';

  /* lis */
  if(Fls) fprintf(Fls,"%s $ %1d WARNING\n",st,e);

  return(e);

}

edbInit(sour,list)
char *sour, *list;
{
  register int i,s;

  Inpf= fopen(sour,"r");

  if(Inpf == NULL) edber(FINOFO);

  if(list)
    {
      /* lis */
      Fls= fopen(list,"w");
      if(Fls == NULL) edber(FINOCR);
    }
  else Fls= NULL;

  Nlin = 0;
  getnewl();
  Erflag = 0;
  Ergl = 0;

  Errn= 0;
  Ercn= -1;
  for (i=0; i<MAXERN; i++) Erset [i]= 0;
  Warn= 0;
  Brlev= 0;

  flushbl();

  if(s= getNextToken()) return(s);

  return(0);
}


edberfini()
{
  register int i;

  if((Ercn != -1) || Warn)
    {
      if(Fls) fprintf(Fls,"\n");
      if(Fls) fprintf(Fls,"%d errors detected\n",Ercn+1);
      if(Fls) fprintf(Fls,"\n");

      for(i=0; i<MAXERN; i++)
	{
	  if(Erset [i] != 0)
	    {
	      if(Erset [i] == 2)
		{
		  if(Fls) fprintf(Fls,"ERROR   %d ",i);
		}

	      if(Erset [i] == 1)
		{
		  if(Fls) fprintf(Fls,"WARNING %d ",i);
		}

	      metaerm(Fls,i);
	      
	    }
	}
    }
}

edbClose()
{
  fclose(Inpf);
  /* lis */
  if(Fls) fclose(Fls);
}

	
static char* Eofinpf;		/* end of file indicator */

static int   Lexdebug=0;

void	metalexdeb(m)
int	m;
{
  Lexdebug= m;
}

getnewl()
{
  if(Eofinpf=fgets(Line,INLINEL,Inpf))
    {
      Nlin++;
      /* lis */
      if(Fls) fprintf(Fls,"%5d   %s", Nlin, Line );
/*pppp*/
      if(Lexdebug) printf("%5d   %s", Nlin, Line ); 

      Ch = ' ';
      Npos = -1;
      Epos = -1;
    }
  else {
    Line[0]= '\0';
/* 03/06/96 - for commet at the end line */
    Line[1]= '\0';
    Line[2]= '\0';
/* 03/06/96 */

    Ch = ' ';
  }
}


#if VLAN
getchr()
{
  Npos++;
  Ch= Line[Npos];
  if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
  if((Ch == '\t') || (Ch == '\f')) Ch= ' ';
  if((Ch == '\0') || (Ch == '\n') || 
     ((Ch == '-') && (Line[Npos+1] == '-'))) {
    if (Eofinpf==NULL) Ch = EOF;
    else getnewl();
  }
}
#endif



/* 2010.05.31 ::: */
#if XMLLAN
/*
 * Comment
 * <!-- ......... -->
 */
/*
getchr()
{
  Npos++;
  Ch= Line[Npos];
  if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
  if((Ch == '\t') || (Ch == '\f')) Ch= ' ';
  if((Ch == '\0') || (Ch == '\n') || 
     ((Ch == '-') && (Line[Npos+1] == '-'))) {
    if (Eofinpf==NULL) Ch = EOF;
    else getnewl();
  }
}
*/


static int ComLine;

getchr()
{
  Npos++;
  Ch= Line[Npos];

 /*begcom:*/

  if((Ch == '<') && (Line[Npos+1] == '!') && (Line[Npos+2] == '-') && (Line[Npos+3] == '-')) {
    /* comment	*/
    ComLine= Nlin;
    Npos++;

    for(;;) {
      if(Eofinpf == NULL) {
    	  printf("No end of comment in line number:%ld\n",ComLine);
    	  break;
      }

      Npos++;
      Ch= Line[Npos];
      if((Ch == '-') && (Line[Npos+1] == '-') && (Line[Npos+2] == '>')) {
    	  Npos++;
    	  Npos++;
    	  Npos++;
    	  Ch= Line[Npos];
    	  break;
      }

      if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
      if((Ch == '\0') || (Ch == '\n')) {
    	  if(Eofinpf == NULL) Ch = EOF;
    	  else getnewl();
      }
    }
  }

  if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
  if((Ch == '\t') || (Ch == '\f')) Ch= ' ';
  if((Ch == '\0') || (Ch == '\n')) {
    if(Eofinpf == NULL) Ch = EOF;
    else getnewl();
  }

  /*
  if((Ch == '<') && (Line[Npos+1] == '-') && (Line[Npos+2] == '-'))  goto  begcom;
  */
}


#endif
/* 2010.05.31 ... */


#if MLAN

static int ComLine;

getchr()
{
  Npos++;
  Ch= Line[Npos];

 begcom:

  if((Ch == '/') && (Line[Npos+1] == '*')) {
    /* comment	*/
    ComLine= Nlin;
    Npos++;

    for(;;) {
      if(Eofinpf == NULL) {
	printf("No end of comment in line number:%ld\n",ComLine);
	break;
      }

      Npos++;
      Ch= Line[Npos];
      if((Ch == '*') && (Line[Npos+1] == '/')) {
	Npos++;
	Npos++;
	Ch= Line[Npos];
	break;
      }

      if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
      if((Ch == '\0') || (Ch == '\n')) {
	if(Eofinpf == NULL) Ch = EOF;
	else getnewl();
      }
    }
  }

  if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
  if((Ch == '\t') || (Ch == '\f')) Ch= ' ';
  if((Ch == '\0') || (Ch == '\n')) {
    if(Eofinpf == NULL) Ch = EOF;
    else getnewl();
  }

  if((Ch == '/') && (Line[Npos+1] == '*')) goto  begcom;

}
#endif




#if SLLAN

static int ComLine;

getchr()
{
  Npos++;
  Ch= Line[Npos];



/***************
  for(;;) {
    if(Ch != '(') break;
    if(Line[Npos+1] != '*') break; 
******************/

 begcom:

  if((Ch == '(') && (Line[Npos+1] == '*')) {

    /* comment	*/
    ComLine= Nlin;
    Npos++;

    for(;;) {
      if(Eofinpf == NULL) {
	printf("No end of comment in line number:%ld\n",ComLine);
	break;
      }

      Npos++;
      Ch= Line[Npos];
      if((Ch == '*') && (Line[Npos+1] == ')')) {
	Npos++;
	Npos++;
	Ch= Line[Npos];
	break;
      }

      if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
      if((Ch == '\0') || (Ch == '\n')) {
	if(Eofinpf == NULL) Ch = EOF;
	else getnewl();
      }
    }
  }  

  if(Ch == '\t') Epos= (Epos&~7)+8; else Epos++;
  if((Ch == '\t') || (Ch == '\f')) Ch= ' ';
  if((Ch == '\0') || (Ch == '\n')) {
    if(Eofinpf == NULL) Ch = EOF;
    else getnewl();
  }





  if((Ch == '(') && (Line[Npos+1] == '*')) goto  begcom;


}
#endif



#if VLAN || XMLLAN

getid()
{
  register int i;

  flushbl();

  if(!(isalnum(Ch))) {
    pdbmess("here must be identifier");
    edber(WRLEXE);
  }

  i= 0;

  while(isalnum(Ch) || (Ch == '_'))
    {
      if(i < LENID-1) {
	Id [i]= Ch;
	i++;
      }
      getchr();
    }

  Id [i] = '\0';
  flushbl();

/*  Kword= KW_IDENTIFIER; */

/*d  if(Fls) fprintf(Fls,"Id=%s\n",Id);*/

  return(0);

}
#endif





#if MLAN

getid()
{
  register int i;

  flushbl();

  if(!(isalnum(Ch)) && (Ch != '_')) {
    pdbmess("here must be identifier");
    edber(WRLEXE);
  }

  i= 0;

  while(isalnum(Ch) || (Ch == '_'))
    {
      if(i < LENID-1) {
	Id [i]= Ch;
	i++;
      }
      getchr();
    }

  Id [i] = '\0';
  flushbl();

/*  Kword= KW_IDENTIFIER; */

/*d  if(Fls) fprintf(Fls,"Id=%s\n",Id);*/

  return(0);

}
#endif





#if SLLAN

getid()
{
  register int i;

  flushbl();

  if(!(isalnum(Ch)) && (Ch != '_')) {
    pdbmess("here must be identifier");
    edber(WRLEXE);
  }

  i= 0;

  while(isalnum(Ch) || (Ch == '_'))
    {
      if(i < LENID-1) {
	Id [i]= Ch;
	i++;
      }
      getchr();
    }

  Id [i] = '\0';
  flushbl();

/*  Kword= KW_IDENTIFIER; */

/*d  if(Fls) fprintf(Fls,"Id=%s\n",Id);*/

  return(0);

}
#endif





/* 30.10.92 */

/* 15.03.93 */


/* 30.10.92 */
#include <math.h>
static	int    	Modeintfloat=0;
static	float	Rval;
/*float	pow();*/


#if SLLAN

getint()
{
  register int i;
  int s;

  flushbl();

  if(!( /*issign() ||*/ isdigit(Ch))) {
    pdbmess("here must be integer");
    edber(WRLEXE);
  }

  s= 1;

/*
  if(issign())
    {
      if(Ch == '+') s= 1; else s= -1;
      getchr();
    }
  flushbl();
*/


  Ival= 0;
  i= 0;
  while(isdigit(Ch))
    {
      if(i >= MAXILEN) edber(TOLOIN);

      i++;
      Ival= Ival*10 + ( ((unsigned)Ch) - ((unsigned)'0') );
      getchr();
    }

/*  Ival= Ival*s;*/
  flushbl();

/*  Kword= KW_INTEGERTOKEN; */

/*d  if(Fls) fprintf(Fls,"Ival=%d\n",Ival);*/

  return(0);
}


#else
/* MLAN, VLAN */

getint()
{
  register int i,b,a,j;

  float	r,t;


  Modeintfloat=0;

  flushbl();

  Ival= 0;

  if(isdigit(Ch)) {

    b= 10;
    if(Ch == '0') {
      b= 8;
      getchr();
      if((Ch == 'x') || (Ch == 'X')) {
	b= 16;
	getchr();
      }

	/* 26.04.95 */
      if(!isdigit(Ch)) {
	if(Ch != '.') {
		flushbl();
		return(0);
	}

	/* 0.XXX */
	b= 10;
      }
	/* 26.04.95 */


    }

    flushbl();

    i= 0;

    if(b != 16) {
      while(isdigit(Ch)) {
	if(i >= MAXILEN) edber(TOLOIN);

	i++;
	Ival= Ival*b + ( ((unsigned)Ch) - ((unsigned)'0') );
	getchr();
      }
    }
    else {
      while(isdigit(Ch) 
	    || (Ch= 'a') || (Ch= 'A')
	    || (Ch= 'b') || (Ch= 'B')
	    || (Ch= 'c') || (Ch= 'C')
	    || (Ch= 'd') || (Ch= 'D')
	    || (Ch= 'e') || (Ch= 'E')
	    || (Ch= 'f') || (Ch= 'F')
	    ) {
	if(i >= MAXILEN) edber(TOLOIN);

	i++;
	if(isdigit(Ch))
	  a= ( ((unsigned)Ch) - ((unsigned)'0') );
	else if ((Ch= 'a') || (Ch= 'A'))
	  a= 10;
	else if ((Ch= 'b') || (Ch= 'B'))
	  a= 11;
	else if ((Ch= 'c') || (Ch= 'C'))
	  a= 12;
	else if ((Ch= 'd') || (Ch= 'D'))
	  a= 13;
	else if ((Ch= 'e') || (Ch= 'E'))
	  a= 14;
	else if ((Ch= 'f') || (Ch= 'F'))
	  a= 15;

	Ival= Ival*b + a;
	getchr();
      }
    }

    if((Ch == 'l') || (Ch == 'L')) {
      getchr();
    }

    flushbl();
  }

  if(Ch == '.') {
    getchr();
    Modeintfloat= 1;

    r= 0.0;
    if(isdigit(Ch)) {
      i= 0;
      j= 0;
      while(isdigit(Ch)) {
	if(i >= MAXILEN) edber(TOLOIN);

	i++;
	j= j*10 + ( ((unsigned)Ch) - ((unsigned)'0') );
	getchr();
      }


/*      r= (double)j*pow((double)10,(double)(-i));*/
      r= (float)j*pow((double)10,(double)(-i));

/*d  if(Fls) fprintf(Fls,"r=%g j=%ld i=%ld\n",r,j,i); */
	    flushbl();/* 04.04.95 */

    }

/*  	    Rval= ((double)Ival+(double)r);*/
    Rval= ((float)Ival+(float)r);

    /*d  if(Fls) fprintf(Fls,"Rval=%g\n",Rval); */

    if((Ch == 'e') || (Ch == 'E')) {
      getchr();
      a= 1;
      if((Ch == '+') || (Ch == '-')) {
	if(Ch == '-') a= (-1);
	getchr();
      }

      i= 0;
      j= 0;
      while(isdigit(Ch)) {
	if(i >= MAXILEN) edber(TOLOIN);

	i++;
	j= j*10 + ( ((unsigned)Ch) - ((unsigned)'0') );
	getchr();
      }

      t= (float) (a*j);

/*      Rval= ((double)Ival+(double)r)*pow((double)10.0,(double)t);*/
      Rval= Rval*pow((double)10.0,(double)t);



/*d  if(Fls) fprintf(Fls,"Rval=%g man=%g exp=%g\n",
Rval,((double)Ival+(double)r),t);
*/
	    flushbl();/* 04.04.95 */

    }


  }


/*  Kword= KW_INTEGERTOKEN; */

/*d  if(Fls) fprintf(Fls,"Ival=%d\n",Ival);*/


/*d
  if(Modeintfloat) {
    if(Fls) fprintf(Fls,"Rval=%g\n",Rval);
  }
*/  

  return(0);
}

#endif



int getkwc()
{
  register int s;

/*  if(s= getid()) return(s); */

/* 21.11.91 */
/*  if(s= lexsear(Id)) edber(s); */

/**/
  if(Kword == KW_IDENTIFIER) {
    if(lexsear(Id)) {
      Kword= KW_IDENTIFIER;
    }
  }
/**/

  return(0);
}

int lexsear(Id)
char *Id;
{
#define LENKWTAB (sizeof(KeyTab)/sizeof(char*))
/* must be other end of table !!!!! */



  register int i,j,k,y;

/*d*
  if(Fls) {
    fprintf(Fls,"LENKWTAB=%d\n",LENKWTAB); 
    for(i=0; i < LENKWTAB; i++)
      fprintf(Fls,"KWTAB[%d]=%s\n",i,KeyTab[i]); 
  }
/**/

  Kword= KW_WRONGKEYWORD;
  i= 1;
  j= 0;

  for(;;)
    {
/*d  if(Fls) fprintf(Fls,"Id[%d]=%c\n",j,Id[j]); */

      for(;;)
	{
/*d    if(Fls) fprintf(Fls,"Keytab[%d]=%s\n",i,KeyTab[i]);*/

	  for(y=1,k=0; k<=j; k++)
	    {
	      /*
	      y= y && ((KeyTab[i][k] == Id[k]) ||
		       (toupper(KeyTab[i][k]) == Id[k]) ||
		       (KeyTab[i][k] == toupper(Id[k])));
		       */
	      y= y && metaletterequal(KeyTab[i][k],Id[k]);
	    }

	  if(y) break;

	  i++;
	  if(i == LENKWTAB) {
	    return(WRKEWO);
	  }
	}

      j++;
      if(j == LENID) {
	return(WRKEWO);
      }

      if(!Id[j])
	{
	  if(!KeyTab[i][j]) {
	    Kword= i;
/*d*    	if(Fls) fprintf(Fls,"Kword=%d Kiden=%s\n",Kword,KeyTab[Kword]);
/**/
	    return(0);
	  }
	  else {
	    return(WRKEWO);
	  }
	}

      if(j == MAXIDN)
	{
	  /* cycle by i in an ather mode */
	  for(;;)
	    {
/*d  if(Fls) fprintf(Fls,"Keytab[%d]=%s\n",i,KeyTab[i]);  */

	      for(y=1,k=MAXIDN; Id[k]; k++)
		{
		  /*
		  y= y && ((KeyTab[i][k] == Id[k]) ||
		       (toupper(KeyTab[i][k]) == Id[k]) ||
		       (KeyTab[i][k] == toupper(Id[k])));
		       */
		  y= y && metaletterequal(KeyTab[i][k],Id[k]);
		}

	      if(y) {
		Kword= i;
/*d*    if(Fls) fprintf(Fls,"Kword=%d Kiden=%s\n",Kword,KeyTab[Kword]);
/**/
		return(0);
	      }

	      i++;
	      if(i == LENKWTAB) {
		return(WRKEWO);
	      }

	      for(y=1,k=0; k<MAXIDN; k++)
		{
		  /*
		  y= y && ((KeyTab[i][k] == Id[k]) ||
		       (toupper(KeyTab[i][k]) == Id[k]) ||
		       (KeyTab[i][k] == toupper(Id[k])));
		       */
		  y= y && metaletterequal(KeyTab[i][k],Id[k]);
		}

	      if(!y) {
		return(WRKEWO);
	      }
	    }
	}
    }
}

getstring(l)
long *l;
{
  register int i,j,s,sh=0;
  register int chc;

  flushbl();
  if(!isquota()) edber(STISMI);

  getchr();
  i= -1;

  if(l)
    {
/**/
      if(s= edfepst(KW_STRINGTOKEN,l)) return(s);
/**/	
    }
	
  for(;;)
    {
      if(iseof()) {
	pdbmess("here must be end of string token");
	edber(WRLEXE);
      }
      i++;
      if(i == LENSTR)
	{
	  if(!l) edber(TOLOST);
/**/
	  if(s= edfepfx(Strng,i,sh*LENSTR)) return(s);
/**/
	  i= 0;
	  sh++;
	}

      if(isquota()) break;


#if VLAN
      if(Ch == '%')
	{
	  getchr();
	  for(;;)
	    {
	      flushbl();
	      if(iseof()) {
		pdbmess("here must be end of string token");
		edber(WRLEXE);	      
	      }

	      if(isdigit(Ch))
		{
		  j= 0;
		  chc= 0;
		  while(isdigit(Ch))
		    {
		      if(j == 3) edber(WRCHSP);
		      j++;
		      chc= chc*10 + ((unsigned)Ch - (unsigned)'0');
		      getchr();
		    }

		  if(chc > 127) edber(WRCHSP);

		  Strng [i]= (char)chc;
		}
	      else edber(WRCHSP);

	      flushbl();
	      if(Ch == '%') break;
	      i++;
	      if(i == LENSTR)
		{
		  if(!l) edber(TOLOST);
/**/
		  if(s= edfepfx(Strng,i,sh*LENSTR)) return(s);
/**/
		  i= 0;
		  sh++;
		}

	    } /* for */

	  if(Ch != '%') edber(WRCHSP);
	  getchr();
	}
      else
	{
	  Strng [i]= Ch;
	  getchr();
	}

#endif






#if MLAN
/* analize \ !!!! */
	  Strng [i]= Ch;
	  getchr();

#endif


#if SLLAN
/* analize \ !!!! */
	  Strng [i]= Ch;
	  getchr();

#endif


#if XMLLAN
/* analize \ !!!! */
	  Strng [i]= Ch;
	  getchr();

#endif
	  
    }

  Strng [i]= '\0';
  flquota();
  
/*  Kword= KW_STRINGTOKEN; */

  if(l)
    {
/**/
      if(s= edfepfx(Strng,i+1,sh*LENSTR)) return(s);
/**/
    }

/*d*   if(Fls)
	{
		fprintf(Fls,"Strng=%s\n",Strng);
	}
/***/

  return(0);
}



getterm()
{
  register int i,s;

  flushbl();
  if(!issquota()) edber(STISMI);

  getchr();

  if(ApostropheMode) {
    /* language mode */
    if(Line[Npos+2] == '\'') {
      Strng[0] = Ch;
      getchr();
      Strng[1]= '\0';
      if(!issquota()) edber(STISMI);
      flsquota();
    }
    else {
      Strng[0]= '\0';
      return(0);
    }
  }
  else {
    /* meta mode */

    if((issquota()) && (Line[Npos+1] == '\'')) {
      getchr();
      Strng[0] = '\'';
      Strng[1]= '\0';
      flsquota();

      return(0);
    }


    
    i= -1;
	
    for(;;)
      {
	if(iseof()) {
	  pdbmess("here must be end of terminal token");
	  edber(WRLEXE);
	}

	i++;
	if(i == LENSTR) {edber(TOLOST);}

	if(issquota()) break;

	Strng [i]= Ch;
	getchr();

      }

    Strng [i]= '\0';
    flsquota();
  }

/*  Kword= KW_TERMTOKEN; */

/*d*   if(Fls)
	{
		fprintf(Fls,"Strng=%s\n",Strng);
	}
/***/

  return(0);
}



int identifier(l)
long *l;
{
  register int s;
  long 	n;


/* 21.11.91 */
/*  if(s= getid()) return(s);*/
/*  if(Kword != KW_IDENTIFIER) edber(WRLEXE); */


/*d*    if(Fls) fprintf(Fls,"ident=%s kw=%d\n",Id,Kword);
/**/

/**/
  if(s= edfnmst(Id,&n)) return(s);
  setedflong(l,KW_IDENTIFIER,n);
/**/

/*d*    if(Fls) fprintf(Fls,"ident=%s n=%d kw=%d\n",Id,n,Kword);
/**/

  if(s= getNextToken()) return(s);

  return(0);
}

int integerToken(l)
long 	*l;
{
  register int s;

/*  if(s= getint()) return(s); */

  if(Kword != KW_INTEGERTOKEN) {
    pdbmess("here must be integer or float token");
    edber(WRLEXE);
  }

  if(!Modeintfloat) {	
    if(s= celedpfst(0,KW_INTEGERTOKEN,l,&Ival,1)) return(s);

/** ppppppppppppppp 
printf("Ival=%ld\n",Ival);
*/

  }
  else {
    if(s= celedpfst(0,KW_FLOATTOKEN,l,&Rval,1)) return(s);
  }

  if(s= getNextToken()) return(s);

  return(0);
}


int termToken(l)
long 	*l;
{
  register int i,s,y;
  long n;

  if(Kword != KW_TERMTOKEN) {
    pdbmess("here must be terminal token");
    edber(WRLEXE);
  }

/*  if(s= getterm()) return(s); */

/*  if(s= celedpfss(KW_TERMTOKEN,l,Strng)) return(s); */

  for(i= 0; i < LENTABLETERMTOKEN; i++) {
    if(!(y= strcmp(Strng,tableTermToken[i].t))) break;
  }

/**/
  if(y) {
    if(s= edfnmst(Strng,&n)) return(s);
  }
  else {
    if(s= edfnmst(KeyTab[tableTermToken[i].k],&n)) return(s);
  }

  setedflong(l,KW_TERMTOKENOFRULE,n);
/**/

  if(s= getNextToken()) return(s);

  return(0);
}


int stringToken(l)
long *l;
{
  register int s;

/*  if(s= getstring(l)) return(s); */

  if(Kword != KW_STRINGTOKEN) {
    pdbmess("here must be string token");
    edber(WRLEXE);
  }

  if(l) *l= CurString;

  if(s= getNextToken()) return(s);

  return(0);
}

/* 2010.05.31 ::: */
#if XMLLAN
int xmlToken(l)
long *l;
{
  register int s;

  /*
  fprintf(Fls, "xmlToken():%ld:%ld Kw:%ld(%ld)\n"
		  , xmlTokenFlag, CurXmlToken, Kword, KW_XMLTOKEN);
  */
  
  /*
  if(Kword != KW_XMLTOKEN) {
    pdbmess("here must be xml token: <tag>...xml token...</tag>");
    edber(WRLEXE);
  }
  */
  if (xmlTokenFlag != 1) {
    pdbmess("here must be xml token: <tag>...xml token...</tag>");
    edber(WRLEXE);
  }

  if (s = getxmltoken(&CurXmlToken)) return(s);
  Kword = KW_XMLTOKEN;

  if(l) *l= CurXmlToken;

  xmlTokenOff();
  if(s= getNextToken()) return(s);

  return(0);
}

#endif
/* 2010.05.31 ... */



#if VLAN

/* 19.11.91   */

int getNextToken()
{
  register int y,i,s;

  if(iseof()) {
    Kword= KW_WRONGKEYWORD;
    return(0);
  }

  if(isleftparenthesisTermToken()) {
	/*    flleftparenthesisTermToken();*/	  
	/*    getkwc();*/
    flleftparenthesisTermToken();
    Kword= KW_LEFTPARENTHESISTERMTOKEN;
  }
  else if(isstringToken()){
    if(s= getstring(&CurString)) return(s);
    Kword= KW_STRINGTOKEN;
  }
  else if(isintegerToken()){
    if(s= getint()) return(s);

/*
    if(Modeintfloat)
      Kword= KW_FLOATTOKEN;
    else
*/
      Kword= KW_INTEGERTOKEN;
  }
  else if(istermToken()) {
    if(ApostropheMode) {
      /* language mode */
      if(Line[Npos+2] == '\'') {
	if(s= getterm()) return(s);
	Kword= KW_TERMTOKEN;
      }
      else {
	flapostropheTermToken();
	Kword= KW_APOSTROPHETERMTOKEN;
      }
    }
    else {
      if(s= getterm()) return(s);
      Kword= KW_TERMTOKEN;
    }
  }
  else if(isquotationTermToken()) {
    flquotationTermToken();
    Kword= KW_QUOTATIONTERMTOKEN;
  }
  else if(issharpTermToken()) {
    flsharpTermToken();
    Kword= KW_SHARPTERMTOKEN;
  }
  else if(isampersandTermToken()) {
    flampersandTermToken();
    Kword= KW_AMPERSANDTERMTOKEN;
  }
  else if(isrightparenthesisTermToken()) {
    flrightparenthesisTermToken();
    Kword= KW_RIGHTPARENTHESISTERMTOKEN;
  }
/*    **    *      **/
  else if(isdoublestarexponentiateTermToken()) {
    fldoublestarexponentiateTermToken();
    Kword= KW_DOUBLESTAREXPONENTIATETERMTOKEN;
  }
  else if(isstarmultiplyTermToken()) {
    flstarmultiplyTermToken();
    Kword= KW_STARMULTIPLYTERMTOKEN;
  }
/*****/
  else if(isplusTermToken()) {
    flplusTermToken();
    Kword= KW_PLUSTERMTOKEN;
  }
  else if(iscommaTermToken()) {
    flcommaTermToken();
    Kword= KW_COMMATERMTOKEN;
  }
  else if(ishyphenminusTermToken()) {
    flhyphenminusTermToken();
    Kword= KW_HYPHENMINUSTERMTOKEN;
  }
  else if(isdotpointperiodTermToken()) {
    fldotpointperiodTermToken();
    Kword= KW_DOTPOINTPERIODTERMTOKEN;
  }
/**    /=      /     **/
  else if(isinequalityTermToken()) {
    flinequalityTermToken();
    Kword= KW_INEQUALITYTERMTOKEN;
  }
  else if(isslashdivideTermToken()) {
    flslashdivideTermToken();
    Kword= KW_SLASHDIVIDETERMTOKEN;
  }
/******/
/** ::=    :=     :**/
  else if(isdefisTermToken()) {
    fldefisTermToken();
    Kword= KW_DEFISTERMTOKEN;
  }
  else if(isvariableassignmentTermToken()) {
    flvariableassignmentTermToken();
    Kword= KW_VARIABLEASSIGNMENTTERMTOKEN;
  }
  else if(iscolonTermToken()) {
    flcolonTermToken();
    Kword= KW_COLONTERMTOKEN;
  }
/***/
  else if(issemicolonTermToken()) {
    flsemicolonTermToken();
    Kword= KW_SEMICOLONTERMTOKEN;
  }
/**  <=   <>    < **/
  /* 2010.05.27 */
  /**  <=   <>    </ < **/
  else if(islessthanorequalsignalassignmentTermToken()) {
    fllessthanorequalsignalassignmentTermToken();
    Kword= KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN;
  }
  else if(isboxTermToken()) {
    flboxTermToken();
    Kword= KW_BOXTERMTOKEN;
  }
  /* 2010.05.27 */
  else if(isxmlEndTermToken()) {
	flxmlEndTermToken();
    Kword= KW_XMLENDTERMTOKEN;
  }  
  else if(islessthanTermToken()) {
    fllessthanTermToken();
    Kword= KW_LESSTHANTERMTOKEN;
  }
/*****/
/* =>    = */
  else if(isarrowTermToken()) {
    flarrowTermToken();
    Kword= KW_ARROWTERMTOKEN;
  }
  else if(isequalTermToken()) {
    flequalTermToken();
    Kword= KW_EQUALTERMTOKEN;
  }
/****/
/** >=         > **/
  else if(isgreaterthanorequalTermToken()) {
    flgreaterthanorequalTermToken();
    Kword= KW_GREATERTHANOREQUALTERMTOKEN;
  }
  else if(isgreaterthanTermToken()) {
    flgreaterthanTermToken();
    Kword= KW_GREATERTHANTERMTOKEN;
  }
/****/
  else if(isunderlineTermToken()) {
    flunderlineTermToken();
    Kword= KW_UNDERLINETERMTOKEN;
  }
  else if(isverticalbarTermToken()) {
    flverticalbarTermToken();
    Kword= KW_VERTICALBARTERMTOKEN;
  }
  else if(isexclamationmarkTermToken()) {
    flexclamationmarkTermToken();
    Kword= KW_EXCLAMATIONMARKTERMTOKEN;
  }
  else if(isdollarTermToken()) {
    fldollarTermToken();
    Kword= KW_DOLLARTERMTOKEN;
  }
  else if(ispercentTermToken()) {
    flpercentTermToken();
    Kword= KW_PERCENTTERMTOKEN;
  }
  else if(isquastionmarkTermToken()) {
    flquastionmarkTermToken();
    Kword= KW_QUASTIONMARKTERMTOKEN;
  }
  else if(iscommercialatTermToken()) {
    flcommercialatTermToken();
    Kword= KW_COMMERCIALATTERMTOKEN;
  }
  else if(isleftsquarebracketTermToken()) {
    flleftsquarebracketTermToken();
    Kword= KW_LEFTSQUAREBRACKETTERMTOKEN;
  }
  else if(isleftbackslashTermToken()) {
    flleftbackslashTermToken();
    Kword= KW_LEFTBACKSLASHTERMTOKEN;
  }
  else if(isrightsquarebracketTermToken()) {
    flrightsquarebracketTermToken();
    Kword= KW_RIGHTSQUAREBRACKETTERMTOKEN;
  }
  else if(iscircumflexTermToken()) {
    flcircumflexTermToken();
    Kword= KW_CIRCUMFLEXTERMTOKEN;
  }
  else if(isgraveaccentTermToken()) {
    flgraveaccentTermToken();
    Kword= KW_GRAVEACCENTTERMTOKEN;
  }
  else if(isleftbraceTermToken()) {
    flleftbraceTermToken();
    Kword= KW_LEFTBRACETERMTOKEN;
  }
  else if(isrightbraceTermToken()) {
    flrightbraceTermToken();
    Kword= KW_RIGHTBRACETERMTOKEN;
  }
  else if(istildeTermToken()) {
    fltildeTermToken();
    Kword= KW_TILDETERMTOKEN;
  }
  else {
/*   Kword= KW_IDENTIFIER; */
/*   if(s= getkwc()) return(s); */
   if(s= getid()) return(s);

   if(lexsear(Id)) {
     Kword= KW_IDENTIFIER;
   }
   else {
     /* search terminals(reserve words) */
     y= 1;
     for(i= 0; i < LENTABLEKEYWORD; i++) {


/*d* 
if(Fls) fprintf(Fls,"getN:i= %d Kword=%d Kiden=%s keyword[i]=%d t=%s\n",
		i,Kword,KeyTab[Kword],
		KeyTabkeyword[i],
		KeyTab[KeyTabkeyword[i]]);
/**/

       if(Kword == KeyTabkeyword[i]) {
	 y= 0;
	 break;
       }
     }

     if(y) Kword= KW_IDENTIFIER;

   }
 }

/*d*    if(Fls) fprintf(Fls,"getNextToken:Kword=%d Kiden=%s\n",
			 Kword,KeyTab[Kword]);
/**/


  return(0);
}

#endif









#if MLAN

/* 23.09.92   */

int getNextToken()
{
  register int y,i,s;

  if(iseof()) {
    Kword= KW_WRONGKEYWORD;
    return(0);
  }

  if(isleftparenthesisTermToken()) {
	/*    flleftparenthesisTermToken();*/	  
	/*    getkwc();*/
    flleftparenthesisTermToken();
    Kword= KW_LEFTPARENTHESISTERMTOKEN;
  }
  else if(isstringToken()){
    if(s= getstring(&CurString)) return(s);
    Kword= KW_STRINGTOKEN;
  }
  else if(isintegerToken()){
    if(s= getint()) return(s);
/*
    if(Modeintfloat)
      Kword= KW_FLOATTOKEN;
    else
*/
      Kword= KW_INTEGERTOKEN;

  }
  else if(istermToken()) {
    if(ApostropheMode) {
      /* language mode */
      if(Line[Npos+2] == '\'') {
	if(s= getterm()) return(s);
	Kword= KW_TERMTOKEN;
      }
      else {
	flapostropheTermToken();
	Kword= KW_APOSTROPHETERMTOKEN;
      }
    }
    else {
      if(s= getterm()) return(s);
      Kword= KW_TERMTOKEN;
    }
  }
  else if(isquotationTermToken()) {
    flquotationTermToken();
    Kword= KW_QUOTATIONTERMTOKEN;
  }
  else if(issharpTermToken()) {
    flsharpTermToken();
    Kword= KW_SHARPTERMTOKEN;
  }
  else if(isampersandampersandTermToken()) {
    flampersandampersandTermToken();
    Kword= KW_AMPERSANDAMPERSANDTERMTOKEN;
  }
  else if(isampersandequalTermToken()) {
    flampersandequalTermToken();
    Kword= KW_AMPERSANDEQUALTERMTOKEN;
  }
  else if(isampersandTermToken()) {
    flampersandTermToken();
    Kword= KW_AMPERSANDTERMTOKEN;
  }
  else if(isrightparenthesisTermToken()) {
    flrightparenthesisTermToken();
    Kword= KW_RIGHTPARENTHESISTERMTOKEN;
  }
/*    **    *      **/
/*
  else if(isdoublestarexponentiateTermToken()) {
    fldoublestarexponentiateTermToken();
    Kword= KW_DOUBLESTAREXPONENTIATETERMTOKEN;
  }
*/
  else if(isstarmultiplyequalTermToken()) {
    flstarmultiplyequalTermToken();
    Kword= KW_STARMULTIPLYEQUALTERMTOKEN;
  }
  else if(isstarmultiplyTermToken()) {
    flstarmultiplyTermToken();
    Kword= KW_STARMULTIPLYTERMTOKEN;
  }
/*****/
  else if(isplusplusTermToken()) {
    flplusplusTermToken();
    Kword= KW_PLUSPLUSTERMTOKEN;
  }
  else if(isplusequalTermToken()) {
    flplusequalTermToken();
    Kword= KW_PLUSEQUALTERMTOKEN;
  }
  else if(isplusTermToken()) {
    flplusTermToken();
    Kword= KW_PLUSTERMTOKEN;
  }
  else if(iscommaTermToken()) {
    flcommaTermToken();
    Kword= KW_COMMATERMTOKEN;
  }
  else if(ishyphenminusmoreTermToken()) {
    flhyphenminusmoreTermToken();
    Kword= KW_HYPHENMINUSMORETERMTOKEN;
  }
  else if(ishyphenminusminusTermToken()) {
    flhyphenminusminusTermToken();
    Kword= KW_HYPHENMINUSMINUSTERMTOKEN;
  }
  else if(ishyphenminusequalTermToken()) {
    flhyphenminusequalTermToken();
    Kword= KW_HYPHENMINUSEQUALTERMTOKEN;
  }
  else if(ishyphenminusTermToken()) {
    flhyphenminusTermToken();
    Kword= KW_HYPHENMINUSTERMTOKEN;
  }
  else if(isdotpointperiodTermToken()) {
    fldotpointperiodTermToken();
    Kword= KW_DOTPOINTPERIODTERMTOKEN;
  }
/**    /=      /     **/
/*
  else if(isinequalityTermToken()) {
    flinequalityTermToken();
    Kword= KW_INEQUALITYTERMTOKEN;
  }
*/
  else if(isslashdivideequalTermToken()) {
    flslashdivideequalTermToken();
    Kword= KW_SLASHDIVIDEEQUALTERMTOKEN;
  }
  else if(isslashdivideTermToken()) {
    flslashdivideTermToken();
    Kword= KW_SLASHDIVIDETERMTOKEN;
  }
/******/
/** ::=    :=     :**/
  else if(isdefisTermToken()) {
    fldefisTermToken();
    Kword= KW_DEFISTERMTOKEN;
  }
/*
  else if(isvariableassignmentTermToken()) {
    flvariableassignmentTermToken();
    Kword= KW_VARIABLEASSIGNMENTTERMTOKEN;
  }
*/
  else if(iscolonTermToken()) {
    flcolonTermToken();
    Kword= KW_COLONTERMTOKEN;
  }
/***/
  else if(issemicolonTermToken()) {
    flsemicolonTermToken();
    Kword= KW_SEMICOLONTERMTOKEN;
  }
/**  <=   <>    < **/

/*
  else if(islessthanorequalsignalassignmentTermToken()) {
    fllessthanorequalsignalassignmentTermToken();
    Kword= KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN;
  }
  else if(isboxTermToken()) {
    flboxTermToken();
    Kword= KW_BOXTERMTOKEN;
  }
*/
  else if(islessthanlessequalTermToken()) {
    fllessthanlessequalTermToken();
    Kword= KW_LESSTHANLESSEQUALTERMTOKEN;
  }
  else if(islessthanlessTermToken()) {
    fllessthanlessTermToken();
    Kword= KW_LESSTHANLESSTERMTOKEN;
  }
  else if(islessthanequalTermToken()) {
    fllessthanequalTermToken();
    Kword= KW_LESSTHANEQUALTERMTOKEN;
  }
  else if(islessthanTermToken()) {
    fllessthanTermToken();
    Kword= KW_LESSTHANTERMTOKEN;
  }
/*****/
/* =>    = */
/*
  else if(isarrowTermToken()) {
    flarrowTermToken();
    Kword= KW_ARROWTERMTOKEN;
  }
*/
  else if(isequalequalTermToken()) {
    flequalequalTermToken();
    Kword= KW_EQUALEQUALTERMTOKEN;
  }
  else if(isequalTermToken()) {
    flequalTermToken();
    Kword= KW_EQUALTERMTOKEN;
  }
/****/
/** >=         > **/
/*
  else if(isgreaterthanorequalTermToken()) {
    flgreaterthanorequalTermToken();
    Kword= KW_GREATERTHANOREQUALTERMTOKEN;
  }
*/
  else if(isgreaterthangreaterequalTermToken()) {
    flgreaterthangreaterequalTermToken();
    Kword= KW_GREATERTHANGREATEREQUALTERMTOKEN;
  }
  else if(isgreaterthangreaterTermToken()) {
    flgreaterthangreaterTermToken();
    Kword= KW_GREATERTHANGREATERTERMTOKEN;
  }
  else if(isgreaterthanequalTermToken()) {
    flgreaterthanequalTermToken();
    Kword= KW_GREATERTHANEQUALTERMTOKEN;
  }
  else if(isgreaterthanTermToken()) {
    flgreaterthanTermToken();
    Kword= KW_GREATERTHANTERMTOKEN;
  }
/****/

/****************************************
  else if(isunderlineTermToken()) {
    flunderlineTermToken();
    Kword= KW_UNDERLINETERMTOKEN;
  }
/********************************************/

  else if(isverticalbarbarTermToken()) {
    flverticalbarbarTermToken();
    Kword= KW_VERTICALBARBARTERMTOKEN;
  }
  else if(isverticalbarequalTermToken()) {
    flverticalbarequalTermToken();
    Kword= KW_VERTICALBAREQUALTERMTOKEN;
  }
  else if(isverticalbarTermToken()) {
    flverticalbarTermToken();
    Kword= KW_VERTICALBARTERMTOKEN;
  }


  else if(isexclamationmarkequalTermToken()) {
    flexclamationmarkequalTermToken();
    Kword= KW_EXCLAMATIONMARKEQUALTERMTOKEN;
  }
  else if(isexclamationmarkTermToken()) {
    flexclamationmarkTermToken();
    Kword= KW_EXCLAMATIONMARKTERMTOKEN;
  }

  else if(isdollarTermToken()) {
    fldollarTermToken();
    Kword= KW_DOLLARTERMTOKEN;
  }

  else if(ispercentequalTermToken()) {
    flpercentequalTermToken();
    Kword= KW_PERCENTEQUALTERMTOKEN;
  }
  else if(ispercentTermToken()) {
    flpercentTermToken();
    Kword= KW_PERCENTTERMTOKEN;
  }

  else if(isquastionmarkcolonTermToken()) {
    flquastionmarkcolonTermToken();
    Kword= KW_QUASTIONMARKCOLONTERMTOKEN;
  }
  else if(isquastionmarkTermToken()) {
    flquastionmarkTermToken();
    Kword= KW_QUASTIONMARKTERMTOKEN;
  }

  else if(iscommercialatTermToken()) {
    flcommercialatTermToken();
    Kword= KW_COMMERCIALATTERMTOKEN;
  }
  else if(isleftsquarebracketTermToken()) {
    flleftsquarebracketTermToken();
    Kword= KW_LEFTSQUAREBRACKETTERMTOKEN;
  }
  else if(isleftbackslashTermToken()) {
    flleftbackslashTermToken();
    Kword= KW_LEFTBACKSLASHTERMTOKEN;
  }
  else if(isrightsquarebracketTermToken()) {
    flrightsquarebracketTermToken();
    Kword= KW_RIGHTSQUAREBRACKETTERMTOKEN;
  }

  else if(iscircumflexequalTermToken()) {
    flcircumflexequalTermToken();
    Kword= KW_CIRCUMFLEXEQUALTERMTOKEN;
  }
  else if(iscircumflexTermToken()) {
    flcircumflexTermToken();
    Kword= KW_CIRCUMFLEXTERMTOKEN;
  }

/*
  else if(isgraveaccentTermToken()) {
    flgraveaccentTermToken();
    Kword= KW_GRAVEACCENTTERMTOKEN;
  }
*/

  else if(isleftbraceTermToken()) {
    flleftbraceTermToken();
    Kword= KW_LEFTBRACETERMTOKEN;
  }
  else if(isrightbraceTermToken()) {
    flrightbraceTermToken();
    Kword= KW_RIGHTBRACETERMTOKEN;
  }

  else if(istildeequalTermToken()) {
    fltildeequalTermToken();
    Kword= KW_TILDEEQUALTERMTOKEN;
  }
  else if(istildeTermToken()) {
    fltildeTermToken();
    Kword= KW_TILDETERMTOKEN;
  }

  else {
/*   Kword= KW_IDENTIFIER; */
/*   if(s= getkwc()) return(s); */
   if(s= getid()) return(s);

   if(lexsear(Id)) {
     Kword= KW_IDENTIFIER;
   }
   else {
     /* search terminals(reserve words) */
     y= 1;
     for(i= 0; i < LENTABLEKEYWORD; i++) {


/*d* 
if(Fls) fprintf(Fls,"getN:i= %d Kword=%d Kiden=%s keyword[i]=%d t=%s\n",
		i,Kword,KeyTab[Kword],
		KeyTabkeyword[i],
		KeyTab[KeyTabkeyword[i]]);
/**/

       if(Kword == KeyTabkeyword[i]) {
	 y= 0;
	 break;
       }
     }

     if(y) Kword= KW_IDENTIFIER;

   }
 }

/*d*    if(Fls) fprintf(Fls,"getNextToken:Kword=%d Kiden=%s\n",
			 Kword,KeyTab[Kword]);
/**/


  return(0);
}

#endif










#if SLLAN

/* 23.09.92   */

int getNextToken()
{
  register int y,i,s;

  if(iseof()) {
    Kword= KW_WRONGKEYWORD;
    return(0);
  }

  if(isleftparenthesisTermToken()) {
	/*    flleftparenthesisTermToken();*/	  
	/*    getkwc();*/
    flleftparenthesisTermToken();
    Kword= KW_LEFTPARENTHESISTERMTOKEN;
  }
  else if(isstringToken()){
    if(s= getstring(&CurString)) return(s);
    Kword= KW_STRINGTOKEN;
  }
  else if(isintegerToken()){
    if(s= getint()) return(s);
/*
    if(Modeintfloat)
      Kword= KW_FLOATTOKEN;
    else
*/
      Kword= KW_INTEGERTOKEN;

  }
  else if(istermToken()) {
    if(ApostropheMode) {
      /* language mode */
      if(Line[Npos+2] == '\'') {
	if(s= getterm()) return(s);
	Kword= KW_TERMTOKEN;
      }
      else {
	flapostropheTermToken();
	Kword= KW_APOSTROPHETERMTOKEN;
      }
    }
    else {
      if(s= getterm()) return(s);
      Kword= KW_TERMTOKEN;
    }
  }
  else if(isquotationTermToken()) {
    flquotationTermToken();
    Kword= KW_QUOTATIONTERMTOKEN;
  }
  else if(issharpTermToken()) {
    flsharpTermToken();
    Kword= KW_SHARPTERMTOKEN;
  }
  else if(isampersandampersandTermToken()) {
    flampersandampersandTermToken();
    Kword= KW_AMPERSANDAMPERSANDTERMTOKEN;
  }
  else if(isampersandequalTermToken()) {
    flampersandequalTermToken();
    Kword= KW_AMPERSANDEQUALTERMTOKEN;
  }
  else if(isampersandTermToken()) {
    flampersandTermToken();
    Kword= KW_AMPERSANDTERMTOKEN;
  }
  else if(isrightparenthesisTermToken()) {
    flrightparenthesisTermToken();
    Kword= KW_RIGHTPARENTHESISTERMTOKEN;
  }
/*    **    *      **/
/*
  else if(isdoublestarexponentiateTermToken()) {
    fldoublestarexponentiateTermToken();
    Kword= KW_DOUBLESTAREXPONENTIATETERMTOKEN;
  }
*/
  else if(isstarmultiplyequalTermToken()) {
    flstarmultiplyequalTermToken();
    Kword= KW_STARMULTIPLYEQUALTERMTOKEN;
  }
  else if(isstarmultiplyTermToken()) {
    flstarmultiplyTermToken();
    Kword= KW_STARMULTIPLYTERMTOKEN;
  }
/*****/
  else if(isplusplusTermToken()) {
    flplusplusTermToken();
    Kword= KW_PLUSPLUSTERMTOKEN;
  }
  else if(isplusequalTermToken()) {
    flplusequalTermToken();
    Kword= KW_PLUSEQUALTERMTOKEN;
  }
  else if(isplusTermToken()) {
    flplusTermToken();
    Kword= KW_PLUSTERMTOKEN;
  }
  else if(iscommaTermToken()) {
    flcommaTermToken();
    Kword= KW_COMMATERMTOKEN;
  }
  else if(ishyphenminusmoreTermToken()) {
    flhyphenminusmoreTermToken();
    Kword= KW_HYPHENMINUSMORETERMTOKEN;
  }
  else if(ishyphenminusminusTermToken()) {
    flhyphenminusminusTermToken();
    Kword= KW_HYPHENMINUSMINUSTERMTOKEN;
  }
  else if(ishyphenminusequalTermToken()) {
    flhyphenminusequalTermToken();
    Kword= KW_HYPHENMINUSEQUALTERMTOKEN;
  }
  else if(ishyphenminusTermToken()) {
    flhyphenminusTermToken();
    Kword= KW_HYPHENMINUSTERMTOKEN;
  }
  else if(isdotpointperiodTermToken()) {
    fldotpointperiodTermToken();
    Kword= KW_DOTPOINTPERIODTERMTOKEN;
  }
/**    /=      /     **/
/*
  else if(isinequalityTermToken()) {
    flinequalityTermToken();
    Kword= KW_INEQUALITYTERMTOKEN;
  }
*/
  else if(isslashdivideequalTermToken()) {
    flslashdivideequalTermToken();
    Kword= KW_SLASHDIVIDEEQUALTERMTOKEN;
  }
  else if(isslashdivideTermToken()) {
    flslashdivideTermToken();
    Kword= KW_SLASHDIVIDETERMTOKEN;
  }
/******/
/** ::=    :=     :**/
  else if(isdefisTermToken()) {
    fldefisTermToken();
    Kword= KW_DEFISTERMTOKEN;
  }
/*
  else if(isvariableassignmentTermToken()) {
    flvariableassignmentTermToken();
    Kword= KW_VARIABLEASSIGNMENTTERMTOKEN;
  }
*/
  else if(iscolonTermToken()) {
    flcolonTermToken();
    Kword= KW_COLONTERMTOKEN;
  }
/***/
  else if(issemicolonTermToken()) {
    flsemicolonTermToken();
    Kword= KW_SEMICOLONTERMTOKEN;
  }
/**  <=   <>    < **/
/*
  else if(islessthanorequalsignalassignmentTermToken()) {
    fllessthanorequalsignalassignmentTermToken();
    Kword= KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN;
  }
  else if(isboxTermToken()) {
    flboxTermToken();
    Kword= KW_BOXTERMTOKEN;
  }
*/
  else if(islessthanlessequalTermToken()) {
    fllessthanlessequalTermToken();
    Kword= KW_LESSTHANLESSEQUALTERMTOKEN;
  }
  else if(islessthanlessTermToken()) {
    fllessthanlessTermToken();
    Kword= KW_LESSTHANLESSTERMTOKEN;
  }
  else if(islessthanequalTermToken()) {
    fllessthanequalTermToken();
    Kword= KW_LESSTHANEQUALTERMTOKEN;
  }
  else if(islessthanTermToken()) {
    fllessthanTermToken();
    Kword= KW_LESSTHANTERMTOKEN;
  }
/*****/
/* =>    = */
/*
  else if(isarrowTermToken()) {
    flarrowTermToken();
    Kword= KW_ARROWTERMTOKEN;
  }
*/
  else if(isequalequalTermToken()) {
    flequalequalTermToken();
    Kword= KW_EQUALEQUALTERMTOKEN;
  }
  else if(isequalTermToken()) {
    flequalTermToken();
    Kword= KW_EQUALTERMTOKEN;
  }
/****/
/** >=         > **/
/*
  else if(isgreaterthanorequalTermToken()) {
    flgreaterthanorequalTermToken();
    Kword= KW_GREATERTHANOREQUALTERMTOKEN;
  }
*/
  else if(isgreaterthangreaterequalTermToken()) {
    flgreaterthangreaterequalTermToken();
    Kword= KW_GREATERTHANGREATEREQUALTERMTOKEN;
  }
  else if(isgreaterthangreaterTermToken()) {
    flgreaterthangreaterTermToken();
    Kword= KW_GREATERTHANGREATERTERMTOKEN;
  }
  else if(isgreaterthanequalTermToken()) {
    flgreaterthanequalTermToken();
    Kword= KW_GREATERTHANEQUALTERMTOKEN;
  }
  else if(isgreaterthanTermToken()) {
    flgreaterthanTermToken();
    Kword= KW_GREATERTHANTERMTOKEN;
  }
/****/

/****************************************
  else if(isunderlineTermToken()) {
    flunderlineTermToken();
    Kword= KW_UNDERLINETERMTOKEN;
  }
/********************************************/

  else if(isverticalbarbarTermToken()) {
    flverticalbarbarTermToken();
    Kword= KW_VERTICALBARBARTERMTOKEN;
  }
  else if(isverticalbarequalTermToken()) {
    flverticalbarequalTermToken();
    Kword= KW_VERTICALBAREQUALTERMTOKEN;
  }
  else if(isverticalbarTermToken()) {
    flverticalbarTermToken();
    Kword= KW_VERTICALBARTERMTOKEN;
  }


  else if(isexclamationmarkequalTermToken()) {
    flexclamationmarkequalTermToken();
    Kword= KW_EXCLAMATIONMARKEQUALTERMTOKEN;
  }
  else if(isexclamationmarkTermToken()) {
    flexclamationmarkTermToken();
    Kword= KW_EXCLAMATIONMARKTERMTOKEN;
  }

  else if(isdollarTermToken()) {
    fldollarTermToken();
    Kword= KW_DOLLARTERMTOKEN;
  }

  else if(ispercentequalTermToken()) {
    flpercentequalTermToken();
    Kword= KW_PERCENTEQUALTERMTOKEN;
  }
  else if(ispercentTermToken()) {
    flpercentTermToken();
    Kword= KW_PERCENTTERMTOKEN;
  }

  else if(isquastionmarkcolonTermToken()) {
    flquastionmarkcolonTermToken();
    Kword= KW_QUASTIONMARKCOLONTERMTOKEN;
  }
  else if(isquastionmarkTermToken()) {
    flquastionmarkTermToken();
    Kword= KW_QUASTIONMARKTERMTOKEN;
  }

  else if(iscommercialatTermToken()) {
    flcommercialatTermToken();
    Kword= KW_COMMERCIALATTERMTOKEN;
  }
  else if(isleftsquarebracketTermToken()) {
    flleftsquarebracketTermToken();
    Kword= KW_LEFTSQUAREBRACKETTERMTOKEN;
  }
  else if(isleftbackslashTermToken()) {
    flleftbackslashTermToken();
    Kword= KW_LEFTBACKSLASHTERMTOKEN;
  }
  else if(isrightsquarebracketTermToken()) {
    flrightsquarebracketTermToken();
    Kword= KW_RIGHTSQUAREBRACKETTERMTOKEN;
  }

  else if(iscircumflexequalTermToken()) {
    flcircumflexequalTermToken();
    Kword= KW_CIRCUMFLEXEQUALTERMTOKEN;
  }
  else if(iscircumflexTermToken()) {
    flcircumflexTermToken();
    Kword= KW_CIRCUMFLEXTERMTOKEN;
  }

/*
  else if(isgraveaccentTermToken()) {
    flgraveaccentTermToken();
    Kword= KW_GRAVEACCENTTERMTOKEN;
  }
*/

  else if(isleftbraceTermToken()) {
    flleftbraceTermToken();
    Kword= KW_LEFTBRACETERMTOKEN;
  }
  else if(isrightbraceTermToken()) {
    flrightbraceTermToken();
    Kword= KW_RIGHTBRACETERMTOKEN;
  }

  else if(istildeequalTermToken()) {
    fltildeequalTermToken();
    Kword= KW_TILDEEQUALTERMTOKEN;
  }
  else if(istildeTermToken()) {
    fltildeTermToken();
    Kword= KW_TILDETERMTOKEN;
  }

  else {
/*   Kword= KW_IDENTIFIER; */
/*   if(s= getkwc()) return(s); */
   if(s= getid()) return(s);

   if(lexsear(Id)) {
     Kword= KW_IDENTIFIER;
   }
   else {
     /* search terminals(reserve words) */
     y= 1;
     for(i= 0; i < LENTABLEKEYWORD; i++) {


/*d* 
if(Fls) fprintf(Fls,"getN:i= %d Kword=%d Kiden=%s keyword[i]=%d t=%s\n",
		i,Kword,KeyTab[Kword],
		KeyTabkeyword[i],
		KeyTab[KeyTabkeyword[i]]);
/**/

       if(Kword == KeyTabkeyword[i]) {
	 y= 0;
	 break;
       }
     }

     if(y) Kword= KW_IDENTIFIER;

   }
 }

/*d*    if(Fls) fprintf(Fls,"getNextToken:Kword=%d Kiden=%s\n",
			 Kword,KeyTab[Kword]);
/**/


  return(0);
}

#endif


/* 2010.05.31 ::: */
#if XMLLAN

int getNextToken()
{
  register int y,i,s;

  if(iseof()) {
    Kword= KW_WRONGKEYWORD;
    return(0);
  }

  /*
  fprintf(Fls, "getNextToken():%ld:%ld Kw:%ld(%ld)\n"
		  , xmlTokenFlag, CurXmlToken, Kword, KW_XMLTOKEN);
  if (xmlTokenFlag) {
    if (s = getxmltoken(&CurXmlToken)) return(s);
    Kword = KW_XMLTOKEN;
    return(0);
  }
  */
  /*
  fprintf(Fls, "getNextToken():0:%ld:%ld Kw:%ld(%ld)\n"
		  , xmlTokenFlag, CurXmlToken, Kword, KW_XMLTOKEN);
  */

  if(isleftparenthesisTermToken()) {
	/*    flleftparenthesisTermToken();*/	  
	/*    getkwc();*/
    flleftparenthesisTermToken();
    Kword= KW_LEFTPARENTHESISTERMTOKEN;
  }
  else if(isstringToken()){
    if(s= getstring(&CurString)) return(s);
    Kword= KW_STRINGTOKEN;
  }
  else if(isintegerToken()){
    if(s= getint()) return(s);

/*
    if(Modeintfloat)
      Kword= KW_FLOATTOKEN;
    else
*/
      Kword= KW_INTEGERTOKEN;
  }
  else if(istermToken()) {
    if(ApostropheMode) {
      /* language mode */
      if(Line[Npos+2] == '\'') {
	if(s= getterm()) return(s);
	Kword= KW_TERMTOKEN;
      }
      else {
	flapostropheTermToken();
	Kword= KW_APOSTROPHETERMTOKEN;
      }
    }
    else {
      if(s= getterm()) return(s);
      Kword= KW_TERMTOKEN;
    }
  }
  else if(isquotationTermToken()) {
    flquotationTermToken();
    Kword= KW_QUOTATIONTERMTOKEN;
  }
  else if(issharpTermToken()) {
    flsharpTermToken();
    Kword= KW_SHARPTERMTOKEN;
  }
  else if(isampersandTermToken()) {
    flampersandTermToken();
    Kword= KW_AMPERSANDTERMTOKEN;
  }
  else if(isrightparenthesisTermToken()) {
    flrightparenthesisTermToken();
    Kword= KW_RIGHTPARENTHESISTERMTOKEN;
  }
/*    **    *      **/
  else if(isdoublestarexponentiateTermToken()) {
    fldoublestarexponentiateTermToken();
    Kword= KW_DOUBLESTAREXPONENTIATETERMTOKEN;
  }
  else if(isstarmultiplyTermToken()) {
    flstarmultiplyTermToken();
    Kword= KW_STARMULTIPLYTERMTOKEN;
  }
/*****/
  else if(isplusTermToken()) {
    flplusTermToken();
    Kword= KW_PLUSTERMTOKEN;
  }
  else if(iscommaTermToken()) {
    flcommaTermToken();
    Kword= KW_COMMATERMTOKEN;
  }
  else if(ishyphenminusTermToken()) {
    flhyphenminusTermToken();
    Kword= KW_HYPHENMINUSTERMTOKEN;
  }
  else if(isdotpointperiodTermToken()) {
    fldotpointperiodTermToken();
    Kword= KW_DOTPOINTPERIODTERMTOKEN;
  }
/**    /=      /     **/
  else if(isinequalityTermToken()) {
    flinequalityTermToken();
    Kword= KW_INEQUALITYTERMTOKEN;
  }
  else if(isslashdivideTermToken()) {
    flslashdivideTermToken();
    Kword= KW_SLASHDIVIDETERMTOKEN;
  }
/******/
/** ::=    :=     :**/
  else if(isdefisTermToken()) {
    fldefisTermToken();
    Kword= KW_DEFISTERMTOKEN;
  }
  else if(isvariableassignmentTermToken()) {
    flvariableassignmentTermToken();
    Kword= KW_VARIABLEASSIGNMENTTERMTOKEN;
  }
  else if(iscolonTermToken()) {
    flcolonTermToken();
    Kword= KW_COLONTERMTOKEN;
  }
/***/
  else if(issemicolonTermToken()) {
    flsemicolonTermToken();
    Kword= KW_SEMICOLONTERMTOKEN;
  }
/**  <=   <>    < **/
  /* 2010.05.27 */
  /**  <=   <>    </ < **/
  else if(islessthanorequalsignalassignmentTermToken()) {
    fllessthanorequalsignalassignmentTermToken();
    Kword= KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN;
  }
  else if(isboxTermToken()) {
    flboxTermToken();
    Kword= KW_BOXTERMTOKEN;
  }
  /* 2010.05.27 */
  else if(isxmlEndTermToken()) {
	flxmlEndTermToken();
    Kword= KW_XMLENDTERMTOKEN;
  }  
  else if(islessthanTermToken()) {
    fllessthanTermToken();
    Kword= KW_LESSTHANTERMTOKEN;
  }
/*****/
/* =>    = */
  else if(isarrowTermToken()) {
    flarrowTermToken();
    Kword= KW_ARROWTERMTOKEN;
  }
  else if(isequalTermToken()) {
    flequalTermToken();
    Kword= KW_EQUALTERMTOKEN;
  }
/****/
/** >=         > **/
  else if(isgreaterthanorequalTermToken()) {
    flgreaterthanorequalTermToken();
    Kword= KW_GREATERTHANOREQUALTERMTOKEN;
  }
  else if(isgreaterthanTermToken()) {
	xmlTokenStart = Npos;
    flgreaterthanTermToken();
    Kword= KW_GREATERTHANTERMTOKEN;
  }
/****/
  else if(isunderlineTermToken()) {
    flunderlineTermToken();
    Kword= KW_UNDERLINETERMTOKEN;
  }
  else if(isverticalbarTermToken()) {
    flverticalbarTermToken();
    Kword= KW_VERTICALBARTERMTOKEN;
  }
  else if(isexclamationmarkTermToken()) {
    flexclamationmarkTermToken();
    Kword= KW_EXCLAMATIONMARKTERMTOKEN;
  }
  else if(isdollarTermToken()) {
    fldollarTermToken();
    Kword= KW_DOLLARTERMTOKEN;
  }
  else if(ispercentTermToken()) {
    flpercentTermToken();
    Kword= KW_PERCENTTERMTOKEN;
  }
  else if(isquastionmarkTermToken()) {
    flquastionmarkTermToken();
    Kword= KW_QUASTIONMARKTERMTOKEN;
  }
  else if(iscommercialatTermToken()) {
    flcommercialatTermToken();
    Kword= KW_COMMERCIALATTERMTOKEN;
  }
  else if(isleftsquarebracketTermToken()) {
    flleftsquarebracketTermToken();
    Kword= KW_LEFTSQUAREBRACKETTERMTOKEN;
  }
  else if(isleftbackslashTermToken()) {
    flleftbackslashTermToken();
    Kword= KW_LEFTBACKSLASHTERMTOKEN;
  }
  else if(isrightsquarebracketTermToken()) {
    flrightsquarebracketTermToken();
    Kword= KW_RIGHTSQUAREBRACKETTERMTOKEN;
  }
  else if(iscircumflexTermToken()) {
    flcircumflexTermToken();
    Kword= KW_CIRCUMFLEXTERMTOKEN;
  }
  else if(isgraveaccentTermToken()) {
    flgraveaccentTermToken();
    Kword= KW_GRAVEACCENTTERMTOKEN;
  }
  else if(isleftbraceTermToken()) {
    flleftbraceTermToken();
    Kword= KW_LEFTBRACETERMTOKEN;
  }
  else if(isrightbraceTermToken()) {
    flrightbraceTermToken();
    Kword= KW_RIGHTBRACETERMTOKEN;
  }
  else if(istildeTermToken()) {
    fltildeTermToken();
    Kword= KW_TILDETERMTOKEN;
  }
  else {
	  
	   /*
	   fprintf(Fls, "getNextToken():1:%ld:%ld Kw:%ld(%ld)\n"
	 		  , xmlTokenFlag, CurXmlToken, Kword, KW_XMLTOKEN);
	   */
	   if (xmlTokenFlag) {
		  /*
	     if (s = getxmltoken(&CurXmlToken)) return(s);
	     Kword = KW_XMLTOKEN;
	     */
	     return(0);
	   }
	   /**/
	   
/*   Kword= KW_IDENTIFIER; */
/*   if(s= getkwc()) return(s); */
   if(s= getid()) return(s);

   if(lexsear(Id)) {
     Kword= KW_IDENTIFIER;
   }
   else {

     /* search terminals(reserve words) */
     y= 1;
     for(i= 0; i < LENTABLEKEYWORD; i++) {


/*d* 
if(Fls) fprintf(Fls,"getN:i= %d Kword=%d Kiden=%s keyword[i]=%d t=%s\n",
		i,Kword,KeyTab[Kword],
		KeyTabkeyword[i],
		KeyTab[KeyTabkeyword[i]]);
/**/

       if(Kword == KeyTabkeyword[i]) {
	 y= 0;
	 break;
       }
     }

     if(y) Kword= KW_IDENTIFIER;

   }
 }

/*d*    if(Fls) fprintf(Fls,"getNextToken:Kword=%d Kiden=%s\n",
			 Kword,KeyTab[Kword]);
/**/


  return(0);
}

#endif
/* 2010.05.31 ... */


/*  end of lexical level */







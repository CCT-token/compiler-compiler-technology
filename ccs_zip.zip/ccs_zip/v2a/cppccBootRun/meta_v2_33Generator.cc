/////////////////////////////////////////////////////////////////////
//  meta_v2_33Generator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "meta_v2_33Parser.h"
#include "meta_v2_33KeyWordDefinition.h"
#include "meta_v2_33Generator.h"

namespace cppcc {
namespace meta_v2_33 {

void
meta_v2_33GeneratorBinary::generate(const std::string& filename)
{
}

}
}

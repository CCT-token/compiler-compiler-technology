/////////////////////////////////////////////////////////////////////
//  meta_v2_33Generator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_meta_v2_33_GENERATOR_H_
#define  _CPPCC_meta_v2_33_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace meta_v2_33 {

	class meta_v2_33GeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		meta_v2_33GeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~meta_v2_33GeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class meta_v2_33GeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		meta_v2_33GeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~meta_v2_33GeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


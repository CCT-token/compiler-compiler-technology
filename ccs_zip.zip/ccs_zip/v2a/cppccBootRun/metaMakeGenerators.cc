/////////////////////////////////////////////////////////////////////
//  metaMakeGenerators.cc
//
//      Change history:
//              2010.06.12              - Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metaParser.h"
#include "metaKeyWordDefinition.h"
#include "metaGenerator.h"

namespace cppcc {


namespace com {

cppcc::gen::GeneratorRuntime*
makeRuntimeGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta
    ::metaGeneratorRuntime(generator);
}

cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta
    ::metaGeneratorBinary(generator);
}
}

}

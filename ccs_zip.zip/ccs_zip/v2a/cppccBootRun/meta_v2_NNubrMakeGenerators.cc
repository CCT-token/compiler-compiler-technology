/////////////////////////////////////////////////////////////////////
//  meta_v2_NNubrMakeGenerators.cc
//
//      Change history:
//              2010.06.12              - Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "meta_v2_NNubrParser.h"
#include "meta_v2_NNubrKeyWordDefinition.h"
#include "meta_v2_NNubrGenerator.h"

namespace cppcc {


namespace com {

cppcc::gen::GeneratorRuntime*
makeRuntimeGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta_v2_NNubr
    ::meta_v2_NNubrGeneratorRuntime(generator);
}

cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta_v2_NNubr
    ::meta_v2_NNubrGeneratorBinary(generator);
}
}

}

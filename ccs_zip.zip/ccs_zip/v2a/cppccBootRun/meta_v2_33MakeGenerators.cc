/////////////////////////////////////////////////////////////////////
//  meta_v2_33MakeGenerators.cc
//
//      Change history:
//              2010.06.12              - Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "meta_v2_33Parser.h"
#include "meta_v2_33KeyWordDefinition.h"
#include "meta_v2_33Generator.h"

namespace cppcc {


namespace com {

cppcc::gen::GeneratorRuntime*
makeRuntimeGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta_v2_33
    ::meta_v2_33GeneratorRuntime(generator);
}

cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator)
{
  return new cppcc::meta_v2_33
    ::meta_v2_33GeneratorBinary(generator);
}
}

}

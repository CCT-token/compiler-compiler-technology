/////////////////////////////////////////////////////////////////////
//  metaGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metaParser.h"
#include "metaKeyWordDefinition.h"
#include "metaGenerator.h"

namespace cppcc {
namespace meta {

void
metaGeneratorBinary::generate(const std::string& filename)
{
}

}
}

////////////////////////////////////////////////////////////////////////
// C++ copmiler compiler binary test
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

//#include "metaFirstParser.h"
#include "metaFirstKeyWordDefinition.h"

namespace cppcc {
namespace test {


struct IRun
{
	virtual void run() = 0;
	virtual ~IRun() {}
};

struct ParserTest : public IRun
{
	typedef std::vector<cppcc::scr::tag::Long>	TagVector;
	  
	cppcc::cmd::Shell 			sh_;
	cppcc::syn::Parser&			parser_;
	std::string					filename_;
	
	ParserTest(int argc, char** argv)
		: sh_(argc, argv)
	    , parser_(*sh_.compilers_[0]->parser_)
	    , filename_(sh_.files_[0]) 
	{}
	
	~ParserTest() {}
	
	void run();

	  
	  void dumpVector(const std::vector<cppcc::scr::tag::Long>& f) 
	  {
		//cppcc::syn::Parser&	parser_ = *sh_.compilers_[0]->parser_;
		std::cout
		  << "---------:::::::::--------------"
		  << "dumpVector:" << f.size()
		  << std::endl;

		for (register std::size_t i = 0, s = f.size(); i < s; i++) {
			std::cout
			  << "--------------------------------"
			  << "dumpVector:" << i
			  << std::endl;

			parser_.runtime_.dumpToken(std::cout, f[i]);
		}
		std::cout
		  << "---------...........------------"
		  << "dumpVector:" << f.size()
		  << std::endl;

	  }
	  
	  void		integerToken(cppcc::scr::tag::Long&	tag, cppcc::scr::tag::Long v)
	  {
		  parser_.tokenizer_.kword_ = cppcc::com::PLS_INTEGER_TOKEN;
		  parser_.tokenizer_.modeintfloat_ = 0;
		  parser_.tokenizer_.ival_ = v;
		  
		  parser_.integerTokenAction(tag);
	  }
	  
	  void 		stringToken(cppcc::scr::tag::Long&	tag, const std::string& ss)
	  {
		  parser_.tokenizer_.kword_ = cppcc::com::PLS_STRING_TOKEN;
		  parser_.tokenizer_.modeintfloat_ = 0;
		  parser_.tokenizer_.strng_ = ss;
		  
		  parser_.stringTokenAction(tag);
		  
	  }
	  
	  void		identifier(cppcc::scr::tag::Long&	tag, const std::string& id)
	  {
		  parser_.tokenizer_.id_ = id;
		  parser_.identifier(tag);
		  
		  parser_.identifierAction(tag);
	  }
	  
	  void		METAACTENDforTesting()
	  {
		  // (A)
		  parser_.runtime_.edfnmst("floatToken",0);
		  parser_.runtime_.edfnmst("xmlToken",0);
		  parser_.runtime_.edfnmst("integerToken",0);
		  
		  parser_.generateBinaryFromRuntime();
		  
		  cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
			parser_.runtime_.cnms_.dataByKey
			  (parser_.runtime_.cnmnumCurrent_);
		  
		  //std::cout << currentContext.namn_ << std::endl;
		  std::cout << "***********************************************" 
				  << std::endl;
		  currentContext.namn_.dump();
		  std::cout << "***********************************************" 
				  << std::endl;

		  std::cout << parser_.binary_;
		  
		  bool isTesting = true;
		  if (isTesting) {
			  std::string dName =  filename_ + ".ubrt";
			  parser_.generator_.decompileBinary(dName);   		  
		  }

	  }
	  
	  //---------------------------------------------
	  void test1() {
		//cppcc::cmp::Compiler&	compiler = 
		//		*sh_.compilers_[0];
		//cppcc::syn::Parser&	parser_ = *sh_.compilers_[0]->parser_;
				
			std::cout
				<< "ParserTest:test1"
				<< " filename:" << "'" << filename_ << "'"
			  	<< std::endl;
			
			parser_.METAACTBEG();
			
			std::vector<cppcc::scr::tag::Long> d(4);
			
			identifier(d[0], "id001");
			identifier(d[1], "id002");
			identifier(d[2], "id022");
			identifier(d[3], "id33333333333");
						
			d.push_back(0); identifier(d.back(), "lastoneAAAlastoneBBB");
			
			dumpVector(d);
			
			std::vector<cppcc::scr::tag::Long> f(2);
			cppcc::scr::tag::setedflong
				(&f[0],cppcc::com::PLS_TERMINAL_TOKEN
				     ,cppcc::metafirst::KW_LEFTPARENTHESIS_TERMTOKEN);
			identifier(f[1], "testtesttest");
			
			parser_.crelasedp(cppcc::metafirst::KW_GRAMMAR_NON_TERMINAL,f,d,
			&parser_.axiom_);
			
			//parser_.runtime_.dump(std::cout);		 
			
			METAACTENDforTesting();
	  }
	  
	  void test2() {
		//cppcc::syn::Parser&	parser_ = *sh_.compilers_[0]->parser_;
			std::cout
				<< "ParserTest:test2"
				<< " filename:" << "'" << filename_ << "'"
			  	<< std::endl;
			
			parser_.METAACTBEG();
			
			std::vector<cppcc::scr::tag::Long> f(4);
			for (std::size_t i =0, s = f.size(); i < s; i++) {
				integerToken(f[i], 1000 + i*10);
			}
			
			f.push_back(0); 
			integerToken(f.back(), 1111111);
			
			
			f.push_back(0); 
			integerToken(f.back(), 2222222);
			
			dumpVector(f);
			
			parser_.runtime_.dump(std::cout);	
			
			METAACTENDforTesting();

	  }
	  
	  
	  
};

}
}

//-------------------------------
namespace cppcc {
namespace test {

void 
ParserTest::run()
{
	std::cout
		<< "ParserTest:run"
	  	<< std::endl;

	test1();
	//test2();
	
}


}
}


int	main(int argc, char** argv)
{
  try {
	  //cppcc::cmd::Shell sh(argc, argv);
	  
	  //sh.run();
	  
	  cppcc::test::ParserTest t(argc, argv);
	  
	  t.run();
	  
	  return 0;
  } 
  catch(const std::exception& e)
  {
    std::cerr << e.what() << std::endl;
	return 1;
  }
  catch(...) {
	std::cerr << "Terminated with uncaught exception!" << std::endl;
	return 1;	
  }

  return 0;
}

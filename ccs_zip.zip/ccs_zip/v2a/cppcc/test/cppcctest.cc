////////////////////////////////////////////////////////////////////////
// C++ copmiler compiler test
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "SyntaxControlledRuntime.h"

namespace cppcc {
namespace test {


struct IRun
{
	virtual void run() = 0;
	virtual ~IRun() {}
};

struct SyntaxControlledRuntimeTest : public IRun
{
	typedef std::vector<cppcc::scr::tag::Long>	TagVector;
	  
	cppcc::scr::SyntaxControlledRuntime   	runtime_;
	cppcc::scr::tag::Long					context_;
	
	SyntaxControlledRuntimeTest()
		: runtime_()
		, context_(0) 
	{}
	
	~SyntaxControlledRuntimeTest() {}
	
	void run();
	
	  
	  void 		METAACTBEG()
	  {
		  runtime_.edfcnst(&context_);
	  }
	  
	  void		METAACTEND()
	  {
		  // (A)
		  runtime_.edfnmst("floatToken",0);
		  runtime_.edfnmst("xmlToken",0);
		  runtime_.edfnmst("integerToken",0);
	  }
	  
	  void		crelasedp
		(int 		k
		,TagVector&	f
		,TagVector&	d
		,cppcc::scr::tag::Long* l
		)
	  {		  
		cppcc::scr::tag::Long r;		  
		runtime_.celedpfst(0, k, &r, f); 
		cppcc::scr::SyntaxControlledRuntime::edp& e = runtime_.celedpfnd(&r);
		runtime_.edfeptd(e, d);		  
		if (l) *l = r;
	  } 
	  
	  void 		crefixe
	    (int		k
	    ,TagVector&	f
	    ,cppcc::scr::tag::Long* l
		)
	  {
		  runtime_.celedpfst(1, k, l, f);
	  }
	  
	  
	  void		crelasdyn
		(int 					k
		,TagVector&				d
		,cppcc::scr::tag::Long* l
		)
	  {
		  std::vector<cppcc::scr::tag::Long> f;
		  cppcc::scr::tag::Long r;
		  runtime_.celedpfst(0, k, &r, f);  
		  cppcc::scr::SyntaxControlledRuntime::edp& e = runtime_.celedpfnd(&r);
		  runtime_.edfeptd(e, d);
		  if (l) *l = r;	  
	  }	  
	  
	  
	  void		identifier
		(const std::string& 	id
		,cppcc::scr::tag::Long&	tag)
	  {
		  cppcc::scr::tag::Long n;

		  //runtime_.edfnmst(tokenizer_.id_, &n);
		  runtime_.edfnmst(id, &n);
		  		  
		  cppcc::scr::tag::setedflong(&tag, cppcc::com::PLS_IDENTIFIER, n);
		  
		  //tokenizer_.getNextToken();
	  }	  
	  
	  void		integerToken(int ival, cppcc::scr::tag::Long&	tag)
	  {
		  cppcc::scr::tag::Long	value = ival;

		  runtime_.celedpfst
			(0, cppcc::com::PLS_INTEGER_TOKEN, &tag, &value, 1);
	  }

	  
	  void		realToken(double rval, cppcc::scr::tag::Long&	tag)
	  {
		  cppcc::scr::tag::Real value = rval;

		  runtime_.celedpfst
			(0, cppcc::com::PLS_FLOAT_TOKEN, &tag,
			reinterpret_cast<cppcc::scr::tag::Long*>(&value), 1);
		  }
	  
	  void 		stringToken
		  (const std::string& 		strng
		  ,cppcc::scr::tag::Long&	tag)
	  {

		  runtime_.celedpfss
			(cppcc::com::PLS_STRING_TOKEN
			,&tag
			,strng
			);
		  
	  }
	 
	  void 		termToken
		  (const std::string& 		strng
		  ,cppcc::scr::tag::Long&	tag)
	  {
		  cppcc::scr::tag::Long n;	  		  
		  runtime_.edfnmst(strng, &n);
		  		  
		  cppcc::scr::tag::setedflong
		    (&tag 
			,cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
		    ,n);

	  }
	  
	  
	  void dumpVector(const std::vector<cppcc::scr::tag::Long>& f) 
	  {
		std::cout
		  << "---------:::::::::--------------"
		  << "dumpVector:" << f.size()
		  << std::endl;

		for (register std::size_t i = 0, s = f.size(); i < s; i++) {
			std::cout
			  << "--------------------------------"
			  << "dumpVector:" << i
			  << std::endl;

			runtime_.dumpToken(std::cout, f[i]);
		}
		std::cout
		  << "---------...........------------"
		  << "dumpVector:" << f.size()
		  << std::endl;

	  }
	  
	  
	  
	  //---------------------------------------------
	  void test1() {
			std::cout
				<< "SyntaxControlledRuntimeTest:test1"
			  	<< std::endl;
			
			METAACTBEG();
			
			std::vector<cppcc::scr::tag::Long> f(4);
			
			identifier("id001",f[0]);
			identifier("id002",f[1]);
			identifier("id022",f[2]);
			identifier("id33333333333",f[3]);
			f.push_back(0); identifier("lastoneAAAlastoneBBB",f.back());
			
			dumpVector(f);
			
			runtime_.dump(std::cout);		  
	  }
	  
	  void test2() {
			std::cout
				<< "SyntaxControlledRuntimeTest:test2"
			  	<< std::endl;
			
			METAACTBEG();
			
			std::vector<cppcc::scr::tag::Long> f(4);
			for (std::size_t i =0, s = f.size(); i < s; i++) {
				integerToken(1000 + i*10, f[i]);
			}
			
			f.push_back(0); integerToken(1111111,f.back());
			f.push_back(0); integerToken(2222222,f.back());
			
			dumpVector(f);
			
			runtime_.dump(std::cout);		  

	  }
	  
	  
	  
};

}
}

//-------------------------------
namespace cppcc {
namespace test {

void 
SyntaxControlledRuntimeTest::run()
{
	std::cout
		<< "SyntaxControlledRuntimeTest:run"
	  	<< std::endl;

	test1();
	//test2();
	
}


}
}


int	main(int argc, char** argv)
{
  try {
	  //cppcc::cmd::Shell sh(argc, argv);
	  
	  //sh.run();
	  
	  cppcc::test::SyntaxControlledRuntimeTest t1;
	  
	  //std::cout
	  //<< argv[0]
	  //<< std::endl;
	  t1.run();
	  
	  return 0;
  } 
  catch(const std::exception& e)
  {
    std::cerr << e.what() << std::endl;
	return 1;
  }
  catch(...) {
	std::cerr << "Terminated with uncaught exception!" << std::endl;
	return 1;	
  }

  return 0;
}

////////////////////////////////////////////////////////////////////////
// Shell.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"

// xml //
//#include "Tokenizer.h"

namespace cppcc {
namespace cmd {

  namespace {
	static const char* LOG_FILE_EXTENTION = ".log";
  
    cppcc::com::SHELL_CMD shellCmd(int argc, char** argv)
    {
      cppcc::com::SHELL_CMD cmd = cppcc::com::SHELL_CMD_COMPILE;
      if (argc > 1) {
    	  char*	a1 	= argv[1];
    	  char	a 	= a1[0];
    	  if ('-' == a) {
    	    char c = a1[1];
    	    cmd =
    	      (('u' == c) || ('U' == c))
    		    ? cppcc::com::SHELL_CMD_UNLOAD
    		    : cppcc::com::SHELL_CMD_COMPILE
    		;
    	  }
      }
      
      return cmd;
    }
    
    cppcc::com::LanguageTokenizerSet
    shellLanguageTokenizerSet(int argc, char** argv)
    {
    	cppcc::com::LanguageTokenizerSet r = 
    	  cppcc::com::LanguageTokenizerSet_Undefined;
    	
        if (argc > 1) {
      	  char*	a1 	= argv[1];
      	  char	a 	= a1[0];
      	  if ('-' == a) {
      	    char c = a1[1];
      	    if  (('l' == c) || ('L' == c)) {
      	      char b = a1[2];
      	      r =
      	        (('x' == b) || ('X' == b))
      		      ? cppcc::com::LanguageTokenizerSet_XML
      		      : ((('m' == b) || ('M' == b))
      		    	? cppcc::com::LanguageTokenizerSet_Meta
      		    	: cppcc::com::LanguageTokenizerSet_Undefined
      		      )
      		  ;
      	    }
      	  }
        }
   	
    	
    	return r;
    }
  
    std::vector<std::string> shellFiles(int argc, char** argv)
	{
      std::vector<std::string> files;
      
      if (argc > 1) {
    	  int 	i 	= 1;
    	  char*	a1 	= argv[i];
    	  char	a 	= a1[0];
    	  if ('-' == a) {
    	    i++;
    	  }
    	  
    	  std::size_t fsize = argc-i;
    	  files.resize(fsize);
    	  for (register std::size_t j = 0; j < fsize; j++) {
    		  files[j] = argv[j+i];
    	  }
      }
      
      return files;
	}
    
    std::string	defaultLogName(const std::string& name)
    {
      std::size_t slashPosition = name.find_last_of('/');
      if (std::string::npos == slashPosition) {
    	 return name + LOG_FILE_EXTENTION;
      }
      else {
    	 return name.substr(slashPosition+1) + LOG_FILE_EXTENTION;
      }
    }
    
    cppcc::log::Logger* shellLogger(int argc, char** argv)
	{
      std::string 				name  = argv[0];
      cppcc::log::Logger* log = 0;
      if (argc > 1) {
        std::vector<std::string> 	files = shellFiles(argc, argv);
        if (files.size() > 0) {
          std::string logName = files[files.size()-1] + LOG_FILE_EXTENTION;
          
          log = new cppcc::log::Logger
            (cppcc::com::LOGGER_LEVEL_DEBUG,logName,name);
        }
      }
      
      if (!log) {
    	  std::string logName = defaultLogName(name);
          log = new cppcc::log::Logger
            (cppcc::com::LOGGER_LEVEL_DEBUG,logName,name);  	 
      }
      
      return log;
	}
    
  }


Shell::Shell(int argc, char** argv)
  : cmd_(shellCmd(argc, argv))
  , files_(shellFiles(argc, argv))
  , name_(argv[0])
  , logger_(shellLogger(argc, argv))
  , compilers_()
  // xml //
  , tokensSetID_(shellLanguageTokenizerSet(argc, argv))
{
	/////std::cout << "Shell:" << tokensSetID_ << std::endl;
  makeCompilers();
}

Shell::~Shell()
{
  try {
	CPPCC_LOG_INFO((*logger_),
	  << name_
      << " finished..."
	)
		
	for (register int i = 0, s = compilers_.size(); i < s; i++) {
	  if(compilers_[i]) {
	    delete compilers_[i];
	    compilers_[i] = 0;       
	  }
	}
	
    if (logger_) {
      delete logger_;
      logger_ = 0;
    }
    
  }
  catch(...)
  {
  }
}

void
Shell::run()
{
  if (0) {
    std::cout
	  << name_ 
	  << " " << cmd_ 
	  << " " << files_.size()
	  << std::endl;
    for (register std::size_t i = 0, s = files_.size(); i < s; i++) {
        std::cout
    	  << name_ 
    	  << " " << files_[i]
    	  << std::endl;  	
    }
  }
  
  if (0) {
	CPPCC_LOG_INFO((*logger_),
	  << name_
	  << " started..."
	)
	
	
	CPPCC_LOG_DEBUG((*logger_),
	  << name_ 
	  << " " << cmd_ 
	  << " " << files_.size()
	)
	
    for (register std::size_t i = 0, s = files_.size(); i < s; i++) {
    	CPPCC_LOG_DEBUG((*logger_),
    	  << name_ 
    	  << " " << files_[i]
    	)	
    }
  }
  
  for (register int i = 0, s = compilers_.size(); i < s; i++) {
	if(compilers_[i]) {
	  compilers_[i]->run();
	}
  }
}

void
Shell::makeCompilers()
{
  compilers_.resize(1);
  compilers_[0] = new cppcc::cmp::Compiler(*this);
}



}
}
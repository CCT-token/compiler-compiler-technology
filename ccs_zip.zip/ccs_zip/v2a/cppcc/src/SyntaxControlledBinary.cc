////////////////////////////////////////////////////////////////////////
// SyntaxControlledBinary.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "SyntaxControlledBinary.h"
#include "TokenNames.h"

namespace cppcc {
namespace scb {

cppcc::scr::tag::Long* 
SyntaxControlledBinary::fixed_(edpirType* e)
{
  return
    e
      ? (
        e->fl
        ?(
            ((e->d >= 0) && (e->d < memory_.size()))
            ? &memory_[e->d]
            : 0
        )
        :0
      )
      : 0
  ;
}


cppcc::scr::tag::Long* 
SyntaxControlledBinary::fixed(edpirType* e)
{
	return fixed_(e);
}

cppcc::scr::tag::Long* 
SyntaxControlledBinary::dynamic_(edpirType* e)
{
  return
    e
      ? (
        e->dl
        ?(
             (((e->d + e->fl) >= 0) 
             && ((e->d + e->fl) < memory_.size()))
             ? &memory_[e->d + e->fl]
             : 0
         )
        :0
      )
      : 0
  ;
}

cppcc::scr::tag::Long* 
SyntaxControlledBinary::dynamic(edpirType* e)
{
  return dynamic_(e);
}

cppcc::scr::tag::TypeInstance& 
SyntaxControlledBinary::fixed
	 (edpirType* e, cppcc::scr::tag::Long i)
{
	if (!e) {
	  CPPCC_THROW_EXCEPTION(
	      << "Can't get fixed value for index:"
	      << i
	      << " - NULL edp pointer!"
	  )
	}
	
	cppcc::scr::tag::Long* f = fixed_(e);
	if (!f) {
	  CPPCC_THROW_EXCEPTION(
	      << "Can't get fixed value for index:"
	      << i
	      << " - NULL edp fixed array pointer!"
	  )
	}

	if (!e->fl) {
	  CPPCC_THROW_EXCEPTION(
		<< "Can't get fixed value for index:"
	    << i
	    << " - edp has no fixed array defined!"
	  )
	}
	
	if ((i < 0) || (i >= e->fl)) {
	  CPPCC_THROW_EXCEPTION(
		<< "Can't get fixed value for index:"
	    << i
	    << " - it's out off range:[.." << e->fl << ")!"
	  )
	}
	
	// OK - all checks passed.
	return (*((cppcc::scr::tag::TypeInstance*)(f+i)));
}

cppcc::scr::tag::TypeInstance& 
SyntaxControlledBinary::dynamic
	 (edpirType* e, cppcc::scr::tag::Long i)
{
	if (!e) {
	  CPPCC_THROW_EXCEPTION(
	      << "Can't get dynamic value for index:"
	      << i
	      << " - NULL edp pointer!"
	  )
	}
	
	cppcc::scr::tag::Long* d = dynamic_(e);
	if (!d) {
	  CPPCC_THROW_EXCEPTION(
	      << "Can't get dynamic value for index:"
	      << i
	      << " - NULL edp dynamic array pointer!"
	  )
	}

	if (!e->dl) {
	  CPPCC_THROW_EXCEPTION(
		<< "Can't get dynamic value for index:"
	    << i
	    << " - edp has no dynamic array defined!"
	  )
	}
	
	if ((i < 0) || (i >= e->dl)) {
	  CPPCC_THROW_EXCEPTION(
		<< "Can't get dynamic value for index:"
	    << i
	    << " - it's out off range:[.." << e->dl << ")!"
	  )
	}
	
	// OK - all checks passed.
	return (*((cppcc::scr::tag::TypeInstance*)(d+i)));
}


void 
SyntaxControlledBinary::writeBinary(const std::string& filename)
{
	std::ofstream		   	output;	
	
	output.open(filename.c_str());
	if (!output) {
	      std::string   syserr = cppcc::com::CPPCCException::systemError();     
	      CPPCC_THROW_EXCEPTION(
	      << "Can't open file for writing binary:'"
	      << filename
	      << "' - Reason:'"
	      << syserr
	      << "'"
	      )
	}

	for (register std::size_t i =0, z = memory_.size(); i < z; i++)
	{
		output << memory_[i] << std::endl;
	}
}

void 
SyntaxControlledBinary::readBinary(const std::string& filename)
{
	std::ifstream		   	input;	
	
	input.open(filename.c_str());
	if (!input) {
	      std::string   syserr = cppcc::com::CPPCCException::systemError();     
	      CPPCC_THROW_EXCEPTION(
	      << "Can't open file for reading binary:'"
	      << filename
	      << "' - Reason:'"
	      << syserr
	      << "'"
	      )
	}
	cppcc::scr::tag::Long	len;
	
	input >> len;
	memory_.resize(len);
	memory_[0] = len;
	for (register cppcc::scr::tag::Long i = 1; i < len; i++) 
	{
		input >> memory_[i];
	}
}

SyntaxControlledBinary::kwnirType*	
SyntaxControlledBinary::setptrkwn(const TagLong ppkw)
{
/*
	std::cout
	  << "setptrkwn"
	  << " ppkw:" << ppkw
	  << " h:" << (*uhead())
	  << " cntnkw:" << head()->cntnkw
	  << std::endl;
*/	  
	
	kwnirType* result = 0;
	for (register TagLong i = 0, s = head()->cntnkw; i < s; i++) {
		result = ptrkwn(i);

/*
		std::cout
		  << "setptrkwn"
		  << " ppkw:" << ppkw
		  << " h:" << (*uhead())
		  << " cntnkw:" << head()->cntnkw
		  << " i:" << i
		  << std::endl;

		if (result) {
			std::cout
			  << "setptrkwn"
			  << " ppkw:" << ppkw
			  << " h:" << (*uhead())
			  << " cntnkw:" << head()->cntnkw
			  << " i:" << i
			  << " result:" << (*result)
			  << std::endl;				
		}
*/		
		if (result && (result->k == ppkw)) {
			return result;
		}
	}
	return 0;
}

// SyntaxControlledBinary::Helper -----------------------------------------
void
SyntaxControlledBinary::Helper::populate()
{
  for (register std::size_t i = 0, z = ids_.size(); i < z; i++) {
	  ids_[i] = b_.ptrids(i);
  }
  
  for (register std::size_t i = 0, z = idn_.size(); i < z; i++) {
	  idn_[i] = b_.ptridn(i);
  }
   
  for (register std::size_t i = 0, z = idi_.size(); i < z; i++) {
	  idi_[i] = b_.ptridnum(i);
  }
  
  for (register std::size_t i = 0, z = h_.cntnkw; i < z; i++) {
	  SyntaxControlledBinary::kwnirType* kk = b_.ptrkwn(i);
	  kwn&	k = kwns_[kk->k];
	  k.k_ = kk;
  }
  
  for (register std::size_t i = 0, z = kwns_.size(); i < z; i++) {
	  kwn&	k = kwns_[i];
	  
	  //k.k_ = b_.ptrkwn(i);
	  ////k.k_ = b_.setptrkwn(i);	  
	  //123// k.b_ = &b_;
	  if (k.k_) {
	    k.edps_.resize(k.k_->l);
	    for (register std::size_t j = 0, z = k.edps_.size(); j < z; j++) {
	      edp& e = k.edps_[j];
	      e.e_ = b_.ptredp(k.k_, j);
	      e.b_ = &b_;
	    }
	  }
  }
}

//const SyntaxControlledBinary::contextType&
//SyntaxControlledBinary::Helper::h()
//{
////  const contextType*	r = b_.head();
//  if (!r) {
//	  CPPCC_THROW_EXCEPTION(
//	      << "Can't get SyntaxControlledBinary header!"
//	  )	  
//  }
// 
//  return (*r);
//}

SyntaxControlledBinary::Helper::kwn& 
SyntaxControlledBinary::Helper::k(const TagLong i)
{
	if ((i < 0) || (i >= kwns_.size())) {
		CPPCC_THROW_EXCEPTION(
		  << "Can't get kwn for index:"
		  << i
		  << " - it's out off range:[.." << kwns_.size() << ")!"
        )		
	}
	
	return kwns_[i];
}

SyntaxControlledBinary::Helper::edp& 
SyntaxControlledBinary::Helper::kwn::e(const TagLong i)
{
	if ((i < 0) || (i >= edps_.size())) {
		CPPCC_THROW_EXCEPTION(
		  << "Can't get edp for index:"
		  << i
		  << " - it's out off range:[.." << edps_.size() << ")!"
		  << " " << (*k_)
        )		
	}
	
	return edps_[i];
}

//SyntaxControlledBinary::kwnirType& 
//SyntaxControlledBinary::Helper::kwn::k()
//{
//	if (!k_) {
//		CPPCC_THROW_EXCEPTION(
//		  << "NULL kwn pointer!"
//		)		
//	}
//	
//	return (*k_);
//}

SyntaxControlledBinary::edpirType& 
SyntaxControlledBinary::Helper::edp::e()
{
	if (!e_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL edp pointer!"
		)		
	}
	
	return (*e_);
}

SyntaxControlledBinary::TagLong* 	   	
SyntaxControlledBinary::Helper::edp::fixed()
{
	if (!e_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL edp pointer!"
		)		
	}
	
	if (!b_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL binary pointer!"
		)		
	}


 	return b_->fixed(e_);	
}

SyntaxControlledBinary::TagLong* 		
SyntaxControlledBinary::Helper::edp::dynamic()
{
	if (!e_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL edp pointer!"
		)		
	}
	
	if (!b_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL binary pointer!"
		)		
	}

 	return b_->dynamic(e_);		
}

SyntaxControlledBinary::TagInstance&  	
SyntaxControlledBinary::Helper::edp::fixed(const TagLong i)
{
	if (!e_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL edp pointer!"
		)		
	}
	
	if (!b_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL binary pointer!"
		)		
	}

 	return b_->fixed(e_, i);		
}

SyntaxControlledBinary::TagInstance&  	
SyntaxControlledBinary::Helper::edp::dynamic(const TagLong i)
{
	if (!e_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL edp pointer!"
		)		
	}
	
	if (!b_) {
		CPPCC_THROW_EXCEPTION(
		  << "NULL binary pointer!"
		)		
	}

 	return b_->dynamic(e_, i);		
}

const char* 
SyntaxControlledBinary::Helper::id(const TagLong i)
{
	if ((i < 0) || (i >= ids_.size())) {
		CPPCC_THROW_EXCEPTION(
		  << "Can't get identifier for index:"
		  << i
		  << " - it's out off range:[.." << ids_.size() << ")!"
        )		
	}
	
	return ids_[i];	
}

void 
SyntaxControlledBinary::Helper::dump(std::ostream&  strm)
{
  strm << "SyntaxControlledBinary::dump()-----------------------" << std::endl;
  strm << h_ << std::endl;
  
  for (register std::size_t i = 0, z = ids_.size(); i < z; i++) {
	  //ids_[i] = b_.ptrids(i);
	  strm << "ids:" << i << "'" << ids_[i] << "'" << std::endl;
  }
  strm << std::endl;
  
  for (register std::size_t i = 0, z = idn_.size(); i < z; i++) {
	  //idn_[i] = b_.ptridn(i);
	  strm << "idn:" << i << "'" << idn_[i] << "'" << std::endl;
  }
  strm << std::endl;
   
  for (register std::size_t i = 0, z = idi_.size(); i < z; i++) {
	  //idi_[i] = b_.ptridnum(i);
	  strm << "idi:" << i << "'" << idi_[i] << "'" << std::endl;
  }
  strm << std::endl;
  
  for (register std::size_t i = 0, z = h_.cntnkw; i < z; i++) {
	  SyntaxControlledBinary::kwnirType* kk = b_.ptrkwn(i);
	  //kwn&	k = kwns_[kk.k];
	  //k.k_ = kk;
	  strm << "kwn:" << i << " --> " << kk->k << std::endl;
  }
  strm << std::endl;
  
  for (register std::size_t i = 0, z = kwns_.size(); i < z; i++) {
	  kwn&	k = kwns_[i];
	  
	  strm 
		  << "kwn:" << i << " " 
		  << std::string(k.k_?("ALLOCATED"):("NULL")) 
		  << std::endl;
	  
	  //k.k_ = b_.ptrkwn(i);
	  ////k.k_ = b_.setptrkwn(i);	  
	  //123// k.b_ = &b_;
	  if (k.k_) {
		  
		  strm 
			  << "kwn:" << i << " " 
			  << (*(k.k_))
			  << std::endl;

	    //k.edps_.resize(k.k_->l);
	    for (register std::size_t j = 0, z = k.edps_.size(); j < z; j++) {
	      edp& e = k.edps_[j];
	      //e.e_ = b_.ptredp(k.k_, j);
	      //e.b_ = &b_;
		  strm 
			  << "kwn:" << i << " " 
			  << " " << "edp:" << j 
			  << std::endl;
		  strm 
			  << "kwn:" << i << " " 
			  << " " << "edp:" << j
			  //<< " " << (*e.e_)
			  << " " << e.e()
			  << std::endl;
		  b_.edpDump(strm,e.e());
	    }
	  }
  }
}

// SyntaxControlledBinary::Helper -----------------------------------------

//-------------------
}
}


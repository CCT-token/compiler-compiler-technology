////////////////////////////////////////////////////////////////////////
// SyntaxControlledRuntime.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "SyntaxControlledRuntime.h"


////////////////////////////////////////////////////////////////////////////
//	scr - Syntax Controlled Runtime
////////////////////////////////////////////////////////////////////////////
//       
//
//      sys |--------|        |--------|cnm     |--------|nam
//          |        |------->| cnmnum |------->| namnum |
//          |        |  cnms  |        |  namn  | namkey |
//          |        |        |        |------->| namend |*
//          |        |        |        |  nams  | namsou |*
//          |--------|        |--------|        |--------|
//                                |kwns
//                                V
//                            |--------|kwn     |--------|edp
//                            | kwnnum |------->| edpnum |
//                            |        |  edps  | edpfix |*
//                            |--------|        | edpdyn |*
//                                              |--------|
//
////////////////////////////////////////////////////////////////////////////


namespace cppcc {
namespace scr {

namespace {
	static const tag::Long InitialContextNumber = 0;
	static const tag::Long InitialEdpNumber = -1;
}

////////////////////////////////////////////////////////////////////////////
// Create new 'cnm' instance.
////////////////////////////////////////////////////////////////////////////
void
SyntaxControlledRuntime::edfcnst(tag::Long* l)
{
	cnm c;

	/*
	c.cnmnum_ =
	    l
	      ? (cnms_.index2name.size()
	          ? cnms_.index2name[cnms_.index2name.size()-1]
	          : InitialContextNumber
	      )
	      : InitialContextNumber
	  ;
	*/
	c.cnmnum_ = cnms_.lastKey(l,InitialContextNumber);
	c.cnmnum_++;
	cnms_.store(c, c.cnmnum_);
	  
	if (l) *l = c.cnmnum_;
	cnmnumCurrent_ = c.cnmnum_;
	
	if (debug_) {
		std::cout 
		<< "edfcnst:"
		<< " cnmnum:" << c.cnmnum_
		<< " cnmnumCurrent_:" << cnmnumCurrent_
		<< std::endl;
	}

	return;
}

////////////////////////////////////////////////////////////////////////////
// Create new 'edp' instance for the given key word 'k' 
//	and a current context.
////////////////////////////////////////////////////////////////////////////
void 
SyntaxControlledRuntime::edfepst(tag::Long k,tag::Long* l)
{
	// wrong: ?????????????????? ----
  ///cnm&	currentContext = cnms_.dataByIndex(cnmnumCurrent_);
  cnm&	currentContext = cnms_.dataByKey(cnmnumCurrent_);
  
/*
  tag::Long idx;
  if (!currentContext.kwns_.lookup(k,idx)) {
	  kwn kwnNew;
	  kwnNew.cnmnum_ = cnmnumCurrent_;
	  kwnNew.kwnnum_ = k;
	  currentContext.kwns_.store(kwnNew, k);
	  idx = currentContext.kwns_.index2data.size() - 1;
  }
  
  kwn& kwnInstance = currentContext.kwns_.dataByIndex(idx);
*/
  kwn& kwnInstance = kwnLookup(k);
  
  edp e;
  e.cnmnum_ = cnmnumCurrent_;
  //!! e.kwnnum_ = idx;
  e.kwnnum_ = k;  
  /*
  e.edpnum_ =
    kwnInstance.edps_.size()
	  ? kwnInstance.edps_[kwnInstance.edps_.size() - 1]
	  : 0
  ;
  */
  //e.edpnum_ = kwnInstance.edps_.lastKey(0);
  e.edpnum_ = kwnInstance.edps_.lastKey(InitialEdpNumber);
  e.edpnum_++;
  
  kwnInstance.edps_.store(e,e.edpnum_);
  tag::Long r;
  tag::setedflong(&r,k,e.edpnum_);
  if (l) *l = r;
  
  if (debug_) {
	  std::cout << "===========================" << std::endl;
	  std::cout << "edfepst:" << k << std::endl;
	  std::cout << "edfepst:Token:" << std::endl;
	  dumpToken(std::cout, r);
	  std::cout << "edfepst:Token." << std::endl;
	  dump(std::cout);

	  std::cout << "edfepst:kwn: " << kwnInstance << std::endl;
	  std::cout << "edfepst:edp: " << e << std::endl;
	 	  
	  std::cout << "===========================" << std::endl;
  }
  
  return;
}

////////////////////////////////////////////////////////////////////////////
// Having 'kwn' id return 'kwn' instance for the current context.
////////////////////////////////////////////////////////////////////////////
SyntaxControlledRuntime::kwn&
SyntaxControlledRuntime::kwnLookup(tag::Long 	k)
{
  if (debug_) {
	cnm&  currentContext = cnms_.dataByKey(cnmnumCurrent_);
	  
	std::cout
	<< "kwnLookup:" << k << " " << cnmnumCurrent_
	<< " " << currentContext.kwns_.index2name.size()
	<< " " << currentContext.kwns_.index2data.size()
	<< std::endl;
	
	currentContext.kwns_.dump();
  }
	
  //Error?? // cnm&  currentContext = cnms_.dataByIndex(cnmnumCurrent_);
  cnm&  currentContext = cnms_.dataByKey(cnmnumCurrent_);
	
  tag::Long idx;
  if (!currentContext.kwns_.lookup(k,idx)) {
	kwn kwnNew;
	kwnNew.cnmnum_ = cnmnumCurrent_;
	kwnNew.kwnnum_ = k;
	currentContext.kwns_.store(kwnNew, k);
	idx = currentContext.kwns_.index2data.size() - 1;
  }
	  
  return currentContext.kwns_.dataByIndex(idx);
}


////////////////////////////////////////////////////////////////////////////
// Having 'edp' tag 'kn' = (kwnnum, edpnum) set the current 'edp'.
////////////////////////////////////////////////////////////////////////////
/*
int 	
SyntaxControlledRuntime::celedpfnd(tag::Long* kn)
{
  tag::Long 	k; 
  tag::Long 	n;
  
  tag::setlongedf(kn,k,n);
  
  if(s= celkwnnum(k)) pdber(s);
  if(s= celedpnum(n)) pdber(s);

  return(0);
}


int	
SyntaxControlledRuntime::celkwnnum(tag::Long k)
{
  return(0);
}

int	
SyntaxControlledRuntime::celedpnum(tag::Long n)
{
  return(0);
}
*/
SyntaxControlledRuntime::edp&	
SyntaxControlledRuntime::celedpfnd(tag::Long* kn)
{
  tag::Long 	k; 
  tag::Long 	n;
	  
  tag::setlongedf(kn,k,n);
  
  /*
  cnm&	currentContext = cnms_.dataByIndex(cnmnumCurrent_);
  
  tag::Long idx;
  if (!currentContext.kwns_.lookup(k,idx)) {
    CPPCC_THROW_EXCEPTION(
      << "SyntaxControlledRuntime::celedpfnd"
      << "(" << k << "," << n << ")"
      << " failed to find 'kwn' for the context:"
      << cnmnumCurrent_
    )
  }
  
  kwn& kwnInstance = currentContext.kwns_.dataByIndex(idx);
  */
  kwn& kwnInstance = kwnLookup(k);
  
  //err??// SyntaxControlledRuntime::edp&	findResult = kwnInstance.edps_.dataByIndex(n);
  SyntaxControlledRuntime::edp&	findResult = kwnInstance.edps_.dataByKey(n);
  
  return findResult;
}

////////////////////////////////////////////////////////////////////////////
// Modify rule definition dynamic part.
////////////////////////////////////////////////////////////////////////////
void
SyntaxControlledRuntime::edfeptd
(SyntaxControlledRuntime::edp& e, tag::Long d[],tag::Long m,tag::Long sh)
{
  if (!m || !d) return;
  
  //std::size_t oldSize = e.edpdyn_.size();
  //std::size_t newSize = oldSize + m;
  //e.edpdyn_.resize(newSize);
  
  for (register std::size_t i = 0, z = m; i < z; i++) {
	  //e.edpdyn_[oldSize+i] = d[i];
	  e.edpdyn_.push_back(d[i]);
  }
	
  return;
}

void
SyntaxControlledRuntime::edfeptd
(SyntaxControlledRuntime::edp& e, const std::vector<tag::Long>& d)
{
  if (!d.size()) return;
  
  //std::size_t oldSize = e.edpdyn_.size();
  //std::size_t newSize = oldSize + d.size();
  //e.edpdyn_.resize(newSize);
  
  for (register std::size_t i = 0, z = d.size(); i < z; i++) {
	  //e.edpdyn_[oldSize+i] = d[i];
	  e.edpdyn_.push_back(d[i]);
  }
	
  return;
}

////////////////////////////////////////////////////////////////////////////
// Modify rule definition fixed part.
////////////////////////////////////////////////////////////////////////////
void
SyntaxControlledRuntime::edfepfx
(SyntaxControlledRuntime::edp& e, tag::Long d[],tag::Long m,tag::Long sh)
{
  if (!m || !d) return;
  
  //std::size_t oldSize = e.edpfix_.size();
  //std::size_t newSize = oldSize + m;
  //e.edpfix_.resize(newSize);
  
  for (register std::size_t i = 0, z = m; i < z; i++) {
	  //e.edpfix_[oldSize+i] = d[i];
	  e.edpfix_.push_back(d[i]);
  }
	
  return;
}

void
SyntaxControlledRuntime::edfepfx
(SyntaxControlledRuntime::edp& e, const std::vector<tag::Long>& f)
{
  if (!f.size()) return;
  
  //std::size_t oldSize = e.edpfix_.size();
  //std::size_t newSize = oldSize + f.size();
  //e.edpfix_.resize(newSize);
  
  for (register std::size_t i = 0, z = f.size(); i < z; i++) {
	  //e.edpfix_[oldSize+i] = f[i];
	  e.edpfix_.push_back(f[i]);
  }
	
  return;
}

////////////////////////////////////////////////////////////////////////////
// Find 'nam' for the current context.
////////////////////////////////////////////////////////////////////////////
/*
bool 
SyntaxControlledRuntime::celnamkey(const std::string& n, tag::Long& idx)
{
  cnm&	currentContext = cnms_.dataByIndex(cnmnumCurrent_);

  return currentContext.namn_.lookup(n,idx);
}
*/

////////////////////////////////////////////////////////////////////////////
// Store identifier representation or just return its tag.
////////////////////////////////////////////////////////////////////////////
void 	
SyntaxControlledRuntime::edfnmst(const std::string& n, tag::Long* l)
{
	if (debug_) {
		std::cout 
		<< "edfnmst:0:"
		<< " id:" << "'" << n << "'"
		<< " cnmnumCurrent_:" << cnmnumCurrent_
		<< std::endl;
	}

  //Wrong::::::::::
  //cnm&			currentContext = cnms_.dataByIndex(cnmnumCurrent_);
  cnm&			currentContext = cnms_.dataByKey(cnmnumCurrent_);
  tag::Long 	idx;
  
	
	if (debug_) {
		std::cout 
		<< "edfnmst:1:"
		<< " id:" << "'" << n << "'"
		<< " cnmnumCurrent_:" << cnmnumCurrent_
		<< std::endl;
	}

  
  if (!currentContext.namn_.lookup(n, idx)) {
	nam 			namInstance;
	namInstance.cnmnum_ = cnmnumCurrent_;
	namInstance.namkey_ = n;
	currentContext.namn_.store(namInstance,n);
	idx = currentContext.namn_.index2data.size() - 1;
	
	if (debug_) {
		std::cout 
		<< "edfnmst:2:"
		<< " id:" << "'" << n << "'"
		<< " cnmnumCurrent_:" << cnmnumCurrent_
		<< " idx:" << idx
		<< std::endl;
	}

  }
  
  if (l) *l = idx;
  
  return;
}

////////////////////////////////////////////////////////////////////////////
// Optimize rule definition fixed part.
// Do not create another instance of 'edp' 
//	if found one with the same fixed part
//	assuming that dynamic part is not defined at all.
////////////////////////////////////////////////////////////////////////////
/*
void 	
SyntaxControlledRuntime::celedpfst
  (int 			flag
  ,tag::Long 	k
  ,tag::Long*	l
  ,tag::Long	t[]
  ,tag::Long	m)
{
  std::vector<tag::Long> 	fixed(t, t+m);
	
  kwn& 						kwnInstance = kwnLookup(k);
  bool 						y = true;
  std::vector<tag::Long> 	fixed(t, t+m);
  tag::Long 				edpnum;
  
  if (flag && optimizationMode_) {
    for (register std::size_t i = 0
      , s = kwnInstance.edps_.index2data.size();i < s; i++) {
      edp& edpInstance = kwnInstance.edps_.index2data[i];
      if ((0 == edpInstance.edpdyn_.size()) 
         && (edpInstance.edpfix_ == fixed)) {
    	  y = false;
    	  edpnum = edpInstance.edpnum_;
    	  break;
      }     
    }
  } 
  
  if (y) {
    edp e;
	e.cnmnum_ = cnmnumCurrent_;
	e.kwnnum_ = k;  
	e.edpnum_ = kwnInstance.edps_.lastKey(0);
	e.edpnum_++;
	  
	kwnInstance.edps_.store(e,e.edpnum_);	  
    edpnum = e.edpnum_;
  }
  
  tag::setedflong(l,k,edpnum);
  
  return;
}
*/

void 	
SyntaxControlledRuntime::celedpfst_
	  (int 			flag
	  ,tag::Long 	k
	  ,tag::Long*	l
	  ,std::vector<tag::Long>& fixed)
{
  kwn& 						kwnInstance = kwnLookup(k);
  bool 						y = true;
  //std::vector<tag::Long> 	fixed(t, t+m);
  tag::Long 				edpnum;
  tag::Long 				r;
  /**********************
  if (flag && optimizationMode_ && fixed.size()) {
    for (register std::size_t i = 0
      , s = kwnInstance.edps_.index2data.size();i < s; i++) {
      edp& edpInstance = kwnInstance.edps_.index2data[i];
      if ((0 == edpInstance.edpdyn_.size()) 
         && (edpInstance.edpfix_ == fixed)) {
    	  y = false;
    	  edpnum = edpInstance.edpnum_;
    	  break;
      }     
    }
  } 
  ********************/
  
  if (y) {
    edp e;
	e.cnmnum_ = cnmnumCurrent_;
	e.kwnnum_ = k;  
	
	//e.edpnum_ = kwnInstance.edps_.lastKey(0);
	e.edpnum_ = kwnInstance.edps_.lastKey(InitialEdpNumber);
	e.edpnum_++;

	// sic!!!!
    //edfepfx(e, fixed);
	e.edpfix_ = fixed;
	  
	kwnInstance.edps_.store(e,e.edpnum_);	  
    edpnum = e.edpnum_;
    
    //------
    if (debug_) {
      edp& edpNew = kwnInstance.edps_.dataByKey(e.edpnum_);
      std::cout 
      << "=====NNNNNNNN======" 
      << e.edpnum_
      << " " << edpNew
      << std::endl;
    }
    //------
    
  //}
  
    // sic!!!!
    ///edfepfx(e, fixed);
    
  //tag::setedflong(l,k,edpnum);
  //tag::Long r;
  tag::setedflong(&r,k,edpnum);
  
  if (debug_) {
	  std::cout << "===========================" << std::endl;
	  std::cout << "celedpfst_:" 
			  << " f:" << flag
			  << " k:" << k 
			  << " edp:" << e
			  << std::endl;
	  for (register std::size_t i = 0, s = e.edpfix_.size(); i < s; i++) {
	    std::cout << "celedpfst_:" 
		  << " f:" << flag
		  << " k:" << k 
		  << "(" 
		    << (((tag::TypeInstance*)&e.edpfix_[i])->t)
		    << " " <<(((tag::TypeInstance*)&e.edpfix_[i])->d)
		  << ")"		  
		<< std::endl;
		
	    dumpToken(std::cout, e.edpfix_[i]);
	  }
	  

	  std::cout << "celedpfst_:kwn: " << kwnInstance << std::endl;
	  std::cout << "celedpfst_:edp: " << e << std::endl;
	  
	  std::cout << "celedpfst_:r: " << std::endl;
	  dumpToken(std::cout, r);
	  
	  std::cout << "===========================" << std::endl;  
	  dump(std::cout);
	  std::cout << "===========================" << std::endl;
  }
  }
  
  //tag::setedflong(l,k,edpnum);
  if (l) *l = r;
  
  return;
}


////////////////////////////////////////////////////////////////////////////
// Optimize string rule definition fixed part.
////////////////////////////////////////////////////////////////////////////
void 	
SyntaxControlledRuntime::celedpfss
	(tag::Long k, tag::Long* l, const std::string& t)
{
  kwn& 			kwnInstance = kwnLookup(k);
  bool 			y = true;
  tag::Long 	edpnum;
	
  /*********** error is here??????????????
  for (register std::size_t i = 0
	, s = kwnInstance.edps_.index2data.size();i < s; i++) {
    edp& edpInstance = kwnInstance.edps_.index2data[i];
	if (std::string((char*)(&edpInstance.edpfix_[0])) == t) {
      y = false;
	  edpnum = edpInstance.edpnum_;
	  break;
	}     
  }
  **********************/
 
  if (y) {
    edp e;
    e.cnmnum_ = cnmnumCurrent_;
    e.kwnnum_ = k;  
	//e.edpnum_ = kwnInstance.edps_.lastKey(0);
    e.edpnum_ = kwnInstance.edps_.lastKey(InitialEdpNumber);
	e.edpnum_++;
	
	// sic !!
	//std::vector<tag::Long> tmpVector = tag::makeTagLongBuffer(t);
	//edfepfx(e,tmpVector);
	e.edpfix_ = tag::makeTagLongBuffer(t);

	
	kwnInstance.edps_.store(e,e.edpnum_);
	
	//std::vector<tag::Long> buf = tag::makeTagLongBuffer(t);
	//edfepfx(e,&buf[0], buf.size(), 0);
	
	///edfepfx(e,tag::makeTagLongBuffer(t));
	/////std::vector<tag::Long> tmpVector = tag::makeTagLongBuffer(t);
	////edfepfx(e,tmpVector);
	
	if (debug_) {
		  std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;
		  std::cout << "celedpfss:" 
			<< " k:" << k 
			<< " t:" << "'" << t << "'"
		    << std::endl;
		  std::cout << "celedpfss:" 
			<< " k:" << k 
			<< " t:" << "'" << t << "'"
			//<< " v:" << "'" << ((char*)&tmpVector[0]) << "'"
			//<< " vs:" << tmpVector.size()
		    << std::endl;
		  std::cout << "celedpfss:" 
			<< " k:" << k 
			<< " t:" << "'" << t << "'"
			<< " f:" << "'" << ((char*)&e.edpfix_[0]) << "'"
			<< " fs:" << e.edpfix_.size()
		    << std::endl;

		  std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!" << std::endl;		
	}
	
	edpnum = e.edpnum_;
  }
	  
  tag::Long r;
  tag::setedflong(&r,k,edpnum);
  if (l) *l = r;
  
  if (debug_) {
	  std::cout << "===========================" << std::endl;
	  std::cout << "celedpfss:" 
			  << " k:" << k 
			  << " t:" << "'" << t << "'"
			  << std::endl;
	  
	    dumpToken(std::cout, r);
	  
	  dump(std::cout);
	  std::cout << "===========================" << std::endl;
  }
  	  
  return;	
}

/*
std::string
SyntaxControlledRuntime::grammarName(cppcc::scr::tag::Long        axiom) 
{
	//cppcc::scr::tag::Long axiomK;
	//cppcc::scr::tag::Long axiomN;
	//tag::setlongedf(&axiom, axiomK, axiomN);
	//cnm&     currentContext = cnms_.dataByKey(cnmnumCurrent_);
	//nam&     metaName = currentContext.namn_.dataByIndex(axiomN);	
	//
	//return metaName.namkey_;
	
	cnm&	currentContext = cnms_.dataByKey(cnmnumCurrent_);
	kwn& 	kwnInstance = kwnLookup(k);
}


void
SyntaxControlledRuntime::decompiler::decompile
	//(const std::string&           filename
	(cppcc::scr::tag::Long        context
	,cppcc::scr::tag::Long        axiom
)
{
	//filename_ 	= "";
	context_	= context;
	axiom_		= axiom;
	
	std::string	gName = runtime_.grammarName(axiom_);	   
	filename_ = gName + ".urt";
	
	if (runtime_.debug_ || 1) {
		std::cout 
		<< "decompiler::decompile:0:"
		<< " ctx:" << context_
		<< " a:" << axiom_
		<< " n:" << "'" << gName << "'"
		<< " cnmnumCurrent_:" << runtime_.cnmnumCurrent_
		<< " filename:" << "'" << filename_ << "'"
		<< std::endl;		
	}
	
	
	if (!filename_.size() || ("" == filename_)) return;
	
	output_.open(filename_.c_str());
	if (!output_) {
	    std::string   syserr = cppcc::com::CPPCCException::systemError();			
	    CPPCC_THROW_EXCEPTION(
			<< "Can't open file for runtime decompiling:'"
			<< filename_
			<< "' - Reason:'"
			<< syserr
			<< "'"
	    )
	}
	
}
*/


void 	
SyntaxControlledRuntime::dump(std::ostream& f)
{
	f << "===============  Runtime::dump::::::::::::: ================"
			<< std::endl;
	f << (*this);
	for (std::size_t cnmIndex=0, cnmSize = cnms_.index2data.size();
	  cnmIndex < cnmSize; cnmIndex++
	) {
      cnm& cnmCurrent = cnms_.index2data[cnmIndex];
      f << "cnm:" << cnmIndex << " " << cnmCurrent
    	<< " namn:" << cnmCurrent.namn_.index2data.size()
    	<< " kwns:" << cnmCurrent.kwns_.index2data.size()
    	<< std::endl;
      ;
      
  	  for (std::size_t namIndex=0, 
  		namSize = cnmCurrent.namn_.index2data.size();
  		namIndex < namSize; namIndex++
  	  ) {
  	    nam& namCurrent = cnmCurrent.namn_.index2data[namIndex];
  	    f << "cnm:" << cnmIndex 
  	      << " nam:" << namIndex << " " << namCurrent
  	    << std::endl;
  	  }
      
  	  for (std::size_t kwnIndex=0, 
  		kwnSize = cnmCurrent.kwns_.index2data.size();
  		kwnIndex <  kwnSize;  kwnIndex++
  	  ) {
  		kwn& kwnCurrent = cnmCurrent.kwns_.index2data[kwnIndex];
  	    f << "cnm:" << cnmIndex 
  	      << " kwn:" << kwnIndex << " " << kwnCurrent
  	      << " edps:" << kwnCurrent.edps_.index2data.size()
  	    << std::endl;
  	    ;
  	    
    	  for (std::size_t edpIndex=0, 
    		edpSize = kwnCurrent.edps_.index2data.size();
    		edpIndex <  edpSize;  edpIndex++
    	  ) {
    		//edp edpCurrent = kwnCurrent.edps_.index2data[kwnIndex];
    		edp& edpCurrent = kwnCurrent.edps_.index2data[edpIndex];
    	    f << "cnm:" << cnmIndex 
    	      << " kwn:" << kwnIndex << " " << kwnCurrent.kwnnum_
    	      << " edp:" << edpIndex << " " << edpCurrent.edpnum_
    	      << " " 
    	      << edpCurrent
    	    << std::endl;
    	    
    	    tag::Long kn;
    	    tag::setedflong(&kn,kwnCurrent.kwnnum_,edpCurrent.edpnum_);
    	    dumpToken(f, kn);
    	  }  
  	  }
	}
	
	f << "===============  Runtime::dump............ ================"
			<< std::endl;
}

void 
SyntaxControlledRuntime::dumpToken(std::ostream& f, tag::Long kn)
{
  //if ((k <= cppcc::com::PLS_WRONG_KEY_WORD) 
  // || (k >= cppcc::com::PLS_TERMINALS_START)) return;

  tag::Long k;
  tag::Long n;
  tag::setlongedf(&kn,k,n);
  
  f 
	  << "dumpToken:||||||||||||||||||||:" 
	  << " be:" << cppcc::com::PLS_WRONG_KEY_WORD 
		  << " " << cppcc::com::PLS_TERMINALS_START
	  << " bool:" << ((k <= cppcc::com::PLS_WRONG_KEY_WORD) 
			   || (k >= cppcc::com::PLS_TERMINALS_START))
	  << " kn:" << kn
	  << " (" << k << " " << n << ")"
	  << "="
	  << std::endl;
  ;
  
  if ((k <= cppcc::com::PLS_WRONG_KEY_WORD) 
   || (k >= cppcc::com::PLS_TERMINALS_START)) {
	  //f << std::endl;
	  return;
  }
  
  cnm&  currentContext = cnms_.dataByKey(cnmnumCurrent_);
  kwn&  kwnInstance = kwnLookup(k);
  //edp&  edpInstance = kwnInstance.edps_.index2data[i];
  //edp&  edpInstance = kwnInstance.edps_.dataByKey(n);

  f 
	  << "dumpToken:" 
	  << currentContext
	  << std::endl;
  ;


  f 
	  << "dumpToken:" 
	  << kwnInstance
	  << std::endl;
  ;

  //f 
  //	  << "dumpToken:" 
  //	  << edpInstance
  //	  << std::endl;
  //;
  
  switch(k)
  {
  case cppcc::com::PLS_IDENTIFIER:
    {
      nam& namInstance = currentContext.namn_.dataByIndex(n);
      f 
      << "dumpToken:identifier:" 
      << namInstance
      << std::endl;
      return;
    }
  case cppcc::com::PLS_STRING_TOKEN:
    {
      edp&  edpInstance = kwnInstance.edps_.dataByKey(n);
      if(edpInstance.edpfix_.size()) {
        f 
          << "dumpToken:stringToken:" 
          << "'" << ((char*)&edpInstance.edpfix_[0]) << "'"
          << std::endl;
      }
      return;
    }
  case cppcc::com::PLS_INTEGER_TOKEN:
    {
      edp&  edpInstance = kwnInstance.edps_.dataByKey(n);
      if(edpInstance.edpfix_.size()) {
        f 
          << "dumpToken:integerToken:" 
          << "'" << edpInstance.edpfix_[0] << "'"
          << std::endl;
      }
      return;
    }
  case cppcc::com::PLS_FLOAT_TOKEN:
    {
    	edp&  edpInstance = kwnInstance.edps_.dataByKey(n);
        if(edpInstance.edpfix_.size()) {
          f 
            << "dumpToken:integerToken:" 
            << "'" << (*((tag::Real*)&edpInstance.edpfix_[0])) << "'"
            << std::endl;
        }
      return;
    }
  case cppcc::com::PLS_TEXT_TOKEN:
    {
      return;
    }
  case cppcc::com::PLS_TERMINAL_TOKEN:
    {
	  // n is enum kw.
      f
        << "dumpToken:terminalToken:" << n
        << std::endl;
      return;
    }
  case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
    {
        nam& namInstance = currentContext.namn_.dataByIndex(n);
        f 
        << "dumpToken:termToken:" 
        << namInstance
        << std::endl;

    	return;
    }
    
  default:
	return;
  }
  
  //f << std::endl;
}



//---------------------
}
}


////////////////////////////////////////////////////////////////////////
// C++ copmiler compiler
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Shell.h"

int	main(int argc, char** argv)
{
  /*
  try {
	  cppcc::cmd::Shell sh(argc, argv);
	  
	  sh.run();
	  
	  return 0;
  } 
  catch(const std::exception& e)
  {
    std::cerr << e.what() << std::endl;
	return 1;
  }
  catch(...) {
	std::cerr << "Terminated with uncaught exception!" << std::endl;
	return 1;	
  }
  */

  cppcc::cmd::Shell sh(argc, argv);
	  
  sh.run();

  return 0;
}

/////////////////////////////////////////////////////////////////////
//	Generator.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_GENERATOR_H_
#define  _CPPCC_GENERATOR_H_

//#include "Parser.h"
//#include "CommonRoutines.h"
#include "Tokenizer.h"
#include "SyntaxControlledBinary.h"

namespace cppcc {
namespace gen {

namespace syn {
	class Parser;
}

class IGenerator
{
public:
  virtual void decompileRuntime(const std::string& filename)= 0;
  virtual void decompileBinary(const std::string& filename)= 0;
  virtual void generateFromRuntime(const std::string& filename)= 0;
  virtual void generateFromBinary(const std::string& filename)= 0;
  //virtual void generateBinaryFromRuntime()= 0;
};

class IRuntimeGenerator
{
public:
  virtual void 	makeAlignment(cppcc::lex::Token& token)= 0;
  virtual void 	decompile(const std::string& filename)= 0;
  virtual void 	generate(const std::string& filename)= 0;
};

class IBinaryGenerator
{
public:
  virtual void 	makeAlignment(cppcc::lex::Token& token)= 0;
  virtual void 	decompile(const std::string& filename)= 0;
  virtual void 	generate(const std::string& filename)= 0;
};


class IRuntimeGeneratorStyle
{
public:
  virtual void 	makeAlignment(cppcc::lex::Token& token)= 0;
  //virtual void 	decompile(const std::string& filename)= 0;
  //virtual void 	generate(const std::string& filename)= 0;
};

class IBinaryGeneratorStyle
{
public:
  virtual void 	makeAlignment(cppcc::lex::Token& token)= 0;
  //virtual void 	decompile(const std::string& filename)= 0;
  //virtual void 	generate(const std::string& filename)= 0;
};
	
struct GeneratorBinary : IBinaryGenerator 
{
	  struct GeneratorBinaryStyle : IBinaryGeneratorStyle
	  {
		  GeneratorBinary& generator_binary_;
	    
		  GeneratorBinaryStyle(GeneratorBinary& generator_binary)
	      : generator_binary_(generator_binary)
	    {}
	    
	    virtual ~GeneratorBinaryStyle() {}
	    virtual void  makeAlignment(cppcc::lex::Token& token)= 0;
	  };
	  
	  struct GeneratorBinaryStyleXML : GeneratorBinaryStyle
	  {
		  GeneratorBinaryStyleXML(GeneratorBinary&  generator_binary)
	      : GeneratorBinaryStyle(generator_binary)
	    {}
	    
	    ~GeneratorBinaryStyleXML() {}
	    
	    void  makeAlignment(cppcc::lex::Token& token);
	  };
	  
	  struct GeneratorBinaryStyleMeta : GeneratorBinaryStyle
	  {
		  GeneratorBinaryStyleMeta(GeneratorBinary& generator_binary)
	      : GeneratorBinaryStyle(generator_binary)
	    {}
	    
	    ~GeneratorBinaryStyleMeta() {}
	    
	    void  makeAlignment(cppcc::lex::Token& token);
	  };

	  GeneratorBinaryStyle*    makeStyle
	    (cppcc::com::LanguageTokenizerSet   tokenizerSet);

	
	Generator& 		generator_;	
	GeneratorBinaryStyle* style_;
	std::string     filename_;
	std::ofstream	output_;  
	bool          	debug_;
	
	// State variables:
	scr::tag::Long	Level_;
	scr::tag::Long  StateLine_;
	scr::tag::Long  StateBlun_;
	//scr::tag::Long  Lasty_;
	scr::tag::Long  Lastnnn_;
	//scr::tag::Long  Lasti_;
	scr::tag::Long  LastKey_;
	int				StringXmlTokenMode_;
	int             LastKKK_;
	
	GeneratorBinary(Generator&  generator);
/*
	GeneratorBinary(Generator&  generator)
		: generator_(generator)
	  	, filename_()
		, output_()
	  	, debug_(false)
		, Level_(0)
		, StateLine_(0)
		, StateBlun_(0)
		//, Lasty_(0)
		, Lastnnn_(0)
		//, Lasti_(0)
		, LastKey_(0)	
	    , StringXmlTokenMode_(0)
		, LastKKK_(0)
	{}
*/
	
	virtual ~GeneratorBinary() {}
	  
	void scDecompileSpace
	    (std::ofstream&         output
	    ,cppcc::scr::tag::Long  kkk);
	
	std::string     grammarName();
	void        	scDecompileMain_(std::ofstream&	output);
	void        	scDecompileMain() 
	{
		scDecompileMain_(output_);
	}
	
	//void        	scDecompile(cppcc::scr::tag::Long tag);
	void        	scDecompile_
		(std::ofstream&	output,cppcc::scr::tag::Long& tag);
	void        	scDecompile(cppcc::scr::tag::Long& tag)
	{
		scDecompile_(output_, tag);
	}
	
	//virtual void 	makeAlignment(cppcc::lex::Token& token);		
	virtual void 	makeAlignment(cppcc::lex::Token& token)
	{
		if (!style_) return;
		style_->makeAlignment(token);
	}

	virtual void 	decompile(const std::string& filename);
	virtual void   	generate(const std::string& filename);
};
	  
struct GeneratorRuntime : IRuntimeGenerator
{
	struct GeneratorRuntimeStyle : IRuntimeGeneratorStyle
	{
		GeneratorRuntime&	generator_runtime_;
		
		GeneratorRuntimeStyle(GeneratorRuntime&	generator_runtime)
		  : generator_runtime_(generator_runtime)
		{}
		
		virtual ~GeneratorRuntimeStyle() {}
		virtual void 	makeAlignment(cppcc::lex::Token& token)= 0;
	};
	
	struct GeneratorRuntimeStyleXML : GeneratorRuntimeStyle
	{
		GeneratorRuntimeStyleXML(GeneratorRuntime&	generator_runtime)
		  : GeneratorRuntimeStyle(generator_runtime)
		{}
		
		~GeneratorRuntimeStyleXML() {}
		
		void 	makeAlignment(cppcc::lex::Token& token);
	};
	
	struct GeneratorRuntimeStyleMeta : GeneratorRuntimeStyle
	{
		GeneratorRuntimeStyleMeta(GeneratorRuntime&	generator_runtime)
		  : GeneratorRuntimeStyle(generator_runtime)
		{}
		
		~GeneratorRuntimeStyleMeta() {}
		
		void 	makeAlignment(cppcc::lex::Token& token);
	};

	GeneratorRuntimeStyle*		makeStyle
		(cppcc::com::LanguageTokenizerSet 	tokenizerSet);
	
	Generator& 					generator_;
	GeneratorRuntimeStyle*		style_;
	std::string     			filename_;
	std::ofstream 				output_;  
	bool          				debug_;
	    
	// State variables:
	scr::tag::Long				Level_;
	scr::tag::Long  			StateLine_;
	scr::tag::Long  			StateBlun_;
	//scr::tag::Long  Lasty_;
	scr::tag::Long  			Lastnnn_;
	//scr::tag::Long  Lasti_;
	scr::tag::Long  			LastKey_;
	
	int							StringXmlTokenMode_;
	int							LastKKK_;
	    
	GeneratorRuntime(Generator& generator);
/*	
	GeneratorRuntime(Generator& generator)
		: generator_(generator)
	    , style_(makeStyle(generator.tokenizerSet_))
		, filename_()
		, output_()
		, debug_(false)
		, Level_(0)
	 	, StateLine_(0)
		, StateBlun_(0)
	 	//, Lasty_(0)
		, Lastnnn_(0)
	   	//, Lasti_(0)
	  	, LastKey_(0)
	{}
*/
	
	virtual ~GeneratorRuntime() {}
	
	void scDecompileSpace
	  (std::ofstream&         output
	  ,cppcc::scr::tag::Long  kkk);
	
	std::string     grammarName();
	//void        	scDecompileMain();
	//void        	scDecompile(cppcc::scr::tag::Long tag);
	void        	scDecompileMain_(std::ofstream&	output);
	void        	scDecompileMain() 
	{
		scDecompileMain_(output_);
	}
	
	//void        	scDecompile(cppcc::scr::tag::Long tag);
	void        	scDecompile_
		(std::ofstream&	output,cppcc::scr::tag::Long& tag);
	void        	scDecompile(cppcc::scr::tag::Long& tag)
	{
		scDecompile_(output_, tag);
	}
	
	virtual void 	makeAlignment(cppcc::lex::Token& token)
	{
		if (!style_) return;
		style_->makeAlignment(token);
	}
	
	virtual void  	decompile(const std::string& filename);
	virtual void  	generate(const std::string& filename);
};

class Generator : IGenerator
{
	void prolog();
	void epilog() throw();

public:	  
	GeneratorBinary*					binary_;
	GeneratorRuntime*					runtime_;	
	cppcc::syn::Parser&     			parser_;
	cppcc::com::LanguageTokenizerSet 	tokenizerSet_;

  Generator
    (cppcc::syn::Parser&     parser
    ,cppcc::com::LanguageTokenizerSet 	tokenizerSet)	
    //: binary_(cppcc::com::makeBinaryGenerator(*this))
	:binary_(0)
    //, runtime_(cppcc::com::makeRuntimeGenerator(*this))
	, runtime_(0)
    , parser_(parser)
	, tokenizerSet_(tokenizerSet)
  {
	  //std::cout << "Generator:" << tokenizerSet_ << std::endl;
	  binary_ 	= cppcc::com::makeBinaryGenerator(*this);
	  runtime_ 	= cppcc::com::makeRuntimeGenerator(*this);

	  prolog();
  }
  //Generator(cppcc::syn::Parser&     parser);
	
  ~Generator() 
  {
	  epilog();
  }

  void decompileRuntime(const std::string& filename)
	  { runtime_->decompile(filename); }
  void decompileBinary(const std::string& filename)
	  { binary_->decompile(filename); }
  void generateFromRuntime(const std::string& filename)
	  { runtime_->generate(filename); }
  void generateFromBinary(const std::string& filename)
	  { binary_->generate(filename); }

  
};
}
}

#endif


/////////////////////////////////////////////////////////////////////
//	SystemRoutines.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_SYSTEM_ROUTINES_H_
#define  _CPPCC_SYSTEM_ROUTINES_H_

#include "cppccstd.h"


namespace cppcc {
namespace sys {

// NB: integrate with boost, C++0x, ...

class   noncopyable
{
protected:
  noncopyable() {}
  ~noncopyable() {}
  
private:
  noncopyable(const noncopyable&);
  const noncopyable& operator= (const noncopyable&);
};


}
}

#endif
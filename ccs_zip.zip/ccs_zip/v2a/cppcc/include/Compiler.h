/////////////////////////////////////////////////////////////////////
//	Compiler.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_COMPILER_H_
#define  _CPPCC_COMPILER_H_

#include "cppccstd.h"
#include "CommonRoutines.h"
#include "SystemRoutines.h"

namespace cppcc {

namespace cmd {
	class Shell;
}

namespace syn {
	class Parser;
}

namespace cmp {

class Compiler
	: private cppcc::sys::noncopyable
	, public cppcc::com::IRun
{
   struct Action : cppcc::com::IRun
   {
	   Compiler& compiler_;
	   
	   Action(Compiler& compiler)
	     : compiler_(compiler)
	   {}
	   virtual ~Action() {}
   };
   
   struct ActionUnload : Action
   {
	   ActionUnload(Compiler& compiler)
	     : Action(compiler)
	   {}
	   ~ActionUnload() {}	  
	   void run();
   };
   
   struct ActionCompile : Action
   {
	   ActionCompile(Compiler& compiler)
	     : Action(compiler)
	   {}
	   ~ActionCompile() {}	  
	   void run();
   };
   
   Action*				makeAction(cppcc::cmd::Shell& sh);
   //cppcc::syn::Parser*	makeParser(cppcc::cmd::Shell& sh);

/*   
   // xml //  :::::::::::::::::
   cppcc::com::KeyWordsContainer    makeCompilerKeyWords_
     (cppcc::com::LanguageTokenizerSet tokensSetID)
   {
	   if ((cppcc::com::LanguageTokenizerSet_Meta == tokensSetID)
		 || (cppcc::com::LanguageTokenizerSet_Undefined == tokensSetID)
	   ){
	      return cppcc::com::makeCompilerKeyWords();
	   }
	   else if (cppcc::com::LanguageTokenizerSet_XML == tokensSetID) {
		  cppcc::com::KeyWordsContainer r = cppcc::com::makeCompilerKeyWords();
		  
		  r.tokens_.push_back("?");
		  r.tokens_.push_back("/");
		  r.tokens_.push_back("</");
	   }
	   else {
		 cppcc::com::KeyWordsContainer r;
		   
		 return r;
	   }
   }
   // xml //  .................
*/
   
public:	
   
   cppcc::cmd::Shell& 				shell_;
   cppcc::com::KeyWordsContainer    keyWords_;   
   Action*							action_;
   cppcc::syn::Parser*				parser_;


  Compiler(cppcc::cmd::Shell& sh)
	  : shell_(sh)
	  //xml// 
      , keyWords_(cppcc::com::makeCompilerKeyWords())
      //xml// , keyWords_(makeCompilerKeyWords_(sh.tokensSetID_))
	  , action_(makeAction(sh))
      , parser_(cppcc::com::makeParser(*this))
  {
	  //std::cout << "Compiler:" << sh.tokensSetID_ << std::endl;
	  prolog();
  }
  
  virtual ~Compiler() {
	  epilog();
  }
  
  //cppcc::cmd::Shell& 				shell() { return shell_; }
  
  void run();

private:
  void prolog();
  void epilog() throw();
};


}
}

#endif




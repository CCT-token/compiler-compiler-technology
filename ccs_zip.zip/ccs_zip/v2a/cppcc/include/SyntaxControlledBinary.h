/////////////////////////////////////////////////////////////////////
//	SyntaxControlledBinary.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_SYNTAX_CONTROLLED_BINARY_H_
#define  _CPPCC_SYNTAX_CONTROLLED_BINARY_H_

#include "cppccstd.h"
#include "SyntaxControlledRuntime.h"

namespace cppcc {
namespace scb {

struct SyntaxControlledBinary 
{
	struct kwnirType;
	
	typedef cppcc::scr::tag::Long         TagLong;
	typedef TagLong*                      TagPointer;
	typedef cppcc::scr::tag::TypeInstance TagInstance;
	typedef std::vector<kwnirType*>       kwnirTypeVector;
	
	std::vector<TagLong>                  memory_;
	

	// head of dynamic array with its context 
	struct contextType {
	  TagLong   cntlen;		// total length		
	  TagLong   cntcur;		// current index:0 ... cntlen - 1

	  TagLong   cntbeg;		// axiom:struct TagInstance	

	  TagLong   cntnid;		// total number of identifiers
	  TagLong   cntdid;   // dynamic array of identifiers map:
                        //   sequantial number to TagLong

	  TagLong   cntnkw;		// total number of kwn's
	  TagLong   cntdkw;		// dynamic array of kwn's map:
                        //  sequantial number to ptrType
	};
	
	// contextType size aligned
	std::size_t	SOFCNT() {
		return
			(sizeof(contextType) + sizeof(TagLong) - 1)/sizeof(TagLong)
		;
	}
	
	// head of kwn representation 
	struct kwnirType {
	  TagLong	l;		// total number of kwn edp instances
	  TagLong	k;		// enum cppcc::...::KeyWords kwn key number
	  TagLong	d;		// beginning of kwn instances
	};
	
	// kwnirType size aligned
	std::size_t	SOFKWN() {
		return
			(sizeof(kwnirType) + sizeof(TagLong) - 1)/sizeof(TagLong)
		;		
	}
	
	// head of edp representation 
	struct edpirType {
	  TagLong	fl;		// number of items of fixed part
	  TagLong	dl;		// number of items of dynamic part
	  TagLong	d;		// begin of edp instances
	};
	
	// edpirType size aligned
	std::size_t	SOFEDP() {
		return
			(sizeof(kwnirType) + sizeof(TagLong) - 1)/sizeof(TagLong)
		;		
	}
	
	// TagInstance size aligned - should be always 1
	std::size_t	SOFEDFTD() {
		return
			(sizeof(TagInstance) + sizeof(TagLong) - 1)/sizeof(TagLong)
		;		
	}
	
	const contextType*	head()
	{
	   return	
	     reinterpret_cast<const contextType*>  
		   (&memory_[0])
	   ;
	}

	contextType*	uhead()
	{
	   return	
	     reinterpret_cast<contextType*>  
		   (&memory_[0])
	   ;
	}

	
	// get identifier by its number in a sequential order.
	const char*	ptrids(const TagLong id)
	{
		return
		  reinterpret_cast<const char*>  
			(&memory_[memory_[head()->cntdid + id]])
		;
	}
	
	// get identifier by its number in an alphabetic order.
	const char*	ptridn(const TagLong id)
	{
		return
		  reinterpret_cast<const char*>  
			(&memory_[memory_[head()->cntnid + head()->cntdid + 2*id]])
		;
	}
	
	// get identifier number by its number in an alphabetic order.
	TagLong	ptridnum(const TagLong id)
	{
		return
		  //memory_[memory_[head()->cntnid + head()->cntdid + 2*id+1]]
		  memory_[head()->cntnid + head()->cntdid + 2*id+1]
		;
	}

  TagLong pdbidnsea(const std::string& id)
  {

    for(TagLong j=0, z = (head()->cntnid); j < z; j++) {
      if (id == std::string(ptridn(j))) {
        return ptridnum(j);
      }
    }

    return(-1);
  }

  TagLong find_id(const std::string& id)
  {
    return pdbidnsea(id);
  }

	// get kwn representation (kwnirType*) by kwn id.
	//const 
	kwnirType*	ptrkwn(const TagLong i)
	{
		return	
			reinterpret_cast<kwnirType*>  
			   //(&memory_[memory_[head()->cntdkw + i*SOFKWN()]])
			   (&memory_[head()->cntdkw + i*SOFKWN()])
		;		
	}
	
	// get edp representation (edpirType*) by kwn id.
	//const 
	edpirType*	ptredp(kwnirType* i, const TagLong j)
	{
		return	
			reinterpret_cast<edpirType*>  
				//(&memory_[memory_[i->d + j*SOFEDP()]])
				(&memory_[i->d + j*SOFEDP()])
		;		
	}
			
	// convert TagLong to char*
	char*	ptrchar(const TagLong d)
	{
		return	
			reinterpret_cast<char*>  
			   (&memory_[d])
		;			
	}
	
	// convert TagLong to const char*
	const char*	ptrcchar(const TagLong d)
	{
		return	
			reinterpret_cast<const char*>  
			   (&memory_[d])
		;			
	}

	// aligned size of anything with initial size 'e'
	std::size_t	lenofedpchar(std::size_t e)
	{
		return
			(e + sizeof(TagLong) - 1)/sizeof(TagLong)		
		;
	}
	
	// sizeof binary internal representation 
	std::size_t	lenofir()
	{
		return
			(head()->cntlen)*sizeof(TagLong)		
		;
	}

	// edp - grammar rule representation
	struct ruleType {
	  TagInstance*	f;		// fixed    part of rule 
	  TagInstance*	d;		// dynamic 	part of rule
	};

	// populate ruleType& ppu instance having 
	//	kwnirType* 	ppk
	//	edpirType*	ppd
	void	setptrrule
		(kwnirType* 	ppk
		,edpirType*		ppd
		,ruleType&		ppu)
	{
	  ppu.f = 0;
	  if (ppd && ppd->fl) {
		ppu.f = reinterpret_cast<TagInstance*>(&memory_[ppd->d]);
	  }
	  ppu.d = 0;
	  if (ppd && ppd->dl) {
		ppu.d = reinterpret_cast<TagInstance*>(&memory_[ppd->d + ppd->fl]);
	  }	  
	}
	
	//ruleType  setrule(kwnirType* 	ppk, edpirType*		ppd)
	ruleType  setrule(edpirType*		ppd)
	{
		ruleType r;
		r.f = 0;
		r.d = 0;
		
		if (ppd && ppd->fl) {
			//r.f = reinterpret_cast<TagInstance*>(&memory_[ppd->d]);
			r.f = (TagInstance*)(&memory_[ppd->d]);
		}
		
		if (ppd && ppd->dl) {
			//r.d = reinterpret_cast<TagInstance*>(&memory_[ppd->d + ppd->fl]);
			r.d = (TagInstance*)(&memory_[ppd->d + ppd->fl]);
		}	  
		
		return r;
	}

	 cppcc::scr::tag::Long* 		fixed
		 (edpirType* e);
	 cppcc::scr::tag::TypeInstance& fixed
		 (edpirType* e, cppcc::scr::tag::Long i);

	 cppcc::scr::tag::Long* 		dynamic
		 (edpirType* e);	 
	 cppcc::scr::tag::TypeInstance& dynamic
		 (edpirType* e, cppcc::scr::tag::Long i);

	
	// method for searching & creating a kwnType descriptor by its enum number
	//  enum KeyNum 		ppkw;
	//  struct kwnirType	*ppk;
	//const 
	kwnirType*	setptrkwn(const TagLong ppkw);
/*
	{
		std::cout
		  << "setptrkwn"
		  << " ppkw:" << ppkw
		  << " h:" << (*uhead())
		  << " cntnkw:" << head()->cntnkw
		  << std::endl;
		  
		
		kwnirType* result = 0;
		for (register TagLong i = 0, s = head()->cntnkw; i < s; i++) {
			result = ptrkwn(i);
			
			std::cout
			  << "setptrkwn"
			  << " ppkw:" << ppkw
			  << " h:" << (*uhead())
			  << " cntnkw:" << head()->cntnkw
			  << " i:" << i
			  << std::endl;

			if (result) {
				std::cout
				  << "setptrkwn"
				  << " ppkw:" << ppkw
				  << " h:" << (*uhead())
				  << " cntnkw:" << head()->cntnkw
				  << " i:" << i
				  << " result:" << (*result)
				  << std::endl;				
			}
			
			if (result && (result->k == ppkw)) {
				return result;
			}
		}
		return 0;
	}
*/
	
	// initialize tag vector elements
	void pdbinitf(std::vector<TagLong>& f)
	{
		for (register std::size_t i = 0, s = f.size(); i<s; i++) {
		  f[i] = 0;
		}
	}

	void writeBinary(const std::string& filename);  
	void readBinary(const std::string& filename);
	
	void setkeywor(kwnirTypeVector& kwv) {
		for (register std::size_t i = 0, s = kwv.size(); i<s; i++) {
			kwv[i] = setptrkwn(static_cast<TagLong>(i));
		}		
	}
	

	void edpDump
		(std::ostream& 	strm
		,SyntaxControlledBinary::edpirType&  edp)
	{
		strm
			<< "edp="
			<< "(" 
			<< "fl=" << edp.fl
			<< " dl=" << edp.dl
			<< " d=" << edp.d
			<< ")"
			<< std::endl
		;


		  for (cppcc::scr::tag::Long i = 0, z = edp.fl; i < z; i++) {
		  strm
		    << "edp="
		    << "(" 
		    << "fl=" << edp.fl
		    << " dl=" << edp.dl
		    << " d=" << edp.d
		    << " fixed:" << i 
		        << " " << memory_[edp.d+i]
		        << "(" << (((TagInstance*)&memory_[edp.d+i])->t)
		        << " " << (((TagInstance*)&memory_[edp.d+i])->d)
		        << ")"
		    << ")"
		    << std::endl
		  ;
		  
		  }
		 
		   
		  for (cppcc::scr::tag::Long i = 0, z = edp.dl; i < z; i++) {
		  strm
		    << "edp="
		    << "(" 
		    << "fl=" << edp.fl
		    << " dl=" << edp.dl
		    << " d=" << edp.d
		    << " dyn:" << i 
		        << " " << memory_[edp.d+edp.fl+i]
		        << "(" << (((TagInstance*)&memory_[edp.d+edp.fl+i])->t)
		        << " " << (((TagInstance*)&memory_[edp.d+edp.fl+i])->d)
		        << ")"
		    << ")"
		    << std::endl
		  ;
		  
		  }
	
		
		//return strm;
	}

struct Helper {
	
	struct edp 
	{
		SyntaxControlledBinary*	b_;
		edpirType*				e_;
		
		edpirType&		e();
		
		TagLong* 	   	fixed();
		TagLong* 		dynamic();
		TagInstance&  	fixed(const TagLong i);
		TagInstance&  	dynamic(const TagLong i);
		
		operator bool() const { return e_; }
	};
	
	struct kwn
	{
		//123// SyntaxControlledBinary*	b_;
		kwnirType*		  		k_;
		std::vector<edp>  		edps_;
		
		edp&			  e(const TagLong i);
		
		//kwnirType&		  k();
		
		operator bool() const { return k_; }
	};
	
	SyntaxControlledBinary& 				b_;
	SyntaxControlledBinary::contextType& 	h_;
	std::vector<const char*>        		ids_;
	std::vector<const char*>        		idn_;
	std::vector<TagLong>        			idi_;
	std::vector<kwn>						kwns_;
	
	Helper(SyntaxControlledBinary& b, const TagLong kwnSize) 
	  : b_(b)
	  , h_(*(b_.uhead()))
	  , ids_(h_.cntnid)
	  , idn_(h_.cntnid)
	  , idi_(h_.cntnid)
	  //, kwns_(h_.cntnkw)
	  , kwns_(kwnSize)
	{
		populate();
	}

	//const contextType&	h();
	kwn&				k(const TagLong i);

	//const std::string&  id(const TagLong i);
	const char*  		id(const TagLong i);
	
	void 				dump(std::ostream&  strm);
	
private:
	void populate();
};
	
	
private:
	
	 cppcc::scr::tag::Long* fixed_(edpirType* e);
	 cppcc::scr::tag::Long*	dynamic_(edpirType* e);	 
	
};


inline
std::ostream& operator<<
	(std::ostream& 	strm
	,SyntaxControlledBinary::contextType&  cnm)
{
	strm
		<< "Header="
		<< "(" << "cntlen=" << cnm.cntlen
		<< " " << "cntcur=" << cnm.cntcur
		<< " " << "cntbeg=" << cnm.cntbeg
			<< "(" << (((cppcc::scr::tag::TypeInstance*)&cnm.cntbeg)->t)
			<< " " << (((cppcc::scr::tag::TypeInstance*)&cnm.cntbeg)->d)
		   	<< ")"
		<< " " << "cntnid=" << cnm.cntnid
		<< " " << "cntdid=" << cnm.cntdid
		<< " " << "cntnkw=" << cnm.cntnkw
		<< " " << "cntdkw=" << cnm.cntdkw
		<< ")"
		<< std::endl;
	;
	
	return strm;
}


inline
std::ostream& operator<<
	(std::ostream& 	strm
	,SyntaxControlledBinary::kwnirType&  kwn)
{
	strm
		<< "kwn="
		<< "(" 
		<< "l=" << kwn.l
		<< " k=" << kwn.k
		<< " d=" << kwn.d
		<< ")"
	;
	
	return strm;
}


inline
std::ostream& operator<<
	(std::ostream& 	strm
	,SyntaxControlledBinary::edpirType&  edp)
{
	strm
		<< "edp="
		<< "(" 
		<< "fl=" << edp.fl
		<< " dl=" << edp.dl
		<< " d=" << edp.d
		<< ")"
	;

/*	
	  for (cppcc::scr::tag::Long i = 0, z = edp.fl; i < z; i++) {
	  strm
	    << "edp="
	    << "(" 
	    << "fl=" << edp.fl
	    << " dl=" << edp.dl
	    << " d=" << edp.d
	    << " fixed:" << i 
	        << " " << memory_[edp.d+i]
	        << "(" << (((TagInstance*)&memory_[edp.d+i])->t)
	        << " " << (((TagInstance*)&memory_[edp.d+i])->d)
	        << ")"
	    << ")"
	  ;
	  
	  }
	 
	   
	  for (cppcc::scr::tag::Long i = 0, z = edp.dl; i < z; i++) {
	  strm
	    << "edp="
	    << "(" 
	    << "fl=" << edp.fl
	    << " dl=" << edp.dl
	    << " d=" << edp.d
	    << " dyn:" << i 
	        << " " << memory_[edp.d+edp.fl+i]
	        << "(" << (((TagInstance*)&memory_[edp.d+edp.fl+i])->t)
	        << " " << (((TagInstance*)&memory_[edp.d+edp.fl+i])->d)
	        << ")"
	    << ")"
	  ;
	  
	  }
*/
	
	return strm;
}

inline
std::ostream& operator<<
	(std::ostream& 				strm
	,SyntaxControlledBinary&  	b)
{
	strm
		<< "Binary="
		<< (*b.uhead())
		<< std::endl;
	;
	
	for (cppcc::scr::tag::Long i = 0, z = b.head()->cntnid; i < z; i++) {
		strm
		<< "Binary=  "
		<< "i:" << i
		<< " n:" << "'" << b.ptrids(i) << "'"
		<< std::endl;
		
	}

	for (cppcc::scr::tag::Long i = 0, z = b.head()->cntnid; i < z; i++) {
		strm
		<< "Binary=  "
		<< "i:" << i
		<< " j:" << b.ptridnum(i)
		<< " n:" << "'" << b.ptridn(i) << "'"
		<< std::endl;
		
	}
	
	return strm;
}

///

///

}
}

#endif

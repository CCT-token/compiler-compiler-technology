/////////////////////////////////////////////////////////////////////
//	TokenNames.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_TOKENNAMES_H_
#define  _CPPCC_TOKENNAMES_H_

#include "cppccstd.h"


namespace cppcc {
namespace tnm {

struct	TokenNameContainer {
	typedef std::map<std::string, std::string> TokenNameMap;
	
	TokenNameMap	tokenNames_;
	
	TokenNameContainer() {
		populate();
	}

private:
	void populate();
};

}
}

#endif

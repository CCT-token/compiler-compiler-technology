/////////////////////////////////////////////////////////////////////
//	Tokenizer.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_TOKENIZER_H_
#define  _CPPCC_TOKENIZER_H_

#include "cppccstd.h"
#include "CommonRoutines.h"
#include "SystemRoutines.h"
#include "SyntaxControlledRuntime.h"
#include "TokenNames.h"

namespace cppcc {

namespace log {
	class Logger;
}

// xml //
namespace syn {
	class Parser;
}

namespace lex {

/* -> moved to com
enum LanguageTokenizerSet
{
  LanguageTokenizerSet_Undefined
  ,LanguageTokenizerSet_Meta
  ,LanguageTokenizerSet_XML
  //,LanguageTokenizerSet_CPP
  //,LanguageTokenizerSet_C
  //,LanguageTokenizerSet_VHDL
};
*/

enum TokenizerReader
{
	TokenizerReader_Undefined
	,TokenizerReader_File
	,TokenizerReader_String
};


class Tokenizer;

class LineReader
{

protected:

    Tokenizer&      tok;

public:

    virtual bool	  get(std::string&  theLine) = 0;
    virtual void	  put(const std::string&  theLine) = 0;
    virtual bool      hasListing() const = 0;
    virtual bool      isEof() const = 0;
    
    virtual void	  start
		(const std::string& filename
		,const std::string& listname) = 0;
    
    virtual void	  start
		(const std::string& inputString
		,bool				isListing) = 0;
    
    LineReader(Tokenizer&      theTokenizer)
      : tok(theTokenizer)
    {
    }
    
    virtual ~LineReader() 
    {
    }
    
};

///////////////////////////////////////////////////////////////////////////////
// Reading from file.
///////////////////////////////////////////////////////////////////////////////
class FileLineReader : public LineReader
{

	std::string			    fileName_;
	std::string			    listName_;
	std::ifstream		    inpf_;
	std::ofstream		    lstf_;	
	bool                	listingFlag_;
	
	void                	openFiles();


public:

/*
  FileLineReader
      (Tokenizer&             theTokenizer
      ,const std::string&	  theFileName
      ,const std::string&	  theListName)
      : LineReader(theTokenizer)
      , fileName_(theFileName)
      , listName_(theListName)
      , listingFlag_(false)
  {
    openFiles();
  }
*/
  FileLineReader(Tokenizer& 	theTokenizer)
	: LineReader(theTokenizer)
	, fileName_()
    , listName_()
    , listingFlag_(false)
  {}
   
    
  ~FileLineReader() 
  {
  }
    
  bool	    get(std::string&  theLine) 
  {
	  std::getline(inpf_, theLine);
	  
	  return inpf_;
  }
	  
  void	    put(const std::string&  theLine) 
  {
	  if (lstf_) {
	    lstf_ << theLine << std::endl;
	  }
  }

  bool      hasListing() const
  {
	  return listingFlag_;
  }

  bool      isEof() const 
  {
	  return inpf_;
  }

  /*
  void	  start
		(const std::string& filename
		,bool 				isListing)
  {
	  fileName_ 	= filename;
	  listingFlag_	= isListing;
	  if (listingFlag_) {
		listName_ = filename + ".lis";
	  }
	  openFiles();
  }
  
  void	  start
		(const std::string& inputString
		,std::string& 		outputString)
  {
	  
  }
  */
  void	  start
		(const std::string& filename
		,const std::string& listname)
  {
	  fileName_ 	= filename;
	  listName_		= listname;
	  listingFlag_	= ("" != listName_);
	  openFiles();
  }
  
  void	  start
		(const std::string& inputString
		,bool				isListing)
  {}

  operator	std::ifstream&	()		{ return inpf_; }   
  operator	std::ofstream&	()		{ return lstf_; }   
	
};

class StringLineReader : public LineReader
{

	std::string			source_;
	std::string			listing_;
	bool                listingFlag_;

	void                buildLineContainer()
	{
	}

public:

/*
  StringLineReader
      (Tokenizer&             theTokenizer
      ,const std::string&	  theSource)
      : LineReader(theTokenizer)
      , source_(theSource)
      , listing_("")
      , listingFlag_(false)
  {
    buildLineContainer();
  }
 
  StringLineReader
      (Tokenizer&             theTokenizer
      ,const std::string&	  theSource
      ,bool                   theListingFlag)
      : LineReader(theTokenizer)
      , source_(theSource)
      , listing_("")
      , listingFlag_(theListingFlag)
  {
    buildLineContainer();
  }
*/
	StringLineReader
	(Tokenizer&             theTokenizer)
	: LineReader(theTokenizer)
	,source_()
	,listing_()
	,listingFlag_(false)
	{}
 
  ~StringLineReader() 
  {
  }
    
  bool	    get(std::string&  theLine) 
  {
	return false;
  }
	   
  void	    put(const std::string&  theLine) 
  {  
  }

  bool      hasListing() const
  {
	  return listingFlag_;
  }

  bool      isEof() const 
  {
	  return false;
  }

/*
  void	  start
		(const std::string& filename
		,bool 				isListing)
  {
  }
  
  void	  start
		(const std::string& inputString
		,std::string& 		outputString)
  {
		//std::string			source_;
		//std::string			listing_;
		//bool                listingFlag_;

	 source_ 		= inputString;
	 listingFlag_ 	= true;
	 buildLineContainer();
  }	
*/
  void	  start
		(const std::string& filename
		,const std::string& listname)
  {}
  
  void	  start
		(const std::string& inputString
		,bool				isListing)
  {
	  source_ 		= inputString;
	  listingFlag_	= isListing;
  }
  
  operator	std::string&	()		{ return listing_; }   
   
};

struct Token
{
  Tokenizer&    tokenizer_;
  std::string   token_;
  std::string   name_;
  int           symbol_;
  
  Token(
    Tokenizer&          tokenizer
    ,const std::string& token
    ,const std::string& name
  )
  : tokenizer_(tokenizer)
  , token_(token)
  , name_(name)
  , symbol_(0)
  {}
  
  virtual ~Token() {}
  
  virtual bool isToken() = 0;
  virtual void flushToken() = 0;
  virtual void skipToken(const int t, cppcc::scr::tag::Long& l);

  // ub:
  virtual std::string gid() const
  {
    int isDebug =1;

    if (isDebug) {
      std::cout
        << "token_:" << "'" << token_ << "'"
        << " name_:" << "'" << name_ << "'"
        << " symbol_:" << symbol_
        << std::endl
      ;
    }

    return
      (" " == token_)
        ? name_
        : token_
    ;
  }

};

struct OneCharToken : public Token
{
  OneCharToken
    (Tokenizer&          	tokenizer
	,const std::string& 	token
	,const std::string&	 	name)
	  : Token(tokenizer, token, name)
  {}
  
  ~OneCharToken()
  {}
  
  bool isToken();
  // xml.11 // 
  void flushToken();
  // xml.11 // virtual void flushToken();
  //void skipToken(cppcc::scr::tag::Long& l);
};

struct OneCharXmlGreaterThanToken : OneCharToken
{
	bool	isXmlTokenFlag_;
	
	OneCharXmlGreaterThanToken
	    (Tokenizer&          	tokenizer
		,const std::string& 	token
		,const std::string&	 	name)
		: OneCharToken(tokenizer, token, name)
		, isXmlTokenFlag_(false)
	{}
	  
	~OneCharXmlGreaterThanToken()
	{}	
	
	void skipToken(const int t, cppcc::scr::tag::Long& f);
	void processGreaterThanAndXmlTermToken(cppcc::scr::tag::Long& f);
	//xml// void xmlTokenOff() 	{ isXmlTokenFlag_ = false; }
	//xml// void xmlTokenOn() 	{ isXmlTokenFlag_ = true; }
	//void xmlDataSegmentAsStringToken(std::string& result);
	
	// xml.11 // void flushToken();
};

struct TwoCharToken : public Token
{
	TwoCharToken
      (Tokenizer&          	tokenizer
	  ,const std::string& 	token
	  ,const std::string&	name)
	  : Token(tokenizer, token, name)
  {}
	
  ~TwoCharToken()
  {}
  
  bool isToken();
  void flushToken();
  //void skipToken(cppcc::scr::tag::Long& l);
};


struct ThreeCharToken : public Token
{
	ThreeCharToken
      (Tokenizer&          	tokenizer
	  ,const std::string& 	token
	  ,const std::string&	name)
	  : Token(tokenizer, token, name)
  {}
	
  ~ThreeCharToken()
  {}
  
  bool isToken();
  void flushToken();
  //void skipToken(cppcc::scr::tag::Long& l);
};

//typedef std::map<std::string, int>		TerminalSymbols;

//////typedef std::map<std::string, Token*>	Tokens;
struct Tokens 
{
	typedef std::map<std::string, int>  Name2IndexMap;
	typedef std::vector<Token*>         TokenVector;
	
  // token_ to index map:
	Name2IndexMap	name2index_;

  // name_ to index map:
  //ub:
  Name2IndexMap	id2index_;
	TokenVector		tokens_;
	
	~Tokens() {
	  epilog();
	}
	
	void epilog() throw();

  std::string gid(const std::string& tn) const
  {
    int isDebug = 1;
    Name2IndexMap::const_iterator cf = id2index_.find(tn);
    Name2IndexMap::const_iterator ce = id2index_.end();
    bool y = (ce != cf);
    std::string tn2;

    if (y) {
      if ((cf->second < 0) || (cf->second >= tokens_.size())) {
        // exception !
      }
      else
      {
        cppcc::lex::Token* token = tokens_[cf->second];
        if (token)
        {
          tn2 = token->token_;

          if (isDebug) {
            std::cout
              << "Tokens::gid" 
              << " tn:" << "'" << tn << "'"
              << " tt::token_:" << "'" << token->token_ << "'"
              << " tt::name_:" << "'" << token->name_ << "'"
              << " tt::symbol_:" << token->symbol_
              << std::endl;
          }

        }
        else {
          // exception !
        }
      }
    } else {
      tn2 = tn;
    }

    if (isDebug) {
      std::cout
        << "Tokens::gid" 
        << " tn:" << "'" << tn << "'"
        << " tn2:" << "'" << tn2 << "'"
        << std::endl;
    }

    return tn2;
  }
};

inline
std::ostream& operator<<(std::ostream& strm, const Token& t)
{
	strm
		<< "Token="
		<< "("
		<< t.symbol_ 
		<< " " << "'" << t.token_ << "'"
		<< " " << "'" << t.name_ << "'"
		<< ")"
	;
	
	return strm;
}

inline
std::ostream& operator<<(std::ostream& out, const Tokens& ts)
//std::ostream& operator<<(std::ostream& out, Tokens& ts)
{
  out
	<< "name2index_.size:" << ts.name2index_.size()
  << " id2index_.size:" << ts.id2index_.size()
	<< " tokens_.size:" << ts.tokens_.size()
	<< std::endl;

  out
	<< "name2index_.size:" << ts.name2index_.size()
	<< std::endl;
  {
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ci =
	  ts.name2index_.begin();  
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ce = 
	  ts.name2index_.end();
    for (; ce != ci; ++ci) {
      int idx = ci->second;

      out
        << " index:" << idx;

	    if((idx < 0) || (idx >= ts.tokens_.size())) {
        out << std::endl;
	      continue;
	    }

	    cppcc::lex::Token* t = ts.tokens_[idx];
      if (t) {
        out << " " << (*t) ;
      }
      out << std::endl;
    }
  }

  out
  << " id2index_.size:" << ts.id2index_.size()
	<< std::endl;
  {
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ci =
	  ts.id2index_.begin();  
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ce = 
	  ts.id2index_.end();
    for (; ce != ci; ++ci) {
      int idx = ci->second;

      out
        << " index:" << idx;

	    if((idx < 0) || (idx >= ts.tokens_.size())) {
        out << std::endl;
	      continue;
	    }

	    cppcc::lex::Token* t = ts.tokens_[idx];
      if (t) {
        out << " " << (*t) ;
      }
      out << std::endl;
    }
  }

  out
	<< " tokens_.size:" << ts.tokens_.size()
	<< std::endl;

  for (std::size_t i= 0, z = ts.tokens_.size(); i < z; i++) {
	  cppcc::lex::Token* t = ts.tokens_[i];
    out
      << " index:" << i;
    if (t) {
      out << " " << (*t) ;
    }
    out << std::endl;
  }

  return out;
}

struct Language
{
// --> cppcc::com
/*
  enum PREDEFINED_LANGUAGE_SYMBOLS {
	  PLS_WRONG_KEY_WORD
	  ,PLS_IDENTIFIER
	  ,PLS_STRING_TOKEN
	  ,PLS_INTEGER_TOKEN
	  ,PLS_FLOAT_TOKEN
	  ,PLS_TEXT_TOKEN
	  ,PLS_TERMINAL_TOKEN
	  ,PLS_TERMTOKENOFRULE_TOKEN
	  ,PLS_TERMINALS_START
  };
*/
	
  Tokenizer&				tokenizer_;
  Tokens					tokens_;
  Tokens					keyWords_;
  Tokens					nonTerminals_;
  //TerminalSymbols   terminalSymbols_;
  cppcc::com::LanguageTokenizerSet		tokenizerSet_;
  
  Language(Tokenizer&	tokenizer, cppcc::com::LanguageTokenizerSet tset)
	 : tokenizer_(tokenizer)
	 , tokens_()
	 , keyWords_()
     , nonTerminals_()
	 //, terminalSymbols_() 
	 , tokenizerSet_(tset)
  {}
  
  virtual ~Language() {}
  virtual void getchr() = 0;
  virtual void getid() = 0; 
  virtual void getint() = 0; 
  virtual void getstring() = 0; 
  virtual void getNextToken() = 0; 
  virtual void flush() = 0;
  //virtual void getchrXmlData() = 0;
  //virtual void xmlTokenOn() {}
		  
  void 		populateTerminals();
  bool		isDefinedToken();
  bool		isKeyWord(const std::string& id);
  void  	setKeyWord(const std::string& id);
  void		setNextToken();
  void  	skipToken(const int t, cppcc::scr::tag::Long& l);
  Token& 	getToken(const int t);
  void 		getTermString();
};

struct LanguageMeta : Language
{
	LanguageMeta(Tokenizer&	tokenizer, cppcc::com::LanguageTokenizerSet tset)
		: Language(tokenizer, tset)
	{
		populate();
	}
	
	~LanguageMeta() {}
	
	void getchr();
	void getid(); 
	void getint(); 
	void getstring(); 
	void getNextToken(); 
	void flush();
	///void getchrXmlData();
	
	void populate();
	
	//void getTermString();
	
	// methods below are used by getNextToken() only
	bool	isStringToken();
	bool	isIntegerToken();
	bool	isTerminalStringToken();

	Token*	makeToken
		(const std::string& t
		,const std::string& n);
};


struct LanguageXML : Language
{
	LanguageXML(Tokenizer&	tokenizer, cppcc::com::LanguageTokenizerSet tset)
		: Language(tokenizer, tset)
	{
		populate();
	}
	
	~LanguageXML() {}
	
	void getchr();
	void getid(); 
	void getint(); 
	void getstring(); 
	void getNextToken(); 
	void flush();
	//void getchrXmlData();
	
	void populate();
	void getXmlDataString();
	void convertSpecialCharacters();
	//void getTermString();
	
	// methods below are used by getNextToken() only	
	bool	isStringToken();
	bool	isIntegerToken();
	bool	isTerminalStringToken();
	//void 	xmlTokenOn();
	
	Token*	makeToken
		(const std::string& t
		,const std::string& n);
};


///////////////////////////////////////////////////////////////////////////////
// Tokenizer class defines language tokens set and manipulations.
///////////////////////////////////////////////////////////////////////////////
struct Tokenizer {
  
  // xml //
  cppcc::syn::Parser&				parser_;
  
  cppcc::log::Logger&				logger_;
  cppcc::com::KeyWordsContainer&	grammarSymbols_;
  cppcc::tnm::TokenNameContainer	defaultTokenNames_;
  LineReader* 						reader_;
  Language*							language_;

  int					    ch_;
  int					  	nline_;
  int					  	npos_;
  int						epos_;
  std::string				line_;
  int					    errn_;
  int					  	ercn_;
  //std::vector<int>	      	erset_;
  int					 	warn_;	
  int					  	brlev_;		

  std::string				id_;	
  long    			     	ival_;
  std::string    		    strng_; 
  std::string    		    termString_; 
  double				  	rval_;
  int   				  	kword_;
  int   					rword_;
  int    				  	erflag_;
  int					   	ergl_;		
  int					  	debug_;
  int					   	modeintfloat_;
  bool                    	isString_;
  bool                    	isTermString_;
  //bool 						xmlEolMode_;
  //std::vector<std::string>  KeyTab_;	
	
  //int		    warning(enum ErrorCode e);
  void	        getnewl();

  //void          initErset();
  void          startAction();
  
  void 			prolog();
  void 			epilog() throw();
  Language*	  	makeLanguage(cppcc::com::LanguageTokenizerSet languageID);
  LineReader*   makeLineReader(TokenizerReader readerID);
  
	Tokenizer
	    // xml
	    (cppcc::syn::Parser&			parser
	    ,cppcc::log::Logger& 			theLogger
	    ,cppcc::com::KeyWordsContainer&	theKeyWords
	    //,int theNonTerms
	    //,const tag::ReservedKeyWords&   theGrammerKeyWords
	    ,cppcc::com::LanguageTokenizerSet			theLanguage
	    ,TokenizerReader 				theReader
	    )
		: parser_(parser)
		, logger_(theLogger)
		, grammarSymbols_(theKeyWords)
		, defaultTokenNames_() 
		, reader_(makeLineReader(theReader))
		, language_(makeLanguage(theLanguage))
		, ch_(0)
		, nline_(0)
		, npos_(0)
		, epos_(0)
		, line_()
		, errn_(0)
		, ercn_(0)
		//, erset(static_cast<int>(EC_EREND))
		, warn_(0)
		, brlev_(0)
		, id_()
		, ival_(0)
		, strng_()
		, termString_()
		, rval_(0.0)
		, kword_(0)
		, rword_(0)
		, erflag_(0)
		, ergl_(0)
		, debug_(0)
		, modeintfloat_(0)
		//, gkw(theGrammerKeyWords)
		, isString_(false)
		, isTermString_(false)
		//, KeyTab...
	    //, xmlEolMode_(false)
	{
       prolog();
	}
	
	~Tokenizer()
	{
	   epilog();
	}

	//int		  err(enum ErrorCode e);
	//void 	      mess(const std::string& m);
	void	start(const char *sour, const char *list);
	void	start(const std::string& sour, bool list);
	void	erfini();
	
	void 	errorMessage(const std::string& mes);
	void 	infoMessage(const std::string& mes);	

	void  	flushBlanks() {
	  while (ch_ == ' ') getchr();
	}
	
	bool 	iseof() { return (ch_ == EOF); }

/*
	void    checkReader(const std::string& n)
	{
		if (!reader_) {
			CPPCC_THROW_EXCEPTION(
			  << "Tokenizer::" << n << "() -- Language is not set!"
			)  
		}	
	}
	
	bool      isReaderEof()
	{
	  checkReader("isReaderEof");
      return reader_->isEof();
	}	
*/
	
	void    checkLanguage(const std::string& n)
	{
		if (!language_) {
			CPPCC_THROW_EXCEPTION(
			  << "Tokenizer::" << n << "() -- Language is not set!"
			)  
		}	
	}
	
	void 	flush() {
	  checkLanguage("flush");
	  language_->flush();
	}

	void 	getchr() {
	  checkLanguage("getchr");
	  language_->getchr();
	}
	
	//void 	getchrXmlData() {
	//  checkLanguage("getchrXmlData");
	//  language_->getchrXmlData();
	//}

	void	getNextToken() {
	  checkLanguage("getNextToken"); 
	  language_->getNextToken();
	}

	void	getid() {
	  checkLanguage("getid"); 
	  language_->getid();
	}

	void	getint() {
	  checkLanguage("getint"); 
	  language_->getint();
	}

	void	getstring() {
	  checkLanguage("getstring"); 
	  language_->getstring();
	}
	
	//void 	xmlTokenOn() {
	//  checkLanguage("getstring"); 
	//  language_->xmlTokenOn();
	//}
	
	bool	isQuote()			{ return ('"' == ch_);}
	void	flushQuote()		{ if (isQuote()) {getchr(); flushBlanks(); }}
	
	bool	isSingleQuote()		{ return ('\'' == ch_);} 
	void	flushSingleQuote()	{ if (isSingleQuote()) {getchr(); flushBlanks(); }}
	
	void 	convertSpecialCharacters();
	void 	getXmlDataString();
};


inline 
bool	
LanguageMeta::isStringToken() {
	return
		tokenizer_.isQuote()
    ;
}

inline
bool	
LanguageMeta::isIntegerToken() {
	return
		isdigit(tokenizer_.ch_)
    ;
}

inline
bool	
LanguageMeta::isTerminalStringToken() {
	return
		tokenizer_.isSingleQuote()
    ;
}

inline
bool	
LanguageXML::isStringToken() {
	return
		tokenizer_.isQuote()
    ;
}

inline
bool	
LanguageXML::isIntegerToken() {
	return
		isdigit(tokenizer_.ch_)
		|| (
			('.' == tokenizer_.ch_)
			&& (
			  ((tokenizer_.npos_+1) 
					  < static_cast<int>(tokenizer_.line_.size()))
			  && (isdigit(tokenizer_.line_[tokenizer_.npos_+1]))
			)
		)
    ;
}


inline
bool	
LanguageXML::isTerminalStringToken() {
	return
		tokenizer_.isSingleQuote()
    ;
}

/*
inline
std::ostream& operator<<(std::ostream& strm, const Token& t)
{
	strm
		<< "Token="
		<< "("
		<< t.symbol_ 
		<< " " << "'" << t.token_ << "'"
		<< " " << "'" << t.name_ << "'"
		<< ")"
	;
	
	return strm;
}
*/

inline
bool
OneCharToken::isToken() 
{
  return tokenizer_.ch_ == token_[0];
}

inline
void 
OneCharToken::flushToken() 
{
  if (isToken()) {
    tokenizer_.getchr();
    tokenizer_.flushBlanks();
  }
} 

/*
// xml.11 // 
inline
void 
OneCharXmlGreaterThanToken::flushToken() 
{
  if (isToken()) {
    tokenizer_.getchr();
    ///tokenizer_.flushBlanks();
    if (!tokenizer_.parser_.isXmlTokenFlag()) {
      tokenizer_.flushBlanks();
    }
  }
} 
*/

inline
bool 
TwoCharToken::isToken() {
	return 
	  (tokenizer_.ch_ == token_[0])
	  && (
	    ((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size()))
	    &&
		(tokenizer_.line_[tokenizer_.npos_+1] == token_[1])
	  )
	;
}

inline
void 
TwoCharToken::flushToken() {
	  if (isToken()) {
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.flushBlanks();
	  }
} 

inline
bool 
ThreeCharToken::isToken() {
	return 
	  (tokenizer_.ch_ == token_[0])
	  && (
			((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size()))
			&&  
			(tokenizer_.line_[tokenizer_.npos_+1] == token_[1])
	  )
	  && (
			((tokenizer_.npos_+2) < static_cast<int>(tokenizer_.line_.size()))
			&&  
			(tokenizer_.line_[tokenizer_.npos_+2] == token_[2])
	  )
	;
}

inline
void 
ThreeCharToken::flushToken() {
	  if (isToken()) {
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.flushBlanks();
	  }
} 

inline
Token& 	
Language::getToken(const int t) 
{
  int s1 =
	cppcc::com::PLS_TERMINALS_START
	+ static_cast<int>(tokens_.tokens_.size());
  
  int s2 = 
	s1
	+ static_cast<int>(keyWords_.tokens_.size());
  
  int s3 = 
	s2
	+ static_cast<int>(nonTerminals_.tokens_.size());
  
  Token*	token = 0;
  if ((t >= cppcc::com::PLS_TERMINALS_START) && (t < s1)) {
    const int index = t - cppcc::com::PLS_TERMINALS_START;
    //error// token = tokens_.tokens_[t];
    token = tokens_.tokens_[index];
  } 
  else if ((t >= s1) && (t < s2)) 
  {
	const int index = t - s1;
	//error// token = keyWords_.tokens_[t];
	token = keyWords_.tokens_[index];
  } 
  else if ((t >= s2) && (t < s3)) 
  {
	const int index = t - s2;
	//error// token = nonTerminals_.tokens_[t];
	token = nonTerminals_.tokens_[index];
  } 
  else {
	CPPCC_THROW_EXCEPTION(
	  << "Can't access token:"
	  << "'" << t << "'"
	  << " - it's out off range:["
	  << cppcc::com::PLS_TERMINALS_START
	  << "," << s3 << ")."
	)	  
  }
  
  if (!token) {
	CPPCC_THROW_EXCEPTION(
	  << "Can't access token:"
	  << "'" << t << "'"
	)	  
  }
  
  return (*token);
}


inline
void  
Language::skipToken
	(const int 				t
	,cppcc::scr::tag::Long& l)
{
	Token& 	token = getToken(t);
	token.skipToken(t, l);
	//!!!// 
	getNextToken();
    //if (!tokenizer_.parser_.isXmlTokenFlag()) {
	//  getNextToken();
    //}	
}


inline
void 
Token::skipToken
	(const int 				t
	,cppcc::scr::tag::Long& f)
{
	//if ((t - cppcc::com::PLS_TERMINALS_START) != symbol_) {
	if (t != symbol_) {
	    CPPCC_THROW_EXCEPTION(
	    	<< "Key Word "
			<< "'" << name_ << "'"
			<< ":" << "'" << token_ << "'"
			<< ":" << "'" << symbol_ << "'"
			//<< "---" << "'" << (t - cppcc::com::PLS_TERMINALS_START) << "'"
			<< "---" << "'" << t << "'"
			<< " is missing."
		)	
	}
	
	cppcc::scr::tag::setedflong(&f,cppcc::com::PLS_TERMINAL_TOKEN,t);
	//!!!// tokenizer_.language_->getNextToken();
}

inline
void 
OneCharXmlGreaterThanToken::skipToken
	(const int 				t
	,cppcc::scr::tag::Long& f)
{
	//if ((t - cppcc::com::PLS_TERMINALS_START) != symbol_) {
	if (t != symbol_) {
		CPPCC_THROW_EXCEPTION(
			<< "Key Word "
			<< "'" << name_ << "'"
			<< ":" << "'" << token_ << "'"
			<< ":" << "'" << symbol_ << "'"
			//<< "---" << "'" << (t - cppcc::com::PLS_TERMINALS_START) << "'"
			<< "---" << "'" << t << "'"
			<< " is missing."
		)	
	}

	processGreaterThanAndXmlTermToken(f);
	//!!!// 
	//does not get called!///tokenizer_.language_->getNextToken();
}
/*
inline
void 
OneCharXmlGreaterThanToken::processGreaterThanAndXmlTermToken
	(cppcc::scr::tag::Long& l)
{

  // xml //
  // xml // if (isXmlTokenFlag_) {
  if (tokenizer_.parser_.isXmlTokenFlag()) {
	if ('<' != tokenizer_.ch_) {
		//register int s;
		//long f[2];
		//
		//setedflong((f),KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
		//if(s= xmlDataSegmentAsStringToken(f+1)) return(s);
		//crefixe(KW_XMLTOKEN);
		std::vector<cppcc::scr::tag::Long> f(2);
		cppcc::scr::tag::setedflong(&f[0],cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
		
		//33// std::string result;
		//33// xmlDataSegmentAsStringToken(result);
		// result -> &f[1]
		tokenizer_.getXmlDataString();
		// tokenizer_.termString_ ==>> &f[1]
		
		//crefixe(KW_XMLTOKEN);
	} else {
		//setedflong(l,KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
		cppcc::scr::tag::setedflong(&l,cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
	}
    
	tokenizer_.parser_.xmlTokenOff();
  } else {
    //setedflong(l,KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
	cppcc::scr::tag::setedflong(&l,cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
  }
  
  return;
}
*/

/*
inline
void 	
LanguageXML::xmlTokenOn()
{
  Tokens::Name2IndexMap::const_iterator cIter = 
    tokens_.name2index_.find(">");
    
  if (tokens_.name2index_.end() == cIter) return;

  if (
    (cIter->second < 0)
    || (cIter->second >= static_cast<int>(tokens_.tokens_.size()))
  ) {
    return;
  }

  Token* t = tokens_.tokens_[cIter->second];
  if (!t) return;
  
  OneCharXmlGreaterThanToken* xt = 
		  dynamic_cast<OneCharXmlGreaterThanToken*>(t);
  if (!xt) return;
  xt->xmlTokenOn();
}
*/



inline
void 
Tokens::epilog() throw()
{
  try {
	  for (std::size_t i, s = tokens_.size(); i < s; i++) {
		  if(tokens_[i]) {
			  delete tokens_[i];
			  tokens_[i] = 0;
		  }
	  }
  }
  catch(...) 
  {}
}
	
	
//--------------------------------
}
}


//std::ostream& operator<<(std::ostream& out, const cppcc::lex::Token& t);
//std::ostream& operator<<(std::ostream& out, const cppcc::lex::Tokens& ts);


#endif


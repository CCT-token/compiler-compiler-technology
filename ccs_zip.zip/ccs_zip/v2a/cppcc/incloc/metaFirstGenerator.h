/////////////////////////////////////////////////////////////////////
//	metaFirstGenerator.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_META_FIRST_GENERATOR_H_
#define  _CPPCC_META_FIRST_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace metafirst {

class metaFirstGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
{

public:
  
	metaFirstGeneratorRuntime(cppcc::gen::Generator&   generator)
	  : cppcc::gen::GeneratorRuntime(generator)
	{
	}
	
  ~metaFirstGeneratorRuntime()
	{
	}
	
  //void        decompile(const std::string& filename);
  //void        generate(const std::string& filename);

};
	
class metaFirstGeneratorBinary
  : public cppcc::gen::GeneratorBinary
{

public:
	  
	metaFirstGeneratorBinary(cppcc::gen::Generator&   generator)
		: cppcc::gen::GeneratorBinary(generator)

	{
	}
		
	~metaFirstGeneratorBinary()
	{
	}
		
	//void        decompile(const std::string& filename);
	//222// 
	void        generate(const std::string& filename);

};
	

}


}

#endif

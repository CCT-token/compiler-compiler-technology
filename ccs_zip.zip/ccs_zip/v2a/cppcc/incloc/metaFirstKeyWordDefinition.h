/////////////////////////////////////////////////////////////////////
//	KeyWordDefinition.h <- metaaKeyWordDefinition.h
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_METAFIRSTKEYWORDDEFINITION_H_
#define  _CPPCC_METAFIRSTKEYWORDDEFINITION_H_

#include "CommonRoutines.h"

namespace cppcc {
namespace metafirst {

enum KeyWords
{
	// 0
	KW_WRONGKEYWORD
	// 1
	,KW_IDENTIFIER
	// 2 
	,KW_STRINGTOKEN
	// 3
	,KW_INTEGERTOKEN
	// 4
	,KW_FLOATTOKEN
	// 5
	,KW_TEXTTOKEN
	// 6
	,KW_TERMTOKEN
	// 7
	,KW_TERMTOKENOFRULE
	////////  ,PLS_TERMINALS_START
	// 8 - 0
	,KW_QUOTETERMTOKEN
	// 9 - 1
	,KW_APOSTROPHETERMTOKEN
	// 10 - 2
	,KW_LEFTPARENTHESISTERMTOKEN
	// 11 - 3
	,KW_RIGHTPARENTHESISTERMTOKEN
	// 12 - 4 
	,KW_LESSTHANTERMTOKEN
	// 13 - 5
	,KW_EQUALTERMTOKEN
	// 14 - 6
	,KW_GREATERTHANTERMTOKEN
	// 15 - 7
	,KW_LEFTSQUAREBRACKETTERMTOKEN
	// 16 - 8
	,KW_RIGHTSQUAREBRACKETTERMTOKEN
	// 17 - 9
	,KW_VERTICALBARTERMTOKEN
	// 18 - 10
	,KW_LEFTBRACETERMTOKEN
	// 19 - 11
	,KW_RIGHTBRACETERMTOKEN
	// 20 - 12
	,KW_DEFISTERMTOKEN
	// 21 - 13
	// xml ::::::::::::::::::::::::::
	/////
	,KW_COLONMARKTERMTOKEN
	,KW_QUESTIONMARKTERMTOKEN
	,KW_SLASHMARKTERMTOKEN
	,KW_XMLENDTERMTOKEN
	////
	// xml ..........................
	
	// dot:::::::::::::::::::::::::::
	,KW_COMMATERMTOKEN
	,KW_SEMICOLONTERMTOKEN
	,KW_EDGEOPTERMTOKEN
	//,KW_DIGRAPHTERMTOKEN
	//,KW_SUBGRAPHTERMTOKEN
	// dot...........................
	
	////// _KEYWORD
	////// non-terminals
	// 21 - 0
	,KW_GRAMMAR 
	// 22 - 1
	,KW_GRAMMARNAMEDEF 
	// 23 - 2
	,KW_RULE 
	// 24 - 3
	,KW_NTERM 
	// 25 - 4
	,KW_RIGHT 
	// 26 - 5
	,KW_ELEMENT 
	// 27 - 6
	,KW_ACTION 
	// 28 - 7
	,KW_ACTIONS 
	// 29 - 8
	,KW_IDENTALT 
	// 30 - 9
	,KW_ALTPART 
	// 31 - 10
	,KW_NTERMTERMACT 
	// 32 - 11
	,KW_NTERMTERM 
	// 33 - 12 
	,KW_ALTERNATIVE 
	// 34 - 13
	,KW_IDENTMISS 
	// 35 - 14
	,KW_ITERATION 
	// 36 - 15
	,KW_ITERITEMS 
	// 37 - 16
	,KW_ALTITERITEM 
	// 38 - 17
	,KW_ITERITEMACT 
	// 39 - 18
	,KW_ITERITEM 
	// 40 - 19
	,KW_MAYBENTERM
	// 41 - 20
	// Total: 41+1 = 42
	,KW_KEYWORDS_TOTAL
};

cppcc::com::KeyWordsContainer makeKeyWordsContainer();


}


}


#endif

/////////////////////////////////////////////////////////////////////
//	metaFirstGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////



#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metaFirstParser.h"
#include "metaFirstKeyWordDefinition.h"
#include "metaFirstGenerator.h"

namespace cppcc {
namespace metafirst {

namespace {
   std::string errorNoIdentifierFound("parser generation failed: no identifier found!");
   std::string errorNoRightEntryFound("parser generation failed: no 'right' entry found!");
   std::string errorHereMustBeIdentAlt("here must be 'identAlt'!");
   std::string errorHereMustBeIterItemact("here must be 'iterItemact'!");
   std::string errorHereMustAlternative("here must be 'alternative element' (| ...)!");   
   std::string errorHereMustINtermTermAct("here must be 'ntermtermact'!");
   std::string errorHereMustBeIdentifier("here must be 'identifier'!");
   std::string errorWrongSimpleElement("wrong simple element");
   std::string errorHereMustActions("here must be 'actions'");
   std::string errorWrongRightElement("wrong right part element type");
   std::string errorHereMustBeIterItem("here must be 'iterItem'!");
   std::string errorHereMustBeIterItems("here must be 'iterItems'!");
   std::string errorHereMustBeAltIterItem("here must be 'altIterItem'");
   std::string errorHereMustBeAltpart("here must be 'Altpart'");
   std::string errorSimpleAlternativeMustBeOne("simple alternative must be one");
   std::string errorSimpleAlternativeMustBeOneWithoutElements("simple alternative must be one (without other elements)");
   std::string errorIterationMustBeOne("iteration must be one"); 
   std::string errorHereMustBeIdentifierOrLess("here must be 'identifier' or < ... >"); 
   std::string errorRightElementHasNoDefinition("right part of rule has no definition in grammar");
   std::string errorTooManyFirstSymbols("too many first symbols");
   std::string errorUndefinedSimlpTerminal("3:undefined simple terminal in first symbols checking");
   std::string errorUndefinedSimlpTerminal1("1:undefined simple terminal in first symbols checking");
   std::string errorMetaidalFailed("call to metaidal() failed!");
   std::string errorFirstSymbolsConflict("first symbols conflict");   
   std::string errorHereMustBeIntegerToken("here must be 'integerToken'");  
   std::string errorUndefinedSimpleTerminal("undefined simple terminal");
   std::string errorNotYetImplementedVariantOfIteration("not yet implemented variant of iteration");
   std::string errorOnlyOneSymbolMayBeFollowedByIteration("only one symbol may be followed by iteration");
   std::string errorHereMustStringToken("here must be 'stringToken'");
   std::string errorFirstItemOfAlternativeMustBe("first item of alternative must be 'identifier' or 'key word'");
   std::string errorHereMustBeTermTokenOfRule("items of alternative must be 'key word' items");
   std::string errorSecondDefinitionOfLeftPartOfRule("second definition of left part of rule");
   
   std::string errorHereMustBeRight("here must be 'right'");
   
   std::string warningRuleIsNotUsed("this rule isn't used in any other rules (in right part)");
   
   std::string IITT("INTEGERTOKEN");
   
   std::string GeneratorHCode[] = {
	"/////////////////////////////////////////////////////////////////////"
	,"//  $Generator.h"
	,"//"
	,"//  Change history:"
	,"//    2010.06.12    - Initial version"
	,"//"
	,"/////////////////////////////////////////////////////////////////////"
    ,""
	,"#ifndef  _CPPCC_$_GENERATOR_H_"
	,"#define  _CPPCC_$_GENERATOR_H_"
    ,""
	,"#include \"Generator.h\""
    ,""
	,"namespace cppcc {"
	,"namespace $ {"
    ,""
	,"	class $GeneratorRuntime"
	,"	: public cppcc::gen::GeneratorRuntime"
	,"	{"
	,"	public:"
	,"		$GeneratorRuntime(cppcc::gen::Generator&   generator)"
	,"	       : cppcc::gen::GeneratorRuntime(generator)"
	,"	 	{"
	,"	  	}"
	,""	     
	,"		~$GeneratorRuntime()"
	,"	   	{"
	,"	   	}"
	,""	     
	,"	 	//void        decompile(const std::string& filename);"
	,"	  	//void        generate(const std::string& filename);"
    ,""
	,"	};"
	,""	     
	,"	class $GeneratorBinary"
	,"	: public cppcc::gen::GeneratorBinary"
	,"	{"
	,"	public:"   
	,"		$GeneratorBinary(cppcc::gen::Generator&   generator)"
	,"	       : cppcc::gen::GeneratorBinary(generator)"
    ,""
	,"		{"
	,"	 	}"
	,""	       
	,"		~$GeneratorBinary()"
	,"	   	{"
	,"	  	}"
	,""	       
	,"		//void        decompile(const std::string& filename);"
	,"		void        generate(const std::string& filename);"
	,"	};"
	,"}"
	,"}"
	,""
	,"#endif"
	,""	   
   };
   std::size_t GeneratorHCodeSize = sizeof(GeneratorHCode)/sizeof(GeneratorHCode[0]);

   std::string KeyWordDefinitionHCodeStart[] = {
  "/////////////////////////////////////////////////////////////////////"
  ,"//  $KeyWordDefinition.h"
  ,"//"
  ,"//  Change history:"
  ,"//    2010.06.12    - Initial version"
  ,"//"
  ,"/////////////////////////////////////////////////////////////////////"
    ,""
  ,"#ifndef  _CPPCC_$_KEYWORDDEFINITION_H_"
  ,"#define  _CPPCC_$_KEYWORDDEFINITION_H_"
    ,""
  ,"#include \"CommonRoutines.h\""
    ,""
  ,"namespace cppcc {"
  ,"namespace $ {"
  ,""
  ,"enum KeyWords"
  ,"{"
  };
   std::size_t KeyWordDefinitionHCodeStartSize = 
     sizeof(KeyWordDefinitionHCodeStart)/
     sizeof(KeyWordDefinitionHCodeStart[0]);
 
    std::string KeyWordDefinitionHCodeFinish[] = {
   "};"
   ,""
   ,"cppcc::com::KeyWordsContainer makeKeyWordsContainer();"
  ,""
  ,"}"
  ,"}"
  ,""
  ,"#endif"
  ,""    
   };
   std::size_t KeyWordDefinitionHCodeFinishSize = 
     sizeof(KeyWordDefinitionHCodeFinish)/
     sizeof(KeyWordDefinitionHCodeFinish[0]);

   // A
   //static std::string   predef_[] =
   //{
   //  "Wrong_Key_Word"
   //  ,"identifier"
   //  ,"string"
   //  ,"integer"
   //  ,"float"
   //  ,"text"
   //  ,"terminal"
   //  ,"terminalTokenOfRule"
   //};
   
   // B - no suffix
   static std::string   predef_[] =
   {
     "Wrong_Key_Word"
     ,"identifier"
     ,"stringToken"
     ,"integerToken"
     ,"floatToken"
     ,"textToken"
     //BUG// ,"terminalToken"
     ,"termToken"
     ,"terminalTokenOfRule"
   };

   static std::size_t	predefSize_ = 
     sizeof(predef_)/sizeof(predef_[0]);



   std::string ParserHCodeStart[] = {
   "/////////////////////////////////////////////////////////////////////"
   ,"//  $Parser.h"
   ,"//"
   ,"//  Change history:"
   ,"//    2010.06.12    - Initial version"
   ,"//"
   ,"/////////////////////////////////////////////////////////////////////"
   ,""
   ,"#ifndef  _CPPCC_$_PARSER_H_"
   ,"#define  _CPPCC_$_PARSER_H_"
   ,""
   ,"#include \"Parser.h\""
   ,""
   ,"namespace cppcc {"
   ,""
   ,"namespace cmp {"
   ,"  class Compiler;"
   ,"}"
   ,""
   ,"namespace $ {"
   ,""
   ,"class $Parser"
   ,"  : public cppcc::syn::Parser"
   ,"{"
   ,""
   ,"public:"
   ,"  $Parser "
   ,"    (cppcc::log::Logger&          logger"
   ,"    ,cppcc::com::KeyWordsContainer&   theKeyWords"
   ,"    ,cppcc::com::LanguageTokenizerSet   theLanguage"
   ,"    ,cppcc::lex::TokenizerReader    theReader)"
   ,"  : Parser(logger, theKeyWords, theLanguage, theReader)"
   ,"  {"
   ,"  }"
   ,""
   ,"  ~$Parser()"
   ,"  {"
   ,"  }"
   ,"" 
   ,"  void compile"
   ,"    (const char *sour, const char *list);"
   ,""   
   ,"  void compile"
   ,"      (const std::string& filename"
   ,"      ,const std::string& sourceString"
   ,"    ,bool         isListing);"
   ,""    
   ,""   
   };

    std::size_t ParserHCodeStartSize = 
        sizeof(ParserHCodeStart)/
        sizeof(ParserHCodeStart[0]);

     std::string ParserHCodeFinish[] = {
   "};"
   ,""
   ,"}"
   ,"}"
   ,""
   ,"#endif"  
     };
     
     std::size_t ParserHCodeFinishSize = 
        sizeof(ParserHCodeFinish)/
        sizeof(ParserHCodeFinish[0]);



     std::string GeneratorCCCode[] = {
     "/////////////////////////////////////////////////////////////////////"
     ,"//  $Generator.cc "
     ,"//"
     ,"//	Change history:"
     ,"//		2010.06.12		- Initial version"
     ,"//"
     ,"/////////////////////////////////////////////////////////////////////"
     ,""
     ,""
     ,"#include \"Shell.h\""
     ,"#include \"Logger.h\""
     ,"#include \"Compiler.h\""
     ,"#include \"Parser.h\""
     ,""
     ,"#include \"$Parser.h\""
     ,"#include \"$KeyWordDefinition.h\""
     ,"#include \"$Generator.h\""
     ,""
     ,"namespace cppcc {"
     ,"namespace $ {"
     ,""
     ,"void"      
     ,"$GeneratorBinary::generate(const std::string& filename)"
     ,"{"
     ,"}"
     ,""
     ,"}"
     ,"}"
        };
        std::size_t GeneratorCCCodeSize = 
        sizeof(GeneratorCCCode)/sizeof(GeneratorCCCode[0]);

   
        std::string MakeGeneratorsCCCode[] = {
   "/////////////////////////////////////////////////////////////////////"
   ,"//  $MakeGenerators.cc"
   ,"//"
   ,"//      Change history:"
   ,"//              2010.06.12              - Initial version"
   ,"//"
   ,"/////////////////////////////////////////////////////////////////////"
   ,""
   ,""
   ,"#include \"Shell.h\""
   ,"#include \"Logger.h\""
   ,"#include \"Compiler.h\""
   ,"#include \"Parser.h\""
   ,""
   ,"#include \"$Parser.h\""
   ,"#include \"$KeyWordDefinition.h\""
   ,"#include \"$Generator.h\""
   ,""
   ,"namespace cppcc {"
   ,""
   ,""
   ,"namespace com {"
   ,""
   ,"cppcc::gen::GeneratorRuntime*"  
   ,"makeRuntimeGenerator(cppcc::gen::Generator&   generator)"
   ,"{"
   ,"  return new cppcc::$"
   ,"    ::$GeneratorRuntime(generator);"
   ,"}"
   ,""
   ,"cppcc::gen::GeneratorBinary*"
   ,"makeBinaryGenerator(cppcc::gen::Generator&   generator)"
   ,"{"
   ,"  return new cppcc::$"
   ,"    ::$GeneratorBinary(generator);"
   ,"}"
   ,"}"
   ,""
   ,"}"
     };
     std::size_t MakeGeneratorsCCCodeSize = 
     sizeof(MakeGeneratorsCCCode)/sizeof(MakeGeneratorsCCCode[0]);

     std::string KeyWordDefinitionCCCodeStart[] = {
"/////////////////////////////////////////////////////////////////////"
,"//  $KeyWordDefinition.cc"
,"//"
,"//      Change history:"
,"//              2010.06.12              - Initial version"
,"//"
,"/////////////////////////////////////////////////////////////////////"
,""
,"#include \"$KeyWordDefinition.h\""
,""
,"namespace cppcc {"
,"namespace $ {"
,""
,"namespace {"
  };
  std::size_t KeyWordDefinitionCCCodeStartSize = 
  sizeof(KeyWordDefinitionCCCodeStart)/
    sizeof(KeyWordDefinitionCCCodeStart[0]);

  std::string KeyWordDefinitionCCCodeFinish[] = {
//   "}"
//   ,""
//   ,"cppcc::com::KeyWordsContainer makeKeyWordsContainer()"
//   ,"{"
//   ,"  cppcc::com::KeyWordsContainer result;"
//   ,""  
//   ,"  result.predefined_.assign(predef_,predef_+predefSize_);"
//   ,"  result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);"
//   ,"  result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);"
//   ,""  
//   ,"  return result;"
//   ,"}"
""
,"}"
,"}"
,""
,"namespace com {"
,"cppcc::com::KeyWordsContainer"
,"makeCompilerKeyWords()"
,"{"
,"  return cppcc::$::makeKeyWordsContainer();"
,"}"
,"}"
,""
,"}"
,""  
  };
  std::size_t KeyWordDefinitionCCCodeFinishSize = 
  sizeof(KeyWordDefinitionCCCodeFinish)/
    sizeof(KeyWordDefinitionCCCodeFinish[0]);
  

  std::string ParserCCCodeStart[] = {
"/////////////////////////////////////////////////////////////////////"
,"//  $Parser.cc "
,"//"
,"//  Change history:"
,"//    2010.06.12    - Initial version"
,"//"
,"/////////////////////////////////////////////////////////////////////"
,""
,"#include \"Shell.h\""
,"#include \"Logger.h\""
,"#include \"Compiler.h\""
,"#include \"Parser.h\""
,""
,"#include \"$Parser.h\""
,"#include \"$KeyWordDefinition.h\""
,""
,"namespace cppcc {"
,"namespace $ {"
,""
,"void" 
,"$Parser::compile"
,"  (const char *sour, const char *list)"
,"{"
,"  CPPCC_LOG_INFO(logger_,"
,"    << \"$Parser::compile() \""
,"    << \" source:\" << \"'\" << std::string(sour?sour:\"\") << \"'\""
,"    << \" listing:\" << \"'\" << std::string(list?list:\"\") << \"'\""
,"  )"
,""
,"  filename_ = sour?sour:\"\";"
,"  tokenizer_.start(sour, list);"
,""
,"  @(axiom_);"
,"" 
,"  tokenizer_.erfini();"
,"}"
,""  
,"void"
,"$Parser::compile"
,"    (const std::string& filename"
,"    ,const std::string& sourceString"
,"  ,bool         isListing)"
,"{"
,"  filename_ = filename;"
,"  tokenizer_.start(sourceString, isListing);"
,""
,"  @(axiom_);"
,""
,"  tokenizer_.erfini();"
,"}"
,""
  };
  std::size_t ParserCCCodeStartSize = 
  sizeof(ParserCCCodeStart)/sizeof(ParserCCCodeStart[0]);





  std::string ParserCCCodeFinish[] = {
"}"
,""
,"namespace com {"
,"cppcc::syn::Parser* "
,"makeParser(cppcc::cmp::Compiler& compiler)"
,"{"
,"  CPPCC_LOG_INFO((*compiler.shell_.logger_),"
,"    << \"com::makeParser() started...\""
,"    << \" tokensSetID:\" << compiler.shell_.tokensSetID_"
,"  )"
,"" 
,"  return"
,"    new cppcc::$"
,"      ::$Parser"
,"      ((*compiler.shell_.logger_)"
,"      ,compiler.keyWords_"
,"      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_^"
,"      ,cppcc::lex::TokenizerReader_File)"
,"    ;"
,"}"
,"}"
,""
,"}"
  };
  std::size_t ParserCCCodeFinishSize = 
  sizeof(ParserCCCodeFinish)/sizeof(ParserCCCodeFinish[0]);

   //------------------------------------------- ^
   
   
   std::string	line(const std::string& l, const std::string& gn)
   {
		std::size_t 	d = l.find_last_of('$');	
		
		//if (std::string::npos == d) {
		//	//output << l << std::endl;
		//	return l;
		//} else {
		//	//output 
		//	//	<< l.substr(0,d)
		//	//	<< gn
		//	//	<< l.substr(d+1)
		//	//	<< std::endl;
		//	return 
		//	l.substr(0,d)
		//	+ gn
		//	+ l.substr(d+1)
		//	;
		//}
		
		return
		  (std::string::npos == d)
		  ? (l)
		  : (l.substr(0,d) + gn + l.substr(d+1))
		;
   }

   std::string	line
	   (const std::string& l
	   ,const std::string& gn
	   ,const std::string& an)
   {
		std::size_t 	d = l.find_last_of('$');	
		std::size_t 	a = l.find_last_of('@');
		
		return
		  (std::string::npos == d)
		  ? (
			(std::string::npos == a)
			? l
			: (l.substr(0,a) + an + l.substr(a+1))
		  )
		  : (l.substr(0,d) + gn + l.substr(d+1))
		;
   }

   std::string	line
	   (const std::string& l
	   ,const std::string& gn
	   ,const std::string& an
	   ,const std::string& en)
   {
		std::size_t 	d = l.find_last_of('$');	
		std::size_t 	a = l.find_last_of('@');
		std::size_t 	e = l.find_last_of('^');	
		
		return
		  (std::string::npos == d)
		  ? (
			(std::string::npos == a)
			? (
			  (std::string::npos == e)
			  ? l
			  : (l.substr(0,e) + en + l.substr(e+1))
			)
			: (l.substr(0,a) + an + l.substr(a+1))
		  )
		  : (l.substr(0,d) + gn + l.substr(d+1))
		;
   }

   
   std::string	name(const std::string& filename)
   {
	std::size_t       	dot = filename.find_last_of('.');
	return
	  (std::string::npos == dot)
	    ? filename
	    : filename.substr(0,dot)
	;
   }
 
   
   std::string	extention(const std::string& filename)
   {
	std::size_t dot = filename.find_last_of('.');
	std::string ext =
	  (std::string::npos == dot)
	    ? std::string("")
	    : filename.substr(dot+1)
	;
	
	return
	  ("sgr" == ext)
	  ? "Meta"
	  : "XML"
	;
   }

   
   std::string	upper(const std::string& s)
   {
	   std::string r(s);
	   //std::for_each(r.begin(), r.end(), toupper);
	   for (std::size_t i = 0, z = s.size(); i < z; i++) {
		   r[i]= toupper(s[i]);
	   }
	   return r;
   }
   
	// std::string 	prefix = "KW_";
    // //22// << prefix << upper(predef_[i]) 
	// //22// // B: no suffix..... << predefinedSuffix
    // << predefinedKeyWord(predef_[i])
   std::string 	prefix = "KW_";
   //kw// 
   //kw// std::string	predefinedKeyWord(const std::string& s)
   //kw// {
   //kw//    return prefix + upper(s);
   //kw// }
   
   std::string 	tokenSuffix = "_TERMTOKEN";
   //kw// std::string	tokenKeyWord(const std::string& s)
   //kw// {
   //kw//    return prefix + upper(s) + tokenSuffix;
   //kw// }
   
   std::string 	reservedTokenSuffix = "_RESERVEDTOKEN";
   //kw// std::string	reservedKeyWord(const std::string& s)
   //kw// {
   //kw//    return prefix + upper(s) + reservedTokenSuffix;
   //kw// }
   
   std::string 	nonTerminalSuffix = "_NON_TERMINAL";
   //kw// std::string	nonTerminalKeyWord(const std::string& s)
   //kw// {
   //kw//    return prefix + upper(s) + nonTerminalSuffix;
   //kw// }
   
   std::string 	totalSuffix = "KEYWORDS_TOTAL";
   //kw// std::string	totalKeyWord()
   //kw// {
   //kw//    return prefix + totalSuffix;
   //kw// }
   
   std::string prefixKeyWord(const std::string& s)
   {
      return prefix + upper(s);
   }

   bool isPredefined(const std::string& kw) {

     for (std::size_t i = 0; i < predefSize_; i++) {
       if (kw == predef_[i]) {
         return true;
       }
     }

     return false;
   }

struct GenerateKeyWordsContainer
{
	cppcc::gen::GeneratorBinary&                binary_;
	std::string                                 filename_;
  cppcc::scb::SyntaxControlledBinary&         bin_;
  cppcc::scb::SyntaxControlledBinary::Helper  help_;
  cppcc::lex::Tokenizer&                      tok_;
  cppcc::com::KeyWordsContainer               kwc_;
  int                                         isDebug_;

  // grammarKeyWords_IDENTMISS(s, nnrule, tdi.d);
  void
  grammarKeyWords_IDENTMISS
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_IDENTMISS).k_,n);
    if (e && bin_.fixed(e)) {
      if (KW_IDENTALT != bin_.fixed(e,1).t) {
        tok_.errorMessage(errorHereMustBeIdentAlt);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule 
          << " tag:" << bin_.fixed(e,1).t
          << " should be:" << KW_IDENTALT
          << " for:" << KW_IDENTMISS << " " << n << " "
          << errorHereMustBeIdentAlt    
        )  
      }
      grammarKeyWords_IDENTALT(s, nnrule, bin_.fixed(e,1).d);
    }
  }

  //grammarKeyWords_ALTERNATIVE(s, nnrule, tdi.d);
  void
  grammarKeyWords_ALTERNATIVE
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_ALTERNATIVE).k_,n);
    if (e && bin_.fixed(e)) {
      if (KW_IDENTALT != bin_.fixed(e,1).t) {
        tok_.errorMessage(errorHereMustBeIdentAlt);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << " tag:" << bin_.fixed(e,1).t
          << " should be:" << KW_IDENTALT
          << " for:" << KW_ALTERNATIVE << " " << n << " "
          << errorHereMustBeIdentAlt    
        )  
      }
      grammarKeyWords_IDENTALT(s, nnrule, bin_.fixed(e,1).d);
    }

  }

  // grammarKeyWords_IDENTALT(s, nnrule, tdi.d);
  void
  grammarKeyWords_IDENTALT
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_IDENTALT).k_,n);
    if (e) {
      if (bin_.fixed(e)) {
        if (KW_NTERMTERMACT != bin_.fixed(e, 0).t) {
          //ruleError(output, nnrule, errorHereMustINtermTermAct);
          tok_.errorMessage(errorHereMustINtermTermAct);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << " tag:" << bin_.fixed(e, 0).t
            << " should be:" << KW_NTERMTERMACT
            << " for:" << KW_IDENTALT << n << " "
            << errorHereMustINtermTermAct    
          )
        }

        cppcc::scb::SyntaxControlledBinary::edpirType* eact =
          bin_.ptredp(help_.k(KW_NTERMTERMACT).k_, bin_.fixed(e, 0).d);
        if (eact) {
          if (bin_.fixed(eact)) {

            //if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
            //  s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
            //}

            if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == bin_.fixed(eact, 0).t) {
              std::string kw = bin_.ptrids(bin_.fixed(eact, 0).d);

              if (isDebug_) {
                std::cout
                  << "rule:" << nnrule
                  << " id:" << "'" << kw << "'"
                  << std::endl;
              }

              s.insert(kw);
            }
          }
        }
      }

      if (bin_.dynamic(e)) {
        for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
          cppcc::scr::tag::TypeInstance& tdi = bin_.dynamic(e, i);
          if (KW_ALTPART != tdi.t) {
            tok_.errorMessage(errorHereMustBeAltpart);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << " tag:" << tdi.t
              << " should be:" << KW_ALTPART
              << " for:" << KW_IDENTALT << " " << n << " "
              << errorHereMustBeAltpart    
            ) 
          }

          cppcc::scb::SyntaxControlledBinary::edpirType* ee =
            bin_.ptredp(help_.k(KW_ALTPART).k_,tdi.d);
          if (ee && bin_.fixed(ee)) {
        	  if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
        	    tok_.errorMessage(errorHereMustINtermTermAct);	
                CPPCC_THROW_EXCEPTION(
                  << " rule:" << nnrule << " "
                  << " tag:" << bin_.fixed(ee, 1).t
                  << " should be:" << KW_NTERMTERMACT
                  << " for:" << tdi.t << " " << tdi.d << " "
                  << errorHereMustINtermTermAct    
                )       		
        	  } 

            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_, bin_.fixed(ee, 1).d);
            if (eact) {
              if (bin_.fixed(eact)) {

                //if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
                //  s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
                //}

                if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == bin_.fixed(eact, 0).t) {
                  //s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
                  std::string kw = bin_.ptrids(bin_.fixed(eact, 0).d);

                  if (isDebug_) {
                    std::cout
                      << "rule:" << nnrule
                      << " i:" << i
                      << " id:" << "'" << kw << "'"
                      << std::endl;
                  }

                  s.insert(kw);
                }
              }
            }

          }
        }
      }
    }
  }

  //grammarKeyWordsRight(s, nnrule, kr.d);
  void
  grammarKeyWordsRight
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   nright)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_RIGHT).k_,nright);

    if (e && bin_.dynamic(e)) {
      for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
        cppcc::scr::tag::TypeInstance& tdi = bin_.dynamic(e, i);

        if (KW_ITERATION == tdi.t) {
        }
        else if (KW_IDENTMISS == tdi.t) {
          grammarKeyWords_IDENTMISS(s, nnrule, tdi.d);
        }
        else if (KW_ALTERNATIVE == tdi.t) {
          grammarKeyWords_ALTERNATIVE(s, nnrule, tdi.d);
        }
        else if (KW_ACTION == tdi.t) {

        }
        else if (KW_IDENTALT == tdi.t) {
          grammarKeyWords_IDENTALT(s, nnrule, tdi.d);
        }
      }
    }
  }

  cppcc::com::KeyWordsContainer::NameVector 
  grammarKeyWords()
  {
    std::set<std::string>                     s;

		cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		  help_.k(KW_RULE);
    if (k) {
		  for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		    cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		    cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		    if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		      tok_.errorMessage(errorNoIdentifierFound);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		        )
		    }

        cppcc::scr::tag::TypeInstance&  kr  = eru.fixed(3);
        if(KW_RIGHT != kr.t) {
		      tok_.errorMessage(errorHereMustBeRight);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kr.t << " n:" << kr.d
		        )
        }

		    //kwc_.nonTerminals_.push_back(bin_.ptrids(kn.d));    
        grammarKeyWordsRight(s, nnrule, kr.d);
		  }
	  }

    cppcc::com::KeyWordsContainer::NameVector r(s.begin(), s.end());
    return r;
  }

  /*
  // kwc_.keyWords_ = finalize(kwc_.predefined_, kwc_.nonTerminals_, allKeyWords);
  cppcc::com::KeyWordsContainer::NameVector 
  finalize
    (const cppcc::com::KeyWordsContainer::NameVector& predefined
    ,const cppcc::com::KeyWordsContainer::NameVector& nonTerminals
    ,const cppcc::com::KeyWordsContainer::NameVector& allKeyWords)
  {
    cppcc::com::KeyWordsContainer::NameVector r;

    std::set<std::string> predefined_(predefined.begin(), predefined.end());
    std::set<std::string> nonTerminals_(nonTerminals.begin(), nonTerminals.end());

    if (isDebug_) {
      {
        std::cout
          << "predefined_.size()=" << predefined_.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = predefined_.begin();
        std::set<std::string>::const_iterator ce = predefined_.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "predefined_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }

      {
        std::cout
          << "nonTerminals_.size()=" << nonTerminals_.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = nonTerminals_.begin();
        std::set<std::string>::const_iterator ce = nonTerminals_.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "nonTerminals_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }
    }

    for (std::size_t i = 0, z = allKeyWords.size(); i < z; i++) {
      const std::string& n = allKeyWords[i];

      std::set<std::string>::const_iterator iPredefined = predefined_.find(n);
      bool yPredefined = (iPredefined == predefined_.end());

      std::set<std::string>::const_iterator iNonTerminals = nonTerminals_.find(n);
      bool yNonTerminals = (iNonTerminals == nonTerminals_.end());
      
      if (yNonTerminals && yPredefined) {
        r.push_back(n);
      }

      if (isDebug_) {
        std::cout
          << "kw:" << "'" << n << "'"
          << " yPredefined:" << yPredefined
          << " yNonTerminals:" << yNonTerminals
          << std::endl;
      }
    }

    return r;
  }
  */

  void generate()
	{

    // 	typedef std::vector<std::string> NameVector;
	  // 	
	  // 	NameVector	predefined_;
	  // 	NameVector	tokens_;
	  // 	NameVector	keyWords_;
	  // 	NameVector	nonTerminals_;

    // 	NameVector	predefined_;
    for (std::size_t i = 0, z = cppcc::com::PLS_TERMINALS_START; i < z; i++) {
      kwc_.predefined_.push_back(cppcc::com::predefinedKeyWord(i));
    }

	  // 	NameVector	tokens_;
    /*
    cppcc::scb::SyntaxControlledBinary::kwnirType*	kwnTerminalTokens = 
      ptrkwn(cppcc::com::PLS_TERMINAL_TOKEN);
    for(cppcc::scr::tag::Long i = 0, z = kwnTerminalTokens->l; i < z; i++)
    {
      cppcc::scb::SyntaxControlledBinary::edpirType* edpTerminalTokens =
        ptredp(kwnTerminalTokens, i);

      if (fixed(edpTerminalTokens)) {
         std::cout
           << " i:" << i 
           << " fl:" << edpTerminalTokens->fl
           << " dl:" << edpTerminalTokens->dl
           << " d:" << edpTerminalTokens->d
           << " tf[0]:" << fixed(edpTerminalTokens, 0).t
                        << ":"
                        << fixed(edpTerminalTokens, 0).d
           << std::endl;
      }

      if (dynamic(edpTerminalTokens)) {
         std::cout
           << " i:" << i 
           << " fl:" << edpTerminalTokens->fl
           << " dl:" << edpTerminalTokens->dl
           << " d:" << edpTerminalTokens->d
           << " td[0]:" << dynamic(edpTerminalTokens, 0).t
                        << ":"
                        << dynamic(edpTerminalTokens, 0).d
           << std::endl;
      }

    }
    */
    cppcc::tnm::TokenNameContainer	defaultTokenNames;
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator ci = 
      defaultTokenNames.tokenNames_.begin();
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator ce = 
      defaultTokenNames.tokenNames_.end();
    for(std::size_t i = 0; ce != ci; ++ci, i++) {
      const std::string& n = (ci->second);

      kwc_.tokens_.push_back(n);
    }

	  // 	NameVector	keyWords_; ===>>>
	  // 	NameVector	nonTerminals_;
	  // 	First, generate nonTerminals_ from rule names.
	  // 	Second, generate keyWords_ that are from ptrids 
	  // 	but not in predefined_, neither in tokens_, neither in nonTerminals_.
		
    // Extract rule names from grammar definition.    
		cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		  help_.k(KW_RULE);
    if (k) {
		  for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		    cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		    cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		    if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		      tok_.errorMessage(errorNoIdentifierFound);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		        )
		    }

		    kwc_.nonTerminals_.push_back(bin_.ptrids(kn.d));      
		  }
	  }		

    // 	NameVector	keyWords_;    
    //  Key Words must be extracted from Grammar
    //  processing all rules looking for the righ part having 'xyz'...
    //111// cppcc::com::KeyWordsContainer::NameVector allKeyWords = grammarKeyWords();
    //111// kwc_.keyWords_ = finalize(kwc_.predefined_, kwc_.nonTerminals_, allKeyWords);
    kwc_.keyWords_ = grammarKeyWords();
    //cppcc::com::KeyWordsContainer::NameVector genKeyWords =
    //  finalize(kwc_.predefined_, kwc_.nonTerminals_, kwc_.keyWords_);
    kwc_.finalize();

    // Dump kwc_
    if (isDebug_) {
      std::cout
        << "GenerateKeyWordsContainer::generate:" 
        << " kwc:" << kwc_
        << std::endl;
    }
  }

	GenerateKeyWordsContainer
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
    , bin_(binary.generator_.parser_.binary_)
    , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
    , tok_(binary_.generator_.parser_.tokenizer_)
    , kwc_()
    , isDebug_(1)
	{
		generate();
	}
};

class GenerateGeneratorH
{
	cppcc::gen::GeneratorBinary&	binary_;
	std::string 				filename_;
	
	void generate()
	{
		std::string 	ext = "Generator.h";
		//std::size_t  	dot = filename_.find_last_of('.');
		//std::string 	gn  =
		//  (std::string::npos == dot)
		//    ? filename_
		//    : filename_.substr(0,dot)
		//;
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;

		//std::string fn = 
		//  generator_.runtime_.grammarName()
		//  + 
		//;
		std::ofstream 	output;  	
		
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
		   	CPPCC_THROW_EXCEPTION(
		      << "Can't open file for writing gnerated code:'"
		      << fn
		      << "' - Reason:'"
		      << syserr
		      << "'"
		  	)
		}

		for (std::size_t i = 0; i < GeneratorHCodeSize; i++) {
			//std::string 	l = GeneratorHCode[i];
			//std::size_t 	d = l.find_last_of('$');	
			//
			//if (std::string::npos == d) {
			//	output << l << std::endl;
			//} else {
			//	output 
			//		<< l.substr(0,d)
			//		<< gn
			//		<< l.substr(d+1)
			//		<< std::endl;
			//}
			output << line(GeneratorHCode[i], gn) << std::endl;
		}
	}
	
public:
	GenerateGeneratorH
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	{
		generate();
	}	
};

class GenerateKeyWordDefinitionH
{
	cppcc::gen::GeneratorBinary&				binary_;
	std::string 								filename_;
    cppcc::scb::SyntaxControlledBinary&     	bin_;
    cppcc::scb::SyntaxControlledBinary::Helper  help_;
    cppcc::lex::Tokenizer&            			tok_;
		
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionHCodeStartSize; i++) {
			output << line(KeyWordDefinitionHCodeStart[i], gn) << std::endl;
		}
			
		std::size_t cnt = 0;
		for (std::size_t i = 0; i < predefSize_; i++) {
			output << "  // " << cnt+i << std::endl;
			output 
				<< "  " 
				<< std::string(i?",":"")
				
			    //22// << prefix << upper(predef_[i]) 
				//22// // B: no suffix..... << predefinedSuffix
			    //kw// << predefinedKeyWord(predef_[i])
			    << prefixKeyWord(predef_[i])
				
				<< std::endl;
		}		
		cnt += predefSize_;
		
		std::size_t tokensSize = 
		  binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  //kw// << tokenKeyWord(cIter->second)
			  << prefixKeyWord(cIter->second)
			  << std::endl;
		}	
		cnt += tokensSize;
		
    bool isGeneratedFromIDs = false;
    if (isGeneratedFromIDs) {
		  std::size_t keyWordsSize = 
			  binary_.generator_.parser_.grammarSymbols_.keyWords_.size();
		  for (std::size_t i = 0; i < keyWordsSize; i++) {
			  const std::string& 	rw = 
				  binary_.generator_.parser_.grammarSymbols_.keyWords_[i];
		
			  output << "  // " << cnt+i << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;
			
		  }
		  cnt += keyWordsSize;
    } else {
      // loop for all context identifiers.
      cppcc::scr::tag::Long ids_size = bin_.head()->cntnid;
      cppcc::scr::tag::Long sz = 0;
      for (cppcc::scr::tag::Long i = 0; i < ids_size; i++) {
        //std::string 	rw = bin_.ptrids(i);
        std::string 	rw = bin_.ptridn(i);

        if(isPredefined(rw)) {
          continue;
        }

        ///output << "  // " << cnt+i << std::endl;
        output << "  // " << cnt+sz << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;

        sz++;
      }

      cnt += sz;
    }
		
		///--------------------------------------
	    
	    bool isGeneratedFromGrammarSymbols = false;
	    if (isGeneratedFromGrammarSymbols) {
			std::size_t nonTerminalsSize = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
			for (std::size_t i = 0; i < nonTerminalsSize; i++) {
				const std::string& 	nont = 
					binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
			
				output << "  // " << cnt+i << std::endl;
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(nont)
					<< std::endl;
			}
			cnt += nonTerminalsSize;
	    }
		else {
      bool doit = false;
      if (doit) {
		      // Extract rule names from grammar definition.    
		   cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		        help_.k(KW_RULE);
		   if (k) {
		      for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		        cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		        cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		        if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		          tok_.errorMessage(errorNoIdentifierFound);
		           CPPCC_THROW_EXCEPTION(
		             << errorNoIdentifierFound
		             << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		           )
		        }
		        
		        output << "  // " << cnt+nnrule << std::endl;  
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(bin_.ptrids(kn.d))
					<< std::endl;
		        
		       }
		   }			
		   cnt += k.edps_.size();
      }
		}
		///------------------------------------

		
		output << "  // " << cnt << " -- Total"<< std::endl;
		output 
			<< "  " 
			<< ","
			//kw// << totalKeyWord()
			<< prefixKeyWord(totalSuffix)
			<< std::endl;
		
		
		for (std::size_t i = 0; i < KeyWordDefinitionHCodeFinishSize; i++) {
			output << line(KeyWordDefinitionHCodeFinish[i], gn) << std::endl;
		}		
	}		

	
public:
	GenerateKeyWordDefinitionH
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
        , bin_(binary.generator_.parser_.binary_)
        , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
        , tok_(binary_.generator_.parser_.tokenizer_)
	{
		generate();
	}	
};

// V2GenerateKeyWordDefinitionH +++++++++++++++++++++++
class V2GenerateKeyWordDefinitionH
{
	// cppcc::gen::GeneratorBinary&                binary_;
	// std::string                                 filename_;
  // cppcc::scb::SyntaxControlledBinary&         bin_;
  // cppcc::scb::SyntaxControlledBinary::Helper  help_;
  // cppcc::lex::Tokenizer&                      tok_;
  GenerateKeyWordsContainer&  gkwc_;
		
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(gkwc_.filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionHCodeStartSize; i++) {
			output << line(KeyWordDefinitionHCodeStart[i], gn) << std::endl;
		}
			
		std::size_t cnt = 0;
    std::size_t predefinedSize = gkwc_.kwc_.predefined_.size();
		for (std::size_t i = 0; i < predefinedSize; i++) {
			output << "  // " << cnt+i << std::endl;
			output 
        << "  " 
        << std::string(i?",":"")
        << prefixKeyWord(gkwc_.kwc_.predefined_[i])
        << std::endl;
		}		
		cnt += predefinedSize;
		
		std::size_t tokensSize = 
		  gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_.size();
    std::size_t tokensSizeReal = 0;
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  gkwc_.binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			gkwc_.binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  //kw// << tokenKeyWord(cIter->second)
			  << prefixKeyWord(cIter->second)
			  << std::endl;
      tokensSizeReal++;
		}	
		cnt += tokensSizeReal;
		
    ///++++++++++++++++++++++++++++++++++++++
    /// termToken instances
    ///......................................
    /// Loop through gkwc_.kwc_.keyWordsGenerated_
    std::size_t keyWordsGeneratedSize = gkwc_.kwc_.keyWordsGenerated_.size();
    for (std::size_t i = 0; i < keyWordsGeneratedSize; i++) {
      const std::string& 	n = gkwc_.kwc_.keyWordsGenerated_[i];

		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  << prefixKeyWord(n)
			  << std::endl;
    }
    cnt += keyWordsGeneratedSize;
		
		///++++++++++++++++++++++++++++++++++++++
    // nonTerminals
		///......................................
    /// Loop through gkwc_.kwc_.nonTerminals_
    std::size_t nonTerminalsdSize = gkwc_.kwc_.nonTerminals_.size();
    for (std::size_t i = 0; i < nonTerminalsdSize; i++) {
      const std::string& 	n = gkwc_.kwc_.nonTerminals_[i];

		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  << prefixKeyWord(n)
			  << std::endl;
    }
    cnt += nonTerminalsdSize;
		
		output << "  // " << cnt << " -- Total"<< std::endl;
		output 
			<< "  " 
			<< ","
			//kw// << totalKeyWord()
			<< prefixKeyWord(totalSuffix)
			<< std::endl;
			
		for (std::size_t i = 0; i < KeyWordDefinitionHCodeFinishSize; i++) {
			output << line(KeyWordDefinitionHCodeFinish[i], gn) << std::endl;
		}		
	}		

	
public:
	V2GenerateKeyWordDefinitionH
		(GenerateKeyWordsContainer&   gkwc)
		: gkwc_(gkwc)
	{
		generate();
	}	
};

// V2GenerateKeyWordDefinitionH -----------------------

class GenerateParserH
{
	cppcc::gen::GeneratorBinary&			    binary_;
	std::string 								filename_;
	cppcc::scb::SyntaxControlledBinary&			bin_;
	cppcc::scb::SyntaxControlledBinary::Helper 	help_;
	cppcc::lex::Tokenizer&						tok_;
	
	void generate()
	{
		std::string 	ext = "Parser.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		std::ofstream 	output;  	
		
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
				<< "Can't open file for writing gnerated code:'"
				<< fn
				<< "' - Reason:'"
				<< syserr
				<< "'"
			)
		}
		
		for (std::size_t i = 0; i < ParserHCodeStartSize; i++) {
			output << line(ParserHCodeStart[i], gn) << std::endl;
		}
		
		bool isGeneratedFromGrammarSymbols = false;
		if (isGeneratedFromGrammarSymbols) {
		  // should not be used at all.
			std::size_t nonTerminalsSize = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
			for (std::size_t i = 0; i < nonTerminalsSize; i++) {
				const std::string& 	nont = 
					binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
			
				output 
					<< "  " 
					<< "void "
					<< nont
					<< "(cppcc::scr::tag::Long& tag);"
					<< std::endl;
				
			}
		}
		else {
		  // Extract rule names from grammar definition.		
		  cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		    help_.k(KW_RULE);
		  if (k) {
			for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
			  cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
				        	
			  cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
			  if (cppcc::com::PLS_IDENTIFIER != kn.t) {
			    tok_.errorMessage(errorNoIdentifierFound);
					 CPPCC_THROW_EXCEPTION(
					   << errorNoIdentifierFound
					   << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
				)
			  }
			  
		      output 
					<< "  " 
					<< "void "
					<< bin_.ptrids(kn.d)
					<< "(cppcc::scr::tag::Long& tag);"
					<< std::endl;
			  
		    }
		  }
		}
		
		for (std::size_t i = 0; i < ParserHCodeFinishSize; i++) {
			output << line(ParserHCodeFinish[i], gn) << std::endl;
		}
		
	}

	
public:
	GenerateParserH
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
    , bin_(binary.generator_.parser_.binary_)
    , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
    , tok_(binary_.generator_.parser_.tokenizer_)

	{
		generate();
	}	
};

class GenerateGeneratorCC
{
	cppcc::gen::GeneratorBinary&	binary_;
	std::string 				filename_;
	
	void generate()
	{
		std::string 	ext = "Generator.cc";
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		std::ofstream 	output;  	
		
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
				<< "Can't open file for writing gnerated code:'"
				<< fn
				<< "' - Reason:'"
				<< syserr
				<< "'"
			)
		}
		
		for (std::size_t i = 0; i < GeneratorCCCodeSize; i++) {
			output << line(GeneratorCCCode[i], gn) << std::endl;
		}
	}
	
public:
	GenerateGeneratorCC
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	{
		generate();
	}	
};

class GenerateKeyWordDefinitionCC
{
	cppcc::gen::GeneratorBinary&	binary_;
	std::string 				filename_;
	
	
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.cc";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeStartSize; i++) {
			output << line(KeyWordDefinitionCCCodeStart[i], gn) << std::endl;
		}
		output << std::endl;
		
		output << "  static std::string   predef_[] =" << std::endl;
		output << "  {" << std::endl;
		for (std::size_t i = 0; i < predefSize_; i++) {
			output 
				<< "    " 
				<< std::string(i?",":"")				
			    << "\"" << predef_[i] << "\""				
				<< std::endl;
		}		
		output << "  };" << std::endl;
		output << "  static std::size_t  predefSize_ =" << std::endl; 
		output << "  sizeof(predef_)/sizeof(predef_[0]);" << std::endl; 
		output << std::endl;
		
		output << "  static std::string   charTokens_[] =" << std::endl;
		output << "  {" << std::endl;		
		std::size_t tokensSize = 
		  binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output 
			  << "    " 
			  << std::string(i?",":"")	
			  //<< tokenKeyWord(cIter->second)
		      << "\"" 
		         << (("\"" == cIter->first)?("\\"):(""))
		         << cIter->first 
		      << "\""		
			  << std::endl;
		}	
		output << "  };" << std::endl;
		output << "  static std::size_t  charTokensSize_ =" << std::endl; 
		output << "  sizeof(charTokens_)/sizeof(charTokens_[0]);" << std::endl; 
		output << std::endl;
		
		std::size_t keyWordsSize = 
			binary_.generator_.parser_.grammarSymbols_.keyWords_.size();

	    output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "  static std::string   keyWords_[] =" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  {" << std::endl;
			
		for (std::size_t i = 0; i < keyWordsSize; i++) {
				const std::string& 	rw = 
				binary_.generator_.parser_.grammarSymbols_.keyWords_[i];
		
				output
					<< "    " 
					<< std::string(i?",":"")	
					<< "\""  << rw << "\"" 
					<< std::endl;
		}
			
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  };" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  static std::size_t  keyWordsSize_ =" << std::endl; 
		output
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  sizeof(keyWords_)/sizeof(keyWords_[0]);" << std::endl; 
		
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << std::endl;
		
		
		output << "  static std::string   non_Terminals_[] =" << std::endl;
		output << "  {" << std::endl;
		std::size_t nonTerminalsSize = 
			binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
		for (std::size_t i = 0; i < nonTerminalsSize; i++) {
			const std::string& 	nont = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
		
			output 
				<< "    " 
				<< std::string(i?",":"")	
				<< "\""  << nont << "\"" 
				<< std::endl;
			
		}
		output << "  };" << std::endl;
	    output << "  static std::size_t  non_TerminalsSize_ =" << std::endl; 
	    output << "  sizeof(non_Terminals_)/sizeof(non_Terminals_[0]);" << std::endl; 
	    output << std::endl;
		

	    //---
	    output << "}" << std::endl;
	    output << "" << std::endl;
	    output << "cppcc::com::KeyWordsContainer makeKeyWordsContainer()" << std::endl;
	    output << "{" << std::endl;
	    output << "  cppcc::com::KeyWordsContainer result;" << std::endl;
	    output << "  result.predefined_.assign(predef_,predef_+predefSize_);" << std::endl;
	    output << "  result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);" << std::endl;
	    
	    output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "result.keyWords_.assign(keyWords_,keyWords_+keyWordsSize_);" << std::endl;
	    
	    output << "  result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);" << std::endl;
	    output << "  return result;" << std::endl;
	    //---
		
		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeFinishSize; i++) {
			output << line(KeyWordDefinitionCCCodeFinish[i], gn) << std::endl;
		}		
	}			
	
public:
	GenerateKeyWordDefinitionCC
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	{
		generate();
	}	
};

/// ub:
///++++++++++++++++++++++++++++++++++++++++

class V2GenerateKeyWordDefinitionCC
{
	//cppcc::gen::GeneratorBinary&	binary_;
	//std::string 				          filename_;
  GenerateKeyWordsContainer&    gkwc_;
	
	
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.cc";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(gkwc_.filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeStartSize; i++) {
			output << line(KeyWordDefinitionCCCodeStart[i], gn) << std::endl;
		}
		output << std::endl;
		
    ///++++++++++++++++++++++++++++++++++++++
    /// predefined...
    ///......................................
		output << "  static std::string   predef_[] =" << std::endl;
		output << "  {" << std::endl;
    std::size_t predefinedSize = gkwc_.kwc_.predefined_.size();
		for (std::size_t i = 0; i < predefinedSize; i++) {
			output 
				<< "    " 
				<< std::string(i?",":"")				
			    << "\"" << gkwc_.kwc_.predefined_[i] << "\""				
				<< std::endl;
		}		
		output << "  };" << std::endl;
		output << "  static std::size_t  predefSize_ =" << std::endl; 
		output << "  sizeof(predef_)/sizeof(predef_[0]);" << std::endl; 
		output << std::endl;

    ///++++++++++++++++++++++++++++++++++++++
    /// tokens...
    ///......................................
		output << "  static std::string   charTokens_[] =" << std::endl;
		output << "  {" << std::endl;		
		std::size_t tokensSize = 
		  gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  gkwc_.binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			gkwc_.binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output 
			  << "    " 
			  << std::string(i?",":"")	
			  //<< tokenKeyWord(cIter->second)
		      << "\"" 
		         << (("\"" == cIter->first)?("\\"):(""))
		         << cIter->first 
		      << "\""		
			  << std::endl;
		}	
		output << "  };" << std::endl;
		output << "  static std::size_t  charTokensSize_ =" << std::endl; 
		output << "  sizeof(charTokens_)/sizeof(charTokens_[0]);" << std::endl; 
		output << std::endl;
		
    // ub:
    ///++++++++++++++++++++++++++++++++++++++
    /// termToken instances
    ///......................................
    std::size_t keyWordsSize = gkwc_.kwc_.keyWordsGenerated_.size();

	  output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "  static std::string   keyWords_[] =" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  {" << std::endl;
			
		for (std::size_t i = 0; i < keyWordsSize; i++) {
		  const std::string& 	rw = gkwc_.kwc_.keyWordsGenerated_[i];
		
	    output
        << "    " 
        << std::string(i?",":"")	
        << "\""  << rw << "\"" 
        << std::endl;
		}
			
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  };" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  static std::size_t  keyWordsSize_ =" << std::endl; 
		output
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  sizeof(keyWords_)/sizeof(keyWords_[0]);" << std::endl; 
		
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << std::endl;
		
    /// ub:
	  ///++++++++++++++++++++++++++++++++++++++
    // nonTerminals
		///......................................	
		output << "  static std::string   non_Terminals_[] =" << std::endl;
		output << "  {" << std::endl;
		std::size_t nonTerminalsSize = 
			gkwc_.kwc_.nonTerminals_.size();
		for (std::size_t i = 0; i < nonTerminalsSize; i++) {
			const std::string& 	nont = 
				gkwc_.kwc_.nonTerminals_[i];
		
			output 
				<< "    " 
				<< std::string(i?",":"")	
				<< "\""  << nont << "\"" 
				<< std::endl;
			
		}
		output << "  };" << std::endl;
	  output << "  static std::size_t  non_TerminalsSize_ =" << std::endl; 
	  output << "  sizeof(non_Terminals_)/sizeof(non_Terminals_[0]);" << std::endl; 
	  output << std::endl;
		

	    //---
	    output << "}" << std::endl;
	    output << "" << std::endl;
	    output << "cppcc::com::KeyWordsContainer makeKeyWordsContainer()" << std::endl;
	    output << "{" << std::endl;
	    output << "  cppcc::com::KeyWordsContainer result;" << std::endl;
	    output << "  result.predefined_.assign(predef_,predef_+predefSize_);" << std::endl;
	    output << "  result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);" << std::endl;
	    
	    output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "result.keyWords_.assign(keyWords_,keyWords_+keyWordsSize_);" << std::endl;
	    
	    output << "  result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);" << std::endl;
	    output << "  result.finalize();" << std::endl;
      output << "  return result;" << std::endl;
	    //---
		
		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeFinishSize; i++) {
			output << line(KeyWordDefinitionCCCodeFinish[i], gn) << std::endl;
		}		
	}			
	
public:
	V2GenerateKeyWordDefinitionCC
		(GenerateKeyWordsContainer&  gkwc)
		: gkwc_(gkwc)
	{
		generate();
	}	
};
///----------------------------------------

class GenerateMakeGeneratorsCC
{
	cppcc::gen::GeneratorBinary&	binary_;
	std::string 				filename_;
	
	void generate()
	{
		std::string 	ext = "MakeGenerators.cc";
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		std::ofstream 	output;  	
		
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
				<< "Can't open file for writing gnerated code:'"
				<< fn
				<< "' - Reason:'"
				<< syserr
				<< "'"
			)
		}
		
		for (std::size_t i = 0; i < MakeGeneratorsCCCodeSize; i++) {
			output << line(MakeGeneratorsCCCode[i], gn) << std::endl;
		}
	}
	
public:
	GenerateMakeGeneratorsCC
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	{
		generate();
	}	
};


class GenerateParserCC
{
	  struct  metantmType 
	  {
	    //typedef std::vector<int>   SymbolsContainer;
	    typedef std::set<int>   SymbolsContainer;

	    cppcc::scr::tag::Long 	nterm;
	    SymbolsContainer    	first;
	    SymbolsContainer    	follow;
	  };

	  struct  metagrmType {
	      typedef std::vector<metantmType>            NonTerminalsContainer;
	      typedef std::vector<cppcc::scr::tag::Long>  NonTerminalRuleContainer;
	 	  
	    NonTerminalsContainer     rulval;
	    NonTerminalRuleContainer  ntmrul;
	  };

	  cppcc::gen::GeneratorBinary&					binary_;
	std::string 								filename_;
	metagrmType 								grammar_;
	int											CheckMode_;
	int											GlobalReturnCode_;	
	cppcc::scb::SyntaxControlledBinary&			bin_;
	cppcc::scb::SyntaxControlledBinary::Helper 	help_;
	cppcc::lex::Tokenizer&						tok_;
	int											Gffin_;
	std::vector<std::string>				    predefinedIDs_;
	std::string 								IITT_;

	
void metaalone
	(std::ofstream& 		output
	,std::size_t 			nnrule
	,cppcc::scr::tag::Long	t
	,cppcc::scr::tag::Long	d
	,cppcc::scr::tag::Long	iiii
	,cppcc::scr::tag::Long	iact
	);
	
void generateKWAlt
	(std::ofstream&           output
	,cppcc::scr::tag::Long    ndd);	
	
void dumpSymbols
	(std::ofstream& 				output
	,std::size_t					nnrule
	,metantmType::SymbolsContainer&	symbols);
	
void dumpFirstFollow(std::ofstream& 		output);

std::string		keyword(cppcc::scr::tag::Long   ndd);

void metagrfsimp
(std::ofstream& 	   			output
,std::size_t 		   			nnrule
,cppcc::scr::tag::Long 			nit
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer& symbols);


void metagrfaltr
(std::ofstream& 	   output
,std::size_t 		   nnrule
,cppcc::scr::tag::Long nal
//,std::set<int>&		   symbols
,metantmType::SymbolsContainer& symbols);


void metagetstr
//(output, ruleIndex, bin_.dynamic(e,i).t,0)
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	acid
,const char**				t);


void metagetint
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	n
,cppcc::scr::tag::Long*  	v);

void 
metaactionsfind
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	actp
,cppcc::scr::tag::Long  	scid
,cppcc::scr::tag::Long  	vv
,int*						yy);

void metarfaddset
(std::ofstream&         		output
,std::size_t          			nnrule
,metantmType& 				 	ntm
,metantmType::SymbolsContainer& symbols);

void metagrfiden
(std::ofstream&         		output
,std::size_t          			nnrule
,cppcc::scr::tag::Long      	nnn
,metantmType::SymbolsContainer& symbols);

void 
metagrfiter
(std::ofstream&         		output
,std::size_t          			nnrule
,cppcc::scr::tag::Long      	nid
,metantmType::SymbolsContainer& symbols);

void metagggg
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	nitr
,cppcc::scb::SyntaxControlledBinary::edpirType*  ei);

void metarral
	(std::ofstream& 				output
	,std::size_t					nnrule
	,cppcc::scr::tag::Long			nid
	,cppcc::scr::tag::Long			nal
	,int*							yy);
	
void metarfalid
	(std::ofstream& 				output
	,std::size_t					nnrule
	,cppcc::scr::tag::Long 	    d
	,metantmType::SymbolsContainer&	symbols);
	
void metarfsimp
	(std::ofstream& 				output
	,std::size_t					nnrule
	,cppcc::scr::tag::Long 			t
	,cppcc::scr::tag::Long 	    	d
	,metantmType::SymbolsContainer&	symbols);
	
void ruleError
	  (std::ofstream& 		   output
	  ,cppcc::scr::tag::Long   dNTerm
	  ,const std::string&	   t);

void ruleWarning
	(std::ofstream& 		output
	,cppcc::scr::tag::Long 	nnrule
	,const std::string&	   	t);
	
// if(s= metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy)) return(s);
// if(s= metaidal(r,k,nnrule,nid,ua.f[1].d,yy)) return(s);
void metaidal
(std::ofstream& 		output
,cppcc::scr::tag::Long 	nnrule
,cppcc::scr::tag::Long	nid
,cppcc::scr::tag::Long  nal
,int* 					yy);

//int metachrr(r,k,nnrule,nid,rig,yy)
//void metachrr(j, kn.d, knr.d, &yy);
void metachrr
(std::ofstream& 		output
,cppcc::scr::tag::Long 	nnrule
,cppcc::scr::tag::Long	nid
,cppcc::scr::tag::Long  rig
,int* 					yy);

void checkGrammar(std::ofstream&   output);

// int metarfiden(r,k,nnrule,nnn,nta,len)
// if(s= metarfiden(r,k,nnrule,nnn,nta,len)) return(s);
void metarfiden
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nnn
,metantmType::SymbolsContainer&	symbols);

// // if(s= metarfiter(r,k,nnrule,u.d[i].d,nta,len)) return(s);
// 	metarfiter(output, nnrule, bin_.dynamic(e, i).d, symbols);
void metarfiter
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer&	symbols);

//if(s= metachnt(r,k,nnrule,nnn,&rull)) return(s);
void metachnt
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nnn
,cppcc::scr::tag::Long* 		rull);

// if(s= metarfaddnxt(r,k,nnrule,nnn,nta,len)) return(s);
//int metarfaddnxt(r,k,nnrule,nnn,nta,len)
void metarfaddnxt
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nnn
,metantmType::SymbolsContainer&	symbols);

void metarfmiss
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer&	symbols);

void metarfaltr
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer&	symbols);


void metarfaltern
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer&	symbols);

//if(s= metarfoll(r,k,nnrule,nta,len)) return(s);
//void metarfoll(output, nnrule, symbols);
void metarfoll
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols);

// 	s= metarfir(r,k,j,ffbuf,&fflen);
//metantmType::SymbolsContainer	tmpFirst;
//metarfir(j, tmpFirst);
void metarfir
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols);

//	s= metarfcheck(r,k,j,ffbuf,fflen);
void metarfcheck
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols);


//int	metagenfirfol(r,k,g)
//inrType 	r;
//struct 		kwnirType 	*k[];
//struct		metagrmType	*g;	
void generateFirstFollow(std::ofstream& 		output);

	
void metaactglob
(std::ofstream& 	output
,std::size_t 		ruleIndex);

void metaactnewf
(std::ofstream& 	output
,std::size_t 		ruleIndex);

void  metaangl
 (std::ofstream& 		output
 ,cppcc::scr::tag::Long  dNTerm
 ,cppcc::scr::tag::Long  dRight);


int  metadynp
 (std::ofstream& 		output
 ,cppcc::scr::tag::Long  dNTerm
 ,cppcc::scr::tag::Long  dRight);


int  metafixe
  (std::ofstream& 		   output
  ,cppcc::scr::tag::Long   dNTerm
  ,cppcc::scr::tag::Long   dRight);


//sss// int
void
metaalid
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	nalid);

void
metaalid_ccc
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	nalid);


void metaiter
//(output, ruleIndex, e, eru, i)
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scb::SyntaxControlledBinary::edpirType* e
,cppcc::scb::SyntaxControlledBinary::edpirType* eru
,cppcc::scr::tag::Long  	i);


void metaaction
//(output, ruleIndex, bin_.dynamic(e,i).t,0)
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	acid
,cppcc::scr::tag::Long  	vv);

//  if(s= metamiss(output,ruleIndex,bin_.dynamic(e,i).d
//    ,i,yy,&firstMiss,iact,
//	(i == ((e->dl) - 1)))) return(s);
//int metamiss(r,k,nnrule,nal,iiii,yyyy,fmis,iact,iend)
void metamiss
(std::ofstream& 	output
,std::size_t 		ruleIndex
,int  				nal
,int 				iiii
,int  				yyyy
,int*  				fmis
,int  				iact
,int  				iend
);

////--------------------------------------------------------------
/*
void
metagrfaltr
(std::ofstream& 	   output
,std::size_t 		   ruleIndex
,cppcc::scr::tag::Long nal
//,std::set<int>&		   symbols
,metantmType::SymbolsContainer&	symbols
);
*/
void metagrfalid
(std::ofstream& 	   			output
,std::size_t 		   			nnrule
,cppcc::scr::tag::Long 			nalid
,metantmType::SymbolsContainer& symbols);


////--------------------------------------------------------------

// generate ( . . . )
//  if(s= metaaltr(output,ruleIndex,bin_.dynamic(e,i).d
//    ,i,iact)) return(s);          
//  if(s= metaaltr(r,k,nnrule,u.d[i].d,i,iact)) return(s);
void metaaltr
(std::ofstream& 		output
,std::size_t 			ruleIndex
,cppcc::scr::tag::Long	nal
,cppcc::scr::tag::Long	iiii
,cppcc::scr::tag::Long	iact
);


//  if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) 
//    return(0);
////if (s = metaactions(output,ruleIndex,
////  bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
//// )) return(s);	
void metaactions
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long		actp
,cppcc::scr::tag::Long		acid
,cppcc::scr::tag::Long		vv
);

//
//if (s = metasimp(output,ruleIndex,
//	bin_.dynamic(eact,0).t, bin_.dynamic(eact,0).d,
//	e, &i, iact
//  )) 
//  return(s);
//
int metasimp
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long		uit
,cppcc::scr::tag::Long		uid
,cppcc::scb::SyntaxControlledBinary::edpirType* e
,cppcc::scr::tag::Long*     iiii
,cppcc::scr::tag::Long 		iact
);


void  metarigh
  (std::ofstream& 			output
  ,std::size_t 				ruleIndex
  ,cppcc::scr::tag::Long  	dNTerm
  ,cppcc::scr::tag::Long  	dRight);

void generateRuleBody
	    (std::ofstream& 		output
		,std::size_t 			ruleIndex
		,cppcc::scr::tag::Long  dNTerm
        ,cppcc::scr::tag::Long  dRight);
	
std::string axiomRuleName();

void generateKW
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd);

// ub:
void generateKWelse
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd);

void generateKWLoop
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd);


void generate();

public:
	GenerateParserCC
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	    //33// , kwns_(KW_KEYWORDS_TOTAL) 
	    , grammar_()
		, CheckMode_(0) 
	    , GlobalReturnCode_(0)
	    , bin_(binary_.generator_.parser_.binary_)
	    , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
	    , tok_(binary_.generator_.parser_.tokenizer_)
	    , Gffin_(0)
	    , predefinedIDs_(tok_.grammarSymbols_.predefined_.size())
	    , IITT_() 
	{
		for (std::size_t i = 0, iz = predefinedIDs_.size();i < iz; i++) {
			predefinedIDs_[i] = prefix + upper(tok_.grammarSymbols_.predefined_[i]);
		}
		IITT_ = upper(tok_.grammarSymbols_.predefined_[cppcc::com::PLS_INTEGER_TOKEN]);
		generate();
	}	
};

}



//////////////////////////////////////////////////////////////
// GenerateParserCC Implementation.
//////////////////////////////////////////////////////////////
namespace {

/*
std::string		
GenerateParserCC::keyword(cppcc::scr::tag::Long   ndd)
{
  std::string k = bin_.ptrids(ndd);
  if (ndd < tok_.grammarSymbols_.predefined_.size()) {
    return predefinedKeyWord(k);
  }
  else if ((ndd >= tok_.grammarSymbols_.predefined_.size()) 
    && (ndd < (tok_.grammarSymbols_.predefined_.size()
    		+ tok_.grammarSymbols_.tokens_.size()
    		))) 
  {
    return tokenKeyWord(k);
  }
  else if 
    (tok_.grammarSymbols_.keyWords_.size()
    &&
        ((ndd >= (tok_.grammarSymbols_.predefined_.size()
  		+ tok_.grammarSymbols_.tokens_.size()
  		))
    && (ndd < (tok_.grammarSymbols_.predefined_.size()
    		+ tok_.grammarSymbols_.tokens_.size()
    		+ tok_.grammarSymbols_.keyWords_.size()
    		))) 
    )
  {
    return reservedKeyWord(k);
  }
  else if (
    ((ndd >= (tok_.grammarSymbols_.predefined_.size()
    		+ tok_.grammarSymbols_.tokens_.size()
    		+ tok_.grammarSymbols_.keyWords_.size()
    		))
    )
    && (
    		(ndd < (tok_.grammarSymbols_.predefined_.size()
    		    		+ tok_.grammarSymbols_.tokens_.size()
    		    		+ tok_.grammarSymbols_.keyWords_.size()
    		    		+ tok_.grammarSymbols_.nonTerminals_.size()
    		    		))
    )
  )
  {
	return nonTerminalKeyWord(k);  
  }
  
}
*/
std::string		
GenerateParserCC::keyword(cppcc::scr::tag::Long   ndd)
{
  cppcc::scr::tag::Long s0 = tok_.grammarSymbols_.predefined_.size();
  cppcc::scr::tag::Long s1 = tok_.grammarSymbols_.tokens_.size();
  cppcc::scr::tag::Long s2 = tok_.grammarSymbols_.keyWords_.size();
  cppcc::scr::tag::Long s3 = tok_.grammarSymbols_.nonTerminals_.size();
	
  //std::string k = bin_.ptrids(ndd);
  if (ndd < s0) {
    //return predefinedKeyWord(k);
    return prefix + upper(tok_.grammarSymbols_.predefined_[ndd]);
  }
  else if ((ndd >= s0) && (ndd < (s0 + s1))) 
  {
    //return tokenKeyWord(k);
	cppcc::scr::tag::Long i = ndd - s0;
	return prefix + upper(tok_.language_->tokens_.tokens_[i]->name_) + tokenSuffix;
  }
  else if 
    (s2
    &&
        ((ndd >= (s0 + s1))
    && (ndd < (s0 + s1 + s2))) 
    )
  {
    //return reservedKeyWord(k);
	cppcc::scr::tag::Long i = ndd - s0 - s1;
    return prefix + upper(tok_.grammarSymbols_.keyWords_[i]) + reservedTokenSuffix;
  }
  else if (
    ((ndd >= (s0 + s1 + s2))
    )
    && (
    		(ndd < (s0 + s1 + s2 + s3))
    )
  )
  {
	//return nonTerminalKeyWord(k);  
	cppcc::scr::tag::Long i = ndd - s0 - s1 - s2;
	return prefix + upper(tok_.grammarSymbols_.nonTerminals_[i]) + nonTerminalSuffix;
  }
  
}


void 
GenerateParserCC::generateKW
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd)
{
  std::string kw = bin_.ptrids(ndd);
  kw = upper(kw);
  if (IITT_ != kw) {
	//kw = 
    output 
      << "    if(kword() == KW_" << kw << ") {"
      << std::endl;   
  } else {
    output 
      << "    if((kword() == " << predefinedIDs_[cppcc::com::PLS_INTEGER_TOKEN]
      << ") || (kword() == " << predefinedIDs_[cppcc::com::PLS_FLOAT_TOKEN]
      << ")) {"
      << std::endl;                 
  
  }
}

void 
GenerateParserCC::generateKWelse
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd)
{
  std::string kw = bin_.ptrids(ndd);
  kw = upper(kw);
  if (IITT_ != kw) {
	//kw = 
    output 
      << "    else if(kword() == KW_" << kw << ") {"
      << std::endl;   
  } else {
    output 
      << "    else if((kword() == " << predefinedIDs_[cppcc::com::PLS_INTEGER_TOKEN]
      << ") || (kword() == " << predefinedIDs_[cppcc::com::PLS_FLOAT_TOKEN]
      << ")) {"
      << std::endl;                 
  
  }
}


void 
GenerateParserCC::generateKWLoop
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd)
{
  std::string kw = bin_.ptrids(ndd);
  kw = upper(kw);
  if (IITT_ != kw) {
	//kw = 
    output 
      << "(kword() == KW_" << kw << ")"
      << std::endl;   
  } else {
    output 
      << "((kword() == " << predefinedIDs_[cppcc::com::PLS_INTEGER_TOKEN]
      << ") || (kword() == " << predefinedIDs_[cppcc::com::PLS_FLOAT_TOKEN]
      << "))"
      << std::endl;                 
  
  }
}

void  
GenerateParserCC::ruleError
  (std::ofstream& 		   output
  ,cppcc::scr::tag::Long   dNTerm
  ,const std::string&	   t)
{
  {
    std::ostringstream o;
    o << "Rule:" << dNTerm;
    tok_.infoMessage(o.str());
  }

  output << "Rule:" << dNTerm << std::endl;
  cppcc::scr::tag::Long rule;
  cppcc::scr::tag::setedflong(&rule,KW_RULE,dNTerm);
  binary_.generator_.binary_->scDecompile_(output, rule);

  {
    std::ostringstream o;
    o << " *** error *** " << t;
    tok_.errorMessage(o.str());
    output << o.str() << std::endl;
  }

}

void
GenerateParserCC::ruleWarning
(std::ofstream& 		output
,cppcc::scr::tag::Long 	nnrule
,const std::string&	   	t)
{
  {
    std::ostringstream o;
    o << "Rule:" << nnrule;
    tok_.infoMessage(o.str());
  }
  
  output << "Rule:" << nnrule << std::endl;
  
  cppcc::scr::tag::Long rule;
  cppcc::scr::tag::setedflong(&rule,KW_RULE,nnrule);
  binary_.generator_.binary_->scDecompile_(output, rule);

  {
    std::ostringstream o;
    o << " *** warning *** " << t;
    tok_.infoMessage(o.str());
    output << o.str() << std::endl;
  }
}


// if(s= metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy)) return(s);
// if(s= metaidal(r,k,nnrule,nid,ua.f[1].d,yy)) return(s);
void 
GenerateParserCC::metaidal
(std::ofstream& 		output
,cppcc::scr::tag::Long 	nnrule
,cppcc::scr::tag::Long	nid
,cppcc::scr::tag::Long  nal
,int* 					yy)
{
	//bool isDebugBug = true;
	bool isDebugBug = false;
	
	if (isDebugBug) {
	        	std::cout << "metaidal:0:" 
	        			<< " nnrule:" << nnrule
	        		    << " nid:" << nid 
	        		    << " id:" << bin_.ptrids(nal)
	        			<< " nal:" << nal 
	        	<< std::endl;
	}
	
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_IDENTALT).k_
      ,nal);
  
	if (isDebugBug) {
	        	std::cout << "metaidal:1:"
	        			<< " nnrule:" << nnrule
	        			<< " nid " << nid 
	        			<< " id:" << bin_.ptrids(nal)
	        			<< " nal:" << nal 
	        			<< " e:" << (e?1:0)
	        	<< std::endl;
	}

  
  if (e) {
    if (bin_.fixed(e)) {
      if (KW_NTERMTERMACT != bin_.fixed(e, 0).t) {
        //ruleError(output, nnrule, errorHereMustBeIterItemact);
        ruleError(output, nnrule, errorHereMustINtermTermAct);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << " tag:" << bin_.fixed(e, 0).t
          << " should be:" << KW_NTERMTERMACT
          << errorHereMustBeIdentifier    
        )
      }
      
  	if (isDebugBug) {
  	        	std::cout << "metaidal:1:"
  	        			<< " nnrule:" << nnrule
  	        			<< " nid " << nid 
  	        			<< " id:" << bin_.ptrids(nal)
  	        			<< " nal:" << nal 
  	        			<< " e:" << (e?1:0)
  	        			<< " fixed-----------"
  	        	<< std::endl;
  	}
     
      cppcc::scb::SyntaxControlledBinary::edpirType* eact =
        //BUG:// bin_.ptredp(help_.k(KW_IDENTALT).k_
        bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
          ,bin_.fixed(e, 0).d);
      if (eact) {
        if (bin_.fixed(eact)) {
          if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
        	  
if (isDebugBug) {
        	  	        	std::cout << "metaidal:1:"
        	  	        			<< " nnrule:" << nnrule
        	  	        			<< " nid:" << nid 
        	  	        			<< " nal:" << nal 
        	  	        			<< " id:" << bin_.ptrids(nal)
        	  	        			<< " e:" << (e?1:0)
        	  	        			<< " fixed-----------"
        	  	        			<< " d:" << bin_.fixed(eact, 0).d
        	  	        			<< " r:" << bin_.ptrids(bin_.fixed(eact, 0).d)
        	  	        	<< std::endl;
}
       	  
        	if (nid == bin_.fixed(eact, 0).d) {
    	      if(yy) *yy= 0;
    	      return;  
        	}
          }
        }
      }     
    }
    
    if (bin_.dynamic(e)) {
if (isDebugBug) {
    		std::cout << "metaidal:1:"
    				<< " nnrule:" << nnrule
    				<< "nid " << nid 
    	        	<< " nal:" << nal 
    	        	<< " id:" << bin_.ptrids(nal)
    	        	<< " e:" << (e?1:0)
    	        	<< " dynamic-----------"
    	        	<< " dl:" <<  e->dl
    	        	<< std::endl;
}

      for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
        if (KW_ALTPART !=  bin_.dynamic(e, i).t) {
      	  ruleError(output, nnrule, errorHereMustBeAltpart);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << " tag:" << bin_.dynamic(e, i).t
            << " should be:" << KW_ALTPART
            << errorHereMustBeAltpart    
          )
        }

if (isDebugBug) {
            		std::cout << "metaidal:1:"
            				<< " nnrule:" << nnrule
            				<< " nid:" << nid 
            	        	<< " nal:" << nal 
            	        	<< " id:" << bin_.ptrids(nal)
            	        	<< " e:" << (e?1:0)
            	        	<< " dynamic-----------"
            	        	<< " dl:" <<  e->dl
            	        	<< " i:" << i
            	        	<< std::endl;
}
        
        cppcc::scb::SyntaxControlledBinary::edpirType* ee =
          //BUG:// bin_.ptredp(help_.k(KW_IDENTALT).k_
          bin_.ptredp(help_.k(KW_ALTPART).k_
            ,bin_.dynamic(e, i).d);
        if (ee) {
          if (bin_.fixed(ee)) {
        	if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
              //ruleError(output, nnrule, errorHereMustBeIterItemact);
        	  ruleError(output, nnrule, errorHereMustINtermTermAct);	
              CPPCC_THROW_EXCEPTION(
                << " rule:" << nnrule << " "
                << " tag:" << bin_.fixed(ee, 1).t
                << " should be:" << KW_NTERMTERMACT
                << errorHereMustINtermTermAct    
              )       		
        	}
        	  
            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                ,bin_.fixed(ee, 1).d);
            if (eact) {
              if (bin_.fixed(eact)) {
            	//BUG:// if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 1).t) {
            	if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
            	  //BUG:// if(nid == bin_.fixed(eact, 1).d) {
 
if (isDebugBug) {
    std::cout << "metaidal:1:"
    		<< " nnrule:" << nnrule
    << " nid:" << nid 
    << " nal:" << nal 
    << " id:" << bin_.ptrids(nal)
    << " e:" << (e?1:0)
   << " dynamic-----------"
   << " dl:" <<  e->dl
   << " i:" << i
   << " d:" << bin_.fixed(eact, 0).d
		<< " r:" << bin_.ptrids(bin_.fixed(eact, 0).d)
   << std::endl;
}
            		
            		if(nid == bin_.fixed(eact, 0).d) {
            		if(yy) *yy= 0;  
                    return;      
            	  }
            	}
              }
            }     
          }
        }     
      }
    }
  }

}
	
//int metachrr(r,k,nnrule,nid,rig,yy)
//void metachrr(j, kn.d, knr.d, &yy);
void 
GenerateParserCC::metachrr
(std::ofstream& 		output
,cppcc::scr::tag::Long 	nnrule
,cppcc::scr::tag::Long	nid
,cppcc::scr::tag::Long  rig
,int* 					yy)
{
  cppcc::scr::tag::Long i, z;
  cppcc::scr::tag::Long ii, zz;
	
  //bool isDebugBug = true;
  bool isDebugBug = false;
  
  if (isDebugBug) {
    std::cout << "metachrr:0:start:" 
    << nid <<  " " << bin_.ptrids(nid)
    << " r:" << rig
    << std::endl;
  }
  
  cppcc::scb::SyntaxControlledBinary::edpirType* etr =
   bin_.ptredp(help_.k(KW_RIGHT).k_,rig);
  if (etr) {
    if (bin_.dynamic(etr)) {
    	
if (isDebugBug) {
    	std::cout << "metachrr:1: " 
    	<< " dl:" << etr->dl
    	<< std::endl;
}
    	
      for (i = 0, z = etr->dl; i < z; i++) {
        cppcc::scr::tag::Long t = bin_.dynamic(etr,i).t;

if (isDebugBug) {
std::cout << "metachrr:2:i " << i 
<< " t:" << t
<< std::endl;
}
        
        if (KW_ITERATION == t) {
       	  cppcc::scb::SyntaxControlledBinary::edpirType* eiter =
            bin_.ptredp(help_.k(KW_ITERATION).k_
              ,bin_.dynamic(etr,i).d);
          if (eiter) {
            if (bin_.fixed(eiter)) {
              if (KW_ITERITEMACT != bin_.fixed(eiter, 1).t) {
            	  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(eiter, 1).t
                    << " should be:" << KW_ITERITEMACT
                    << errorHereMustBeIterItemact    
                  )
              }
 
if (isDebugBug) {
  std::cout << "metachrr:3:i" << i << std::endl;
}
           	  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                  ,bin_.fixed(eiter,1).d);
              if (eact) {
                if (bin_.fixed(eact)) {
                  cppcc::scr::tag::Long tt = bin_.fixed(eact,0).t;
                  if (cppcc::com::PLS_IDENTIFIER == tt) {
                	//BUG: should be added:
                	if (nid == bin_.fixed(eact,0).d) {
                		if(yy) *yy = 0;
                	
                		return;
                	}
                  }    
                  else if (KW_MAYBENTERM == tt) {
                    cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
                      bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                        ,bin_.fixed(eact,0).d);
                    if (eitit) {
                      if (bin_.fixed(eitit)) {
                        if (cppcc::com::PLS_IDENTIFIER != 
                          bin_.fixed(eitit,1).t) {
                          ruleError(output, nnrule,errorHereMustBeIdentifier);
                          CPPCC_THROW_EXCEPTION(
                            << " rule:" << nnrule << " "
                            << " tag:" << bin_.fixed(eitit,1).t
                            << " should be:" << cppcc::com::PLS_IDENTIFIER
                            << errorHereMustBeIdentifier    
                          )
                        }
                        
            			if(nid == bin_.fixed(eitit,1).d) {
            			  if(yy) *yy= 0;
            			  return;
            			}                    
                        
                      }
                    }
                  }
                  else {
                	ruleError(output, nnrule, errorHereMustBeIterItem);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << errorHereMustBeIterItem    
                    )
                  }
                  
                  
                  if (KW_ITERITEMS != bin_.fixed(eiter,2).t) {
                  	ruleError(output, nnrule, errorHereMustBeIterItems);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << " tag:" << bin_.fixed(eiter,2).t
                      << " should be:" << KW_ITERITEMS
                      << errorHereMustBeIdentifier    
                    )                 
                  }
                  
                  cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
                    //BUG:// bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                    bin_.ptredp(help_.k(KW_ITERITEMS).k_
                      ,bin_.fixed(eiter,2).d);
                  if (eitit) {
                    if (bin_.dynamic(eitit)) {
                      for (ii = 0, zz = eitit->dl; ii < zz; ii++) {
                        //cppcc::scr::tag::Long t = bin_.dynamic(eitit,ii).t;
                    	// BUG: // if (KW_ALTITERITEM == 
if (isDebugBug) {
  std::cout << "metachrr:4:i" << i << " ii:" << ii << std::endl;
}
                    	  
                    	  if (KW_ALTITERITEM != 
                          bin_.dynamic(eitit,ii).t) {
                          ruleError(output, nnrule,errorHereMustBeAltIterItem);
                          CPPCC_THROW_EXCEPTION(
                            << " rule:" << nnrule << " "
                            << " tag:" << bin_.dynamic(eitit,ii).t
                            << " should be:" << KW_ALTITERITEM
                            << errorHereMustBeAltIterItem    
                          )                      
                        }
                        
                        cppcc::scb::SyntaxControlledBinary::edpirType* ea =
                          // BUG: // bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                          bin_.ptredp(help_.k(KW_ALTITERITEM).k_
                            // BUG:
                            //,bin_.fixed(eitit,ii).d);
                            ,bin_.dynamic(eitit,ii).d);
                        if (ea) {
                          if (bin_.fixed(ea)) {
                        	//BUG: // if (KW_ITERITEMACT ==  
                            if (KW_ITERITEMACT != 
                                bin_.fixed(ea,1).t) {
                                ruleError(output, nnrule, errorHereMustBeIterItemact);
                                CPPCC_THROW_EXCEPTION(
                                  << " rule:" << nnrule << " "
                                  << " tag:" << bin_.fixed(ea,1).t
                                  << " should be:" << KW_ITERITEMACT
                                  << errorHereMustBeIterItemact    
                                )                       
                            }
                            
                            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                              bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                                ,bin_.fixed(ea,1).d);
                            if (eact) {
                              if (bin_.fixed(eact)) {
                            	cppcc::scr::tag::Long t0 = bin_.fixed(eact,0).t;
 
if (isDebugBug) {
std::cout << "metachrr:5:i" << i << " ii:" << ii 
		<< " t0:" << t0
<< std::endl;
}
                            	
                            	if (cppcc::com::PLS_IDENTIFIER == t0) {                              
                      			  if(nid == bin_.fixed(eact,0).d) {
                      			    if(yy) *yy= 0;
                      			    return;
                      			  }                                   	  
                                }
                                else if (KW_MAYBENTERM == t0) {
                                  cppcc::scb::SyntaxControlledBinary::edpirType* eaa =
                                    bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                                      ,bin_.fixed(eact,0).d);
                                  if (eaa) {
                                    if (bin_.fixed(eaa)) {
                                      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eaa, 1).t) {
                                        ruleError(output, nnrule, errorHereMustBeIdentifier);
                                        CPPCC_THROW_EXCEPTION(
                                          << " rule:" << nnrule << " "
                                          << " tag:" << bin_.fixed(eaa, 1).t
                                          << " should be:" << cppcc::com::PLS_IDENTIFIER
                                          << errorHereMustBeIdentifier    
                                        )                               		
                                      }
                                      
                				      if(nid == bin_.fixed(eaa, 1).d) {
                				    	  if(yy) *yy= 0;
                				    	  return;
                				      }              	
                                    }
                                  }
                                }
                                else {
                                	ruleError(output, nnrule, errorHereMustBeIterItem);
                                    CPPCC_THROW_EXCEPTION(
                                       << " rule:" << nnrule << " "
                                       << errorHereMustBeIterItem    
                                     )
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }             
            }
          }      	
        } 
        else if(KW_IDENTMISS == t) {
          cppcc::scb::SyntaxControlledBinary::edpirType* ea =
            bin_.ptredp(help_.k(KW_IDENTMISS).k_
              ,bin_.dynamic(etr,i).d);
          if (ea) {
            if (bin_.fixed(ea)) {
              if (KW_IDENTALT != 
                bin_.fixed(ea,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIdentAlt);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(ea,1).t
                    << " should be:" << KW_IDENTALT
                    << errorHereMustBeIdentAlt    
                  )                    
              }
              
              //register int s = 0;
              //if(s= metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy)) return(s);
              metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy);
    	      if(yy) {
			    if(!(*yy)) return;
    	      }
            }
          }
        } 
        else if(KW_ALTERNATIVE == t) {
          cppcc::scb::SyntaxControlledBinary::edpirType* ea =
            bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
              ,bin_.dynamic(etr,i).d);
          if (ea) {
            if (bin_.fixed(ea)) {
              if (KW_IDENTALT != 
                bin_.fixed(ea,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIdentAlt);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(ea,1).t
                    << " should be:" << KW_IDENTALT
                    << errorHereMustBeIdentAlt    
                  )                       
                }
                
              //register int s = 0;
              //if(s= metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy)) return(s);
              metaidal(output,nnrule,nid,bin_.fixed(ea,1).d,yy);
      	      if(yy) {
  			    if(!(*yy)) return;
      	      }
            }
          }     	
        } 
        else if(KW_IDENTALT == t) {
if (isDebugBug) {
        	std::cout << "metachrr:6:t " << t
        			
        			<< " KW_IDENTALT"
        	<< std::endl;
}

          //register int s = 0;
          //if(s= metaidal(output,nnrule,nid,bin_.fixed(etr,i).d,yy)) return(s);
          // BUG: // metaidal(output,nnrule,nid,bin_.fixed(etr,i).d,yy);
          metaidal(output,nnrule,nid,bin_.dynamic(etr,i).d,yy);
    	  if(yy) {
		    if(!(*yy)) return;
    	  }       	
        } 
        else if(KW_ACTION == t) {
        	
        }
        else {
          ruleError(output, nnrule, errorWrongRightElement);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            //<< " tag:" << bin_.fixed(e, 0).t
            //<< " should be:" << KW_NTERMTERMACT
            << errorWrongRightElement    
          )
        }
      } // i
    }
  }	
  
  return;
}

// fixed


void 
GenerateParserCC::checkGrammar(std::ofstream&   output) 
{
   //bool isBugTesting = true;	
   bool isBugTesting = false;	
	
   cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
    help_.k(KW_RULE);
   if (k) {
     for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
	   cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
	        	
	   cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
	   if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		 tok_.errorMessage(errorNoIdentifierFound);
		 CPPCC_THROW_EXCEPTION(
		   << errorNoIdentifierFound
		   << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		 )
	   }

	   cppcc::scr::tag::TypeInstance&  knr = eru.fixed(3);
	   if (KW_RIGHT != knr.t) {
         tok_.errorMessage(errorNoRightEntryFound);
			CPPCC_THROW_EXCEPTION(
			  << errorNoRightEntryFound
			  << " rule:" << nnrule << " k:" << knr.t << " n:" << knr.d
			)
	   }
	            
	   cppcc::scr::tag::Long rule;
	   cppcc::scr::tag::setedflong(&rule,KW_RULE,nnrule);

if (isBugTesting) {
std::cout << "Checking:" << nnrule << std::endl;
}

	   //generateRuleBody(output, nnrule, kn.d, knr.d);

	   //int cntIteration	=	0;
	   //int cntIdentAlt	=	0;
	   //int cntIdentMiss	=	0;

	   cppcc::scr::tag::Long nright = knr.d;
	   cppcc::scb::SyntaxControlledBinary::edpirType* e =
	      bin_.ptredp(help_.k(KW_RIGHT).k_,nright);
	   if (e) {
	     if (bin_.dynamic(e)) {
	       // Check left part of rule (nterm) in other rules
	       // in a left part - forbidden.
	       if (eru.fixed()) {
	         int yy = 1;
	         
	         for (cppcc::scr::tag::Long j = 0, z2 = k.edps_.size(); j<z2; j++) {
	           cppcc::scb::SyntaxControlledBinary::edpirType* er =
	             bin_.ptredp(help_.k(KW_RULE).k_,j);
if (isBugTesting) {
std::cout << "Checking:" << nnrule << " j:" << j << std::endl;
}	           
	           if (er) {
	             if (bin_.fixed(er)) {
	               if(nnrule != 0) {
	                 if(yy) {
	                   if (bin_.fixed(er, 3).t != KW_RIGHT) {
	              		 tok_.errorMessage(errorNoRightEntryFound);
	              		 CPPCC_THROW_EXCEPTION(
	              		   << errorNoRightEntryFound
	              		   << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
	              		   << " checking rule:" << j 
	              		 )
	                   }
	                   
if (isBugTesting) {
std::cout << "Checking:" << nnrule << " j:" << j << "before:metachrr" << std::endl;
}	           
	                   
	                   // metachrr(r,k,j,uru.f[1].d,ur.f[3].d,&yy)
	                   //if(metachrr(output, j, kn.d, knr.d, &yy)) return;
	                   // BUG:: //metachrr(output, j, kn.d, knr.d, &yy);
	                   metachrr(output, j, kn.d, bin_.fixed(er, 3).d, &yy);
if (isBugTesting) {
std::cout << "Checking:" << nnrule << " j:" << j 
		<< "after:metachrr" 
		<< " yy:" << yy
		<< std::endl;
}	 	                   
	                 }
	               }
	               
	               if (j > nnrule) {
	                   if (bin_.fixed(er, 1).t != KW_IDENTIFIER) {
	              		 tok_.errorMessage(errorHereMustBeIdentifier);
	              		 CPPCC_THROW_EXCEPTION(
	              		   << errorHereMustBeIdentifier
	              		   << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
	              		   << " checking rule:" << j 
	              		 )
	                   }
            	   
	                   if (bin_.fixed(er, 1).d == kn.d) {
		              		 tok_.errorMessage(errorSecondDefinitionOfLeftPartOfRule);
		              		 CPPCC_THROW_EXCEPTION(
		              		   << errorSecondDefinitionOfLeftPartOfRule
		              		   << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		              		   << " checking rule:" << j 
		              		 )
	                	   
	                   }
	               } //if (j > nnrule) 
	             }
	           }
	         }
	         
	         
	         if (nnrule != 0) {
	     	    if(yy) ruleWarning(output, nnrule,warningRuleIsNotUsed);       	 
	         }
	       }
	       
	       
		   int cntIteration	=	0;
		   int cntIdentAlt	=	0;
		   int cntIdentMiss	=	0;
		   
		   // check right part restrictions by its representation 
		   for(cppcc::scr::tag::Long i= 0, z3 = e->dl; i < z3; i++) {
			  if(KW_ITERATION == bin_.dynamic(e,i).t) cntIteration++;
			  else if(KW_IDENTMISS == bin_.dynamic(e,i).t) cntIdentMiss++;
			  else if(KW_IDENTALT == bin_.dynamic(e,i).t) {
			    //eidentalt= ptredp(r,k[KW_IDENTALT],u.d[i].d);
			    //if(eidentalt) {
			    //  if((eidentalt->dl) > 0) cntIdentAlt++;
			    //}
				cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
			      bin_.ptredp(help_.k(KW_IDENTALT).k_
			        ,bin_.dynamic(e,i).d);
				if (eidentalt) {
				  if (bin_.dynamic(eidentalt)) {
				    cntIdentAlt++;
				  }
				}
			  }
		   }

		   if(cntIdentAlt > 1) {
			  ruleError(output, nnrule,errorSimpleAlternativeMustBeOne);
			  return;
		   }

		   if((cntIdentAlt == 1) && ((e->dl) > 1)) {
			  ruleError(output, nnrule,errorSimpleAlternativeMustBeOneWithoutElements);
			  return;
		   }
		   
		   if(cntIteration > 1) {
			  ruleError(output, nnrule,errorIterationMustBeOne);
			  return;
		   }
	       	       
	     }
	   }
     }
   }		
}

// int metarfiden(r,k,nnrule,nnn,nta,len)
// if(s= metarfiden(r,k,nnrule,nnn,nta,len)) return(s);
void GenerateParserCC::metarfiden
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nnn
,metantmType::SymbolsContainer&	symbols)
{
  cppcc::scr::tag::Long 		rull;
  
  //if(s= metachnt(r,k,nnrule,nnn,&rull)) return(s);
  metachnt(output, nnrule, nnn, &rull);
  
  if (-1 == rull) {
    // if(s= metarfaddnxt(r,k,nnrule,nnn,nta,len)) return(s);
	metarfaddnxt(output, nnrule, nnn, symbols);
  } else {
	// recursive call
	// if(s= metarfir(r,k,rull,nta,len)) return(s);
	metarfir(output, rull, symbols);
  }  
}


// // if(s= metarfiter(r,k,nnrule,u.d[i].d,nta,len)) return(s);
// 	metarfiter(output, nnrule, bin_.dynamic(e, i).d, symbols);
void 
GenerateParserCC::metarfiter
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer&	symbols)
{
  //cppcc::scr::tag::Long 							nnn = 0;	
  cppcc::scb::SyntaxControlledBinary::edpirType* 	ee =
    bin_.ptredp(help_.k(KW_ITERATION).k_,nid);
  if (ee) {
    if (bin_.fixed(ee)) {  
	  if (KW_ITERITEMACT != bin_.fixed(ee,1).t) {  
    	tok_.errorMessage(errorHereMustBeIterItemact);
    	output 
    	  << errorHereMustBeIterItemact 
  	      << " rule:" << nnrule
  	      << " k:" << bin_.fixed(ee,1).t
  	      << " n:" << bin_.fixed(ee,1).d
    	<< std::endl;
    	  
    	CPPCC_THROW_EXCEPTION(
    	    << errorHereMustBeIterItemact
    	    << " rule:" << nnrule
    	    << " k:" << bin_.fixed(ee,1).t
    	    << " n:" << bin_.fixed(ee,1).d
    	)		  
	  }

	  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
	    bin_.ptredp(help_.k(KW_ITERITEMACT).k_
	      ,bin_.fixed(ee,1).d);
	  if (eact) {
	    if (bin_.fixed(eact)) {  
	    	
	      cppcc::scr::tag::Long 	nnn = 0;	
	      cppcc::scr::tag::Long 	t = bin_.fixed(eact,0).t;
		  if (KW_MAYBENTERM == t) {  
            cppcc::scb::SyntaxControlledBinary::edpirType* en =
              bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                ,bin_.fixed(eact,0).d);
            if (en) {
              if (bin_.fixed(en)) {
                if (cppcc::com::PLS_IDENTIFIER != 
                  bin_.fixed(en,1).t) {
                    //ruleError(output, nnrule,errorHereMustBeIdentifier);
                    //return;
                	tok_.errorMessage(errorHereMustBeIdentifier);
                	output 
                	  << errorHereMustBeIdentifier 
              	      << " rule:" << nnrule
              	      << " k:" << bin_.fixed(en,1).t
              	      << " n:" << bin_.fixed(en,1).d
                	<< std::endl;
                	  
                	CPPCC_THROW_EXCEPTION(
                	    << errorHereMustBeIdentifier
                	    << " rule:" << nnrule
                	    << " k:" << bin_.fixed(en,1).t
                	    << " n:" << bin_.fixed(en,1).d
                	)		  
            	  }
                  nnn = bin_.fixed(en,1).d;
                  
                }               
             }
          }		  
		  else if (cppcc::com::PLS_IDENTIFIER == t) {  
		      nnn = bin_.fixed(eact,0).d;
		  }
		  else {
            	tok_.errorMessage(errorHereMustBeIdentifierOrLess);
            	output 
            	  << errorHereMustBeIdentifierOrLess 
          	      << " rule:" << nnrule
          	      << " k:" << bin_.fixed(eact,0).t
          	      << " n:" << bin_.fixed(eact,0).d
            	<< std::endl;
            	  
            	CPPCC_THROW_EXCEPTION(
            	    << errorHereMustBeIdentifierOrLess
            	    << " rule:" << nnrule
            	    << " k:" << bin_.fixed(eact,0).t
            	    << " n:" << bin_.fixed(eact,0).d
            	)		  

		  }  
		  
		  //if(s= metarfiden(r,k,nnrule,nnn,nta,len)) return(s);
		  metarfiden(output,nnrule,nnn,symbols);
	  
		}		  
	  }
	}	  
  }
}

// check identifier in grammer rules.
//if(s= metachnt(r,k,nnrule,nnn,&rull)) return(s);
void 
GenerateParserCC::metachnt
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nid
,cppcc::scr::tag::Long* 		rul)
{
  cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
    help_.k(KW_RULE);
  
  //if (!help_.k(KW_RULE).k_) return;
  if (!k) return;
  
  //bool isDebugBug = true;
  bool isDebugBug = false;
  
  std::string kwd = bin_.ptrids(nid);
  
  if (isDebugBug) {
	std::cout << "metachnt:" 
	<< " nid:" << nid
	<< " kwd:" << kwd
	<< " id:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_IDENTIFIER]
    << " s:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_STRING_TOKEN]
    << " i:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_INTEGER_TOKEN]
    << " t:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TERMINAL_TOKEN]
    << " z:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TEXT_TOKEN]                                             
	<< std::endl; 
  }
  
  if ((tok_.grammarSymbols_.predefined_[cppcc::com::PLS_IDENTIFIER] == kwd)
	|| (tok_.grammarSymbols_.predefined_[cppcc::com::PLS_STRING_TOKEN] == kwd)
	|| (tok_.grammarSymbols_.predefined_[cppcc::com::PLS_INTEGER_TOKEN] == kwd)
	|| (tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TERMINAL_TOKEN] == kwd)
	|| (tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TEXT_TOKEN] == kwd)
  )
  {
    if (rul) *rul = -1;
    if (isDebugBug) {
  	std::cout << "metachnt:=====----->>>>>> -1 >>>>" 
  	<< " nid:" << nid
  	<< " kwd:" << kwd
  	<< " id:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_IDENTIFIER]
      << " s:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_STRING_TOKEN]
      << " i:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_INTEGER_TOKEN]
      << " t:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TERMINAL_TOKEN]
      << " z:" << tok_.grammarSymbols_.predefined_[cppcc::com::PLS_TEXT_TOKEN]                                             
  	<< std::endl; 
    }
    return;
  }
  
  if (CheckMode_) {
    cppcc::scr::tag::Long j = grammar_.ntmrul[nid];
	//		    j= Grammer.ntmrul[nid];
	//		    if((j >= 0) && (j < (Grammer.ntmlen))) {
	//		      if(rul) *rul= j;
	//		      return(0);
	//		    }
    if ((j >= 0) && (j < grammar_.ntmrul.size())) {
      if (rul) *rul = j; 
	  
	  if (isDebugBug) {
		std::cout << "metachnt:===================>" 
		<< " nid:" << nid
		<< " kwd:" << kwd
		<< " rul:" << j
		<< std::endl; 
	  }

      return;
    }
  }
  else {
	for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
	  cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);	  
	  if (eru.fixed()) {
	    if (cppcc::com::PLS_IDENTIFIER == eru.fixed(1).t) {
	      if (eru.fixed(1).d == nid) {
	    	if (rul) *rul = nnrule; 	
	    	  
	    	  if (isDebugBug) {
	    		std::cout << "metachnt:--------------->" 
	    		<< " nid:" << nid
	    		<< " kwd:" << kwd
	    		<< " nnrule:" << nnrule
	    		<< std::endl; 
	    	  }
	    	  
	    	return;  
	      }
	    }
	  }
	}
  }
  
  if(rul) *rul= -2;
  tok_.errorMessage(errorRightElementHasNoDefinition);
  output
  << " nonterminal:" << "'" << kwd << "'" << " "
  << errorRightElementHasNoDefinition
  << std::endl;
  CPPCC_THROW_EXCEPTION(
	<< " nonterminal:" << "'" << kwd << "'" << " "
    << errorRightElementHasNoDefinition
  )  
}

// if(s= metarfaddnxt(r,k,nnrule,nnn,nta,len)) return(s);
//int metarfaddnxt(r,k,nnrule,nnn,nta,len)
void 
GenerateParserCC::metarfaddnxt
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nnn
,metantmType::SymbolsContainer&	symbols)
{
  if (symbols.size() == tok_.grammarSymbols_.size()) {
	  tok_.errorMessage(errorTooManyFirstSymbols);
	  output
	  << " size:" << symbols.size() << " "
	  << errorTooManyFirstSymbols
	  << std::endl;
	  CPPCC_THROW_EXCEPTION(
		<< " size:" << symbols.size() << " "
	    << errorTooManyFirstSymbols
	  )  	  
  }
  
  if (symbols.end() != symbols.find(nnn)) {
    return;
    /*
	  tok_.errorMessage(errorFirstSymbolsConflict);
	  output
	    << " rule:" << nnrule << " "
	    << " symbol:" << nnn 
	    << " " << "'" << bin_.ptrids(nnn) << "'" 
	    << " " << errorFirstSymbolsConflict
	    << std::endl;
	  
	  metantmType::SymbolsContainer::const_iterator cIter = symbols.begin();
	  metantmType::SymbolsContainer::const_iterator cEnd = symbols.end();	  
	  for (std::size_t cnt = 0; cEnd != cIter; ++cIter, cnt++) {
		  output
		    << " rule:" << nnrule << " "
		    << " first:" << cnt
		    << " " << (*cIter)
		    << " " << "'" << bin_.ptrids((*cIter)) << "'" 
		    //<< " " << "'" << bin_.ptrids((*cIter)) << "'"
		    << " " << errorFirstSymbolsConflict
		    << std::endl;		  
	  }
	  
	  CPPCC_THROW_EXCEPTION(
	    << " rule:" << nnrule << " "
	    << " symbol:" << nnn
	    << " " << errorFirstSymbolsConflict
	  )  	  
	*/
  }
  
  symbols.insert(nnn);
  
  //bool isDump = true;
  bool isDump = false;
  if (isDump) {
	  /*
	  metantmType::SymbolsContainer::const_iterator cIter = symbols.begin();
	  metantmType::SymbolsContainer::const_iterator cEnd = symbols.end();	  
	  for (std::size_t cnt = 0; cEnd != cIter; ++cIter, cnt++) {
		  output
		    << " rule:" << nnrule << " "
		    << " first:" << cnt
		    << " " << (*cIter)
		    << " " << "'" << bin_.ptrids((*cIter)) << "'" 
		    //<< " " << "'" << bin_.ptrids((*cIter)) << "'"
		    << std::endl;		  
	  }  
	  */
	  dumpSymbols(output, nnrule, symbols);
  }
  
}

// //setptrrule(r,k[KW_IDENTALT],eidentalt,uidentalt);
// //if(s= metarfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
// //		     nta,len)) return(s);
// metarfsimp(output, nnrule
//   ,bin_.fixed(eidentalt,0).t
//   ,bin_.fixed(eidentalt,0).d
//   ,symbols
// );
void
GenerateParserCC::metarfsimp
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nit
,cppcc::scr::tag::Long 	    	nid
,metantmType::SymbolsContainer&	symbols)
{
  if (KW_NTERMTERMACT != nit) {
    	/// errorHereMustBeIterItemact
  	  tok_.errorMessage(errorHereMustINtermTermAct);
  	  output
  	    << " rule:" << nnrule << " "
  	    << errorHereMustINtermTermAct
  	    << std::endl;
  	  CPPCC_THROW_EXCEPTION(
  		<< " rule:" << nnrule << " "
  	    << errorHereMustINtermTermAct
  	  )  	  
  }
  
  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
    bin_.ptredp(help_.k(KW_NTERMTERMACT).k_,nid);
  if (eact && bin_.fixed(eact)) {
    switch (bin_.fixed(eact,0).t) {
    case cppcc::com::PLS_IDENTIFIER:
	  //if(s= metarfiden(r,k,nnrule,nnn,nta,len)) return(s);
	  metarfiden(output,nnrule,bin_.fixed(eact,0).d,symbols);
      break;
    case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
      // if(s= metarfaddnxt(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
      metarfaddnxt(output,nnrule,bin_.fixed(eact,0).d,symbols);
      break;
    default:
      {
      	/// errorHereMustBeIterItemact
    	  tok_.errorMessage(errorUndefinedSimlpTerminal);
    	  output
    	    << " rule:" << nnrule << " "
    	    << errorUndefinedSimlpTerminal
    	    << std::endl;
    	  CPPCC_THROW_EXCEPTION(
    		<< " rule:" << nnrule << " "
    	    << errorUndefinedSimlpTerminal
    	  )  	  
    	
      }
    }
  }
}

// // simple alternative or identifier 
// //  if(s= metarfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s); 
// metarfalid(output, nnrule, bin_.fixed(e,1).d, symbols)
void
GenerateParserCC::metarfalid
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 	    	nalid
,metantmType::SymbolsContainer&	symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
    bin_.ptredp(help_.k(KW_IDENTALT).k_
      ,nalid);
  if (eidentalt) {
  if (bin_.fixed(eidentalt)) {
    if (bin_.fixed(eidentalt,0).t != KW_NTERMTERMACT) {
        ruleError(output, nnrule, errorHereMustBeIterItemact);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << errorHereMustBeIterItemact
        )                            
     }
      
     cppcc::scb::SyntaxControlledBinary::edpirType* eact =
       bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
        ,bin_.fixed(eidentalt,0).d);
     if (eact) {
       if (bin_.fixed(eact)) {
         //if (bin_.fixed(eact,0).t != 
         // cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
         switch (bin_.fixed(eact,0).t) {
         case cppcc::com::PLS_IDENTIFIER:
           // if(s= metarfiden(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
           metarfiden(output, nnrule, bin_.fixed(eact,0).d, symbols);
           break;
         case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
           // if(s= metarfaddnxt(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
           metarfaddnxt(output,nnrule,bin_.fixed(eact,0).d,symbols);
           break;      
         default:
         {
           /// errorHereMustBeIterItemact
           //tok_.errorMessage(errorUndefinedSimlpTerminal);
           //output
           //  << " rule:" << nnrule << " "
           //  << errorUndefinedSimlpTerminal
           //  << std::endl;
           ruleError(output, nnrule, errorUndefinedSimlpTerminal);
           CPPCC_THROW_EXCEPTION(
           << " rule:" << nnrule << " "
             << errorUndefinedSimlpTerminal
           )     
         
         }
       }
     }
   }
  }   
  
  if (bin_.dynamic(eidentalt)) {
    for (cppcc::scr::tag::Long i = 0, z = eidentalt->dl; i < z; i++) {
      // BUG: added :::
      if (KW_ALTPART != bin_.dynamic(eidentalt,i).t) {
          ruleError(output, nnrule, errorHereMustBeAltpart);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << " tag:" << bin_.dynamic(eidentalt,i).t
            << " should be:" <<KW_ALTPART
            << errorHereMustBeAltpart
          )                                              	  
      }
      // BUG: added ...
    	
      cppcc::scb::SyntaxControlledBinary::edpirType* ee =
        bin_.ptredp(help_.k(KW_ALTPART).k_
          ,bin_.dynamic(eidentalt,i).d);
      if (bin_.fixed(ee)) {
        if (bin_.fixed(ee, 1).t != KW_NTERMTERMACT) {
            ruleError(output, nnrule, errorHereMustINtermTermAct);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << errorHereMustINtermTermAct
            )                                              
        }
        
        cppcc::scb::SyntaxControlledBinary::edpirType* eact = 
          bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
            ,bin_.fixed(ee,1).d);
        if (eact) {
          if (bin_.fixed(eact)) {
            switch(bin_.fixed(eact,0).t) {
            case cppcc::com::PLS_IDENTIFIER:
              // if(s= metarfiden(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
              metarfiden(output, nnrule, bin_.fixed(eact,0).d, symbols);
              break;
            case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
              // if(s= metarfaddnxt(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
              metarfaddnxt(output,nnrule,bin_.fixed(eact,0).d,symbols);
              break;      
            default:
            {
              /// errorHereMustBeIterItemact
              //tok_.errorMessage(errorUndefinedSimlpTerminal);
              //output
              //  << " rule:" << nnrule << " "
              //  << errorUndefinedSimlpTerminal
              //  << std::endl;
              ruleError(output, nnrule, errorUndefinedSimlpTerminal);
              CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
                << errorUndefinedSimlpTerminal
              )     
            
            }
            }
          }
        }
      }
    }
  }
  } 
}


void 
GenerateParserCC::metarfmiss
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nal
,metantmType::SymbolsContainer&	symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_IDENTMISS).k_,nal);
  if (e && bin_.fixed(e)) {
    if (KW_IDENTALT != bin_.fixed(e,1).t) {
    	//errorHereMustBeIdentAlt
  	  tok_.errorMessage(errorHereMustBeIdentAlt);
  	  output
  	    << " rule:" << nnrule << " "
  	    << errorHereMustBeIdentAlt
  	    << std::endl;
  	  CPPCC_THROW_EXCEPTION(
  		<< " rule:" << nnrule << " "
  	    << errorHereMustBeIdentAlt
  	  )  	  
    }
    
    // Simple alternamtive or identifier:
    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
      bin_.ptredp(help_.k(KW_IDENTALT).k_,bin_.fixed(e,1).d);
    if (eidentalt) {
      if (eidentalt->dl == 0) {
    	//setptrrule(r,k[KW_IDENTALT],eidentalt,uidentalt);
    	//if(s= metarfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
    	//		     nta,len)) return(s);
    	metarfsimp(output, nnrule
    	  ,bin_.fixed(eidentalt,0).t
    	  ,bin_.fixed(eidentalt,0).d
    	  ,symbols
    	);
      } else {
        // simple alternative or identifier 
    	//  if(s= metarfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s); 
    	metarfalid(output, nnrule, bin_.fixed(e,1).d, symbols);
      }
    }
  }
}


void 
GenerateParserCC::metarfaltr
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nal
,metantmType::SymbolsContainer&	symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
	bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
	  ,nal);
  if (e) {
    if (bin_.fixed(e)) {
	  if (bin_.fixed(e,1).t != KW_IDENTALT) {
	    ruleError(output, nnrule, errorHereMustBeIdentAlt);
	    CPPCC_THROW_EXCEPTION(
	      << " rule:" << nnrule << " "
	      << errorHereMustBeIdentAlt
	    )                            
	  }

	    // Simple alternamtive or identifier:
	    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
	      bin_.ptredp(help_.k(KW_IDENTALT).k_,bin_.fixed(e,1).d);
	    if (eidentalt) {
	      if (eidentalt->dl == 0) {
	      //setptrrule(r,k[KW_IDENTALT],eidentalt,uidentalt);
	      //if(s= metarfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
	      //         nta,len)) return(s);
	      metarfsimp(output, nnrule
	        ,bin_.fixed(eidentalt,0).t
	        ,bin_.fixed(eidentalt,0).d
	        ,symbols
	      );
	      } else {
	        // simple alternative or identifier 
	      //  if(s= metarfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s); 
	      metarfalid(output, nnrule, bin_.fixed(e,1).d, symbols);
	      }
	    }
	  
    }
  }
}


void 
GenerateParserCC::metarfaltern
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long 			nal
,metantmType::SymbolsContainer&	symbols)
{
    // Simple alternamtive or identifier:
    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
      bin_.ptredp(help_.k(KW_IDENTALT).k_,nal);
    if (eidentalt) {
      if (eidentalt->dl == 0) {
      //setptrrule(r,k[KW_IDENTALT],eidentalt,uidentalt);
      //if(s= metarfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
      //         nta,len)) return(s);
      metarfsimp(output, nnrule
        ,bin_.fixed(eidentalt,0).t
        ,bin_.fixed(eidentalt,0).d
        ,symbols
      );
      } else {
        // simple alternative or identifier 
      //  if(s= metarfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s); 
      metarfalid(output, nnrule, nal, symbols);
      }
    }

}

// //if(s= metarral(r,k,nnrule,nid,ua.f[1].d,&yy)) return(s);
// metarral(output, nnrule, nid, bin_.fixed(ea, 1).d, &yy);
// int metarral(r,k,nnrule,nid,nal,yy)
void 
GenerateParserCC::metarral
(std::ofstream& 				output
,std::size_t					nnrule
,cppcc::scr::tag::Long			nid
,cppcc::scr::tag::Long			nal
,int*							yy)
{
  int y = 1;
  
  //if(metaidal(output,nnrule,nid,nal,&y))
  //{
  //    ruleError(output, nnrule, errorMetaidalFailed);
  //    CPPCC_THROW_EXCEPTION(
  //      << " rule:" << nnrule << " "
  //      << " nid:" << nid
  //      << " nal:" << nal
  //      << errorMetaidalFailed
  //    )       	  	  
  //}
  metaidal(output,nnrule,nid,nal,&y);

  if(yy) *yy= !y;
}

// find follow symbol of rule 
//if(s= metarfoll(r,k,nnrule,nta,len)) return(s);
//void metarfoll(output, nnrule, symbols);
void 
GenerateParserCC::metarfoll
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols)
{
  cppcc::scr::tag::Long nid = -1;
  int					yy  = 0;
  int					y   = 0;
  
  // BUG:??? //
  cppcc::scr::tag::Long j, z;
  cppcc::scr::tag::Long i, iz;
  
  cppcc::scb::SyntaxControlledBinary::edpirType* er =
    bin_.ptredp(help_.k(KW_RULE).k_
      ,nnrule);
  if (er) {
    if (bin_.fixed(er)) {	  
      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(er,1).t) {
          ruleError(output, nnrule, errorHereMustBeIdentifier);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << errorHereMustBeIdentifier
          )       	  
      }
      
      nid = bin_.fixed(er,1).d;
    }
  }

  // BUG: // for (cppcc::scr::tag::Long j = 0, z = help_.k(KW_RULE).k_->l; j < z; j++) 
  for (j = 0, z = help_.k(KW_RULE).k_->l; j < z; j++) 
  {
	er =
	  bin_.ptredp(help_.k(KW_RULE).k_
	    ,j);
	if (er && bin_.fixed(er)) {
	  if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(er, 1).t) {	
          ruleError(output, nnrule, errorHereMustBeIdentifier);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << errorHereMustBeIdentifier
          )		  
	  }
	  
	  if (KW_RIGHT != bin_.fixed(er, 3).t) {	
          ruleError(output, nnrule, errorNoRightEntryFound);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << errorHereMustBeIdentifier
          )		  
	  }

	  cppcc::scb::SyntaxControlledBinary::edpirType* etr =
	    bin_.ptredp(help_.k(KW_RIGHT).k_
	      ,bin_.fixed(er, 3).d);
	  if (etr && bin_.dynamic(etr)) {
	    //for (cppcc::scr::tag::Long i=0, iz = etr->dl; i < iz; i++) {
	    for (i=0, iz = etr->dl; i < iz; i++) {
	      yy= 0;
	      cppcc::scr::tag::Long t = bin_.dynamic(etr, i).t;
	      cppcc::scr::tag::Long d = bin_.dynamic(etr, i).d;
	      if (KW_ITERATION == t) {
	        cppcc::scb::SyntaxControlledBinary::edpirType* eiter =
	    	  bin_.ptredp(help_.k(KW_ITERATION).k_
	    	    ,d);
	    	if (eiter && bin_.fixed(eiter)) {
	    	  if (KW_ITERITEMACT != bin_.fixed(eiter,1).t) {	
	              ruleError(output, nnrule, errorHereMustBeIterItemact);
	              CPPCC_THROW_EXCEPTION(
	                << " rule:" << nnrule << " "
	                << errorHereMustBeIterItemact
	              )		  
	    	  }

		      cppcc::scb::SyntaxControlledBinary::edpirType* eact =
		    	// BUG:// bin_.ptredp(help_.k(KW_ITERATION).k_
		    	bin_.ptredp(help_.k(KW_ITERITEMACT).k_
		    	  ,bin_.fixed(eiter,1).d);
		      if (eact && bin_.fixed(eact)) {
		    	  cppcc::scr::tag::Long t0 = bin_.fixed(eact,0).t;
		    	  cppcc::scr::tag::Long d0 = bin_.fixed(eact,0).d;
                if (cppcc::com::PLS_IDENTIFIER == t0) {
                  if (nid == d0) {
                    yy= 1;
                  }
                }
                else if (KW_MAYBENTERM == t0) {
      		      cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
      		    	bin_.ptredp(help_.k(KW_MAYBENTERM).k_
      		    	  ,d0);
      		      if (eitit && bin_.fixed(eitit)) {
      		        if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eitit,1).t) {
        	          ruleError(output, nnrule, errorHereMustBeIdentifier);
        	          CPPCC_THROW_EXCEPTION(
        	            << " rule:" << nnrule << " "
        	            << errorHereMustBeIdentifier   	
        	          )
      		        }
      		        
      		        if (nid == bin_.fixed(eitit,1).d) {
      		          yy = 1;
      		        }
      		      }
                }
                else {
  	              ruleError(output, nnrule, errorHereMustBeIdentifier);
  	              CPPCC_THROW_EXCEPTION(
  	                << " rule:" << nnrule << " "
  	                << errorHereMustBeIdentifier
  	              )		                 	
                }
                
                if (!yy) {
                  if (KW_ITERITEMS != bin_.fixed(eiter,2).t) {
        	        ruleError(output, nnrule, errorHereMustBeIterItems);
        	        CPPCC_THROW_EXCEPTION(
        	            << " rule:" << nnrule << " "
        	            << errorHereMustBeIterItems   	
        	        )               	  
                  }
                	
        		  cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
        		    bin_.ptredp(help_.k(KW_ITERITEMS).k_
        		      ,bin_.fixed(eiter,2).d);
        		  if (eitit && bin_.dynamic(eitit)) {
                    for (cppcc::scr::tag::Long ii=0, zz = eitit->dl; 
                    		ii < zz; ii++) 
                    {
                      if (KW_ALTITERITEM != 
                        bin_.dynamic(eitit, ii).t) {
              	        ruleError(output, nnrule, errorHereMustBeAltIterItem);
              	        CPPCC_THROW_EXCEPTION(
              	            << " rule:" << nnrule << " "
              	            << errorHereMustBeAltIterItem   	
              	        )               	                  	  
                      }
                      
            		  cppcc::scb::SyntaxControlledBinary::edpirType* ea =
            		    bin_.ptredp(help_.k(KW_ALTITERITEM).k_
            		      ,bin_.dynamic(eitit, ii).d);
            		  if (ea && bin_.fixed(ea)) {
            		    if (KW_ITERITEMACT != bin_.fixed(ea,1).t) {
                  	      ruleError(output, nnrule, errorHereMustBeIterItemact);
                  	      CPPCC_THROW_EXCEPTION(
                  	            << " rule:" << nnrule << " "
                  	            << errorHereMustBeIterItemact   	
                  	      )
            		    }
  
              		    cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              		      bin_.ptredp(help_.k(KW_ITERITEMACT).k_
              		        //BUG:// ,bin_.fixed(ea,0).d);
              		        ,bin_.fixed(ea,1).d);
              		    if (eact && bin_.fixed(eact)) {
              			  if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact,0).t) {
              			    if (nid == bin_.fixed(eact,0).d) {
              			      yy = 1;
              			    }
              			  }
              			  else if (KW_MAYBENTERM == bin_.fixed(eact,0).t) {
                    	    cppcc::scb::SyntaxControlledBinary::edpirType* eaa =
                    		  //BUG:// bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                    		  bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                    		    ,bin_.fixed(eact,0).d);
                    		if (eaa && bin_.fixed(eaa)) {
                    		  if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eaa, 1).t) {
                          	    ruleError(output, nnrule, errorHereMustBeIdentifier);
                          	    CPPCC_THROW_EXCEPTION(
                          	      << " rule:" << nnrule << " "
                          	      << errorHereMustBeIdentifier   	
                          	    )
                    		  }
                    		  
                    		  if (nid == bin_.fixed(eaa, 1).d) {
                    			yy = 1;  
                    		  }
                    		}
              			  }
              			  else {
                	        ruleError(output, nnrule, errorHereMustBeIterItem);
                	        CPPCC_THROW_EXCEPTION(
                	            << " rule:" << nnrule << " "
                	            << errorHereMustBeIterItem   	
                	        )           				  
              			  }
              		    }           		    
            		  }                    
                    } // ii
        		  }       		  
                } // yy              
		      }	    		
	    	}
	      }
	      else if (KW_IDENTMISS == t) {
	        cppcc::scb::SyntaxControlledBinary::edpirType* ea =
	    	  bin_.ptredp(help_.k(KW_IDENTMISS).k_
	    	    ,d);
	    	if (ea && bin_.fixed(ea)) {
	    	  if (KW_IDENTALT !=  bin_.fixed(ea, 1).t) {
      	        ruleError(output, nnrule, errorHereMustBeIdentAlt);
      	        CPPCC_THROW_EXCEPTION(
      	            << " rule:" << nnrule << " "
      	            << errorHereMustBeIdentAlt   	
      	        )           				  	    		  
	    	  }
	    	  
	    	  //if(s= metarral(r,k,nnrule,nid,ua.f[1].d,&yy)) return(s);
	    	  metarral(output, nnrule, nid, bin_.fixed(ea, 1).d, &yy);
	    	}	    	  
	      }
	      else if (KW_ALTERNATIVE == t) {
	        cppcc::scb::SyntaxControlledBinary::edpirType* ea =
	          bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
	            ,d);
	        if (ea && bin_.fixed(ea)) {
		      if (KW_IDENTALT !=  bin_.fixed(ea, 1).t) {
	      	        ruleError(output, nnrule, errorHereMustBeIdentAlt);
	      	        CPPCC_THROW_EXCEPTION(
	      	            << " rule:" << nnrule << " "
	      	            << errorHereMustBeIdentAlt   	
	      	        )           				  	    		  
		       }
		    	  
		       //if(s= metarral(r,k,nnrule,nid,ua.f[1].d,&yy)) return(s);
		       metarral(output, nnrule, nid, bin_.fixed(ea, 1).d, &yy);

	        }         	    	  
	      }
	      else if (KW_IDENTALT == t) {
		       //if(s= metarral(r,k,nnrule,nid,ua.f[1].d,&yy)) return(s);
		       metarral(output, nnrule, nid, d, &yy);	    	  
	      }
	      else if (KW_ACTION == t) {
	    	  
	      }
	      else {
	          ruleError(output, nnrule, errorWrongRightElement);
	          CPPCC_THROW_EXCEPTION(
	            << " rule:" << nnrule << " "
	            << errorWrongRightElement
	          )		  	    	  
	      }
	      
	      //
	      if (yy) {
	    	if (i == ((etr->dl) - 1)) {
	    	  // if(s= metarfoll(r,k,j,nta,len)) return(s);
	    		metarfoll(output, j, symbols);
	    	} else {
	    	  y = 1;
	    
	    	  for(i= i+1; i < (etr->dl); i++) {
	              cppcc::scr::tag::Long tt = bin_.dynamic(etr, i).t;
	              cppcc::scr::tag::Long dd = bin_.dynamic(etr, i).d;
	              if (KW_ACTION == tt) {
	              }
	              else if (KW_ITERATION == tt) {
	                // if(s= metarfiter(r,k,nnrule,u.d[i].d,nta,len)) return(s);
	                metarfiter(output, nnrule, dd, symbols);
	              }
	              else if (KW_IDENTMISS == tt) {
	                // if(s= metarfmiss(r,k,nnrule,u.d[i].d,nta,len)) return(s);
	                metarfmiss(output, nnrule, dd, symbols);
	              }
	              else if (KW_ALTERNATIVE == tt) {
	                  // if(s= metarfaltr(r,k,nnrule,u.d[i].d,nta,len)) return(s);
	                // return(0);
	                metarfaltr(output, nnrule, dd, symbols);
	                y = 0;
	                break;
	              }
	              else if (KW_IDENTALT == tt) {
	                //if(s= metarfaltern(r,k,nnrule,u.d[i].d,nta,len)) return(s);
	                //return(0);
	                //metarfaltr(output, nnrule, dd, symbols);
	                metarfaltern(output, nnrule, dd, symbols);
	                y = 0;
	                break;
	              }
	            } // i = i+1

   	  
	    	  if (y) {
	    		//  end of right 
	    	    // if(s= metarfoll(r,k,j,nta,len)) return(s);  
	    		metarfoll(output, j, symbols);
	    	  }
	    	} // else
	      } // yy
	      //	 
	      
	      
	    } //i
	  }	  
	}
  } // j
  
}


void 
GenerateParserCC::dumpSymbols
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols)
{
	output << "dumpSymbols:" 
			<< " nrule:" << nnrule
			<< " sz:" << symbols.size()
	<< std::endl;	
	  metantmType::SymbolsContainer::const_iterator cIter = symbols.begin();
	  metantmType::SymbolsContainer::const_iterator cEnd = symbols.end();	  
	  for (std::size_t cnt = 0; cEnd != cIter; ++cIter, cnt++) {
		  output
		    << " rule:" << nnrule << " "
		    << " first:" << cnt
		    << " " << (*cIter)
		    << " " << "'" << bin_.ptrids((*cIter)) << "'" 
		    //<< " " << "'" << bin_.ptrids((*cIter)) << "'"
		    << std::endl;		  
	  }  
	 
   bool isStdout = 1;
   if (isStdout) {
		std::cout << "dumpSymbols:" 
				<< " nrule:" << nnrule
				<< " sz:" << symbols.size()
		<< std::endl;	
		  metantmType::SymbolsContainer::const_iterator cIter = symbols.begin();
		  metantmType::SymbolsContainer::const_iterator cEnd = symbols.end();	  
		  for (std::size_t cnt = 0; cEnd != cIter; ++cIter, cnt++) {
			  std::cout
			    << " rule:" << nnrule << " "
			    << " first:" << cnt
			    << " " << (*cIter)
			    << " " << "'" << bin_.ptrids((*cIter)) << "'" 
			    //<< " " << "'" << bin_.ptrids((*cIter)) << "'"
			    << std::endl;		  
		  }  
	   
   }
}

// 	s= metarfir(r,k,j,ffbuf,&fflen);
//metantmType::SymbolsContainer	tmpFirst;
//metarfir(j, tmpFirst);
void 
GenerateParserCC::metarfir
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols)
{
	cppcc::scr::tag::Long i, z;
	
  bool isDebugBug3 = false;
  
  bool isDebugBug2 = false;
  
  //bool isDebugBug = true;
  bool isDebugBug = false;
if (isDebugBug) {
  std::cout 
    << "metarfir::::::::::::::::::::::::::::::: start ::::::::::::::::" 
    << " rule:" << nnrule
    << " sz:" << symbols.size()
    << std::endl;
}
	
if (isDebugBug3) {
  std::cout 
    << "metarfir:begin: rule=" << nnrule
    << std::endl;
}


  cppcc::scb::SyntaxControlledBinary::edpirType* eru =
    bin_.ptredp(help_.k(KW_RULE).k_,nnrule);
  //if (eru) {
  //  if (bin_.fixed(eru)) {
  if (!eru || !bin_.fixed(eru)) return;
  
      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eru,1).t) {
    	  tok_.errorMessage(errorNoIdentifierFound);
    	  output 
    	  << errorNoIdentifierFound 
  	      << " rule:" << nnrule
  	      << " k:" << bin_.fixed(eru,1).t
  	      << " n:" << bin_.fixed(eru,1).d
    	  << std::endl;
    	  
    	  CPPCC_THROW_EXCEPTION(
    	    << errorNoIdentifierFound
    	    << " rule:" << nnrule
    	    << " k:" << bin_.fixed(eru,1).t
    	    << " n:" << bin_.fixed(eru,1).d
    	  )

      }
      
if (isDebugBug3 && symbols.size()) {
	std::cout 
 	<< "metarfir:start:" 
  	<< " rule=" << nnrule
  	<< " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
	<< std::endl;
	dumpSymbols(output, nnrule, symbols);
}

      if (KW_RIGHT != bin_.fixed(eru,3).t) {
    	  tok_.errorMessage(errorNoRightEntryFound);
    	  output 
    	  << errorNoRightEntryFound 
  	      << " rule:" << nnrule
  	      << " k:" << bin_.fixed(eru,3).t
  	      << " n:" << bin_.fixed(eru,3).d
    	  << std::endl;
    	  
    	  CPPCC_THROW_EXCEPTION(
    	    << errorNoRightEntryFound
    	    << " rule:" << nnrule
    	    << " k:" << bin_.fixed(eru,3).t
    	    << " n:" << bin_.fixed(eru,3).d
    	  )

      }
    //}
  //}

  cppcc::scb::SyntaxControlledBinary::edpirType* e =
        //BUG:// bin_.ptredp(help_.k(KW_RULE).k_
        bin_.ptredp(help_.k(KW_RIGHT).k_
          ,bin_.fixed(eru,3).d);

      if (e) {
if (isDebugBug) {
    std::cout 
    << "metarfir:" 
    << " rule:" << nnrule
    << " e:" << (*e)
    << std::endl;
}
    	  
        if (bin_.dynamic(e)) {
          //for (i = 0, z = e->dl; i < z; i++) {
          for (i = 0; i < e->dl; i++) {
        	cppcc::scr::tag::Long t = bin_.dynamic(e, i).t;
 if (isDebugBug) {
   std::cout 
     << "metarfir:start:" 
     << " rule=" << nnrule
     << " i:" << i
     << " s:" << e->dl
     << " t:" << t
     << " d:" << bin_.dynamic(e, i).d
     << " e:" << (*e)
     << std::endl;
 }
 
 if (isDebugBug3) {
    std::cout 
    << "metarfir:loop:" 
    << " rule=" << nnrule
    << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
    << " i:" << i
    << " s:" << e->dl
    << " t:" << t
    << " d:" << bin_.dynamic(e, i).d
    << std::endl;
    //dumpSymbols(output, nnrule, symbols);
 }

        	if (KW_ACTION == t) {
        	}
        	else if (KW_ITERATION == t) {
        	  // if(s= metarfiter(r,k,nnrule,u.d[i].d,nta,len)) return(s);
 if (isDebugBug2) {
	 std::cout 
     << "metarfir :metarfiter: +++++++++++++++++++++++++++++++++++++++++++++++" 
     << " rule" << nnrule
     << " e:" << (*e)
     << " i:" << i
     << " t:" << t
      << " d:" << bin_.dynamic(e, i).d
      << " metarfiter:" << symbols.size()
     << std::endl;
} 
        	  metarfiter(output, nnrule, bin_.dynamic(e, i).d, symbols);
if (isDebugBug2) {
   std::cout 
   << "metarfir .metarfiter. ::::::::::::::::::::::::::::::::::::::::::::::" 
  << " rule" << nnrule
   << " e:" << (*e)
   << " i:" << i
  << " t:" << t
  << " d:" << bin_.dynamic(e, i).d
  << " metarfiter:" << symbols.size()
<< std::endl;
}

if (isDebugBug3 && symbols.size()) {
   std::cout 
   << "metarfiter" 
   << " rule" << nnrule
   << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
   << " i:" << i
   << " t:" << t
   << " d:" << bin_.dynamic(e, i).d
   << std::endl;
   dumpSymbols(output, nnrule, symbols);
}        	  

        	  
if (isDebugBug) {
        	    std::cout 
        	      << "metarfir:" 
        	      << " rule" << nnrule
        	      << " e:" << (*e)
        	      << " i:" << i
        	      << " t:" << t
        	      << " d:" << bin_.dynamic(e, i).d
        	      << " metarfiter:" << symbols.size()
        	      << std::endl;
 }

        	}
        	else if (KW_IDENTMISS == t) {
        	  // if(s= metarfmiss(r,k,nnrule,u.d[i].d,nta,len)) return(s);
if (isDebugBug2) {
 	std::cout 
 	<< "metarfir:metarfmiss: +++++++++++++++++++++++" 
   	<< " rule" << nnrule
   	<< " e:" << (*e)
   	<< " i:" << i
    	 << " t:" << t
    	<< " d:" << bin_.dynamic(e, i).d
     	<< " metarfmiss:" << symbols.size()
  	<< std::endl;
}

        	  metarfmiss(output, nnrule, bin_.dynamic(e, i).d, symbols);

if (isDebugBug3 && symbols.size()) {
        	     std::cout 
        	     << "metarfmiss" 
        	     << " rule" << nnrule
        	     << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
        	     << " i:" << i
        	     << " t:" << t
        	     << " d:" << bin_.dynamic(e, i).d
        	     << std::endl;
        	     dumpSymbols(output, nnrule, symbols);
}        	  


if (isDebugBug2) {
   std::cout 
    << "metarfir.metarfmiss. :::::::::::::::::::::::::::::" 
    << " rule" << nnrule
    << " e:" << (*e)
     << " i:" << i
     << " t:" << t
    << " d:" << bin_.dynamic(e, i).d
    << " metarfmiss:" << symbols.size()
    << std::endl;
}

        	  
if (isDebugBug) {
        	 std::cout 
        	   << "metarfir:" 
        	    << " rule" << nnrule
        	<< " e:" << (*e)
        	 << " i:" << i
        	 << " t:" << t
        	  << " d:" << bin_.dynamic(e, i).d
        	<< " metarfmiss:" << symbols.size()
        	<< std::endl;
}

        	}
        	else if (KW_ALTERNATIVE == t) {
              // if(s= metarfaltr(r,k,nnrule,u.d[i].d,nta,len)) return(s);
        	  // return(0);
  if (isDebugBug2) {
        		        std::cout 
	<< "metarfir:metarfaltr: +++++++++++++++++++++++++++++++++" 
        		       << " rule" << nnrule
        		        << " e:" << (*e)
        		        << " i:" << i
        		        << " t:" << t
        		       << " d:" << bin_.dynamic(e, i).d
        		    << " metarfaltr:" << symbols.size()
        		    << std::endl;
 }
        	  metarfaltr(output, nnrule, bin_.dynamic(e, i).d, symbols);
if (isDebugBug2) {
        std::cout 
        << "metarfir.metarfaltr. ::::::::::::::::::::::::::::::" 
       << " rule" << nnrule
        << " e:" << (*e)
        << " i:" << i
        << " t:" << t
       << " d:" << bin_.dynamic(e, i).d
    << " metarfaltr:" << symbols.size()
    << std::endl;
}

if (isDebugBug) {
        std::cout 
        << "metarfir:" 
       << " rule" << nnrule
        << " e:" << (*e)
        << " i:" << i
        << " t:" << t
       << " d:" << bin_.dynamic(e, i).d
    << " metarfaltr:" << symbols.size()
    << std::endl;
}


if (isDebugBug3 && symbols.size()) {
        	     std::cout 
        	     << "metarfaltr" 
        	     << " rule" << nnrule
        	     << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
        	     << " i:" << i
        	     << " t:" << t
        	     << " d:" << bin_.dynamic(e, i).d
        	     << std::endl;
        	     dumpSymbols(output, nnrule, symbols);
}        	  

				// BUG: should be returned !!!!!!!!!
				return;
        	}
        	else if (KW_IDENTALT == t) {
        	  //if(s= metarfaltern(r,k,nnrule,u.d[i].d,nta,len)) return(s);
			  //return(0);
if (isDebugBug2) {
        		        std::cout 
<< "metarfir:metarfaltern:+++++++++++++++++++++++++++++++" 
        		        << " rule" << nnrule
        		       << " e:" << (*e)
        		      << " i:" << i
        		   << " t:" << t
        		     << " d:" << bin_.dynamic(e, i).d
        		     << " metarfaltern:" << symbols.size()
        		   << std::endl;
}
        	  metarfaltern(output, nnrule, bin_.dynamic(e, i).d, symbols);
if (isDebugBug2) {
        std::cout 
        << "metarfir.metarfaltern.::::::::::::::::::::::::::" 
        << " rule" << nnrule
       << " e:" << (*e)
      << " i:" << i
   << " t:" << t
     << " d:" << bin_.dynamic(e, i).d
     << " metarfaltern:" << symbols.size()
   << std::endl;
   dumpSymbols(output, nnrule, symbols);
}

if (isDebugBug) {
        std::cout 
        << "metarfir:" 
        << " rule" << nnrule
       << " e:" << (*e)
      << " i:" << i
   << " t:" << t
     << " d:" << bin_.dynamic(e, i).d
     << " metarfaltern:" << symbols.size()
   << std::endl;
}       

if (isDebugBug3 && symbols.size()) {
        	     std::cout 
        	     << "metarfaltern" 
        	     << " rule" << nnrule
        	     << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
        	     << " i:" << i
        	     << " t:" << t
        	     << " d:" << bin_.dynamic(e, i).d
        	     << std::endl;
        	     dumpSymbols(output, nnrule, symbols);
}
				// BUG: should be returned !!!!!!!!!
				return;

        	}
          }
          
          //if(s= metarfoll(r,k,nnrule,nta,len)) return(s);
          //555// 
if (isDebugBug2) {
                            std::cout 
<< "metarfir:metarfoll:++++++++++++++++++++++++++++++++++++" 
                            << " rule" << nnrule
                           << " e:" << (*e)
                    
                         << " metarfoll:" << symbols.size()
                       << std::endl;
}

          metarfoll(output, nnrule, symbols);
if (isDebugBug2) {
                  std::cout 
                  << "metarfir.metarfoll.::::::::::::::::::::::::::" 
                  << " rule" << nnrule
                 << " e:" << (*e)
          
               << " metarfoll:" << symbols.size()
             << std::endl;
}

if (isDebugBug) {
                  std::cout 
                  << "metarfoll:" 
                  << " rule" << nnrule
                 << " e:" << (*e)
          
               << " metarfoll:" << symbols.size()
             << std::endl;
}

if (isDebugBug3 && symbols.size()) {
        	     std::cout 
        	     << "metarfoll" 
        	     << " rule" << nnrule
        	     << " nterm=" << "'" << bin_.ptrids(bin_.fixed(eru,1).d) << "'"
        	     << std::endl;
        	     dumpSymbols(output, nnrule, symbols);
}


        }
      }      
	//}
  //}
  
  
  if (isDebugBug) {
    std::cout 
      << "metarfir::::::::::::::::::::::::::::::: finish ::::::::::::::::" 
      << " rule:" << nnrule
      << " sz:" << symbols.size()
      << std::endl;
  }
}

//	s= metarfcheck(r,k,j,ffbuf,fflen);
//  it is not needed!
void 
GenerateParserCC::metarfcheck
(std::ofstream& 				output
,std::size_t					nnrule
,metantmType::SymbolsContainer&	symbols)
{
	
}


//int	metagenfirfol(r,k,g)
//inrType 	r;
//struct 		kwnirType 	*k[];
//struct		metagrmType	*g;	
void 
GenerateParserCC::generateFirstFollow(std::ofstream& 		output) 
{
  cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
    help_.k(KW_RULE);
  if (!k)  return;

  grammar_.rulval.resize(k.edps_.size());
  cppcc::scr::tag::Long maxnterm = 0;
  for (std::size_t j = 0, z = grammar_.rulval.size(); j < z; j++) {
    cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(j);
	        	
	cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
	if (cppcc::com::PLS_IDENTIFIER != kn.t) {
	  tok_.errorMessage(errorNoIdentifierFound);
	  CPPCC_THROW_EXCEPTION(
	    << errorNoIdentifierFound
	    << " rule:" << j << " k:" << kn.t << " n:" << kn.d
	  )
	}
	
	grammar_.rulval[j].nterm = kn.d;
	if (kn.d > maxnterm) maxnterm = kn.d;
	
	metantmType::SymbolsContainer	tmpFirst;
    //output << "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ metarfir :::::::::::" << std::endl;
	metarfir(output, j, tmpFirst);
	//dumpSymbols(output, j, tmpFirst);
	//output << "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ metarfir ..........." << std::endl;
	metarfcheck(output, j, tmpFirst);
	
	//grammar_.rulval[j].first.assign(tmpFirst.begin(), tmpFirst.end());
	grammar_.rulval[j].first = tmpFirst;
	
	// was follow generated??
  }
  
  maxnterm++;
  grammar_.ntmrul.resize(maxnterm);
  for (std::size_t i = 0, z = grammar_.ntmrul.size(); i < z; i++) {
	  grammar_.ntmrul[i] = -1;
  }
 
  for (std::size_t j = 0, z = grammar_.rulval.size(); j < z; j++) {
	  grammar_.ntmrul[grammar_.rulval[j].nterm] = j;
  }
  
  bool isDumpFF = false;
  if (isDumpFF) {
	  dumpFirstFollow(output);
  }
  
}

void 
GenerateParserCC::
dumpFirstFollow(std::ofstream& 		output) 
{
	for (std::size_t j = 0, z = grammar_.rulval.size(); j < z; j++) {
	  metantmType&	r = grammar_.rulval[j];
	  output 
	  << "rule:" << j
	  << " nterm:" << r.nterm 
	  << " " << "'" << bin_.ptrids(r.nterm) << "'"
	  << " firstSize:" << r.first.size()
	  << " followSize:" << r.follow.size()
	  << std::endl;
	  
  	  metantmType::SymbolsContainer::const_iterator cIter =
  	    r.first.begin();
  	  metantmType::SymbolsContainer::const_iterator cEnd =
  	    r.first.end();
  	
  	  for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
  		cppcc::scr::tag::Long 	ndd2 = (*cIter);
  	    output 
  	      << "rule:" << j
  	      << " nterm:" << r.nterm 
  	      << " " << "'" << bin_.ptrids(r.nterm) << "'"
  	      << " firstSize:" << r.first.size()
  	      << " first:" << i 
  	      << " " << ndd2
  	      << " " << bin_.ptrids(ndd2)
  	      << std::endl;
  	  } // i
    
  	  cIter = r.follow.begin();
  	  cEnd  = r.follow.end();
  	  for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
  		cppcc::scr::tag::Long 	ndd2 = (*cIter);
  	    output 
  	      << "rule:" << j
  	      << " nterm:" << r.nterm 
  	      << " " << "'" << bin_.ptrids(r.nterm) << "'"
  	      << " firstSize:" << r.first.size()
  	      << " follow:" << i 
  	      << " " << ndd2
  	      << " " << bin_.ptrids(ndd2)
  	      << std::endl;
  	  } // i
  	  
  	  output << std::endl;
	} // j
	
	for (std::size_t i = 0, z = grammar_.ntmrul.size(); i < z; i++) {
	  cppcc::scr::tag::Long k = grammar_.ntmrul[i];
	  std::string 	n = 
		(-1 == k)
		   ? ""
		   : bin_.ptrids(grammar_.rulval[k].nterm)
	  ;
	  
	  cppcc::scr::tag::Long nt = 
			  (-1 == k)
			  ? (-1)
			  : grammar_.rulval[k].nterm
	  ;
	  output 
	  << "i:" << k
	  << " r:" << grammar_.ntmrul[i]
	  << " n:" << nt
	  << " "  << "'" << n << "'"
	  << std::endl;
	}
}
	
void 
GenerateParserCC::metaactglob
(std::ofstream& 	output
,std::size_t 		nnrule) 
{
  cppcc::scb::SyntaxControlledBinary::edpirType* eru =
    bin_.ptredp(help_.k(KW_RULE).k_,nnrule);
  if (eru) {
    if (bin_.fixed(eru)) {
      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eru,1).t) {
        tok_.errorMessage(errorNoIdentifierFound);
        output 
        << errorNoIdentifierFound 
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,1).t
          << " n:" << bin_.fixed(eru,1).d
        << std::endl;
        
        CPPCC_THROW_EXCEPTION(
          << errorNoIdentifierFound
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,1).t
          << " n:" << bin_.fixed(eru,1).d
        )

      }

      if (KW_RIGHT != bin_.fixed(eru,3).t) {
        tok_.errorMessage(errorNoRightEntryFound);
        output 
        << errorNoRightEntryFound 
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,3).t
          << " n:" << bin_.fixed(eru,3).d
        << std::endl;
        
        CPPCC_THROW_EXCEPTION(
          << errorNoRightEntryFound
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,3).t
          << " n:" << bin_.fixed(eru,3).d
        )

      }

      cppcc::scb::SyntaxControlledBinary::edpirType* e =
        //BUG:// bin_.ptredp(help_.k(KW_RULE).k_
        bin_.ptredp(help_.k(KW_RIGHT).k_
          ,bin_.fixed(eru,3).d);
      if (e) {
        if (bin_.dynamic(e)) {
          for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
            cppcc::scr::tag::Long t = bin_.dynamic(e, i).t;
            if (KW_ACTION == t) {
        	  //if(s= metaaction(r,k,nnrule,u.d[i].d,2)) return(s);
        	  metaaction(output, nnrule, bin_.dynamic(e, i).d, 2);
            }
          }
        }      
      }
    }
  }
}
	
void 
GenerateParserCC::metaactnewf
(std::ofstream& 	output
,std::size_t 		nnrule) 
{
  cppcc::scb::SyntaxControlledBinary::edpirType* eru =
    bin_.ptredp(help_.k(KW_RULE).k_,nnrule);
  if (eru) {
    if (bin_.fixed(eru)) {
      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eru,1).t) {
        tok_.errorMessage(errorNoIdentifierFound);
        output 
        << errorNoIdentifierFound 
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,1).t
          << " n:" << bin_.fixed(eru,1).d
        << std::endl;
        
        CPPCC_THROW_EXCEPTION(
          << errorNoIdentifierFound
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,1).t
          << " n:" << bin_.fixed(eru,1).d
        )

      }

      if (KW_RIGHT != bin_.fixed(eru,3).t) {
        tok_.errorMessage(errorNoRightEntryFound);
        output 
        << errorNoRightEntryFound 
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,3).t
          << " n:" << bin_.fixed(eru,3).d
        << std::endl;
        
        CPPCC_THROW_EXCEPTION(
          << errorNoRightEntryFound
          << " rule:" << nnrule
          << " k:" << bin_.fixed(eru,3).t
          << " n:" << bin_.fixed(eru,3).d
        )

      }

      cppcc::scb::SyntaxControlledBinary::edpirType* e =
        bin_.ptredp(help_.k(KW_RULE).k_
          ,bin_.fixed(eru,3).d);
      if (e) {
        if (bin_.dynamic(e)) {
        	
          int yy = 1;
          for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
            cppcc::scr::tag::Long t = bin_.dynamic(e, i).t;
            if (KW_ACTION == t) {
              cppcc::scb::SyntaxControlledBinary::edpirType* ea =
                bin_.ptredp(help_.k(KW_ACTION).k_
                  ,bin_.dynamic(e, i).d);
              if (ea && bin_.fixed(ea)) {
            	if (cppcc::com::PLS_INTEGER_TOKEN != bin_.fixed(ea,0).t) {
      	          ruleError(output, nnrule, errorHereMustBeIntegerToken);
      	          CPPCC_THROW_EXCEPTION(
      	            << " rule:" << nnrule << " "
      	            << errorHereMustBeIntegerToken
      	          )		  	    	             		
            	}
            	
            	cppcc::scr::tag::Long v = -1;
            	//if(s= metagetint(r,k,nnrule,ua.f[0].d,&v)) return(s);
            	metagetint(output, nnrule, bin_.fixed(ea, 0).d, &v);
            	if (v == 4) {
            	  yy = 0;
            	  break;
            	}
              }
            }
          }
          
          if (yy) return;
          // ------------------ file splitting mode::::::
          
          // ------------------ file splitting mode.......
        }      
      }
    }
  }
}


void  
GenerateParserCC::metaangl
(std::ofstream& 		output
,cppcc::scr::tag::Long  nnrule
,cppcc::scr::tag::Long  rig)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* etr =
   bin_.ptredp(help_.k(KW_RIGHT).k_,rig);
  if (etr) {
    if (bin_.dynamic(etr)) {
      for (cppcc::scr::tag::Long i = 0, z = etr->dl; i < z; i++) {
        cppcc::scr::tag::Long t = bin_.dynamic(etr,i).t;
        if (KW_ITERATION == t) {
          cppcc::scb::SyntaxControlledBinary::edpirType* eiter =
            bin_.ptredp(help_.k(KW_ITERATION).k_
              ,bin_.dynamic(etr,i).d);
          if (eiter) {
            if (bin_.fixed(eiter)) {
              if (KW_ITERITEMACT != bin_.fixed(eiter, 1).t) {
                ruleError(output, nnrule, errorHereMustBeIterItemact);
    	        CPPCC_THROW_EXCEPTION(
    	            << " rule:" << nnrule << " "
    	            << errorHereMustBeIterItemact
    	        )		  	    	             		
              }
              
              cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                  ,bin_.fixed(eiter,1).d);
              if (eact) {
                if (bin_.fixed(eact)) {
                  cppcc::scr::tag::Long tt = bin_.fixed(eact,0).t;
                  
                  if (KW_MAYBENTERM == tt) {
                    cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
                      bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                        ,bin_.fixed(eact,0).d);
                    if (eitit) {
                      if (bin_.fixed(eitit)) {
                        if (cppcc::com::PLS_IDENTIFIER != 
                          bin_.fixed(eitit,1).t) {
                          ruleError(output, nnrule,errorHereMustBeIdentifier);
              	          CPPCC_THROW_EXCEPTION(
              	            << " rule:" << nnrule << " "
              	            << errorHereMustBeIdentifier
              	          )		  	    	             		
                        }
                        
                        //fprintf(ff,"  char Y%s=0;\n",ptrids(r,un.f[1].d));            
                        output 
                        << "  char Y" << bin_.ptrids(bin_.fixed(eitit,1).d) << "=0;"
                        << std::endl;
                      }
                    }
                  }
          
                  
                  if ((bin_.fixed(eiter,2).t != 0) || (bin_.fixed(eiter,2).d != 0)) { 
                  if (KW_ITERITEMS != bin_.fixed(eiter,2).t) {
                    ruleError(output, nnrule, errorHereMustBeIterItems);
        	        CPPCC_THROW_EXCEPTION(
        	            << " rule:" << nnrule << " "
        	            << errorHereMustBeIterItems
        	        )		  	    	             		
                  }
                  
                  cppcc::scb::SyntaxControlledBinary::edpirType* eitit =
                    //error/ bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                    bin_.ptredp(help_.k(KW_ITERITEMS).k_
                      ,bin_.fixed(eiter,2).d);
                  if (eitit) {
                    if (bin_.dynamic(eitit)) {
                      for (cppcc::scr::tag::Long ii = 0, zz = eitit->dl; ii < zz; ii++) {
                        //cppcc::scr::tag::Long t = bin_.dynamic(eitit,ii).t;
                        // BUG:
                        // if (KW_ALTITERITEM == 
                        if (KW_ALTITERITEM != 
                          bin_.dynamic(eitit,ii).t) {
                          ruleError(output, nnrule,errorHereMustBeAltIterItem);
              	          CPPCC_THROW_EXCEPTION(
              	            << " rule:" << nnrule << " "
              	            << errorHereMustBeAltIterItem
              	          )		  	    	             		
                        }
                        
                        cppcc::scb::SyntaxControlledBinary::edpirType* eAltIterItem =
                          bin_.ptredp(help_.k(KW_ALTITERITEM).k_
                            ,bin_.dynamic(eitit,ii).d);

                        if (bin_.fixed(eAltIterItem,1).t != KW_ITERITEMACT ) {
                          ruleError(output, nnrule,errorHereMustBeIterItemact);
              	          CPPCC_THROW_EXCEPTION(
              	            << " rule:" << nnrule << " "
              	            << errorHereMustBeIterItemact
              	          )		
                        }

                        cppcc::scb::SyntaxControlledBinary::edpirType* ea =
                          bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                            ,bin_.fixed(eAltIterItem,1).d);
                        if (ea) {
                          if (bin_.fixed(ea)) {

                                cppcc::scr::tag::Long t0 = bin_.fixed(ea,0).t;
                                
                                if (KW_MAYBENTERM == t0) {
                                  cppcc::scb::SyntaxControlledBinary::edpirType* eaa =
                                    bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                                      // BUG:
                                      // ,bin_.fixed(eact,0).d);
                                      ,bin_.fixed(ea,0).d);
                                  if (eaa) {
                                    if (bin_.fixed(eaa)) {
                                      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eaa, 1).t) {
                                        ruleError(output, nnrule, errorHereMustBeIdentifier);
                            	        CPPCC_THROW_EXCEPTION(
                            	            << " rule:" << nnrule << " "
                            	            << errorHereMustBeIdentifier
                            	        )                                 
                                      }
                                      
                                      //fprintf(ff,"  char Y%s=0;\n",
                                      //ptrids(r,unalti.f[1].d));      
                                      output 
                                      << "  char Y" << bin_.ptrids(bin_.fixed(eaa,1).d) << "=0;"
                                      << std::endl;
                                      
                                    }

                
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                }
              }             
            }
          }       
        } 

      }
    }
  } 
  
}

int  
GenerateParserCC::metadynp
		(std::ofstream& 		output
		,cppcc::scr::tag::Long  dNTerm
        ,cppcc::scr::tag::Long  dRight)
{
		//bool isDebug = true;
		bool isDebug = false;
		
		if (isDebug) {
			output 
			<< "  metadynp:" 
			<< " nterm:" << dNTerm
			<< " right:" << dRight
			<< std::endl; 
		}
		
	    cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
	         help_.k(KW_RIGHT);
	    //if (k.k_) {
	    //
	    if (k) {
	    	
			if (isDebug) {
				output 
				<< "  metadynp:" 
				<< " nterm:" << dNTerm
				<< " right:" << dRight
				<< (*k.k_)
				<< std::endl; 
			}
	
	    	
	      cppcc::scb::SyntaxControlledBinary::Helper::edp& e = k.e(dRight);
	    	
			if (isDebug && e) {
				output 
				<< "  metadynp:" 
				<< " nterm:" << dNTerm
				<< " right:" << dRight
				<< " iteration:" << KW_ITERATION
				//<< (*e.e_)
				<< e.e()
				<< std::endl; 
				
				bin_.edpDump(output,e.e());
		    }
	      
	      if (e.dynamic()) {
	        for (std::size_t i = 0, z = e.e().dl; i < z; i++) {
	          if (e.dynamic(i).t == KW_ITERATION) return(1);
	        }
	      }
	    }
	    
	    return(0);
}



int  
GenerateParserCC::metafixe
  (std::ofstream& 		   output
  ,cppcc::scr::tag::Long   dNTerm
  ,cppcc::scr::tag::Long   dRight)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_RIGHT).k_,dRight);
  if (e) {
    if (bin_.dynamic(e)) {
      if(((e->dl) == 1) || ((e->dl) == 0)) {
	    if((e->dl) == 1) {
	      if(bin_.dynamic(e,0).t == KW_ALTERNATIVE) {
	    	e = bin_.ptredp(help_.k
	    	  (KW_ALTERNATIVE).k_,bin_.dynamic(e,0).d);
	    	if (e) {
	    	  if (bin_.fixed(e)) {	
	    	    if(bin_.fixed(e,1).t == KW_IDENTALT) {
	      	      ruleError(output, dNTerm, errorHereMustBeIdentAlt);
	      	      return 0;	    	    	
	    	    }
	    	    
	    	    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
	    	      bin_.ptredp(help_.k(KW_IDENTALT).k_
	    	    	,bin_.fixed(e,1).d);
	    	    if (eidentalt) {
	    	      if (bin_.fixed(eidentalt,0).t != KW_NTERMTERMACT) {
		      	      ruleError(output, dNTerm, errorHereMustBeIterItemact);
		      	      return 0;	    	    		    	    	  
	    	      }
	    	      
		    	  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
		    	    bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
		    	     ,bin_.fixed(eidentalt,0).d);
	    	      if (eact) {
				    if (bin_.fixed(eact)) {
				      if (bin_.fixed(eact,0).t != 
				    	cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
				    	  return 0;			      
				    }
				    
				    cppcc::scb::SyntaxControlledBinary::edpirType* ea = 0;
				    for (cppcc::scr::tag::Long j = 0, z = eidentalt->dl;
				      j < z; j++
				    ) {
				      if (bin_.dynamic(eidentalt, j).t != 
				        KW_ALTPART) {
			      	      ruleError(output, dNTerm, errorHereMustAlternative);
			      	      return 0;	    	    		    	    	  				    	  
				      }
				      
			    	  //cppcc::scb::SyntaxControlledBinary::edpirType* ea =
			    	  ea =
			    	    bin_.ptredp(help_.k(KW_ALTPART).k_
			    	     ,bin_.dynamic(eidentalt,j).d);
		    	      if (bin_.fixed(ea)) {
					    if (bin_.fixed(ea, 1).t != 
					      KW_NTERMTERMACT) {
				      	  ruleError(output, dNTerm, errorHereMustINtermTermAct);
				      	  return 0;	    	    		    	    	  				    	  
					    }
					    
					    eact = 
					      bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
					        ,bin_.fixed(ea,1).d);
				        if (eact) {
						  if (bin_.fixed(eact)) {
						    if (bin_.fixed(eact,0).t != 
							  cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
							return(0);
						  }
				        }
		    	      }			      
				    } // j
				    
				    //cppcc::scb::SyntaxControlledBinary::edpirType* 
				    eact =
			    	  bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
			    	    ,bin_.fixed(eidentalt,0).d);
		    	    if (eact) {
					  if (bin_.fixed(eact)) {
					    if (bin_.fixed(eact,0).t != 
					      cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
					    return(0);			      
					  }
		    	    }
				    
				    for (cppcc::scr::tag::Long j = 0, z = eidentalt->dl;
				      j < z; j++
				    ) {
				      if (bin_.dynamic(eidentalt, j).t != 
				        KW_ALTPART) {
			      	      ruleError(output, dNTerm, errorHereMustAlternative);
			      	      return 0;	    	    		    	    	  				    	  
				      }
				      
			    	  //cppcc::scb::SyntaxControlledBinary::edpirType* ea =
				      ea =
			    	    bin_.ptredp(help_.k(KW_ALTPART).k_
			    	     ,bin_.dynamic(eidentalt,j).d);
		    	      if (bin_.fixed(ea)) {
					    if (bin_.fixed(ea, 1).t != 
					      KW_NTERMTERMACT) {
				      	  ruleError(output, dNTerm, errorHereMustINtermTermAct);
				      	  return 0;	    	    		    	    	  				    	  
					    }
					    
					    eact = 
					      bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
					        ,bin_.fixed(ea,1).d);
				        if (eact) {
						  if (bin_.fixed(eact)) {
						    if (bin_.fixed(eact,0).t != 
							  cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
							return(0);
						  }
				        }
		    	      }			      
				    } // j

				    eact =
			    	  bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
			    	    ,bin_.fixed(eidentalt,0).d);
		    	    if (eact) {
					  if (bin_.fixed(eact)) {
					    if (bin_.fixed(eact,0).t != 
					      cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
					    return(0);			      
					  }
		    	    }
				    for (cppcc::scr::tag::Long j = 0, z = eidentalt->dl;
				      j < z; j++
				    ) {
				      if (bin_.dynamic(eidentalt, j).t != 
				        KW_ALTPART) {
			      	      ruleError(output, dNTerm, errorHereMustAlternative);
			      	      return 0;	    	    		    	    	  				    	  
				      }
				      
			    	  //cppcc::scb::SyntaxControlledBinary::edpirType* ea =
				      ea =
			    	    bin_.ptredp(help_.k(KW_ALTPART).k_
			    	     ,bin_.dynamic(eidentalt,j).d);
		    	      if (bin_.fixed(ea)) {
					    if (bin_.fixed(ea, 1).t != 
					      KW_NTERMTERMACT) {
				      	  ruleError(output, dNTerm, errorHereMustINtermTermAct);
				      	  return 0;	    	    		    	    	  				    	  
					    }
					    
					    eact = 
					      bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
					        ,bin_.fixed(ea,1).d);
				        if (eact) {
						  if (bin_.fixed(eact)) {
						    if (bin_.fixed(eact,0).t != 
							  cppcc::com::PLS_TERMTOKENOFRULE_TOKEN) 
							return(0);
						  }
				        }
		    	      }			      
				    } // j
	    	      
	    	    	  
	    	      }
	    	      
	    	    }
	    	    
	    	  }
	    	}
	    	  
	        return 1;
	      }
	    }
	    
	    return 0;
      }
      
      // final action:
      register int nact = 0, y = 0, i = 0, z = e->dl;
      for (;i < z; i++) {
    	if (bin_.dynamic(e,i).t == KW_ITERATION) {
    	  y = 1;
    	  break;
    	} else if (bin_.dynamic(e,i).t == KW_ACTION) {
    	  nact++;
    	}
      } //i
      
      if(!y) i= (e->dl);

      return(i - nact);     
    }
  }
  
  return 0;
}

////////////////////////////////////////////////////////////////////////
// generate program code for simple (one) element of right part of rule 
////////////////////////////////////////////////////////////////////////
void
GenerateParserCC::metaalid_ccc
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	nalid)
{
  //std::vector<cppcc::scr::tag::Long>	elements;
}

void
GenerateParserCC::metaalid
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	nalid)
{
	
  //output << "metaalid:----------------------------" 
  //		  << " r:" << nnrule 
  //		  << " n:" << nalid
  //		  << std::endl;	
	
  cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
    bin_.ptredp(help_.k(KW_IDENTALT).k_
	  ,nalid);
  if (eidentalt) {
	if (eidentalt->dl > 0) {
	  // simple alternative 
	  //metantmType&  	ntm = grammar_.rulval[nnrule];
	  
	  if (bin_.fixed(eidentalt)) {
	    if (KW_NTERMTERMACT != bin_.fixed(eidentalt, 0).t) {
	      //ruleError(output, nnrule, errorHereMustBeIterItemact);
	      ruleError(output, nnrule, errorHereMustINtermTermAct);
	      CPPCC_THROW_EXCEPTION(
	        << " rule:" << nnrule << " "
	        << errorHereMustINtermTermAct
	      )                                 
	    }
	    
	    cppcc::scb::SyntaxControlledBinary::edpirType* eact =
	      bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
	        ,bin_.fixed(eidentalt, 0).d);
	    if (eact) {
	      if (bin_.fixed(eact)) {
	        if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {
	  	      ruleError(output, nnrule, errorHereMustBeIdentifier);
	  	      CPPCC_THROW_EXCEPTION(
	  	        << " rule:" << nnrule << " "
	  	        << errorHereMustBeIdentifier
	  	      )                                 	        	
	        }
	        
	        cppcc::scr::tag::Long 	ndd 		= bin_.fixed(eact, 0).d;
	        //std::string 			keyword1 	= keyword(ndd);
	        //std::string 			keywordInt 	= keyword(cppcc::com::PLS_INTEGER_TOKEN);
	        //std::string 			keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);
	        
	        cppcc::scr::tag::Long 		rull;
	        //if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
	        metachnt(output, nnrule, ndd, &rull);
	        if (-1 == rull) {
	        	generateKW(output, ndd);
	        	
	        	//output << "  ){" << std::endl;
	        	output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
	        	output << "  }" << std::endl;

	        } 
	        else {
	          metantmType&  	ntmi = grammar_.rulval[rull];
	          
	          if (1 == ntmi.first.size()) {
	        	  cppcc::scr::tag::Long 	ndd2 = *ntmi.first.begin();
	        	  
	        	  generateKW(output, ndd2);
		        	//output << "  ){" << std::endl;
	        	  
		        	// bug:: //output << "    " << bin_.ptrids(ndd2) << "(tag);" << std::endl;
		        	output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;

		        	output << "  }" << std::endl;
	          } 
	          else {
	            // fprintf(ff,"    if(");
	        	//qq// output << "    if(" << std::endl;	
	        	output << "  if(";

	        	// loop processing first set.
	        	metantmType::SymbolsContainer::const_iterator cIter =
	        	  ntmi.first.begin();
	        	metantmType::SymbolsContainer::const_iterator cEnd =
	        	  ntmi.first.end();
	        	
	        	for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
	        		cppcc::scr::tag::Long 	ndd2 = (*cIter);
	        		if (i) {
	        		  //fprintf(ff,"   || "); 
	        		  output << "   || ";	
	        		}
	        		
	        		generateKWLoop(output, ndd2);
	        	} // first
	        	
	        	if (ntmi.first.size() != 1) {
	        	  output << "  ";
	        	}
	        	
	    		//fprintf(ff,"){\n");
	    		//fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
	    		//fprintf(ff,"  }\n");
	        	output << "){" << std::endl;
	        	output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
	        	output << "  }" << std::endl;
	          } // 1 != ntm.first.size()
	          
	          
	        } // -1 != rull
	        
	        
	      }
	    }     
	  }
	  
	  if (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt)) {
	    for (cppcc::scr::tag::Long j = 0; j < eidentalt->dl; j++) {
	      if (KW_ALTPART !=  bin_.dynamic(eidentalt, j).t) {
	          ruleError(output, nnrule, errorHereMustBeAltpart);
	  	      CPPCC_THROW_EXCEPTION(
	  	        << " rule:" << nnrule << " "
	  	        << errorHereMustBeAltpart
	  	      )                                 	        	
	      }
	    
	      cppcc::scb::SyntaxControlledBinary::edpirType* ee =
	        bin_.ptredp(help_.k(KW_ALTPART).k_
	          ,bin_.dynamic(eidentalt, j).d);
	      if (ee) {
	        if (bin_.fixed(ee)) {
	           if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
	                //ruleError(output, nnrule, errorHereMustBeIterItemact);
	              ruleError(output, nnrule, errorHereMustINtermTermAct);  
		  	      CPPCC_THROW_EXCEPTION(
		  	        << " rule:" << nnrule << " "
		  	        << errorHereMustINtermTermAct
		  	      )                                 	        	          
	           }
	              
	           cppcc::scb::SyntaxControlledBinary::edpirType* eact =
	             bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
	               ,bin_.fixed(ee, 1).d);
	           if (eact) {
	             if (bin_.fixed(eact)) {
	            	// BUG:// if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 1).t) {
	                if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {        	
	      	          ruleError(output, nnrule, errorHereMustBeIdentifier);
	      	  	      CPPCC_THROW_EXCEPTION(
	      	  	        << " rule:" << nnrule << " "
	      	  	        << errorHereMustBeIdentifier
	      	  	      )                                 	        	
	                }
	                
	                cppcc::scr::tag::Long 	ndd = bin_.fixed(eact, 0).d;
	                //std::string  keyword1  = keyword(ndd);
	                //std::string  keywordInt  = keyword(cppcc::com::PLS_INTEGER_TOKEN);
	                //std::string  keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);
	                
	                cppcc::scr::tag::Long     rull;
	                //if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
	                metachnt(output, nnrule, ndd, &rull);
	                if (-1 == rull) {
	                	/*
	                  //if (IITT != keyword) {
	                  if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
	                    output 
	                    << "    if(kword() == KW_" << keyword1 << ") {"
	                    << std::endl;   
	                  } else {
	                  output 
	                  << "    if((kword() == " << keywordInt
	                  << ") || (kword() == " << keywordFloat
	                  << ")) {"
	                  << std::endl;                 
	                  }
	                  */
	                  //qq// output << "    else if(" << std::endl;
	                  output << "  else if(";
	                  //ss// generateKW(output, ndd);
	                  generateKWLoop(output, ndd);
	                  output << "  ){" << std::endl;
	                  output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
	                  output << "  }" << std::endl;

	                } 
	                else {
	                  metantmType&    ntmi = grammar_.rulval[rull];
	                  
	                  if (1 == ntmi.first.size()) {
	                    cppcc::scr::tag::Long   ndd2 = *ntmi.first.begin();
	                    std::string  kwd = keyword(ndd2);
	                    /*
	                    if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
	                      output 
	                      << "    if(kword() == KW_" << keyword1 << ") {"
	                      << std::endl;   
	                    } else {
	                    output 
	                    << "    if((kword() == " << keywordInt
	                    << ") || (kword() == " << keywordFloat
	                    << ")) {"
	                    << std::endl;                 
	                    }     
	                    */
	                    //qq// output << "    else if(" << std::endl;
	                    output << "  else if(" ;
	                    generateKWLoop(output, ndd2);
	                    output << "  ){" << std::endl;
		                  output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
		                  output << "  }" << std::endl;

	                  } 
	                  else {
	                    // fprintf(ff," else if(");
	                  output << "  else if(" << std::endl; 

	                  // loop processing first set.
	                  metantmType::SymbolsContainer::const_iterator cIter =
	                    ntmi.first.begin();
	                  metantmType::SymbolsContainer::const_iterator cEnd =
	                    ntmi.first.end();
	                  
	                  for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
	                    cppcc::scr::tag::Long   ndd2 = (*cIter);
	                    if (i) {
	                      //fprintf(ff,"   || "); 
	                      output << "   || ";  
	                    }

	                    /*
	                    std::string  kwd = keyword(ndd2);
	                    if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
	                        output 
	                        << "    if(kword() == KW_" << keyword1 << ") {"
	                        << std::endl;   
	                    } else {
	                      output 
	                      << "    if((kword() == " << keywordInt
	                      << ") || (kword() == " << keywordFloat
	                      << ")) {"
	                      << std::endl;                 
	                    }    
	                    */
	                    generateKWLoop(output, ndd2);
		                  output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
		                  output << "  }" << std::endl;

	                  } // first
	                  
	                  if (ntmi.first.size() != 1) {
	                    output << "  ";
	                  }
	                  
	                //fprintf(ff,"){\n");
	                //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
	                //fprintf(ff,"  }\n");
	                  output << "){" << std::endl;
	                  output << "    " << bin_.ptrids(ndd) << "(tag);" << std::endl;
	                  output << "  }" << std::endl;
	                  } // 1 != ntm.first.size()
	                  
	                  
	                } // -1 != rull
	                	                
	             }
	           }
	           
	        	
	        }
	      }
	      
	    } // j
	    
	    // else part 
	    //fprintf(ff,"  else {\n");
	    output << "  else {" << std::endl;
	    
	    metantmType&  	ntm = grammar_.rulval[nnrule];
	    
        // loop processing first set.
        metantmType::SymbolsContainer::const_iterator cIter =
          ntm.first.begin();
        metantmType::SymbolsContainer::const_iterator cEnd =
          ntm.first.end();
        
        for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
          cppcc::scr::tag::Long   	ndd2 = (*cIter);
          //BUG:// std::string  				kwd = keyword(ndd2);
          std::string  				kwd = prefixKeyWord(bin_.ptrids(ndd2));
          
          output 
          << "    pdbkwmis(" 
          << kwd
          << ");" << std::endl;
	    }
	    output << "    edber();" << std::endl;
	    output << "  }" << std::endl;
	    
	  } // fixed && dynamic
	  
	} 
	else {
	  // identifier or simple terminal.
	  if (KW_NTERMTERMACT != bin_.fixed(eidentalt, 0).t) {
		ruleError(output, nnrule, errorHereMustINtermTermAct);
	    CPPCC_THROW_EXCEPTION(
	        << " rule:" << nnrule << " "
	        << errorHereMustINtermTermAct
	    )                                 	        	          
	  }

      cppcc::scb::SyntaxControlledBinary::edpirType* eact =
        bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
          ,bin_.fixed(eidentalt,0).d);
      if (eact && bin_.fixed(eact)) {
        switch (bin_.fixed(eact,0).t) {
        case cppcc::com::PLS_IDENTIFIER:
        {
          //if(s= metachnt(r,k,nnrule,uact.f[0].d,NULLINT)) return(s);
          metachnt(output, nnrule, bin_.fixed(eact,0).d, 0);
          //fprintf(ff,"  if(s= %s(l)) return(s);\n",ptrids(r,uact.f[0].d));
          output 
          << "  " << bin_.ptrids(bin_.fixed(eact,0).d)
          << "(tag);"
          << std::endl;
        } 
        break;   
        case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
        {
          std::string tn = bin_.ptrids(bin_.fixed(eact,0).d);
          //kw// output << "  skipKeyWordTerm(" << tokenKeyWord(tn) << ",tag);"
          output << "  skipKeyWordTerm(" << prefixKeyWord(tn) << ",tag);"
          << std::endl;	  
        }
        break;       
        case cppcc::com::PLS_INTEGER_TOKEN:
        {
	      //std::string keywordInt = keyword(cppcc::com::PLS_INTEGER_TOKEN);

          output 
          //<< "  " << keywordInt
          << "  " << predefinedIDs_[cppcc::com::PLS_INTEGER_TOKEN]
          << "(tag);"
          << std::endl;
       	
        }
        break;       
        case cppcc::com::PLS_STRING_TOKEN:
        {
  	      //std::string keywordST = keyword(cppcc::com::PLS_STRING_TOKEN);
  	      
          output 
          //<< "  " << keywordST
          << "  " << predefinedIDs_[cppcc::com::PLS_STRING_TOKEN]
          << "(tag);"
          << std::endl;
        	
        }
        break;       
        case cppcc::com::PLS_TEXT_TOKEN:
        {
        	
        }
        break;       
		default:
		{
			ruleError(output, nnrule, errorUndefinedSimpleTerminal);
		    CPPCC_THROW_EXCEPTION(
		        << " rule:" << nnrule << " "
		        << " tag:" << bin_.fixed(eact,0).t
		        << errorUndefinedSimpleTerminal
		    )                                 	        	          
		  
		}
        }
      }
	}
  }
//sss// return 0;
}


/// errorHereMustBeIdentifier --         (tag);


//
//if(s= metarfaddset(r,k,nnrule,ntm->firval,ntm->firlen,nta,len)) return(s);
//metarfaddset(output, nnrule, ntm, symbols);
//
//
void 
GenerateParserCC::metarfaddset
(std::ofstream&         		output
,std::size_t          			nnrule
,GenerateParserCC::metantmType& ntm
,metantmType::SymbolsContainer& symbols)
{
  GenerateParserCC::metantmType::SymbolsContainer::const_iterator cIter=
	ntm.first.begin();
  GenerateParserCC::metantmType::SymbolsContainer::const_iterator cEnd=
	ntm.first.end();
  for (; cIter != cEnd; ++cIter) {
	metarfaddnxt(output, nnrule, (*cIter), symbols);
  }
}

///if(s= metagrfiden(r,k,nnrule,nnn,nta,len)) return(s);
//metagrfiden(output,nnrule,nnn,symbols);
///int metagrfiden(r,k,nnrule,nnn,nta,len)
void
GenerateParserCC::metagrfiden
(std::ofstream&         		output
,std::size_t          			nnrule
,cppcc::scr::tag::Long      	nnn
,metantmType::SymbolsContainer& symbols)
{
  //if(s= metachnt(r,k,nnrule,nnn,&rull)) return(s);
  cppcc::scr::tag::Long     rull;
  metachnt(output, nnrule, nnn, &rull);  
  
  if(rull == -1) {
    // if(s= metarfaddnxt(r,k,nnrule,nnn,nta,len)) return(s);
	metarfaddnxt(output,nnrule,nnn,symbols);
  }
  else {
    /* recursive call */
	//metantmType* ntm= (Grammer.rulval) + rull;
	metantmType& ntm = grammar_.rulval[rull];
    //if(s= metarfaddset(r,k,nnrule,ntm->firval,ntm->firlen,nta,len)) return(s);
	metarfaddset(output, nnrule, ntm, symbols);
  } 
}


//
// //if(s= metagrfiter(r,k,nnrule,nitr,fnta,&flen)) return(s);
// metagrfiter(output, nnrule, nitr, symbols);
// int metagrfiter(r,k,nnrule,nid,nta,len)
// 
void 
GenerateParserCC::metagrfiter
(std::ofstream&         		output
,std::size_t          			nnrule
,cppcc::scr::tag::Long      	nid
,metantmType::SymbolsContainer& symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType*  ee =
    bin_.ptredp(help_.k(KW_ITERATION).k_,nid);
  if (ee) {
    if (bin_.fixed(ee)) {  
	  if (KW_ITERITEMACT != bin_.fixed(ee,1).t) {  
	    tok_.errorMessage(errorHereMustBeIterItemact);
	    output 
	        << errorHereMustBeIterItemact 
	          << " rule:" << nnrule
	          << " k:" << bin_.fixed(ee,1).t
	          << " n:" << bin_.fixed(ee,1).d
	    << std::endl;
	        
	    CPPCC_THROW_EXCEPTION(
	          << errorHereMustBeIterItemact
	          << " rule:" << nnrule
	          << " k:" << bin_.fixed(ee,1).t
	          << " n:" << bin_.fixed(ee,1).d
	    )     
	  }

	  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
	      bin_.ptredp(help_.k(KW_ITERITEMACT).k_
	        ,bin_.fixed(ee,1).d);
	  if (eact) {
	    if (bin_.fixed(eact)) {  
	        
	      cppcc::scr::tag::Long   nnn = 0;  
	      cppcc::scr::tag::Long   t = bin_.fixed(eact,0).t;
	      if (KW_MAYBENTERM == t) {  
	            cppcc::scb::SyntaxControlledBinary::edpirType* en =
	              bin_.ptredp(help_.k(KW_MAYBENTERM).k_
	                ,bin_.fixed(eact,0).d);
	            if (en) {
	              if (bin_.fixed(en)) {
	                if (cppcc::com::PLS_IDENTIFIER != 
	                  bin_.fixed(en,1).t) {
	                    //ruleError(output, nnrule,errorHereMustBeIdentifier);
	                    //return;
	                  tok_.errorMessage(errorHereMustBeIdentifier);
	                  output 
	                    << errorHereMustBeIdentifier 
	                      << " rule:" << nnrule
	                      << " k:" << bin_.fixed(en,1).t
	                      << " n:" << bin_.fixed(en,1).d
	                  << std::endl;
	                    
	                  CPPCC_THROW_EXCEPTION(
	                      << errorHereMustBeIdentifier
	                      << " rule:" << nnrule
	                      << " k:" << bin_.fixed(en,1).t
	                      << " n:" << bin_.fixed(en,1).d
	                  )     
	                }
	                  nnn = bin_.fixed(en,1).d;
	                  
	                }               
	             }
	          }     
	      else if (cppcc::com::PLS_IDENTIFIER == t) {  
	          nnn = bin_.fixed(eact,0).d;
	      }
	      else {
	              tok_.errorMessage(errorHereMustBeIdentifierOrLess);
	              output 
	                << errorHereMustBeIdentifierOrLess 
	                  << " rule:" << nnrule
	                  << " k:" << bin_.fixed(eact,0).t
	                  << " n:" << bin_.fixed(eact,0).d
	              << std::endl;
	                
	              CPPCC_THROW_EXCEPTION(
	                  << errorHereMustBeIdentifierOrLess
	                  << " rule:" << nnrule
	                  << " k:" << bin_.fixed(eact,0).t
	                  << " n:" << bin_.fixed(eact,0).d
	              )     

	      }  
	      
	      ///if(s= metagrfiden(r,k,nnrule,nnn,nta,len)) return(s);
	      metagrfiden(output,nnrule,nnn,symbols);
	      
	      // iteritems 
          if (KW_ITERITEMS != bin_.fixed(ee,2).t) {
            ruleError(output, nnrule, errorHereMustBeIterItems);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << " tag:" << bin_.fixed(ee,2).t
              << " should be:" << KW_ITERITEMS
              << errorHereMustBeIterItems     
            )                   
          }
          
          cppcc::scb::SyntaxControlledBinary::edpirType* eiter =
            bin_.ptredp(help_.k(KW_ITERITEMS).k_
              ,bin_.fixed(ee,2).d);
          if (eiter && bin_.dynamic(eiter)) {
            for (cppcc::scr::tag::Long j=0, z = eiter->dl; j < z; j++) 
            {
              if (KW_ALTITERITEM != 
                 bin_.dynamic(eiter, j).t) {
                 ruleError(output, nnrule, errorHereMustBeAltIterItem);
                    CPPCC_THROW_EXCEPTION(
                        << " rule:" << nnrule << " "
                        << " j:" << j
                        << " tag:" << bin_.dynamic(eiter, j).t
                        << " should be:" << KW_ALTITERITEM
                        << errorHereMustBeAltIterItem     
                    )                                       
              }
              
              cppcc::scb::SyntaxControlledBinary::edpirType* ealti =
                bin_.ptredp(help_.k(KW_ALTITERITEM).k_
                  ,bin_.dynamic(eiter, j).d);
              if (ealti && bin_.fixed(ealti)) {
                if (KW_ITERITEMACT != bin_.fixed(ealti,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                        << " rule:" << nnrule << " "
                        << errorHereMustBeIterItemact     
                  )
                }
                
                cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                  bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                    ,bin_.fixed(ealti,1).d);
                if (eact && bin_.fixed(eact)) {
                  if (KW_MAYBENTERM == bin_.fixed(eact,0).t) {
                    cppcc::scb::SyntaxControlledBinary::edpirType* enalti =
                      bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                        ,bin_.fixed(eact,0).d);
                    if (enalti && bin_.fixed(enalti)) {
                      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(enalti, 1).t) {
                              ruleError(output, nnrule, errorHereMustBeIdentifier);
                              CPPCC_THROW_EXCEPTION(
                                << " rule:" << nnrule << " "
                                << errorHereMustBeIdentifier    
                              )
                      }
                      
                      nnn = bin_.fixed(enalti, 1).d;
                  	
                    }
                  }
                  else if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact,0).t) {
                	nnn =   bin_.fixed(eact,0).d;
                  }
                  else {
                      ruleError(output, nnrule, errorHereMustBeIdentifierOrLess);
                      CPPCC_THROW_EXCEPTION(
                        << " rule:" << nnrule << " "
                        << errorHereMustBeIdentifierOrLess    
                      )
               	  
                  }
                
      			  //if(s= metagrfiden(r,k,nnrule,nnn,nta,len)) 
      			  // return(s);
                  metagrfiden(output,nnrule,nnn,symbols);

                } // if (eact && bin_.fixed(eact))
              }
            } //j
            
            
          } // if (eiter && bin_.dynamic(eiter))
	    }     
	  }
    }   
  }
}

// metagetint
// if(s= metagetint(r,k,nnrule,uu.f[0].d,&v)) return(s);
// metagetint(output, nnrule, bin_.fixed(ee,0).d, &v);
//int metagetint(r,k,nnrule,n,v)
void 
GenerateParserCC::metagetint
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	n
,cppcc::scr::tag::Long*  	v
)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(cppcc::com::PLS_INTEGER_TOKEN).k_,n); 
  if (e && bin_.fixed(e)) {
	if (v) *v =   *((cppcc::scr::tag::Long*)(bin_.fixed(e)));
  }
}

// metaactionsfind
// check 1 - actions 
//if(s= metaactionsfind(r,k,nnrule,uact.f[1].t,uact.f[1].d,
//	      1,&yy)) 
//  return(s);
//int metaactionsfind(r,k,nnrule,actp,acid,vv,yy)
//metaactionsfind(output, nnrule, bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 1, &yy);
void 
GenerateParserCC::metaactionsfind
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	actp
,cppcc::scr::tag::Long  	acid
,cppcc::scr::tag::Long  	vv
,int*						yy
)
{
  
  
  if(yy) *yy= 0;
	
  if((actp == 0) && (acid == 0)) return;

  if (actp != KW_ACTIONS) {
    ruleError(output, nnrule, errorHereMustActions);
    CPPCC_THROW_EXCEPTION(
      << " rule:" << nnrule << " "
      << " tag:" << actp
      << " should be:" << KW_ACTIONS
      << errorHereMustActions    
    )
  }
  
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_ACTIONS).k_,acid);
  if (e && bin_.dynamic(e)) {
    for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
      switch (bin_.dynamic(e,i).t) {
      case cppcc::com::PLS_TERMINAL_TOKEN:
        break;
      case KW_ACTION:
        {
           // metagetint
           // if(s= metagetint(r,k,nnrule,uu.f[0].d,&v)) return(s);
           cppcc::scb::SyntaxControlledBinary::edpirType* ee =
        	 bin_.ptredp(help_.k(KW_ACTION).k_
               ,bin_.dynamic(e,i).d);
           if (ee && bin_.fixed(ee)) {
        	 cppcc::scr::tag::Long  	v = 0;
        	 metagetint(output, nnrule, bin_.fixed(ee,0).d, &v);
        	 if (v == vv) {
        	   if (yy) *yy = 1;
        	   return;
        	 }
           }
        }
        break;
      default:
        break;
      }
    }
  }
  
  return;
}


// generate  iteration switch 
/////int metagggg(r,k,nnrule,nitr,ee,uu)
// //if(s= metagggg(r,k,nnrule,u->d[i].d,ei,&ui)) return(s);
// metagggg(output, nnrule, bin_.dynamic(e, i).d, ei);
void 
GenerateParserCC::metagggg
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scr::tag::Long  	nitr
,cppcc::scb::SyntaxControlledBinary::edpirType*  ee)
{
  metantmType::SymbolsContainer symbols;


  //bool isDebugBug = true;
  bool isDebugBug = false;
if (isDebugBug) {
  std::cout 
  << "metagggg:0:"
  << " rule:" << nnrule
  << " ee:" << (*ee)
  << " nitr:" << nitr
  << std::endl;  
}  
  
  //if(s= metagrfiter(r,k,nnrule,nitr,fnta,&flen)) return(s);
  metagrfiter(output, nnrule, nitr, symbols);
if (isDebugBug) {
    std::cout 
    << "metagggg:1:"
    << " rule:" << nnrule
    << " ee:" << (*ee)
    << " nitr:" << nitr
    << " symbols:" << symbols.size()
    << std::endl;  
    //dumpSymbols(output, nnrule, symbols);
}  
 
  if (KW_ITERITEMACT != bin_.fixed(ee, 1).t) {
    ruleError(output, nnrule, errorHereMustBeIterItemact);
    CPPCC_THROW_EXCEPTION(
        << " rule:" << nnrule << " "
        << " tag:" << bin_.fixed(ee, 1).t
        << " should be:" << KW_ITERITEMACT
        << errorHereMustBeIterItemact    
    )  
  }

  if (isDebugBug) {
      std::cout 
      << "metagggg:2:"
      << " rule:" << nnrule
      << " ee:" << (*ee)
      << " nitr:" << nitr
      << " symbols:" << symbols.size()
      << " eed:" << bin_.fixed(ee, 1).d
      << std::endl;  
  }  

  
  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
  bin_.ptredp(help_.k(KW_ITERITEMACT).k_
    ,bin_.fixed(ee, 1).d);
  if (eact && bin_.fixed(eact)) {
	const char*             cnid  = 0;
	int                     maybe = 0;
	cppcc::scr::tag::Long   ndd   = 0;
	
	if (KW_MAYBENTERM == bin_.fixed(eact,0).t) {
	  cppcc::scb::SyntaxControlledBinary::edpirType* en =
	    bin_.ptredp(help_.k(KW_MAYBENTERM).k_
	      ,bin_.fixed(eact, 0).d);
	  if (en && bin_.fixed(en)) {

		  if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(en,1).t) {
			  ruleError(output, nnrule, errorHereMustBeIdentifier);
			  CPPCC_THROW_EXCEPTION(
				<< " rule:" << nnrule << " "
				<< errorHereMustBeIdentifier    
			  )
		  }
		  
		  ndd   = bin_.fixed(en,1).d;
		  cnid  = bin_.ptrids(ndd); 
      // BUG:
      // maybe = 0;
		  maybe = 1;

		  
	  } //if (en && bin_.fixed(en))
	}
	else if(cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact,0).t) {
		  ndd   = bin_.fixed(eact,0).d;
		  cnid  = bin_.ptrids(ndd); 
		  maybe = 0;
		
	}
	else {
        ruleError(output, nnrule, errorHereMustBeIdentifierOrLess);
        CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << errorHereMustBeIdentifierOrLess     
        )                   		
	}
	const char*	    cnnn  = cnid;
	//std::string 	ckw = keyword(ndd);
	
	//55// std::string 	ckw = cnid;
	//55// upper(ckw);
	//55// ckw = std::string("KW_") + ckw;
	std::string 	ckw = cnid;
	ckw = prefixKeyWord(ckw);
	
    //std::string     keywordInt  = keyword(cppcc::com::PLS_INTEGER_TOKEN);
    //std::string     keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);
	
	// generate first element of iteration 
	//if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
	cppcc::scr::tag::Long     rull;
	metachnt(output, nnrule, ndd, &rull);    
	if(rull == -1) {
		/*
        if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
          output 
          << "    if(kword() == KW_" << ckw << ") {"
          << std::endl;   
        } else {
        output 
        << "    if((kword() == " << keywordInt
        << ") || (kword() == " << keywordFloat
        << ")) {"
        << std::endl;                 
        }
		*/
		generateKW(output, ndd);
	}
	else {
      metantmType&    ntm = grammar_.rulval[rull];
        
      if (1 == ntm.first.size()) {
        cppcc::scr::tag::Long   ndd2 = *ntm.first.begin();
        /*
        std::string  kwd = keyword(ndd2);
        if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
            output 
            << "    if(kword() == KW_" << ckw << ") {"
            << std::endl;   
        } else {
          output 
          << "    if((kword() == " << keywordInt
          << ") || (kword() == " << keywordFloat
          << ")) {"
          << std::endl;                 
        }         
        */
        generateKW(output, ndd2);
      }
      else {
        // fprintf(ff,"    if(");
      //qq// output << "    if(" << std::endl; 
      output << "    if( " ;

      // loop processing first set.
      metantmType::SymbolsContainer::const_iterator cIter =
        ntm.first.begin();
      metantmType::SymbolsContainer::const_iterator cEnd =
        ntm.first.end();
      
      for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
        cppcc::scr::tag::Long   ndd2 = (*cIter);
        if (i) {
          //fprintf(ff,"   || "); 
          //qq// output << "   || " << std::endl;  
          output << "      || " ;  
        }

        /*
        std::string  kwd = keyword(ndd2);
        if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
            output 
            << "    if(kword() == KW_" << ckw << ") {"
            << std::endl;   
        } else {
          output 
          << "    if((kword() == " << keywordInt
          << ") || (kword() == " << keywordFloat
          << ")) {"
          << std::endl;                 
        }    
        */
        generateKWLoop(output, ndd2);
      } // i
      
      if (ntm.first.size() != 1) {
        output << "    ";
      }
      
    //fprintf(ff,"){\n");
    //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
    //fprintf(ff,"  }\n");
      output << "){" << std::endl;
      
      } // 1 != ntm.first.size()
	} // rull != -1
	
      if (maybe) {
        //printf(ff,"      if(Y%s)edberkwsdf(KW_%s);\n",cnid,keyword);
    	  //fprintf(ff,"      Y%s=1;\n",cnid);
    	  // BUG: ub:
        //output << "      if(Y" << cnid << ")edberkwsdf(" << ckw << ");"
        //<< std::endl;
        // e.g.:
        //   if(Yb2){edberkwsdf(KW_A2);return;}
        //   Yb2=1;
        output 
          << "      if(Y" << cnid << ") {edberkwsdf(" << ckw << ");return;}"
          << std::endl
          << "      Y" << cnid <<"=1;"
          << std::endl;
      }
 
      // generate 3 - actions 
      //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
      //register int s = 0;
      //if (s = metaactions(output,nnrule,
      //  bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
      // )) return;	
      metaactions(output,nnrule,
        //BUG:// bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
        bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 3
      );
      //fprintf(ff,"    ");
      //output << "    ";
      
      // metaactionsfind
	  // check 1 - actions 
	  //if(s= metaactionsfind(r,k,nnrule,uact.f[1].t,uact.f[1].d,
	  //	      1,&yy)) 
	  //  return(s);
      //int metaactionsfind(r,k,nnrule,actp,acid,vv,yy)
      int yy;
      metaactionsfind(output,nnrule, bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 1, &yy);
     
      //fprintf(ff,"    if(s= %s(d+i)) ",cnid);
      output    << "	    d.push_back(0);" << std::endl;
      output    << "	    " << cnid << "(d.back());" << std::endl;
      if (yy) {
          metaactions(output,nnrule,
            bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 1
          );   	  
      }
 
      metaactions(output,nnrule,
        bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 0
      );   	  
      
      //fprintf(ff,"    }\n");
      output    << "    }"  << std::endl;
      
      // NB: finish  
      //  iteritems  --------------------
      if (KW_ITERITEMS != bin_.fixed(ee, 2).t) {
		  ruleError(output, nnrule, errorHereMustBeIterItems);
		  CPPCC_THROW_EXCEPTION(
			<< " rule:" << nnrule << " "
			<< " tag:" << KW_ITERITEMS
			<< " should be:" << bin_.fixed(ee, 2).t
			<< errorHereMustBeIterItems    
		  )   	  
      }
      
      cppcc::scb::SyntaxControlledBinary::edpirType* eiter =
        bin_.ptredp(help_.k(KW_ITERITEMS).k_
          ,bin_.fixed(ee, 2).d);
      if (eiter && bin_.dynamic(eiter)) {
        for (cppcc::scr::tag::Long j = 0; j < eiter->dl; j++) {
          if (KW_ALTITERITEM != bin_.dynamic(eiter, j).t) {
    		  ruleError(output, nnrule, errorHereMustBeIterItems);
    		  CPPCC_THROW_EXCEPTION(
    			<< " rule:" << nnrule << " "
    			<< " tag:" << KW_ALTITERITEM
    			<< " should be:" << bin_.dynamic(eiter, j).t
    			<< errorHereMustBeIterItems    
    		  )   	        	  
          }
          
          cppcc::scb::SyntaxControlledBinary::edpirType* ealti =
            bin_.ptredp(help_.k(KW_ALTITERITEM).k_
              ,bin_.dynamic(eiter, j).d);
          if (ealti && bin_.fixed(ealti)) {
            if (KW_ITERITEMACT != bin_.fixed(ealti, 1).t) {
      		  ruleError(output, nnrule, errorHereMustBeIterItemact);
      		  CPPCC_THROW_EXCEPTION(
      			<< " rule:" << nnrule << " "
      			<< " tag:" << KW_ITERITEMACT
      			<< " should be:" << bin_.fixed(ealti, 1).t
      			<< errorHereMustBeIterItemact    
      		  )   	        	           	
            }
            
            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              bin_.ptredp(help_.k(KW_ITERITEMACT).k_
                ,bin_.fixed(ealti, 1).d);
            if (eact && bin_.fixed(eact)) {
            	
              cppcc::scr::tag::Long 	ndd2;
              const char*				      cnid2;
              int						          maybe2;
              if (KW_MAYBENTERM == bin_.fixed(eact,0).t) {
                  cppcc::scb::SyntaxControlledBinary::edpirType* enalti =
                    bin_.ptredp(help_.k(KW_MAYBENTERM).k_
                      ,bin_.fixed(eact,0).d);
                  if (enalti && bin_.fixed(enalti)) {
                    if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(enalti,1).t) {
                		  ruleError(output, nnrule, errorHereMustBeIdentifier);
                		  CPPCC_THROW_EXCEPTION(
                			<< " rule:" << nnrule << " "
                			<< " tag:" << bin_.fixed(enalti,1).t
                			<< " should be:" << cppcc::com::PLS_IDENTIFIER
                			<< errorHereMustBeIdentifier   
                		  )   	        	           	                   	
                    }
                    
                    ndd2   = bin_.fixed(enalti,1).d;
                    // BUG:
                    //cnid2  = bin_.ptrids(ndd);
                    cnid2  = bin_.ptrids(ndd2);
                    maybe2 = 1;
                	  
                  } // if (enalti && bin_.fixed(enalti)) 
              }
              else if (KW_IDENTIFIER == bin_.fixed(eact,0).t) {
                  ndd2 	 = bin_.fixed(eact,0).d;
                  // BUG:
                  //cnid2  = bin_.ptrids(ndd);
                  cnid2  = bin_.ptrids(ndd2);
                  maybe2 = 0;           	  
              }
              else {
          		  ruleError(output, nnrule, errorHereMustBeIdentifierOrLess);
          		  CPPCC_THROW_EXCEPTION(
          			<< " rule:" << nnrule << " "
          			<< " tag:" << bin_.fixed(eact,0).t
          			<< " should be:" << KW_MAYBENTERM
          			<< " or should be:" << KW_IDENTIFIER
          			<< errorHereMustBeIdentifierOrLess    
          		  )   	        	           	 	  
              }
              
          	  std::string 	ckw2 = cnid2;
          	  ckw2 = prefixKeyWord(ckw2);

          	  // generate next element(s) of iteration
          	  cppcc::scr::tag::Long     rull;
              // BUG: ub
          	  //metachnt(output, nnrule, ndd, &rull);    
              metachnt(output, nnrule, ndd2, &rull);    

          	  if(rull == -1) {
                // ub:
                // generateKW(output, ndd2);
          	    generateKWelse(output, ndd2);
          	  }
          	  else {
          	      metantmType&    ntm = grammar_.rulval[rull];
          	        
          	      if (1 == ntm.first.size()) {
          	        cppcc::scr::tag::Long   ndd22 = *ntm.first.begin();
                    // ub:
          	        // generateKW(output, ndd22)
                    generateKWelse(output, ndd22);
          	      }
          	      else {
          	        // fprintf(ff,"    if(");
          	        //qq// output << "    else if(" << std::endl; 
          	        output << "      else if(" ;

          	      // loop processing first set.
          	      metantmType::SymbolsContainer::const_iterator cIter =
          	        ntm.first.begin();
          	      metantmType::SymbolsContainer::const_iterator cEnd =
          	        ntm.first.end();
          	      
          	      for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
          	        cppcc::scr::tag::Long   ndd22 = (*cIter);
          	        if (i) {
          	          //fprintf(ff,"   || "); 
          	          //qq// output << "   || " << std::endl;  
          	          output << "     || " ; 
          	        }
          	        
          	        generateKWLoop(output, ndd22);
          	      } // i
          	      
          	      if (ntm.first.size() != 1) {
          	        output << "  ";
          	      }
          	      
          	    //fprintf(ff,"){\n");
          	    //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
          	    //fprintf(ff,"  }\n");
          	      output << "    ){" << std::endl;
          	      
          	      } // 1 != ntm.first.size()
          	  } // else
          	  
          	  // maybe
              // BUG:
              //if (maybe) {
              if (maybe2) {
                //printf(ff,"      if(Y%s)edberkwsdf(KW_%s);\n",cnid,keyword);
                //fprintf(ff,"      Y%s=1;\n",cnid);
                // BUG: ub
                //output << "      if(Y" << cnid << ")edberkwsdf(" << ckw << ");"
                //<< std::endl;
                // ==>>
                output
                  << "      if(Y" << cnid2 << ") {edberkwsdf(" << ckw2 << ");return;}"
                  << std::endl
                  << "      Y" << cnid2 <<"=1;"
                  << std::endl;
              }
             
              // generate 3 - actions 
              metaactions(output,nnrule,
                bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 3
              );         
              
              int yy;
              metaactionsfind(output,nnrule, bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 1, &yy);
              output    << "      d.push_back(0);" << std::endl;
              // BUG: ub
              //output    << "      " << cnid << "(d.back());" << std::endl;
              output    << "      " << cnid2 << "(d.back());" << std::endl;

              if (yy) {
                  metaactions(output,nnrule,
                    bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 1
                  );      
              }
         
              metaactions(output,nnrule,
                bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 0
              );      
              
              output    << "    }"  << std::endl;
              
            } // if (eact && bin_.fixed(eact)) 
            
        	 
          } // if (ealti && bin_.fixed(ealti))
          
        } // j
      } // if (eiter && bin_.fixed(eiter))
      
      // NB: finish /* iteritems */ --------------------
	////} // rull == -1


    // generate error (else) part    
    //fprintf(ff,"    else break;\n");
    output << "    else break;" << std::endl;
  } //if (eact && bin_.fixed(eact)) 
}

//dynamic

void 
GenerateParserCC::metaiter
//(output, ruleIndex, e, eru, i)
(std::ofstream& 			output
,std::size_t 				nnrule
,cppcc::scb::SyntaxControlledBinary::edpirType* e
,cppcc::scb::SyntaxControlledBinary::edpirType* eru
,cppcc::scr::tag::Long  	i)
{
  if (!e || !eru) {
	return;
  }

  //bool isDebugBug = true;
  bool isDebugBug = false;
  
if (isDebugBug) {
  std::cout 
  << "metaiter:0:"
  << " rule:" << nnrule
  << " e:" << (*e)
  << " eru:" << (*eru)
  << " i:" << i
  << std::endl;  
}

  //cppcc::scr::tag::Long iterNo = bin_.dynamic(e, i).d;
  
  std::string	ruleName = bin_.ptrids(bin_.fixed(eru, 1).d);
  //ruleName = upper(ruleName);
  
  const char *followsymbol = 0;
  cppcc::scb::SyntaxControlledBinary::edpirType*  ei =
    bin_.ptredp(help_.k(KW_ITERATION).k_
      ,bin_.dynamic(e, i).d);
  if (ei && bin_.fixed(ei)) {
    if ((i+1) < e->dl) {
      //
      //  grammer ::= '(' grammerNameDef
      //                   { rule }
      //                  ')'
      //
   	  if (KW_IDENTALT != bin_.dynamic(e, i+1).t) {
		 ruleError(output, nnrule, errorNotYetImplementedVariantOfIteration);
		 CPPCC_THROW_EXCEPTION(
		   << " rule:" << nnrule << " "
		   << " tag:" << bin_.dynamic(e, i+1).t
		   << " should be:"
		   << " " << KW_IDENTALT
		   << errorNotYetImplementedVariantOfIteration
		 )                                 	        	            
   	  }
   	  
      cppcc::scb::SyntaxControlledBinary::edpirType* eaaa =
        bin_.ptredp(help_.k(KW_IDENTALT).k_
          ,bin_.dynamic(e, i+1).d);
      if (eaaa && bin_.fixed(eaaa)) {
        if (KW_NTERMTERMACT != bin_.fixed(eaaa,0).t) {
          ruleError(output, nnrule, errorHereMustINtermTermAct);
   		  CPPCC_THROW_EXCEPTION(
   		   << " rule:" << nnrule << " "
   		   << " tag:" << bin_.fixed(eaaa,0).t
   		   << " should be:"
   		   << " " << KW_NTERMTERMACT
   		   << errorHereMustINtermTermAct
   		  )                                 	        	                	
        }
        
        cppcc::scb::SyntaxControlledBinary::edpirType* eact =
          bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
            ,bin_.fixed(eaaa,0).d);
        if (eact && bin_.fixed(eact)) {
          if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == bin_.fixed(eact, 0).t) {
        	followsymbol = bin_.ptrids(bin_.fixed(eact, 0).d);
if (isDebugBug) {
        	  std::cout 
        	  << "metaiter:1:"
        	  << " rule:" << nnrule
        	  << " e:" << (*e)
        	  << " eru:" << (*eru)
        	  << " i:" << i
        	  << " follow:" << followsymbol
        	  << std::endl;  
}

          } 
          else {
     		 ruleError(output, nnrule, errorNotYetImplementedVariantOfIteration);
     		 CPPCC_THROW_EXCEPTION(
     		   << " rule:" << nnrule << " "
     		   << " tag:" << bin_.fixed(eact, 0).t
     		   << " should be:"
     		   << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
     		   << errorNotYetImplementedVariantOfIteration
     		 )                                 	        	                    	  
          }
        }        
      } //  if (eaaa ...
      
      if((i+2) < (e->dl)) {
if (isDebugBug) {
    	          	  std::cout 
    	          	  << "metaiter:3:"
    	          	  << " rule:" << nnrule
    	          	  << " e:" << (*e)
    	          	  << " eru:" << (*eru)
    	          	  << " i:" << i
    	          	  << " e->dl:" << e->dl
    	          	  << std::endl;  
}

    	 // BUG: orig code??? // for (i = i + 2; i < e->dl; i++) {
    	 for (cppcc::scr::tag::Long i2 = i + 2; i2 < e->dl; i2++) {
    	   if (
    	     (KW_ACTION != bin_.dynamic(e, i2).t)
    	     && (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != 
    	    	bin_.dynamic(e, i2).t)
    	   ) 
    	   {
       		 ruleError(output, nnrule, errorOnlyOneSymbolMayBeFollowedByIteration);
       		 CPPCC_THROW_EXCEPTION(
       		   << " rule:" << nnrule << " "
       		   << " tag:" << bin_.dynamic(e, i2).t
       		   << " should be:"
       		   << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
       		   << " or " << KW_ACTION
       		   << errorOnlyOneSymbolMayBeFollowedByIteration
       		 )   		   
    	   }
    	 }
      }
    } //if ((i+1) < e->dl)
    
    //------------------
    // fix it!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    //------------------
    // final generation ------------
    //std::string funname = std::string(i?"crenxtedp":"crenxtdyn");
    //std::string funend  = std::string(i?"crelasedp":"crelasdyn");      
    //std::string kw		= bin_.ptrids(bin_.fixed(eru, 1).d);
    std::string kw		= keyword(bin_.fixed(eru, 1).d);

if (isDebugBug) {
        	          	  std::cout 
        	          	  << "metaiter:4:"
        	          	  << " rule:" << nnrule
        	          	  << " e:" << (*e)
        	          	  << " eru:" << (*eru)
        	          	  << " i:" << i
        	          	  << " e->dl:" << e->dl
        	          	  << " kw:" << kw
        	          	  << std::endl;  
}   
    output << "  for(;;) {" << std::endl;
    output << "    if(iseof()) break;" << std::endl;    
    output << "" << std::endl;    
    
    //if(s= metagggg(r,k,nnrule,u->d[i].d,ei,&ui)) return(s);
if (isDebugBug) {
            	  std::cout 
            	  << "metaiter:2:before metagggg"
            	  << " rule:" << nnrule
            	  << " e:" << (*e)
            	  << " eru:" << (*eru)
            	  << " i:" << i
            	  << " ti:" << bin_.dynamic(e, i).t
            	  << " di:" << bin_.dynamic(e, i).d
            	  << std::endl;  
}
    
    // BUG: orig code???// 
    metagggg(output, nnrule, bin_.dynamic(e, i).d, ei);
    //metagggg(output, nnrule, iterNo, ei);
    
    output << "" << std::endl;  
    //output << "  " <<  funname << "(" << kw << ",f,d,&tag);" << std::endl;     
    output << "  }" << std::endl;    
    output << "" << std::endl;  
    
    if (followsymbol) {
      output << "  d.push_back(0);" << std::endl;  
      output << "  skipToken(" << prefixKeyWord(followsymbol)
      << ",d.back());"
      << std::endl; 
    }
    
    //output << "  " <<  funend << "(" << kw << ",f,d,&tag);" << std::endl;     
    if (i) {
      output << "  crelasedp(" << prefixKeyWord(ruleName) << ",f,d,&tag);" << std::endl;
    }
    else {
      output << "  crelasdyn(" << prefixKeyWord(ruleName) << ",d,&tag);" << std::endl;
    }
  } // if (ei && bin_.fixed(ei))
}

//  //if(s= metagetstr(r,k,nnrule,u.d[i].d,&t)) return(s);
//  //fprintf(ff,"%s\n",t);
//metagetstr(output, ruleIndex, bin_.dynamic(e,i).d, &t);
void 
GenerateParserCC::metagetstr
//(output, ruleIndex, bin_.dynamic(e,i).t,0)
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	n
,const char**				t)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
	bin_.ptredp(help_.k(cppcc::com::PLS_STRING_TOKEN).k_,n);
  if (e && bin_.fixed(e)) {
	if (t) *t = (const char*)(bin_.fixed(e));
    
    //bool	isDebugBug = true;
    bool	isDebugBug = false;
if (isDebugBug) {
std::cout << "metagetstr:"
		<< " rule:" << ruleIndex 
		<< " t:" << std::string(t?(*t):"")
		<< std::endl;	
}

  }
}


void 
GenerateParserCC::metaaction
//(output, ruleIndex, bin_.dynamic(e,i).t,0)
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long  	acid
,cppcc::scr::tag::Long  	vv)
{

  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_ACTION).k_
      ,acid);
  if (e && bin_.fixed(e)) {
    if (cppcc::com::PLS_INTEGER_TOKEN != bin_.fixed(e,0).t) {
        ruleError(output, ruleIndex, errorHereMustBeIntegerToken);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << ruleIndex << " "
          << " tag:" << bin_.fixed(e,0).t
          << " should be:" << cppcc::com::PLS_INTEGER_TOKEN
          << errorHereMustBeIntegerToken    
        )  	
    }
    
    cppcc::scr::tag::Long  	v=0;
    //if(s= metagetint(r,k,nnrule,u.f[0].d,&v)) return(s);
    metagetint(output,ruleIndex, bin_.fixed(e,0).d, &v);
    
    //bool	isDebugBug = true;
    bool	isDebugBug = false;
if (isDebugBug) {
std::cout << "metaaction:"
		<< " vv:" << vv 
		<< " v:" <<v
		<< std::endl;	
}
    
    if (v == vv) {
      for (cppcc::scr::tag::Long i = 0, z= e->dl; i < z; i++) {
    	switch (bin_.dynamic(e,i).t) {
    	case cppcc::com::PLS_TERMINAL_TOKEN:
    	break;
    	case cppcc::com::PLS_STRING_TOKEN:
    	{
    	  const char* t;
  	      //if(s= metagetstr(r,k,nnrule,u.d[i].d,&t)) return(s);
  	      //fprintf(ff,"%s\n",t);
    	  metagetstr(output, ruleIndex, bin_.dynamic(e,i).d, &t);
    	  //fprintf(ff,"%s\n",t);
    	  output << t << std::endl;
    	}
    	break;
    	default:
    	{
            ruleError(output, ruleIndex, errorHereMustStringToken);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << ruleIndex << " "
              << " tag:" << bin_.dynamic(e,i).t
              << " should be:" << cppcc::com::PLS_TERMINAL_TOKEN
              << " or:" << cppcc::com::PLS_STRING_TOKEN
              << errorHereMustStringToken    
            )  	
    		
    	}
    	}
      }
    }
  }

}

//  if(s= metamiss(output,ruleIndex,bin_.dynamic(e,i).d
//    ,i,yy,&firstMiss,iact,
//	(i == ((e->dl) - 1)))) return(s);
//int metamiss(r,k,nnrule,nal,iiii,yyyy,fmis,iact,iend)
void 
GenerateParserCC::metamiss
(std::ofstream& 	output
,std::size_t 		nnrule
,int  				nal
,int 				iiii
,int  				yyyy
,int*  				fmis
,int  				iact
,int  				iend
)
{
  //std::string       keywordInt  = keyword(cppcc::com::PLS_INTEGER_TOKEN);
  //std::string       keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);

  int iii = iiii - iact;
  
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_IDENTMISS).k_,nal);
  if (e && bin_.fixed(e)) {
    if (KW_IDENTALT != bin_.fixed(e,1).t) {
      //errorHereMustBeIdentAlt
      tok_.errorMessage(errorHereMustBeIdentAlt);
      output
        << " rule:" << nnrule << " "
        << errorHereMustBeIdentAlt
        << std::endl;
      CPPCC_THROW_EXCEPTION(
        << " rule:" << nnrule << " "
        << errorHereMustBeIdentAlt
      )     
    }
     
    // Simple alternamtive or identifier:
    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
      bin_.ptredp(help_.k(KW_IDENTALT).k_,bin_.fixed(e,1).d);
    if (eidentalt) { 
      // fprintf(ff,"  f[%d]=(long)0;\n",iii);
      output << "  f[" << iii << "]=0;" << std::endl;

  	  //flen=0;
  	  //if(s= metarfalid(r,k,nnrule,u.f[1].d,fnta,&flen)) return(s);
      metantmType::SymbolsContainer 	symbols;
      metarfalid(output, nnrule, bin_.fixed(e,1).d, symbols);
      
      if (bin_.fixed(eidentalt)) { 
        if (KW_NTERMTERMACT != bin_.fixed(eidentalt, 0).t) {
            //ruleError(output, nnrule, errorHereMustBeIterItemact);
            ruleError(output, nnrule, errorHereMustINtermTermAct);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << errorHereMustINtermTermAct
            )                                 
        }
          
        cppcc::scb::SyntaxControlledBinary::edpirType* eact =
            bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
              ,bin_.fixed(eidentalt, 0).d);
        if (eact) {
          if (bin_.fixed(eact)) {
            if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {

        		/*
        		  XXX::= ( 'a' | 'b' | . . . )
        		  */
              if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != 
            	bin_.fixed(eact, 0).t) {
                ruleError(output, nnrule, errorFirstItemOfAlternativeMustBe);
                CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << errorFirstItemOfAlternativeMustBe
                )                                 
              }
              
              for (cppcc::scr::tag::Long j = 0, zj = eidentalt->dl; j < zj; j++) {
            	if (KW_ALTPART != bin_.dynamic(eidentalt, j).t) {
            	  // ??? no check for 	if (bin_.dynamic(eidentalt)) { 
            	  // see if (bin_.fixed(eidentalt)) { above....
                  ruleError(output, nnrule, errorHereMustAlternative);
                  CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << " tag:" << bin_.dynamic(eidentalt, j).t
                      << " should be:" << KW_ALTPART
                      << errorHereMustAlternative
                  )                                 
            	}
            	
                cppcc::scb::SyntaxControlledBinary::edpirType* ea =
                  bin_.ptredp(help_.k(KW_ALTPART).k_
                    ,bin_.dynamic(eidentalt, j).d);
                if (ea) {
                  if (bin_.fixed(ea)) {
                     if (KW_NTERMTERMACT != bin_.fixed(ea, 1).t) {
                          //ruleError(output, nnrule, errorHereMustBeIterItemact);
                       ruleError(output, nnrule, errorHereMustINtermTermAct);  
                       CPPCC_THROW_EXCEPTION(
                         << " rule:" << nnrule << " "
                         << " tag:" << bin_.fixed(ea, 1).t
                         << " should be:" << KW_NTERMTERMACT
                         << errorHereMustINtermTermAct
                       )                                                       
                     }
                     
                     cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                       bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                         ,bin_.fixed(ea, 1).d);
                     if (eact) {
                       if (bin_.fixed(eact)) {
                          if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {          
                            ruleError(output, nnrule, errorHereMustBeTermTokenOfRule);
                            CPPCC_THROW_EXCEPTION(
                              << " rule:" << nnrule << " "
                              << errorHereMustBeTermTokenOfRule
                            )                                             
                          }
                          
                       }
                     }
                     
                     
                  }
                }           	
              } // j
              
              cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                  ,bin_.fixed(eidentalt, 0).d);
              if (eact && bin_.fixed(eact)) {
                cppcc::scr::tag::Long   ndd     = bin_.fixed(eact, 0).d;
                /*
                std::string       keyword1  = keyword(ndd);
                
                if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
                  output 
                  << "    if(kword() == KW_" << keyword1 << ") {"
                  << std::endl;   
                } else {
                output 
                << "    if((kword() == " << keywordInt
                << ") || (kword() == " << keywordFloat
                << ")) {"
                << std::endl;                 
                }
                */
                generateKW(output, ndd);
           	  
              } // if (eact && bin_.fixed(eact))
              
              for (cppcc::scr::tag::Long i = 0, zi = eidentalt->dl; i < zi; i++) {
                  cppcc::scb::SyntaxControlledBinary::edpirType* ea =
                    bin_.ptredp(help_.k(KW_ALTPART).k_
                      ,bin_.dynamic(eidentalt, i).d);
                  if (ea) {
                    if (bin_.fixed(ea)) {
                       if (KW_NTERMTERMACT != bin_.fixed(ea, 1).t) {
                            //ruleError(output, nnrule, errorHereMustBeIterItemact);
                         ruleError(output, nnrule, errorHereMustINtermTermAct);  
                         CPPCC_THROW_EXCEPTION(
                           << " rule:" << nnrule << " "
                           << " tag:" << bin_.fixed(ea, 1).t
                           << " should be:" << KW_NTERMTERMACT
                           << errorHereMustINtermTermAct
                         )                                                       
                       }
                       
                       cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                         bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                           ,bin_.fixed(ea, 1).d);
                       if (eact) {
                         if (bin_.fixed(eact)) {
                            if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {          
                              ruleError(output, nnrule, errorHereMustBeTermTokenOfRule);
                              CPPCC_THROW_EXCEPTION(
                                << " rule:" << nnrule << " "
                                << errorHereMustBeTermTokenOfRule
                              )                                             
                            }
                            
                            cppcc::scr::tag::Long  ndd = bin_.fixed(eact, 0).d;
                            /*
                            std::string       keyword1  = keyword(ndd);
                          
                            if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
                              output 
                              << "    if(kword() == KW_" << keyword1 << ") {"
                              << std::endl;   
                            } else {
                              output 
                              << "    if((kword() == " << keywordInt
                              << ") || (kword() == " << keywordFloat
                              << ")) {"
                              << std::endl;                 
                            }
                       	    */
                            generateKW(output, ndd);
                         }
                       }
                       
                       
                    }
                  }           	
                } // i             
                
              //fprintf(ff,"  ){\n");
      		  //fprintf(ff,"    skipkeywordTermToken(f");
      		  //if(iii) fprintf(ff,"+%d",iii);
      		  //fprintf(ff,",Kword);\n");
       		  //fprintf(ff,"  }\n");
              //
      		  //return(0);
              
              output << "    ){" << std::endl;
              //output << "  skipKeyWordTerm(" << tokenKeyWord(tn) << ",tag);" 
              output << "    skipkeywordTermToken(f[" << iii << "], kword());" << std::endl;
              output << "  }" << std::endl;
              return;
            } // if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t)
            

  	        // ndd= uact.f[0].d;
            // ckw= ptrids(r,ndd);
            // for(ii=0;keyword[ii]= toupper(*ckw); ii++,ckw++);
            // 
            // if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
            // if(rull == -1) {			  
            cppcc::scr::tag::Long  ndd = bin_.fixed(eact, 0).d;
            //std::string       keyword1  = keyword(ndd);
            cppcc::scr::tag::Long rull;
            metachnt(output, nnrule, ndd, &rull);
            if(rull == -1) {		
            	
            	/*
              if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
                output 
                << "    if(kword() == KW_" << keyword1 << ") {"
                << std::endl;   
              } else {
                output 
                << "    if((kword() == " << keywordInt
                << ") || (kword() == " << keywordFloat
                << ")) {"
                << std::endl;                 
              }  
              */
              generateKW(output, ndd);
              
              // generate 3 - actions 
              //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
              metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
              
      		  //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
      		  //if(iii) fprintf(ff,"+%d",iii);
      		  //fprintf(ff,")) return(s);\n");
              output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  
 
              // generate 0 - actions 
              //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
              metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);             
              
              //fprintf(ff,"  }\n");
              output << "  }" << std::endl;  
            }
            else {
              metantmType&    ntm = grammar_.rulval[rull];
              
              if (1 == ntm.first.size()) {
                cppcc::scr::tag::Long   ndd2 = *ntm.first.begin();
                /*
                std::string  kwd = keyword(ndd2);
                if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
                  output 
                  << "    if(kword() == KW_" << keyword1 << ") {"
                  << std::endl;   
                } else {
                  output 
                  << "    if((kword() == " << keywordInt
                  << ") || (kword() == " << keywordFloat
                  << ")) {"
                  << std::endl;                 
                }    
                */
                generateKW(output, ndd2);
                
                // generate 3 - actions 
                //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
  
      		    //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
      		    //if(iii) fprintf(ff,"+%d",iii);
      		    //fprintf(ff,")) return(s);\n");
                output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                // /* generate 0 - actions */
                // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);

                // fprintf(ff,"  }\n");		  
                output << "  }" << std::endl;  
                
              } //if (1 == ntm.first.size())
              else {
                  // fprintf(ff,"    if(");
                output << "    if(" << std::endl; 

                // loop processing first set.
                metantmType::SymbolsContainer::const_iterator cIter =
                  ntm.first.begin();
                metantmType::SymbolsContainer::const_iterator cEnd =
                  ntm.first.end();
                
                for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
                  cppcc::scr::tag::Long   ndd2 = (*cIter);
                  if (i) {
                    //fprintf(ff,"   || "); 
                    output << "      || " << std::endl;  
                  }

                  /*
                  std::string  kwd = keyword(ndd2);
                  if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
                      output 
                      << "    if(kword() == KW_" << keyword1 << ") {"
                      << std::endl;   
                  } else {
                    output 
                    << "    if((kword() == " << keywordInt
                    << ") || (kword() == " << keywordFloat
                    << ")) {"
                    << std::endl;                 
                  }  
                  */
                  generateKWLoop(output, ndd2);
                } // first
                
                if (ntm.first.size() != 1) {
                  output << "  ";
                }
                
                
              //fprintf(ff,"){\n");
              //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
              //fprintf(ff,"  }\n");
                output << "  ){" << std::endl;
                
                // generate 3 - actions 
                //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
  
      		    //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
      		    //if(iii) fprintf(ff,"+%d",iii);
      		    //fprintf(ff,")) return(s);\n");
                output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                // /* generate 0 - actions */
                // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);
                
                output << "  }" << std::endl;           	  
            	  
              } // else if (1 == ntm.first.size())
              
            } // rull != -1
            
           
          }
        }      
      }
      
      if (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt)) {
          for (cppcc::scr::tag::Long j = 0; j < eidentalt->dl; j++) {
            if (KW_ALTPART !=  bin_.dynamic(eidentalt, j).t) {
                ruleError(output, nnrule, errorHereMustBeAltpart);
                CPPCC_THROW_EXCEPTION(
                  << " rule:" << nnrule << " "
                  << errorHereMustBeAltpart
                )                                             
            }
          
            cppcc::scb::SyntaxControlledBinary::edpirType* ee =
              bin_.ptredp(help_.k(KW_ALTPART).k_
                ,bin_.dynamic(eidentalt, j).d);
            if (ee) {
              if (bin_.fixed(ee)) {
                 if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
                      //ruleError(output, nnrule, errorHereMustBeIterItemact);
                    ruleError(output, nnrule, errorHereMustINtermTermAct);  
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << errorHereMustINtermTermAct
                  )                                                       
                 }
                    
                 cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                   bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                     ,bin_.fixed(ee, 1).d);
                 if (eact) {
                   if (bin_.fixed(eact)) {
                      //BUG:// if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 1).t) {    
                      if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) { 
                        ruleError(output, nnrule, errorHereMustBeIdentifier);
                        CPPCC_THROW_EXCEPTION(
                          << " rule:" << nnrule << " "
                          << errorHereMustBeIdentifier
                        )                                             
                      }
                      
                      cppcc::scr::tag::Long   ndd = bin_.fixed(eact, 0).d;
 ///                     std::string  keyword1  = keyword(ndd);
 //                     std::string  keywordInt  = keyword(cppcc::com::PLS_INTEGER_TOKEN);
 //                     std::string  keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);
                      
                      cppcc::scr::tag::Long     rull;
                      //if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
                      metachnt(output, nnrule, ndd, &rull);
                      if (-1 == rull) {
                    	  /*
                        //if (IITT != keyword) {
                        if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
                          output 
                          << "    if(kword() == KW_" << keyword1 << ") {"
                          << std::endl;   
                        } else {
                        output 
                        << "    if((kword() == " << keywordInt
                        << ") || (kword() == " << keywordFloat
                        << ")) {"
                        << std::endl;                 
                        }
                        */
                    	generateKW(output, ndd);
                        
                        //--                     
                        // generate 3 - actions 
                        //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                        metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
          
              		    //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
              		    //if(iii) fprintf(ff,"+%d",iii);
              		    //fprintf(ff,")) return(s);\n");
                        output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                        // /* generate 0 - actions */
                        // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                        metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                        //--
                      } 
                      else {
                        metantmType&    ntmi = grammar_.rulval[rull];
                        
                        if (1 == ntmi.first.size()) {
                          cppcc::scr::tag::Long   ndd2 = *ntmi.first.begin();
                          /*
                          std::string  kwd = keyword(ndd2);
                          if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
                            output 
                            << "    if(kword() == KW_" << keyword1 << ") {"
                            << std::endl;   
                          } else {
                          output 
                          << "    if((kword() == " << keywordInt
                          << ") || (kword() == " << keywordFloat
                          << ")) {"
                          << std::endl;                 
                          }    
                          */
                          generateKW(output, ndd2);
                          
                          //--                     
                          // generate 3 - actions 
                          //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                          metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
            
                		    //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                		    //if(iii) fprintf(ff,"+%d",iii);
                		    //fprintf(ff,")) return(s);\n");
                          output << bin_.ptrids(ndd2) << "(f[" << iii << "]);" << std::endl;  


                          // /* generate 0 - actions */
                          // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                          metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                          //--

                        } 
                        else {
                          // fprintf(ff," else if(");
                        output << "  else if(" << std::endl; 

                        // loop processing first set.
                        metantmType::SymbolsContainer::const_iterator cIter =
                          ntmi.first.begin();
                        metantmType::SymbolsContainer::const_iterator cEnd =
                          ntmi.first.end();
                        
                        for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
                          cppcc::scr::tag::Long   ndd2 = (*cIter);
                          if (i) {
                            //fprintf(ff,"   || "); 
                            output << "        || " << std::endl;  
                          }

                          /*
                          std::string  kwd = keyword(ndd2);
                          if (cppcc::com::PLS_INTEGER_TOKEN != ndd2) {
                              output 
                              << "    if(kword() == KW_" << keyword1 << ") {"
                              << std::endl;   
                          } else {
                            output 
                            << "    if((kword() == " << keywordInt
                            << ") || (kword() == " << keywordFloat
                            << ")) {"
                            << std::endl;                 
                          }        
                          */
                          generateKWLoop(output, ndd2);
                        } // first
                        
                        if (ntmi.first.size() != 1) {
                          output << "    ";
                        }
                        
                      //fprintf(ff,"){\n");
                      //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
                      //fprintf(ff,"  }\n");
                        output << "){" << std::endl;
                        
                        //--                     
                        // generate 3 - actions 
                        //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                        metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
          
              		    //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
              		    //if(iii) fprintf(ff,"+%d",iii);
              		    //fprintf(ff,")) return(s);\n");
                        output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                        // /* generate 0 - actions */
                        // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                        metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                        //--

                        output << "  }" << std::endl;
                        } // 1 != ntm.first.size()
                        
                        
                      } // -1 != rull
                                        
                   }
                 }
                 
                
              }
            }
            
          } // j   	  
      } // if (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt))
      
    }
  }
}

//if(s= metagrfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
//		     nta,len)) return(s);
//
//metagrfsimp(output, nnrule
//  ,bin_.fixed(eidentalt,0).t, bin_.fixed(eidentalt,0).d, symbols);
//
//int metagrfsimp(r,k,nnrule,nit,nid,nta,len)
void 
GenerateParserCC::metagrfsimp
(std::ofstream& 	   			output
,std::size_t 		   			nnrule
,cppcc::scr::tag::Long 			nit
,cppcc::scr::tag::Long 			nid
,metantmType::SymbolsContainer& symbols)
{
  if (nit != KW_NTERMTERMACT) {
    ruleError(output, nnrule, errorHereMustINtermTermAct);
	CPPCC_THROW_EXCEPTION(
	          << " rule:" << nnrule << " "
	          << errorHereMustINtermTermAct
	          << " tag:" << nit
	          << " should be:" << KW_NTERMTERMACT
    )   
  }
  
  cppcc::scb::SyntaxControlledBinary::edpirType* eact =
    bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
      ,nid);
  if (eact && bin_.fixed(eact)) {
    switch (bin_.fixed(eact,0).t) {
    case cppcc::com::PLS_IDENTIFIER:
    {
      //if(s= metagrfiden(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
      metagrfiden(output,nnrule,bin_.fixed(eact,0).d,symbols);
    } 
    break;   
    case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
    {
      //if(s= metarfaddnxt(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
      metarfaddnxt(output,nnrule,bin_.fixed(eact,0).d,symbols);
    }
    break;       
 
    default:
    {
    	ruleError(output, nnrule, errorUndefinedSimpleTerminal);
    	CPPCC_THROW_EXCEPTION(
        << " rule:" << nnrule << " "
        << " tag:" << bin_.fixed(eact,0).t
        << " should be:" << cppcc::com::PLS_IDENTIFIER
        << " or:" << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
        << errorUndefinedSimpleTerminal
    	)                                                       
  
    }
    }
  }
}


//int metagrfalid(r,k,nnrule,nalid,nta,len)
// simple alternative or identifier 
//if(s= metagrfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s);
///metagrfalid(output, nnrule, bin_.fixed(e,1).d, symbols)
void 
GenerateParserCC::metagrfalid
(std::ofstream& 	   			output
,std::size_t 		   			nnrule
,cppcc::scr::tag::Long 			nalid
,metantmType::SymbolsContainer& symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
    bin_.ptredp(help_.k(KW_IDENTALT).k_
	  ,nalid);
  if (eidentalt && bin_.fixed(eidentalt)) {
    if (KW_NTERMTERMACT != bin_.fixed(eidentalt, 0).t) {
        //ruleError(output, nnrule, errorHereMustBeIterItemact);
        ruleError(output, nnrule, errorHereMustINtermTermAct);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << " tag:" << bin_.fixed(eidentalt, 0).t
          << " should be:" << KW_NTERMTERMACT
          << errorHereMustINtermTermAct
        )                                 
    }
    
    cppcc::scb::SyntaxControlledBinary::edpirType* eact =
      bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
        ,bin_.fixed(eidentalt, 0).d);
    if (eact) {
      switch (bin_.fixed(eact, 0).t) {
      case cppcc::com::PLS_IDENTIFIER:
      {
  	    //if(s= metagrfiden(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
    	metagrfiden(output,nnrule,bin_.fixed(eact, 0).d,symbols);
   	  
      }
      break;
      case cppcc::com::PLS_TERMTOKENOFRULE_TOKEN:
      {
  	    //if(s= metarfaddnxt(r,k,nnrule,uact.f[0].d,nta,len)) return(s);
    	metarfaddnxt(output,nnrule,bin_.fixed(eact, 0).d,symbols);
      }
      break;
      default:
      {
          ruleError(output, nnrule, errorUndefinedSimlpTerminal1);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << " tag:" << bin_.fixed(eidentalt, 0).t
            << " should be:" << cppcc::com::PLS_IDENTIFIER
            << " or:" << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
            << errorUndefinedSimlpTerminal1
          )                                 
   	  
      }
      }
    } 
  }	
}

////--------------------------------------------------------------
//int metagrfaltr(r,k,nnrule,nal,nta,len)
//
void
GenerateParserCC::metagrfaltr
(std::ofstream& 	   output
,std::size_t 		   nnrule
,cppcc::scr::tag::Long nal
//,std::set<int>&		   symbols
,metantmType::SymbolsContainer& symbols)
{
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
      ,nal);
  if (e && bin_.fixed(e)) {
    if (KW_IDENTALT !=  bin_.fixed(e, 1).t) {
        ruleError(output, nnrule, errorHereMustBeIdentAlt);
        CPPCC_THROW_EXCEPTION(
                << " rule:" << nnrule << " "
                << errorHereMustBeIdentAlt    
        )                                 
    }
 
    cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
      bin_.ptredp(help_.k(KW_IDENTALT).k_
        ,bin_.fixed(e,1).d);
    if (eidentalt) {
      if (eidentalt->dl == 0) {
    	// element of fixed part 
        //if(s= metagrfsimp(r,k,nnrule,uidentalt.f[0].t,uidentalt.f[0].d,
    	//	 nta,len)) return(s);
    	metagrfsimp(output, nnrule
    	  ,bin_.fixed(eidentalt,0).t, bin_.fixed(eidentalt,0).d, symbols);
   	  
      }
      else {
        // simple alternative or identifier 
        //if(s= metagrfalid(r,k,nnrule,u.f[1].d,nta,len)) return(s);
    	metagrfalid(output, nnrule, bin_.fixed(e,1).d, symbols);
      }
    }
  }
}


////--------------------------------------------------------------

// generate ( . . . )
//  if(s= metaaltr(output,ruleIndex,bin_.dynamic(e,i).d
//    ,i,iact)) return(s);          
//  if(s= metaaltr(r,k,nnrule,u.d[i].d,i,iact)) return(s);
void 
GenerateParserCC::metaaltr
(std::ofstream& 		output
,std::size_t 			nnrule
,cppcc::scr::tag::Long	nal
,cppcc::scr::tag::Long	iiii
,cppcc::scr::tag::Long	iact
)
{
  cppcc::scr::tag::Long	iii = iiii - iact;
  
  int isDebug = 1;
  if (isDebug) {
    std::cout
      << "metaaltr:0:"
      << " nnrule:" << nnrule
      << " nal:" << nal
      << " iiii:" << iiii
      << " iact:" << iact
      << std::endl;
  }


  cppcc::scb::SyntaxControlledBinary::edpirType*  e =
    bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
      ,nal);
  if (e && bin_.fixed(e)) {
    if (KW_IDENTALT != bin_.fixed(e, 1).t) {
      ruleError(output, nnrule, errorHereMustBeIdentAlt);
      CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << " tag:" << bin_.fixed(e, 1).t
          << " should be:"
          << " " << KW_IDENTALT
          << errorHereMustBeIdentAlt
      )  	
    }
    
    cppcc::scb::SyntaxControlledBinary::edpirType*  eidentalt =
      // BUG:ub 
      // bin_.ptredp(help_.k(KW_ALTERNATIVE).k_
      bin_.ptredp(help_.k(KW_IDENTALT).k_
        ,bin_.fixed(e, 1).d);
    if (eidentalt && bin_.fixed(eidentalt)) {
      if (KW_NTERMTERMACT != bin_.fixed(eidentalt,0).t) {
          ruleError(output, nnrule, errorHereMustINtermTermAct);
          CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << " tag:" << bin_.fixed(eidentalt,0).t
              << " should be:"
              << " " << KW_NTERMTERMACT
              << errorHereMustINtermTermAct
          )  	 	  
      }
      
      cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
        bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
          ,bin_.fixed(eidentalt,0).d);
      if (eact && bin_.fixed(eact)) {
    	 
        if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {
          //
          // ZZZ ::= ( 'a' | 'b' | . . . )
          //
        	
          if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {
            ruleError(output, nnrule, errorFirstItemOfAlternativeMustBe);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << " tag:" << bin_.fixed(eact, 0).t
              << " should be:"
              << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN 
              << errorFirstItemOfAlternativeMustBe
             )  	 	         	
          }
          
          for(cppcc::scr::tag::Long j=0; j < (eidentalt->dl); j++) {
        	if (KW_ALTPART != bin_.dynamic(eidentalt,j).t) {
                ruleError(output, nnrule, errorHereMustAlternative);
                CPPCC_THROW_EXCEPTION(
                  << " rule:" << nnrule << " "
                  << " tag:" << bin_.dynamic(eidentalt,j).t
                  << " should be:"
                  << " " << KW_ALTPART
                  << errorHereMustAlternative
                 )  	 	         	       		
        	}
        	
            cppcc::scb::SyntaxControlledBinary::edpirType*  ea =
              bin_.ptredp(help_.k(KW_ALTPART).k_
                ,bin_.dynamic(eidentalt,j).d);
            if (ea && bin_.fixed(ea)) {
              if (KW_NTERMTERMACT != bin_.fixed(ea,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(ea,1).t
                    << " should be:"
                    << " " << KW_NTERMTERMACT
                    << errorHereMustBeIterItemact
                   )  	 	         	       		           	  
              }
              
          	
              cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
                bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                  ,bin_.fixed(ea,1).d);
              if (eact && bin_.fixed(eact)) {
                  if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {
                    ruleError(output, nnrule, errorFirstItemOfAlternativeMustBe);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << " tag:" << bin_.fixed(eact, 0).t
                      << " should be:"
                      << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN 
                      << errorFirstItemOfAlternativeMustBe
                     )  	 	         	
                  }
            	
              } // if (eact && bin_.fixed(eact))   
            
            } // if (ea && bin_.fixed(ea))	
        	
          } // for j
        
          cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
            bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
              ,bin_.fixed(eidentalt,0).d);
          if (eact && bin_.fixed(eact)) {
        	generateKW(output, bin_.fixed(eact,0).d);
          } // if (eact && bin_.fixed(eact))
          

  if (isDebug) {
    std::cout
      << "metaaltr:1:"
      << " nnrule:" << nnrule
      << " nal:" << nal
      << " iiii:" << iiii
      << " iact:" << iact
      << " eidentalt->dl:" << eidentalt->dl
      << std::endl;
  }
          
          for(cppcc::scr::tag::Long j=0; j < (eidentalt->dl); j++) {
          
            cppcc::scb::SyntaxControlledBinary::edpirType*  ea =
              bin_.ptredp(help_.k(KW_ALTPART).k_
                ,bin_.dynamic(eidentalt,j).d);
            if (ea && bin_.fixed(ea)) {
              if (KW_NTERMTERMACT != bin_.fixed(ea,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(ea,1).t
                    << " should be:"
                    << " " << KW_NTERMTERMACT
                    << errorHereMustBeIterItemact
                   )                                        
              }
              
            
              cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
                bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                  ,bin_.fixed(ea,1).d);
              if (eact && bin_.fixed(eact)) {
                  if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {
                    ruleError(output, nnrule, errorFirstItemOfAlternativeMustBe);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << " tag:" << bin_.fixed(eact, 0).t
                      << " should be:"
                      << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN 
                      << errorFirstItemOfAlternativeMustBe
                     )                
                  }
              
                  generateKWAlt(output, bin_.fixed(eact, 0).d);
              } // if (eact && bin_.fixed(eact))   
            
            } // if (ea && bin_.fixed(ea))  
          
          } // for j         
        
          // fprintf(ff,"  ){\n");
          output << "  ){" << std::endl;
 
          //cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
          eact =
            bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
              ,bin_.fixed(eidentalt,0).d);
          if (eact && bin_.fixed(eact)) {
            std::string ckw = bin_.ptrids(bin_.fixed(eact, 0).d);
            ckw = upper(ckw);
            //fprintf(ff,"    pdbkwmis(KW_%s);\n",keyword);
            output 
            << "    pdbkwmis(KW_" 
            << ckw
            << ");" 
            << std::endl;
          } // if (eact && bin_.fixed(eact))
          
          
          for(cppcc::scr::tag::Long j=0; j < (eidentalt->dl); j++) {
          
            cppcc::scb::SyntaxControlledBinary::edpirType*  ea =
              bin_.ptredp(help_.k(KW_ALTPART).k_
                ,bin_.dynamic(eidentalt,j).d);
            if (ea && bin_.fixed(ea)) {
              if (KW_NTERMTERMACT != bin_.fixed(ea,1).t) {
                  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(ea,1).t
                    << " should be:"
                    << " " << KW_NTERMTERMACT
                    << errorHereMustBeIterItemact
                   )                                        
              }
              
            
              cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
                bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                  ,bin_.fixed(ea,1).d);
              if (eact && bin_.fixed(eact)) {
                  if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN != bin_.fixed(eact, 0).t) {
                    ruleError(output, nnrule, errorFirstItemOfAlternativeMustBe);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << " tag:" << bin_.fixed(eact, 0).t
                      << " should be:"
                      << " " << cppcc::com::PLS_TERMTOKENOFRULE_TOKEN 
                      << errorFirstItemOfAlternativeMustBe
                     )                
                  }
              
                  //generateKWAlt(output, bin_.fixed(eact, 0).d);
                  std::string ckw = bin_.ptrids(bin_.fixed(eact, 0).d);
                  ckw = upper(ckw);
                  output 
                  << "    pdbkwmis(KW_" 
                  << ckw
                  << ");" 
                  << std::endl;

              } // if (eact && bin_.fixed(eact))   
            
            } // if (ea && bin_.fixed(ea))  
          
          } // for j         
         
	      //fprintf(ff,"    edber(WRKEWO);\n");
	      //fprintf(ff,"  }\n");      
	      //fprintf(ff,"\n");
          output << "    edber();" << std::endl;
          output << "  }" << std::endl;
          output << std::endl;
          
  		  // fprintf(ff,"    skipkeywordTermToken(f");
          // if(iii) fprintf(ff,"+%d",iii);
          // fprintf(ff,",Kword);\n");     
      	  output << "  skipKeyWordTerm(kword(),f";
      	  output << "[" << iii << "]);" << std::endl;   	
          
   if (isDebug) {
    std::cout
      << "metaaltr:2:"
      << " nnrule:" << nnrule
      << " nal:" << nal
      << " iiii:" << iiii
      << " iact:" << iact
      << " eidentalt->dl:" << eidentalt->dl
      << std::endl;
  }         
          return;
        } //

   if (isDebug) {
    std::cout
      << "metaaltr:3:"
      << " nnrule:" << nnrule
      << " nal:" << nal
      << " iiii:" << iiii
      << " iact:" << iact
      << " eidentalt->dl:" << eidentalt->dl
      << std::endl;
  }  

        if (eidentalt->dl > 0) {
        
          // zzzzzzzzzzzz metagrfaltr
          metantmType::SymbolsContainer symbols;
          metagrfaltr(output, nnrule, nal, symbols);
        	
          if (bin_.fixed(eidentalt)) {
            if (KW_NTERMTERMACT != bin_.fixed(eidentalt,0).t) {
              ruleError(output, nnrule, errorHereMustBeIterItemact);
              CPPCC_THROW_EXCEPTION(
                  << " rule:" << nnrule << " "
                  << " tag:" << bin_.fixed(eidentalt,0).t
                  << " should be:"
                  << " " << KW_NTERMTERMACT
                  << errorHereMustBeIterItemact
               )                      	
            }
            
            cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                ,bin_.fixed(eidentalt,0).d);
            if (eact && bin_.fixed(eact)) {
                if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {
                  ruleError(output, nnrule, errorHereMustBeIdentifier);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" << bin_.fixed(eact, 0).t
                    << " should be:"
                    << " " << cppcc::com::PLS_IDENTIFIER 
                    << errorHereMustBeIdentifier
                   )                
                }
                
                /// generation is done here: aaaaaaaaaaaaaaa
                cppcc::scr::tag::Long   ndd = bin_.fixed(eact, 0).d;               
                cppcc::scr::tag::Long   rull;
                //if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
                metachnt(output, nnrule, ndd, &rull);
                if (-1 == rull) {

                  generateKW(output, ndd);
                  
                  //--                     
                  // generate 3 - actions 
                  //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                  metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
    
                //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                //if(iii) fprintf(ff,"+%d",iii);
                //fprintf(ff,")) return(s);\n");
                  output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                  // /* generate 0 - actions */
                  // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                  metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                  //--
                  
                  // fprintf(ff,"  }\n");
                  output << "  }" << std::endl;
                } 
                else {
                  metantmType&    ntmi = grammar_.rulval[rull];
                  
                  if (1 == ntmi.first.size()) {
                    cppcc::scr::tag::Long   ndd2 = *ntmi.first.begin();
                    
                    generateKW(output, ndd2);
                    
                    //--                     
                    // generate 3 - actions 
                    //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                    metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
      
                  //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                  //if(iii) fprintf(ff,"+%d",iii);
                  //fprintf(ff,")) return(s);\n");
                    output << bin_.ptrids(ndd2) << "(f[" << iii << "]);" << std::endl;  


                    // /* generate 0 - actions */
                    // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                    metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                    //--
                    // fprintf(ff,"  }\n");
                     output << "  }" << std::endl;
                  } 
                  else {
                    // fprintf(ff," else if(");
                  output << " if(" << std::endl; 

                  // loop processing first set.
                  metantmType::SymbolsContainer::const_iterator cIter =
                    ntmi.first.begin();
                  metantmType::SymbolsContainer::const_iterator cEnd =
                    ntmi.first.end();
                  
                  for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
                    cppcc::scr::tag::Long   ndd2 = (*cIter);
                    if (i) {
                      //fprintf(ff,"   || "); 
                      output << "        || " << std::endl;  
                    }

  
                    generateKWLoop(output, ndd2);
                  } // first
                  
                  if (ntmi.first.size() != 1) {
                    output << "    ";
                  }
                  
                //fprintf(ff,"){\n");
                //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
                //fprintf(ff,"  }\n");
                  output << "){" << std::endl;
                  
                  //--                     
                  // generate 3 - actions 
                  //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                  metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
    
                //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                //if(iii) fprintf(ff,"+%d",iii);
                //fprintf(ff,")) return(s);\n");
                  output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                  // /* generate 0 - actions */
                  // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                  metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                  //--

                  output << "  }" << std::endl;
                  } // 1 != ntm.first.size()
                  
                  
                } // -1 != rull
                                  
               
            } // if (eact && bin_.fixed(eact))
            
          } // if (bin_.fixed(eidentalt))
          
          if (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt)) {
              for (cppcc::scr::tag::Long j = 0; j < eidentalt->dl; j++) {
                if (KW_ALTPART !=  bin_.dynamic(eidentalt, j).t) {
                    ruleError(output, nnrule, errorHereMustBeAltpart);
                    CPPCC_THROW_EXCEPTION(
                      << " rule:" << nnrule << " "
                      << errorHereMustBeAltpart
                    )                                             
                }
              
                cppcc::scb::SyntaxControlledBinary::edpirType* ee =
                  bin_.ptredp(help_.k(KW_ALTPART).k_
                    ,bin_.dynamic(eidentalt, j).d);
                if (ee) {
                  if (bin_.fixed(ee)) {
                     if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
                          //ruleError(output, nnrule, errorHereMustBeIterItemact);
                        ruleError(output, nnrule, errorHereMustINtermTermAct);  
                      CPPCC_THROW_EXCEPTION(
                        << " rule:" << nnrule << " "
                        << errorHereMustINtermTermAct
                      )                                                       
                     }
                        
                     cppcc::scb::SyntaxControlledBinary::edpirType* eact =
                       bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                         ,bin_.fixed(ee, 1).d);
                     if (eact) {
                       if (bin_.fixed(eact)) {
                          if (cppcc::com::PLS_IDENTIFIER != bin_.fixed(eact, 0).t) {          
                            ruleError(output, nnrule, errorHereMustBeIdentifier);
                            CPPCC_THROW_EXCEPTION(
                              << " rule:" << nnrule << " "
                              << errorHereMustBeIdentifier
                            )                                             
                          }
                          
                          cppcc::scr::tag::Long   ndd = bin_.fixed(eact, 0).d;
     ///                     std::string  keyword1  = keyword(ndd);
     //                     std::string  keywordInt  = keyword(cppcc::com::PLS_INTEGER_TOKEN);
     //                     std::string  keywordFloat= keyword(cppcc::com::PLS_FLOAT_TOKEN);
                          
                          cppcc::scr::tag::Long     rull;
                          //if(s= metachnt(r,k,nnrule,ndd,&rull)) return(s);
                          metachnt(output, nnrule, ndd, &rull);
                          if (-1 == rull) {
                            /*
                            //if (IITT != keyword) {
                            if (cppcc::com::PLS_INTEGER_TOKEN != ndd) {
                              output 
                              << "    if(kword() == KW_" << keyword1 << ") {"
                              << std::endl;   
                            } else {
                            output 
                            << "    if((kword() == " << keywordInt
                            << ") || (kword() == " << keywordFloat
                            << ")) {"
                            << std::endl;                 
                            }
                            */
                            generateKW(output, ndd);
                            
                            //--                     
                            // generate 3 - actions 
                            //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                            metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
              
                          //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                          //if(iii) fprintf(ff,"+%d",iii);
                          //fprintf(ff,")) return(s);\n");
                            output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                            // /* generate 0 - actions */
                            // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                            metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                            //--
                            
                            // fprintf(ff,"  }\n");
                            output << "  }" << std::endl;
                          } 
                          else {
                            metantmType&    ntmi = grammar_.rulval[rull];
                            
                            if (1 == ntmi.first.size()) {
                              cppcc::scr::tag::Long   ndd2 = *ntmi.first.begin();
                              
                              // else if 33333333333333333333333
                              generateKW(output, ndd2);
                              
                              //--                     
                              // generate 3 - actions 
                              //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                              metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
                
                            //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                            //if(iii) fprintf(ff,"+%d",iii);
                            //fprintf(ff,")) return(s);\n");
                              output << bin_.ptrids(ndd2) << "(f[" << iii << "]);" << std::endl;  


                              // /* generate 0 - actions */
                              // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                              metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                              //--
                              //fprintf(ff,"  }\n");
                              output << "  }" << std::endl;
                            } 
                            else {
                              // fprintf(ff," else if(");
                            output << "  else if(" << std::endl; 

                            // loop processing first set.
                            metantmType::SymbolsContainer::const_iterator cIter =
                              ntmi.first.begin();
                            metantmType::SymbolsContainer::const_iterator cEnd =
                              ntmi.first.end();
                            
                            for (std::size_t i = 0; cIter != cEnd; cIter++,i++) {
                              cppcc::scr::tag::Long   ndd2 = (*cIter);
                              if (i) {
                                //fprintf(ff,"   || "); 
                                output << "        || " << std::endl;  
                              }

                             
                              generateKWLoop(output, ndd2);
                            } // first
                            
                            if (ntmi.first.size() != 1) {
                              output << "    ";
                            }
                            
                          //fprintf(ff,"){\n");
                          //fprintf(ff,"    if(s= %s(l)) return(s);\n",ptrids(r,ndd));
                          //fprintf(ff,"  }\n");
                            output << "){" << std::endl;
                            
                            //--                     
                            // generate 3 - actions 
                            //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                            metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
              
                          //fprintf(ff,"    if(s= %s(f",ptrids(r,ndd));
                          //if(iii) fprintf(ff,"+%d",iii);
                          //fprintf(ff,")) return(s);\n");
                            output << bin_.ptrids(ndd) << "(f[" << iii << "]);" << std::endl;  


                            // /* generate 0 - actions */
                            // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
                            metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);                    
                            //--

                            output << "  }" << std::endl;
                            } // 1 != ntm.first.size()
                            
                            
                          } // -1 != rull
                                            
                       }
                     }
                     
                    
                  }
                }
                
              } // j      
              
              
      		//// /* else part */     		
        	//// fprintf(ff,"  else {\n");
        	//// 
        	//// for(i= 0; i < flen; i++) {
        	//// 
        	////   nkw= ptrids(r,fnta[i]);
        	//// 
        	////   for(ii=0;kwd[ii]= toupper(*nkw); ii++,nkw++);
        	////   fprintf(ff,"    pdbkwmis(KW_%s);\n",kwd);
        	//// }
        	//// 
        	//// fprintf(ff,"    edber(WRKEWO);\n");
        	//// fprintf(ff,"  }\n");
              
              // loop processing first set.
              metantmType::SymbolsContainer::const_iterator sIter =
                symbols.begin();
              metantmType::SymbolsContainer::const_iterator sEnd =
            	symbols.end();
              
              //fprintf(ff,"  else {\n");
              output << "  else {" << std::endl;
              for (std::size_t q = 0; sIter != sEnd; sIter++,q++) {
                cppcc::scr::tag::Long   sndd = (*sIter);
                
                std::string snkw = bin_.ptrids(sndd);
                snkw = prefixKeyWord(snkw);
                //fprintf(ff,"    pdbkwmis(KW_%s);\n",kwd);
                output << "    pdbkwmis(" << snkw << ");" << std::endl;           
              } // q
          	  
              //// fprintf(ff,"    edber(WRKEWO);\n");
          	  //// fprintf(ff,"  }\n");
              output << "    edber();" << std::endl;     
              output << "  }" << std::endl;  
              
          } // (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt))
          else {
        	/// /* identifier or simple terminal */
            if (KW_NTERMTERMACT != bin_.fixed(eidentalt,0).t) {
                  ruleError(output, nnrule, errorHereMustBeIterItemact);
                  CPPCC_THROW_EXCEPTION(
                    << " rule:" << nnrule << " "
                    << " tag:" <<  bin_.fixed(eidentalt,0).t
                    << " should be:"
                    << " " << KW_NTERMTERMACT
                    << errorHereMustBeIterItemact
                   )                                        
            }
            
            cppcc::scb::SyntaxControlledBinary::edpirType*  eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                ,bin_.fixed(eidentalt,0).d);
            if (eact && bin_.fixed(eact)) {
                //--                     
                // generate 3 - actions 
                //if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) return(s);
                metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 3);
    		    
                // if(s= metaalone(r,k,nnrule,
                // 	uact.f[0].t,uact.f[0].d,iiii,iact))
                //   return(s);
                metaalone(output, nnrule
                	, bin_.fixed(eact, 0).t, bin_.fixed(eact, 0).d
                	, iiii,iact);
                
    		    // /* generate 0 - actions */
    		    // if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) return(s);
    		    metaactions(output, nnrule, bin_.fixed(eact, 1).t, bin_.fixed(eact, 1).d, 0);    
            }
        	  
          } // else --- (bin_.fixed(eidentalt) && bin_.dynamic(eidentalt))
         
          
        } // if (eidentalt->dl > 0)
        
    	 
      } // if (eact && bin_.fixed(eact))
    	
    	
    } // if (eidentalt && bin_.fixed(eidentalt))
    
	  
  } // if (e && bin_.fixed(e))
}

// if(s= metaalone(r,k,nnrule,
// 	uact.f[0].t,uact.f[0].d,iiii,iact))
//   return(s);
//metaalone(output, nnrule
//	, bin_.fixed(eact, 0).t, bin_.fixed(eact, 0).d
//	, iiii,iact);
// int metaalone(r,k,nnrule,t,d,iiii,iact)
void 
GenerateParserCC::metaalone
(std::ofstream& 		output
,std::size_t 			nnrule
,cppcc::scr::tag::Long	t
,cppcc::scr::tag::Long	d
,cppcc::scr::tag::Long	iiii
,cppcc::scr::tag::Long	iact
)
{
	cppcc::scr::tag::Long	iii = iiii - iact;
	
	if (cppcc::com::PLS_IDENTIFIER == t) {
	  // if(s= metachnt(r,k,nnrule,d,NULLINT)) return(s);
	  metachnt(output, nnrule, d, 0);
	}
	
	// fprintf(ff,"  if(s= %s(f",ptrids(r,d));
	//   if(iii) {
	//     fprintf(ff,"+%d",iii);
	//   }
	// 
	//   fprintf(ff,")) return(s);");
	output << "  "<< bin_.ptrids(d) << "(f[" << iii << "]);" << std::endl;
	
}


void 
GenerateParserCC::generateKWAlt
(std::ofstream&           output
,cppcc::scr::tag::Long    ndd)
{
  std::string kw = bin_.ptrids(ndd);
  kw = upper(kw);
  if (IITT_ != kw) {
  //kw = 
    output 
      << "  && (kword() != KW_" << kw << ")"
      << std::endl;   
  } else {
    output 
      << "  && ((kword() != " << predefinedIDs_[cppcc::com::PLS_INTEGER_TOKEN]
      << ") || (kword() == " << predefinedIDs_[cppcc::com::PLS_FLOAT_TOKEN]
      << "))"
      << std::endl;                 
  
  }
}



//  if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) 
//    return(0);
////if (s = metaactions(output,ruleIndex,
////  bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
//// )) return(s);	
void 
GenerateParserCC::metaactions
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long		actp
,cppcc::scr::tag::Long		acid
,cppcc::scr::tag::Long		vv
)
{
	   
//bool	isDebugBug = true;
bool	isDebugBug = false;
if (isDebugBug) {
std::cout << "metaactions:0:"
		<< " rule:" << ruleIndex 
		<< " actp:" << actp
		<< " acid:" << acid
		<< " vv:" <<vv
		<< std::endl;	
}



  if((actp == 0) && (acid == 0)) return;

  if (actp != KW_ACTIONS) {
    ruleError(output, ruleIndex, errorHereMustActions);
    CPPCC_THROW_EXCEPTION(
      << " rule:" << ruleIndex << " "
      << " tag:" << actp
      << " should be:" << KW_ACTIONS
      << errorHereMustActions    
    )
  }
  
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_ACTIONS).k_,acid);
  if (e && bin_.dynamic(e)) {
    for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
      switch (bin_.dynamic(e,i).t) {
      case cppcc::com::PLS_TERMINAL_TOKEN:
        break;
      case KW_ACTION:
        {
    	  //register int s = 0;
    	  //if(s= metaaction(r,k,nnrule,u.d[i].d,vv)) return(s);
	      //if(s= metaaction(output, ruleIndex, bin_.dynamic(e,i).d,vv)) 
	      //  return(s);
if (isDebugBug) {
        	std::cout << "metaactions:1:"
        			<< " rule:" << ruleIndex 
        			<< " actp:" << actp
        			<< " acid:" << acid
        			<< " vv:" <<vv
        			<< " i:" << i
        			<< std::endl;	
        	std::cout << "metaactions:2:"
        			<< " rule:" << ruleIndex 
        			<< " actp:" << actp
        			<< " acid:" << acid
        			<< " vv:" <<vv
        			<< " i:" << i
        			<< " di:" << bin_.dynamic(e,i).d
        			<< std::endl;	
}
        	
	      metaaction(output, ruleIndex, bin_.dynamic(e,i).d,vv);
if (isDebugBug) {
	              	std::cout << "metaactions:3:"
	              			<< " rule:" << ruleIndex 
	              			<< " actp:" << actp
	              			<< " acid:" << acid
	              			<< " vv:" <<vv
	              			<< " i:" << i
	              			<< std::endl;	
}
	      
	      
        }
      default:
    	break;
      }
    }
  }
  
  return;
}

//
//if (s = metasimp(output,ruleIndex,
//	bin_.dynamic(eact,0).t, bin_.dynamic(eact,0).d,
//	e, &i, iact
//  )) 
//  return(s);
//
int 
GenerateParserCC::metasimp
(std::ofstream& 			output
,std::size_t 				ruleIndex
,cppcc::scr::tag::Long		uit
,cppcc::scr::tag::Long		uid
,cppcc::scb::SyntaxControlledBinary::edpirType* e
,cppcc::scr::tag::Long*     iiii
,cppcc::scr::tag::Long 		iact
)
{
  if (!iiii) return 0;
  
  cppcc::scr::tag::Long i   = *iiii;
  cppcc::scr::tag::Long iii = i - iact;
  
  if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == uit) {
	  
    std::string	tn 	= bin_.ptrids(uid);	 
    
    //bool isDebugBug = true;
    bool isDebugBug = false;
    if (isDebugBug) {
      std::cout
      << "metasimp:"
      << " rule:" << ruleIndex
      << " t:" << uit
      << " d:" << uid
      << " tn:" << tn
      << std::endl;
    }
    
    
    bool 		y 	= false;
    for (std::size_t j = 0, z = tok_.language_->tokens_.tokens_.size(); 
    	j < z; j++) 
    {
      lex::Token* token = 
        tok_.language_->tokens_.tokens_[j];
 
      if (isDebugBug) {
        std::cout
        << "metasimp:"
        << " rule:" << ruleIndex
        << " t:" << uit
        << " d:" << uid
        << " tn:" << tn
        << " j:" << j
        << " z:" << z
        << " token:" << (token?token->name_:std::string(""))
        << std::endl;
      }
      
      
      if (token && (tn == token->name_)) {
    	  // BUG:
    	  //tn = token->token_;
    	  y = true;
    	  break;
      }
    }
    
    //BUG: reverse v.s ccc// if (!y) {
    if (y) {
        //  // XXX::= . . .')'   
    	//  fprintf(ff,"  skip%s(f",ckw);
    	//  if(iii) fprintf(ff,"+%d",iii);
    	//  fprintf(ff,");\n");
   	    // --
    	// skipgreaterthanTermToken(f+2);
    	// --
    	// skipToken(KW_GREATERTHAN_TERMTOKEN,f[2]);
    	// --
    	//kw// output << "  skipToken(" << tokenKeyWord(tn) << ",f";
    	output << "  skipToken(" << prefixKeyWord(tn) << ",f";
    	output << "[" << iii << "]);" << std::endl; 
    } else {
    	//kw// output << "  skipKeyWordTerm(" << tokenKeyWord(tn) << ",f";
    	output << "  skipKeyWordTerm(" << prefixKeyWord(tn) << ",f";
    	output << "[" << iii << "]);" << std::endl;   	
    }

    return 0;
  }
  
  if (cppcc::com::PLS_IDENTIFIER == uit) {
	//    fprintf(ff,"  if(s= %s(f",ckw);
	//    if(iii) fprintf(ff,"+%d",iii);
	//    fprintf(ff,")) return(s);\n");      
    //--
	//   if(s= nterm(f+1)) return(s);
	//--
	//    nterm(f[1]);
	//--
	std::string	tn 	= bin_.ptrids(uid);	  
	
	output << "  " << tn << "(f[" << iii << "]);" << std::endl; 
	  
	return 0;
  }
  
  ruleError(output, ruleIndex, errorWrongSimpleElement);  
  return 1;
}

void  
GenerateParserCC::metarigh
  (std::ofstream& 			output
  ,std::size_t 				ruleIndex
  ,cppcc::scr::tag::Long  	dNTerm
  ,cppcc::scr::tag::Long  	dRight)
{
  //int 			s = 0;
  int			iact = 0;
  std::string 	keyword;
  
  //bool			isDebugBug = true;
  bool			isDebugBug = false;
  
if (isDebugBug) {
  std::cout << "metarigh:0:" 
	<< " rule:" << ruleIndex
	<< " nterm:" << dNTerm
	<< " right:" << dRight
	<< std::endl;  
}
  
  cppcc::scb::SyntaxControlledBinary::edpirType* eru =
    bin_.ptredp(help_.k(KW_RULE).k_,ruleIndex);
  if (eru && bin_.fixed(eru)) {
    if (bin_.fixed(eru, 1).t != cppcc::com::PLS_IDENTIFIER) {
      ruleError(output, ruleIndex, errorHereMustBeIdentifier);
      CPPCC_THROW_EXCEPTION(
        << " rule:" << ruleIndex << " "
        << " tag:" << bin_.fixed(eru, 1).t
        << " should be:" << cppcc::com::PLS_IDENTIFIER
        << errorHereMustBeIdentifier    
      )
    }
    
    //keyword = bin_.ptrids(bin_.fixed(eru, 1).d);	 
    //for(register std::size_t i = 0, z = keyword.size(); i < z; i++) {
    //	keyword[i] = toupper(keyword[i]);
    //}
    //keyword = upper(bin_.ptrids(bin_.fixed(eru, 1).d));
    keyword = bin_.ptrids(bin_.fixed(eru, 1).d);
  }

  
  if (isDebugBug) {
    std::cout << "metarigh:1:" 
  	<< " rule:" << ruleIndex
  	<< " nterm:" << dNTerm
  	<< " right:" << dRight
  	<< " kw:" << keyword
  	<< std::endl;  
  }

  
  cppcc::scb::SyntaxControlledBinary::edpirType* e =
    bin_.ptredp(help_.k(KW_RIGHT).k_,dRight);
  if (e && bin_.dynamic(e)) {
    if ((e->dl == 1) && (bin_.dynamic(e,0).t == KW_IDENTALT)) {
      // simple alternative or identifier:
      //sss// if (s = metaalid(output, ruleIndex, bin_.dynamic(e,0).d)) return(s);
    	  
if (isDebugBug) {
    	    std::cout << "metarigh:2:before:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" 
    	  	<< " rule:" << ruleIndex
    	  	<< " nterm:" << dNTerm
    	  	<< " right:" << dRight
    	  	<< " kw:" << keyword
    	  	<< " metaalid:" << bin_.dynamic(e,0).d
    	  	<< std::endl;  
}

    	metaalid(output, ruleIndex, bin_.dynamic(e,0).d);
  	  
if (isDebugBug) {
    	    	    std::cout << "metarigh:2:after:@@@@@@@@@@@@@@@@@@@@@@@@@@@" 
    	    	  	<< " rule:" << ruleIndex
    	    	  	<< " nterm:" << dNTerm
    	    	  	<< " right:" << dRight
    	    	  	<< " kw:" << keyword
    	    	  	<< " metaalid:" << bin_.dynamic(e,0).d
    	    	  	<< std::endl;  
}
    	
    } else {
      // all other cases:
      int firstMiss= 1;
  	  
if (isDebugBug) {
          	    	    std::cout << "metarigh:3:loop:" 
          	    	  	<< " rule:" << ruleIndex
          	    	  	<< " nterm:" << dNTerm
          	    	  	<< " right:" << dRight
          	    	  	<< " kw:" << keyword
          	    	  	<< " e->dl:" << e->dl
          	    	  	<< std::endl;  
}
      
	  for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
        cppcc::scr::tag::Long t = bin_.dynamic(e,i).t;
        
if (isDebugBug) {
         	std::cout << "metarigh:3:loop:" 
         	<< " rule:" << ruleIndex
        	<< " nterm:" << dNTerm
           	<< " right:" << dRight
         	<< " kw:" << keyword
         	<< " e->dl:" << e->dl
         	<< " i:" << i
         	<< " t:" << t
         	<< std::endl;  
}

        if (KW_ITERATION == t) {
          firstMiss= 1;
          
if (isDebugBug) {
                   	std::cout << "metarigh:4:before:metaiter" 
                   	<< " rule:" << ruleIndex
                  	<< " nterm:" << dNTerm
                     	<< " right:" << dRight
                   	<< " kw:" << keyword
                   	<< " e->dl:" << e->dl
                   	<< " i:" << i
                   	<< " t:" << t
                   	<< std::endl;  
}
         
          // generate iteration:
          metaiter(output, ruleIndex, e, eru, i);
          
if (isDebugBug) {
                   	std::cout << "metarigh:4:after:metaiter" 
                   	<< " rule:" << ruleIndex
                  	<< " nterm:" << dNTerm
                     	<< " right:" << dRight
                   	<< " kw:" << keyword
                   	<< " e->dl:" << e->dl
                   	<< " i:" << i
                   	<< " t:" << t
                   	<< std::endl;  
}
          
    	  for (; i < z; i++) {
    	    if (bin_.dynamic(e,i).t == KW_ACTION) {
    	      //if(s= metaaction(output, ruleIndex, bin_.dynamic(e,i).d,0)) 
    	      //  return(s);
if (isDebugBug) {
    	std::cout << "metarigh:5:before:metaaction" 
    		<< " rule:" << ruleIndex
    	  	<< " nterm:" << dNTerm
    	   	<< " right:" << dRight
    	  	<< " kw:" << keyword
    	  	<< " e->dl:" << e->dl
    	   	<< " i:" << i
    		<< " t:" << t
    	 	<< std::endl;  
}
   	    	
    	      metaaction(output, ruleIndex, bin_.dynamic(e,i).d,0);
if (isDebugBug) {
    	          	std::cout << "metarigh:5:after:metaaction" 
    	          		<< " rule:" << ruleIndex
    	          	  	<< " nterm:" << dNTerm
    	          	   	<< " right:" << dRight
    	          	  	<< " kw:" << keyword
    	          	  	<< " e->dl:" << e->dl
    	          	   	<< " i:" << i
    	          		<< " t:" << t
    	          	 	<< std::endl;  
}

    	    }
    	  }
    	  
    	  break;
        }
        else if (KW_IDENTMISS == t) {
          // [ . . . ] generation 
          int yy = 0;
  	      if((i+1) < (e->dl)) 
  	        yy= (bin_.dynamic(e,i+1).t == KW_IDENTMISS);
  	      
  	        //if(s= metamiss(output,ruleIndex,bin_.dynamic(e,i).d
  	        //  ,i,yy,&firstMiss,iact,
  			//(i == ((e->dl) - 1)))) return(s);
if (isDebugBug) {
  	        	          	std::cout << "metamiss:6:before:metamiss" 
  	        	          		<< " rule:" << ruleIndex
  	        	          	  	<< " nterm:" << dNTerm
  	        	          	   	<< " right:" << dRight
  	        	          	  	<< " kw:" << keyword
  	        	          	  	<< " e->dl:" << e->dl
  	        	          	   	<< " i:" << i
  	        	          		<< " t:" << t
  	        	          	 	<< std::endl;  
}

  	       metamiss(output,ruleIndex,bin_.dynamic(e,i).d
  	      	        ,i,yy,&firstMiss,iact,
  	      			(i == ((e->dl) - 1)));
if (isDebugBug) {
  	       	        	          	std::cout << "metamiss:6:after:metamiss" 
  	       	        	          		<< " rule:" << ruleIndex
  	       	        	          	  	<< " nterm:" << dNTerm
  	       	        	          	   	<< " right:" << dRight
  	       	        	          	  	<< " kw:" << keyword
  	       	        	          	  	<< " e->dl:" << e->dl
  	       	        	          	   	<< " i:" << i
  	       	        	          		<< " t:" << t
  	       	        	          	 	<< std::endl;  
}

  	      if(i == ((e->dl) - 1)) {
  	        // end of fixed part
  	        //fprintf(ff,"  crefixe(KW_%s);\n",keyword);
  	    	output 
  	    	<< "  " << "crefixe("
  	    	//kw// << nonTerminalKeyWord(keyword)
  	    	<< prefixKeyWord(keyword)
  	    	<< ",f,&tag);"
  	    	<< std::endl;
  	    	// e.g.:
  	    	// crefixe(KW_MAYBENTERM,f,&tag);
  	      }         
        }
        else if (KW_ALTERNATIVE == t) {
          // ( . . . ) generation
          firstMiss= 1;
  	      //if(s= metaaltr(output,ruleIndex,bin_.dynamic(e,i).d
  	      //  ,i,iact)) return(s);    
if (isDebugBug) {
            	       std::cout << "metamiss:7:before:metaaltr" 
            	       	        	          		<< " rule:" << ruleIndex
            	       	        	          	  	<< " nterm:" << dNTerm
            	       	        	          	   	<< " right:" << dRight
            	       	        	          	  	<< " kw:" << keyword
            	       	        	          	  	<< " e->dl:" << e->dl
            	       	        	          	   	<< " i:" << i
            	       	        	          		<< " t:" << t
            	       	        << std::endl;  
}

          metaaltr(output,ruleIndex,bin_.dynamic(e,i).d,i,iact);
if (isDebugBug) {
                      	       std::cout << "metamiss:7:after:metaaltr" 
                      	       	        	          		<< " rule:" << ruleIndex
                      	       	        	          	  	<< " nterm:" << dNTerm
                      	       	        	          	   	<< " right:" << dRight
                      	       	        	          	  	<< " kw:" << keyword
                      	       	        	          	  	<< " e->dl:" << e->dl
                      	       	        	          	   	<< " i:" << i
                      	       	        	          		<< " t:" << t
                      	       	        << std::endl;  
}
         
    	  if(i == ((e->dl) - 1)) {
    	    // end of fixed part
    	    output 
    	      << "  " << "crefixe("
    	      //kw// << nonTerminalKeyWord(keyword)
    	      << prefixKeyWord(keyword)
    	      << ",f,&tag);"
    	      << std::endl;
    	      // e.g.:
    	      // crefixe(KW_MAYBENTERM,f,&tag);
    	   }         
        }
        else if (KW_ACTION == t) {
          iact++;
          firstMiss= 1;
    	  if(i == ((e->dl) - 1)) {
    	    // end of fixed part
    	    output 
    	      << "  " << "crefixe("
    	      //kw//<< nonTerminalKeyWord(keyword)
    	      << prefixKeyWord(keyword)
    	      << ",f,&tag);"
    	      << std::endl;
     	  }   
    	  
    	  if (isDebugBug) {
    	      	      std::cout << "metamiss:8:before:metaaction" 
    	      	                  << " rule:" << ruleIndex
    	      	                 << " nterm:" << dNTerm
    	      	                << " right:" << dRight
    	      	               << " kw:" << keyword
    	      	               << " e->dl:" << e->dl
    	      	                << " i:" << i
    	      	              << " t:" << t
    	      	    << std::endl;  
    	  }
          
    	  //if(s= metaaction(output,ruleIndex,bin_.dynamic(e,i).d,0)) return(s);
    	  metaaction(output,ruleIndex,bin_.dynamic(e,i).d,0);
if (isDebugBug) {
    	      std::cout << "metamiss:8:after:metaaction" 
    	                        	       	        	          		<< " rule:" << ruleIndex
    	                        	       	        	          	  	<< " nterm:" << dNTerm
    	                        	       	        	          	   	<< " right:" << dRight
    	                        	       	        	          	  	<< " kw:" << keyword
    	                        	       	        	          	  	<< " e->dl:" << e->dl
    	                        	       	        	          	   	<< " i:" << i
    	                        	       	        	          		<< " t:" << t
    	    << std::endl;  
}
    	       	  
        }
        else if (KW_IDENTALT == t) {
          firstMiss= 1;
if (isDebugBug) {
	 std::cout << "metamiss:9:KW_IDENTALT" 
    	<< " rule:" << ruleIndex
    	<< " nterm:" << dNTerm
    	<< " right:" << dRight
    	<< " kw:" << keyword
    	<< " e->dl:" << e->dl
    	<< " i:" << i
		<< " t:" << t
    	<< std::endl;  
}
          
          cppcc::scb::SyntaxControlledBinary::edpirType* eidentalt =
            bin_.ptredp(help_.k(KW_IDENTALT).k_
              ,bin_.dynamic(e,i).d);
          //??? bug???/ if (eidentalt && !bin_.dynamic(eidentalt)) {
          if (eidentalt && (eidentalt->dl == 0)) {
            // element of fixed part:
            
        	//BUG:// if (bin_.dynamic(eidentalt, 0).t != KW_NTERMTERMACT) {
        	if (bin_.fixed(eidentalt, 0).t != KW_NTERMTERMACT) {
      		  //return(ruleError(r,k,nnrule,
      		  //		  "here must be 'iterItemact'"));
		      ruleError(output, ruleIndex, errorHereMustINtermTermAct);
		      CPPCC_THROW_EXCEPTION(
		        << " rule:" << ruleIndex << " "
		        << " tag:" << bin_.dynamic(eidentalt, 0).t 
		        << " should be:" << KW_NTERMTERMACT
		        << errorHereMustINtermTermAct    
		      )
        	}
 
            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_
                // BUG// ,bin_.dynamic(eidentalt,0).d);
                ,bin_.fixed(eidentalt,0).d);
            if (eact && bin_.fixed(eact)) {
    		  //    /* generate 3 - actions */
    		  //  if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,3)) 
    		  //    return(0);
              //  
              //if (s = metaactions(output,ruleIndex,
              //  bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
              // )) return(s);	
if (isDebugBug) {
            		 std::cout << "metamiss:9:KW_IDENTALT:bef:metaactions" 
            	    	<< " rule:" << ruleIndex
            	    	<< " nterm:" << dNTerm
            	    	<< " right:" << dRight
            	    	<< " kw:" << keyword
            	    	<< " e->dl:" << e->dl
            	    	<< " i:" << i
            			<< " t:" << t
            	    	<< std::endl;  
}
              metaactions(output,ruleIndex,
                 //BUG:// bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 3
                 bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 3
              );
if (isDebugBug) {
  std::cout << "metamiss:9:KW_IDENTALT:after:metaactions" 
  << " rule:" << ruleIndex
  << " nterm:" << dNTerm
   << " right:" << dRight
    << " kw:" << keyword
    << " e->dl:" << e->dl
    << " i:" << i
    << " t:" << t
    << std::endl;  
}
            	
    		  //  if(s= metasimp(r,k,nnrule,uact.f[0].t,
    		  //		   uact.f[0].d,e,&u,&i,iact)) return(s); 
			  //if (s = metasimp(output,ruleIndex,
			  //	bin_.dynamic(eact,0).t, bin_.dynamic(eact,0).d,
		      //		e, &i, iact
			  //  )) 
			  //  return(s);
              metasimp(output,ruleIndex,
            		  //BUG:// bin_.dynamic(eact,0).t, bin_.dynamic(eact,0).d,
                bin_.fixed(eact,0).t, bin_.fixed(eact,0).d,
              	  e, &i, iact
              );
if (isDebugBug) {
                std::cout << "metamiss:9:KW_IDENTALT:after:metasimp" 
                << " rule:" << ruleIndex
                << " nterm:" << dNTerm
                 << " right:" << dRight
                  << " kw:" << keyword
                  << " e->dl:" << e->dl
                  << " i:" << i
                  << " t:" << t
                  << std::endl;  
}
              
    		  //  /* generate 0 - actions */
    		  //  if(s= metaactions(r,k,nnrule,uact.f[1].t,uact.f[1].d,0)) 
    		  //    return(0);
              //if (s = metaactions(output,ruleIndex,
              //  bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 0
              // )) return(s);	
              metaactions(output,ruleIndex,
            		  //BUG:// bin_.dynamic(eact,1).t, bin_.dynamic(eact,1).d, 0
                bin_.fixed(eact,1).t, bin_.fixed(eact,1).d, 0
              );
              
if (isDebugBug) {
std::cout << "metamiss:9:KW_IDENTALT:after:metaactions" 
                              << " rule:" << ruleIndex
                              << " nterm:" << dNTerm
                               << " right:" << dRight
                                << " kw:" << keyword
                                << " e->dl:" << e->dl
                                << " i:" << i
                                << " t:" << t
                                << std::endl;  
}            
            }
        	
    	    if(i == ((e->dl) - 1)) {
    	      // end of fixed part
    	      output 
    	        << "  " << "crefixe("
    	        //kw// << nonTerminalKeyWord(keyword)
    	        << prefixKeyWord(keyword)
    	        << ",f,&tag);"
    	        << std::endl;
     	    }    
          }
        }
        else {
          // nothing to do.
        }
        
        output << std::endl;
	  } // i
    }
  }
  
  return;
}

void 
GenerateParserCC::generateRuleBody
	    (std::ofstream& 		output
		,std::size_t 			ruleIndex
		,cppcc::scr::tag::Long  dNTerm
        ,cppcc::scr::tag::Long  dRight)
{
	  bool	isFullRun = false;
	  
	  if (metadynp(output, dNTerm, dRight)) {
	    output << "  TagVector d;" << std::endl; 
		//if (isFullRun) {
	      metaangl(output, dNTerm, dRight);
		//}
	  }

	  int fixedSize = metafixe(output, dNTerm, dRight);
	  if (fixedSize > 0) {
	    output << "  TagVector f(" << fixedSize << ");" << std::endl; 
	  }
	  
	  output << std::endl; 
	  
	  //int s = metarigh(output, ruleIndex, dNTerm, dRight);
	  //GlobalReturnCode_= GlobalReturnCode_ || s;

	  //if (isFullRun) {
	    metarigh(output, ruleIndex, dNTerm, dRight);
	  //}
	  
	  output << std::endl; 
}	
	
	
std::string 
GenerateParserCC::axiomRuleName()
{
		//return "grammar";
		//return "metafirst";
		std::string gn("");
		cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
		  binary_.generator_.parser_.runtime_.cnms_.dataByKey
			(binary_.generator_.parser_.runtime_.cnmnumCurrent_);
		cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
		  binary_.generator_.parser_.runtime_.
		    kwnLookup(KW_RULE);
		cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
		  kwnInstance.edps_.dataByIndex(0);
		if (edpInstance.edpfix_.size() >= 2) {
		  cppcc::scr::tag::Long k;
		  cppcc::scr::tag::Long n;
	      cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
	      //if (KW_IDENTIFIER_TOKEN == k) {
	      if (cppcc::com::PLS_IDENTIFIER == k) {
	        cppcc::scr::SyntaxControlledRuntime::nam namInstance=
	   	      currentContext.namn_.dataByIndex(n);
	        gn = namInstance.namkey_;
	      }
		}
		
		return gn;
}
	
void 
GenerateParserCC::generate()
{
/*
		cppcc::scb::SyntaxControlledBinary&	bin=
		  binary_.generator_.parser_.binary_;
		cppcc::scb::SyntaxControlledBinary::Helper help
		  (bin, KW_KEYWORDS_TOTAL);
		cppcc::lex::Tokenizer&				tok =
		  binary_.generator_.parser_.tokenizer_;
*/
		//binary_.generator_.parser_.binary_.setkeywor(kwns_);
		//33// bin.setkeywor(kwns_);
		
		//std::string     axn = binary_.generator_.parser_.axiomRuleName();
		std::string     axn = axiomRuleName();

		std::string 	ext = "Parser.cc";
		std::string 	gn  = name(filename_);
		std::string 	fe  = extention(filename_);
		std::string 	fn  = gn+ext;
		std::ofstream 	output;  	
		
		bool	isFullRun = false;
		
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
				<< "Can't open file for writing gnerated code:'"
				<< fn
				<< "' - Reason:'"
				<< syserr
				<< "'"
			)
		}
		
		//bool isHelpDump = false;
		//bool isHelpDump = true;
		bool isHelpDump = false;
		if (isHelpDump) {
			output << "---------------------------" << std::endl;
			help_.dump(output);
			output << "---------------------------" << std::endl;
		}

		for (std::size_t i = 0; i < ParserCCCodeStartSize; i++) {
			output << line(ParserCCCodeStart[i], gn,axn) << std::endl;
		}

/////	
		cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		     help_.k(KW_RULE);
		//if (k.k_) {
		if (k) {
		  //if (isFullRun) {
		    //std::cout << "checkGrammar:0:" <<std::endl;
		    checkGrammar(output);
		    //std::cout << "checkGrammar:1:" <<std::endl;
		    
		    //BUG: should be here:// 
		    //CheckMode_ = 1;
		    
		    generateFirstFollow(output);
		    //std::cout << "generateFirstFollow:2:" <<std::endl;
		  //}
		  
		  //BUG:// 
		  CheckMode_ = 1;
			
	      for (std::size_t i = 0, z = k.edps_.size(); i < z; i++) {
	        cppcc::scb::SyntaxControlledBinary::Helper::edp& e = k.e(i);
	        	
	        //33// cppcc::scr::tag::TypeInstance&  kn  = bin.fixed(e,1);
	        cppcc::scr::tag::TypeInstance&  kn  = e.fixed(1);
			if (cppcc::com::PLS_IDENTIFIER != kn.t) {
				tok_.errorMessage(errorNoIdentifierFound);
					CPPCC_THROW_EXCEPTION(
				      << errorNoIdentifierFound
				      << " rule:" << i << " k:" << kn.t << " n:" << kn.d
				  	)
			}

			//33// cppcc::scr::tag::TypeInstance&  knr = bin.fixed(e,3);
			cppcc::scr::tag::TypeInstance&  knr = e.fixed(3);
			if (KW_RIGHT != knr.t) {
				tok_.errorMessage(errorNoRightEntryFound);
				 	CPPCC_THROW_EXCEPTION(
				      << errorNoRightEntryFound
				      << " rule:" << i << " k:" << knr.t << " n:" << knr.d
				  	)
			}
	            
			cppcc::scr::tag::Long rule;
			cppcc::scr::tag::setedflong(&rule,KW_RULE,i);
			//if (isFullRun) {
		    //std::cout << "checkGrammar:3:metaactglob:0" <<std::endl;
			  metaactglob(output, i);
			//std::cout << "checkGrammar:3:metaactglob:1" <<std::endl;
			  metaactnewf(output, i);
			//std::cout << "checkGrammar:3:metaactnewf:1" <<std::endl;
			//}
				
			output << "void" << std::endl;
			output 
				<< gn << "Parser" << "::" 
				//<< bin_.ptrids(kn.d)
				//<< help_.ids_[kn.d]
				<< help_.id(kn.d)
				// (A.1) added arg:
				<< "(cppcc::scr::tag::Long& tag)"
				<< std::endl;
			output << "/*" << std::endl;
			binary_.generator_.binary_->scDecompile_(output, rule);
			output << std::endl;
			output << "*/" << std::endl;
			output << "{" << std::endl;	
				
			generateRuleBody(output, i, kn.d, knr.d);
				
			output << "}" << std::endl;			
			output << std::endl;	
		  }
		}
/////		
		for (std::size_t i = 0; i < ParserCCCodeFinishSize; i++) {
			output << line(ParserCCCodeFinish[i], gn, axn, fe) << std::endl;
		}	
}


}
// namespace: implementtaion.


void        
metaFirstGeneratorBinary::generate(const std::string& filename)
{
  GenerateKeyWordsContainer g0(*this, filename);

	GenerateGeneratorH 				g1(*this, filename);
	
  // ub:
	//GenerateKeyWordDefinitionH 		g2(*this, filename);
	V2GenerateKeyWordDefinitionH 		g2(g0);

	GenerateParserH					g3(*this, filename);
	GenerateGeneratorCC				g4(*this, filename);
	
  //GenerateKeyWordDefinitionCC		g5(*this, filename);
  V2GenerateKeyWordDefinitionCC		g5(g0);

	GenerateMakeGeneratorsCC		g6(*this, filename);
	GenerateParserCC				g7(*this, filename);
}

}
}



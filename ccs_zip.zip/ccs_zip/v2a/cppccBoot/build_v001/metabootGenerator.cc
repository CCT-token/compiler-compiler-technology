/////////////////////////////////////////////////////////////////////
//  metabootGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metabootParser.h"
#include "metabootKeyWordDefinition.h"
#include "metabootGenerator.h"

namespace cppcc {
namespace metaboot {

void
metabootGeneratorBinary::generate(const std::string& filename)
{
}

}
}

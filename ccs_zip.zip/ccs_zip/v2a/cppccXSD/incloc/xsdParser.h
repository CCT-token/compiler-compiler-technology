/////////////////////////////////////////////////////////////////////
//  xsdParser.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_xsd_PARSER_H_
#define  _CPPCC_xsd_PARSER_H_

#include "Parser.h"

namespace cppcc {

namespace cmp {
  class Compiler;
}

namespace xsd {

class xsdParser
  : public cppcc::syn::Parser
{

public:
  xsdParser 
    (cppcc::log::Logger&          logger
    ,cppcc::com::KeyWordsContainer&   theKeyWords
    ,cppcc::com::LanguageTokenizerSet   theLanguage
    ,cppcc::lex::TokenizerReader    theReader)
  : Parser(logger, theKeyWords, theLanguage, theReader)
  {
  }

  ~xsdParser()
  {
  }

  void compile
    (const char *sour, const char *list);

  void compile
      (const std::string& filename
      ,const std::string& sourceString
    ,bool         isListing);


  void grammar(cppcc::scr::tag::Long& tag);
  void xmlVersion(cppcc::scr::tag::Long& tag);
  void xmlVersionAttributes(cppcc::scr::tag::Long& tag);
  void attribute(cppcc::scr::tag::Long& tag);
  void attributeExtention(cppcc::scr::tag::Long& tag);
  void attributes(cppcc::scr::tag::Long& tag);
  void xmlTag(cppcc::scr::tag::Long& tag);
  void xmlTagEndOrTags(cppcc::scr::tag::Long& tag);
  void xmlTagEnd(cppcc::scr::tag::Long& tag);
  void xmlTagID(cppcc::scr::tag::Long& tag);
  void xmlTagIDExtention(cppcc::scr::tag::Long& tag);
  void xmlTags(cppcc::scr::tag::Long& tag);
  void xmlTagsList(cppcc::scr::tag::Long& tag);
};

}
}

#endif

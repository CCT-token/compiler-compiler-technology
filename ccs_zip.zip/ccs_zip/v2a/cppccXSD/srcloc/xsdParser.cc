/////////////////////////////////////////////////////////////////////
//  xsdParser.cc 
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "xsdParser.h"
#include "xsdKeyWordDefinition.h"

namespace cppcc {
namespace xsd {

void
xsdParser::compile
  (const char *sour, const char *list)
{
  CPPCC_LOG_INFO(logger_,
    << "xsdParser::compile() "
    << " source:" << "'" << std::string(sour?sour:"") << "'"
    << " listing:" << "'" << std::string(list?list:"") << "'"
  )

  filename_ = sour?sour:"";
  tokenizer_.start(sour, list);

  grammar(axiom_);

  tokenizer_.erfini();
}

void
xsdParser::compile
    (const std::string& filename
    ,const std::string& sourceString
  ,bool         isListing)
{
  filename_ = filename;
  tokenizer_.start(sourceString, isListing);

  grammar(axiom_);

  tokenizer_.erfini();
}

void
xsdParser::grammar(cppcc::scr::tag::Long& tag)
/*
 ( grammar ::= 0 = "  METAACTBEG();" = xmlVersion xmlTag 0 = "  METAACTEND();" = )
*/
{
  TagVector f(2);

  METAACTBEG();

  xmlVersion(f[0]);

  xmlTag(f[1]);

  crefixe(KW_GRAMMAR,f,&tag);
  METAACTEND();


}

void
xsdParser::xmlVersion(cppcc::scr::tag::Long& tag)
/*
 ( xmlVersion ::= '<' '?' identifier xmlVersionAttributes '>' )
*/
{
  TagVector f(5);

  skipToken(KW_LESSTHENTERMTOKEN,f[0]);

  skipToken(KW_QUESTIONMARKTERMTOKEN,f[1]);

  identifier(f[2]);

  xmlVersionAttributes(f[3]);

  skipToken(KW_GREATERTHENTERMTOKEN,f[4]);
  crefixe(KW_XMLVERSION,f,&tag);


}

void
xsdParser::xmlVersionAttributes(cppcc::scr::tag::Long& tag)
/*
 ( xmlVersionAttributes ::= attributes '?' )
*/
{
  TagVector f(2);

  attributes(f[0]);

  skipToken(KW_QUESTIONMARKTERMTOKEN,f[1]);
  crefixe(KW_XMLVERSIONATTRIBUTES,f,&tag);


}

void
xsdParser::attribute(cppcc::scr::tag::Long& tag)
/*
 ( attribute ::= identifier [ attributeExtention ] '=' stringToken )
*/
{
  TagVector f(4);

  identifier(f[0]);

  f[1]=0;
    if(kword() == KW_COLONMARKTERMTOKEN) {
attributeExtention(f[1]);
  }

  skipToken(KW_EQUALTERMTOKEN,f[2]);

  stringToken(f[3]);
  crefixe(KW_ATTRIBUTE,f,&tag);


}

void
xsdParser::attributeExtention(cppcc::scr::tag::Long& tag)
/*
 ( attributeExtention ::= ':' identifier )
*/
{
  TagVector f(2);

  skipToken(KW_COLONMARKTERMTOKEN,f[0]);

  identifier(f[1]);
  crefixe(KW_ATTRIBUTEEXTENTION,f,&tag);


}

void
xsdParser::attributes(cppcc::scr::tag::Long& tag)
/*
 ( attributes ::= { attribute } )
*/
{
  TagVector d;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_IDENTIFIER) {
	  d.push_back(0);
	  attribute(d.back());
    }
    else break;

  }

  crelasdyn(KW_ATTRIBUTES,d,&tag);

}

void
xsdParser::xmlTag(cppcc::scr::tag::Long& tag)
/*
 ( xmlTag ::= '<' xmlTagID attributes xmlTagEndOrTags )
*/
{
  TagVector f(4);

  skipToken(KW_LESSTHENTERMTOKEN,f[0]);

  xmlTagID(f[1]);

  attributes(f[2]);

  xmlTagEndOrTags(f[3]);
  crefixe(KW_XMLTAG,f,&tag);


}

void
xsdParser::xmlTagEndOrTags(cppcc::scr::tag::Long& tag)
/*
 ( xmlTagEndOrTags ::= xmlTagEnd | xmlTags )
*/
{

    if(kword() == KW_SLASHMARKTERMTOKEN) {
    xmlTagEnd(tag);
  }
  else if((kword() == KW_GREATERTHENTERMTOKEN)
  ){
    xmlTags(tag);
  }
  else {
    pdbkwmis(KW_GREATERTHENTERMTOKEN);
    pdbkwmis(KW_SLASHMARKTERMTOKEN);
    edber();
  }

}

void
xsdParser::xmlTagEnd(cppcc::scr::tag::Long& tag)
/*
 ( xmlTagEnd ::= '/' 0 = "  xmlTokenOn();" = '>' )
*/
{
  TagVector f(2);

  skipToken(KW_SLASHMARKTERMTOKEN,f[0]);

  xmlTokenOn();

  skipToken(KW_GREATERTHENTERMTOKEN,f[1]);
  crefixe(KW_XMLTAGEND,f,&tag);


}

void
xsdParser::xmlTagID(cppcc::scr::tag::Long& tag)
/*
 ( xmlTagID ::= identifier [ xmlTagIDExtention ] )
*/
{
  TagVector f(2);

  identifier(f[0]);

  f[1]=0;
    if(kword() == KW_COLONMARKTERMTOKEN) {
xmlTagIDExtention(f[1]);
  }
  crefixe(KW_XMLTAGID,f,&tag);


}

void
xsdParser::xmlTagIDExtention(cppcc::scr::tag::Long& tag)
/*
 ( xmlTagIDExtention ::= ':' identifier )
*/
{
  TagVector f(2);

  skipToken(KW_COLONMARKTERMTOKEN,f[0]);

  identifier(f[1]);
  crefixe(KW_XMLTAGIDEXTENTION,f,&tag);


}

void
xsdParser::xmlTags(cppcc::scr::tag::Long& tag)
/*
 ( xmlTags ::= 0 = "  xmlTokenOn();" = '>' xmlTagsList xmlTagID '>' )
*/
{
  TagVector f(4);

  xmlTokenOn();

  skipToken(KW_GREATERTHENTERMTOKEN,f[0]);

  xmlTagsList(f[1]);

  xmlTagID(f[2]);

  skipToken(KW_GREATERTHENTERMTOKEN,f[3]);
  crefixe(KW_XMLTAGS,f,&tag);


}

void
xsdParser::xmlTagsList(cppcc::scr::tag::Long& tag)
/*
 ( xmlTagsList ::= { xmlTag } '</' )
*/
{
  TagVector d;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_LESSTHENTERMTOKEN) {
	  d.push_back(0);
	  xmlTag(d.back());
    }
    else break;

  }

  d.push_back(0);
  skipToken(KW_XMLENDTERMTOKEN,d.back());
  crelasdyn(KW_XMLTAGSLIST,d,&tag);

}

}

namespace com {
cppcc::syn::Parser* 
makeParser(cppcc::cmp::Compiler& compiler)
{
  CPPCC_LOG_INFO((*compiler.shell_.logger_),
    << "com::makeParser() started..."
    << " tokensSetID:" << compiler.shell_.tokensSetID_
  )
  
  return
    new cppcc::xsd
      ::xsdParser
      ((*compiler.shell_.logger_)
      ,compiler.keyWords_
      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_XML
      ,cppcc::lex::TokenizerReader_File)
    ;
}
}

}

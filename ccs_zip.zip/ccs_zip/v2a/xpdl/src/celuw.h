/* celuw.d          version of 28.01.91 */

/* user work area */
struct cel {
    dbsch cel ;
    struct cnm cnm;
    struct nam nam;
    struct kwn kwn;
    struct edp edp;
} cel ;



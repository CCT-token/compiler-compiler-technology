/* metamrsq.c                   version of 28.01.91 */
/*
	set buffer size for CAD/DBMS
*/

pdbmrsquo()
{

/*
#define BUFSIZE 64
*/

#define BUFSIZE 32

	msbquo(BUFSIZE);
	mssquo(BUFSIZE);
	msfquo(BUFSIZE);
	msvquo(BUFSIZE);


	return(0);
}




#include <sys/types.h>
#include <time.h>
int	pdbdatetime(d)
long	d[];
{
  time_t		tim;
  struct	tm 	*t;

  if(!d) return(0);

  tim= time((long*)0);
  t= localtime(&tim);


  d[0]= (t->tm_year) + 1900;
  d[1]= (t->tm_mon) + 1;
  d[2]= t->tm_mday;
  d[3]= t->tm_hour;
  d[4]= t->tm_min;
  d[5]= t->tm_sec;

  return(0);
}


int pdbdatetimeini(d)
long d[];
{
  register 	int 	i;

  if(!d) return(0);

  for(i= 0; i < 6; i++) d[i]= (long)0;

  return(0);
}


int pdbdatetimenull(d)
long d[];
{
  register 	int 	i;

  if(!d) return(0);

  for(i= 0; i < 6; i++) {
    if(d[i] != (long)0) return(1);
  }

  return(0);
}



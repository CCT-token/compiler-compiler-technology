/*    cel.h          */

/*    records numbers    */
#define CEL_sys 0
#define CEL_cnm 1
#define CEL_nam 2
#define CEL_kwn 3
#define CEL_edp 4

/*    sets numbers       */
#define CEL_cnms 0
#define CEL_namn 1
#define CEL_nams 2
#define CEL_kwns 3
#define CEL_edps 4

/*    items   numbers    */
/* RECORD sys  */

/* RECORD cnm  */
#define CEL_cnmnum 0
/* len=4 sh=0 sha=0 lenk=0 */

/* RECORD nam  */
#define CEL_namnum 0
/* len=4 sh=0 sha=0 lenk=0 */
#define CEL_namkey 1
/* len=16 sh=4 sha=4 lenk=4 */
#define CEL_namend 2
/* len=4 sh=20 sha=-1 lenk=20 */
#define CEL_namsou 3
/* len=4 sh=24 sha=-1 lenk=24 */

/* RECORD kwn  */
#define CEL_kwnnum 0
/* len=2 sh=0 sha=0 lenk=0 */

/* RECORD edp  */
#define CEL_edpnum 0
/* len=4 sh=0 sha=0 lenk=0 */
#define CEL_edpfix 1
/* len=4 sh=4 sha=-1 lenk=4 */
#define CEL_edpdyn 2
/* len=4 sh=8 sha=-1 lenk=8 */


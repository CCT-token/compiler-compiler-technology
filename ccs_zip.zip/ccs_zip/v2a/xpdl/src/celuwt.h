/* celuwt.d          version of 28.01.91 */

/* stuctures (types) definition */
#include "cmpu.h"
struct cnm {
    long  cnmnum;
};
struct nam {
    long  namnum;
    char  namkey[16];
};
struct kwn {
    short kwnnum;
};
struct edp {
    long  edpnum;
};



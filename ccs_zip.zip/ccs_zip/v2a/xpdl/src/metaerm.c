/* metaerm.c            version of 16.07.91 */


#include "metaer.h"

#include "metakw.h"

#include "metake.h"


/* errors codes & messages */
static struct METtermes Erbuff[]=
{
"ERNORM",         "No errors detected",
 ERNORM,
"FINOFO",         "file not found",	
 FINOFO,
"FINOCR",         "file not created",	
 FINOCR,

"FIREAD",         "file read error",	
 FIREAD,

"FIWRIT",         "file write error",	
 FIWRIT,

"FICLOS",         "file close error",	
 FICLOS,

"TOLOIN",         "too long integer",	
 TOLOIN,
"STISMI",         "string is missing",	
 STISMI,
"TOLOST",         "too long string",	
 TOLOST,
"WRCHSP",         "wrong character specification", 	
 WRCHSP,
"LEBRIS",         "left bracket '(' is missing", 	
 LEBRIS,
"RIBRIS",         "right bracket ')' is missing", 	
 RIBRIS,

"ALEBRIS",         "left bracket '<' is missing", 	
 ALEBRIS,
"ARIBRIS",         "right bracket '>' is missing", 	
 ARIBRIS,

"FLEBRIS",         "left bracket '{' is missing", 	
 FLEBRIS,
"FRIBRIS",         "right bracket '}' is missing", 	
 FRIBRIS,

"RLEBRIS",         "left bracket '[' is missing", 	
 RLEBRIS,
"RRIBRIS",         "right bracket ']' is missing", 	
 RRIBRIS,

"WRLEXE",         "wrong TOKEN or wrong key word", 	
 WRLEXE,


"WRKEWO",         "wrong key word", 	
 WRKEWO,

"FFEOFF",	  "end of file !!!",
 FFEOFF,

/* database manipulation return codes */
"CELDBOPEN",         "CELL database is not opened",
 CELDBOPEN,
"CELDBSSYS",         "CELL database error with SYS record",
 CELDBSSYS,
"CELDBROLL",         "CELL database error with ROLLBACK operation",
 CELDBROLL,
"CELDBCLOS",         "CELL database error with CLOSE operation",
 CELDBCLOS,
"CELDBMEDF",         "CELL database error with EDF record",
 CELDBMEDF,
"CELDBMCNM",         "CELL database error with CNM record",
 CELDBMCNM,
"CELDBMNAM",         "CELL database error with NAM record",
 CELDBMNAM,
"CELDBMKWN",         "CELL database error with KWN record",
 CELDBMKWN,
"CELDBMEDP",         "CELL database error with EDP record",
 CELDBMEDP,
"CELDBMNET",         "CELL database error with NET record",
 CELDBMNET,
"CELDBMINS",         "CELL database error with INS record",
 CELDBMINS,
"CELDBMPIS",         "CELL database error with PIS record",
 CELDBMPIS,
"CELDBMPOR",         "CELL database error with POR record",
 CELDBMPOR,
"CELDBSEDE",         "this edif file has already defined",
 CELDBSEDE,
"CELDBNOTD",         "this edif file was not defined",
 CELDBNOTD,
"CELDBUNLN",         "unloaded (.ued) file is not opened",
 CELDBUNLN,
"CELDBKEEP",         "CELL database error with KEEP operation",
 CELDBKEEP,


"PDBNOMEMO",	     "no memory for malloc",
 PDBNOMEMO,

"PDBDBMFAT",	     "project database fatal error",		
 PDBDBMFAT,


"METNOMEMO",	     "no memory for malloc",
 METNOMEMO,

"METDBMFAT",	     "project database fatal error",		
 METDBMFAT,

#include "metaexms.h"

"EREND",          "end of errors and messages",
 EREND
};

metaerm(f,e)
FILE *f;
enum METretcod e;
{
  register int i;

  for(i= 0; i < sizeof(Erbuff)/sizeof(struct METtermes); i++) {
    if(Erbuff[i].erc == e) {
      if(f) {fprintf(f,"(%s): %s\n",Erbuff[i].ere,Erbuff[i].ert);}
      fprintf(stderr,"(%s): %s\n",Erbuff[i].ere,Erbuff[i].ert);
    }
  }

  return(e);
}

metaprt(e)
enum METretcod e;
{
  register int i;


  for(i= 0; i < sizeof(Erbuff)/sizeof(struct METtermes); i++) {
    if(Erbuff[i].erc == e) {
      fprintf(stderr,"(%s): %s\n",Erbuff[i].ere,Erbuff[i].ert);
    }
  }

  return(e);
}


pdbmess(e)
char *e;
{
  fprintf(stderr,"%s\n",e);

  edbmess(e);

  return(0);
}


pdbkwmis(e)
int e;
{
  static char m[256];

  sprintf(m,"key word '%s' is missing",KeyTab[e]);

  pdbmess(m);

  return(0);
}


pdbkwsdf(e)
int e;
{
  static char m[256];

  sprintf(m,"second definition of key word '%s' ",KeyTab[e]);

  pdbmess(m);

  return(0);
}












/* metaer.h            version of 16.07.91 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <malloc.h>


/* errors codes */
enum	METretcod
{
ERNORM,		/* normal end				*/
FINOFO,		/* file not found			*/
FINOCR,		/* file not created			*/

FIREAD,		/* file read error			*/
FIWRIT,		/* file write error			*/
FICLOS,		/* file close error			*/

TOLOIN,		/* too long integer			*/
STISMI,		/* string is missing			*/
TOLOST,		/* too long string			*/
WRCHSP,		/* wrong character specification	*/
LEBRIS,		/* left bracket '(' is missing		*/
RIBRIS,		/* right bracket ')' is missing		*/

ALEBRIS,	/* left bracket '<' is missing		*/
ARIBRIS,	/* right bracket '>' is missing		*/
FLEBRIS,	/* left bracket '{' is missing		*/
FRIBRIS,	/* right bracket '}' is missing		*/
RLEBRIS,	/* left bracket '[' is missing		*/
RRIBRIS,	/* right bracket ']' is missing		*/

WRLEXE,         /* wrong TOKEN or wrong key word        */
WRKEWO,         /* wrong key word    			*/

FFEOFF,		/* end of file !!!			*/

/* database manipulation return codes */
CELDBOPEN,         /* CELL database is not opened */
CELDBSSYS,         /* CELL database error with SYS record */
CELDBROLL,         /* CELL database error with ROLLBACK operation */
CELDBCLOS,         /* CELL database error with CLOSE operation */
CELDBMEDF,         /* CELL database error with EDF record */
CELDBMCNM,         /* CELL database error with CNM record */
CELDBMNAM,         /* CELL database error with NAM record */
CELDBMKWN,         /* CELL database error with KWN record */
CELDBMEDP,         /* CELL database error with EDP record */
CELDBMNET,         /* CELL database error with NET record */
CELDBMINS,         /* CELL database error with INS record */
CELDBMPIS,         /* CELL database error with PIS record */
CELDBMPOR,         /* CELL database error with POR record */

CELDBSEDE,         /* this edif file has already defined */
CELDBNOTD,         /* this edif file was not defined */
CELDBUNLN,         /* unloaded (.ued) file is not opened */
CELDBKEEP,         /* CELL database error with KEEP operation */

PDBNOMEMO,	/* no memory for malloc			*/

PDBDBMFAT,	/* project database fatal error		*/

METNOMEMO,	/* no memory for malloc			*/

METDBMFAT,	/* project database fatal error		*/


#include "metaexen.h"


EREND           /* end of errors and messages             */
};


struct METtermes {
	char *ere;
	char *ert;
	enum	METretcod erc;
};


/* string message for any module */
static char mes[256];

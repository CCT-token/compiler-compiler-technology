/* metaarts.h             version of 10.01.91 */
/*                        version of 28.01.91 */

/*                        version of 18.06.91 */
/*                        version of 08.07.91 */


#define pdber(e)	return(metaprt(e))
#define edbier(s,e)	{errprint(s);pdber(e);}
#define pdbier(s,e)	edbier(s,e)

#define pdberkwmis(e)	return(pdbkwmis(e))
#define pdberkwsdf(e)	return(pdbkwsdf(e))


#define edberkwmis(e)	{pdbkwmis(e);return(edberr(WRKEWO));}
#define edberkwsdf(e)	{pdbkwsdf(e);return(edberr(WRKEWO));}

enum metaarcom
{
	C_STORE,		/* store to database */
	C_MODIFY,		/* erase & store     */
	C_LIST,			/* print object list */
	C_UNLOAD,		/* unload from database */
	C_GENER,		/* generate .c  from database */
	C_ERASE,		/* erase database representation */
	C_HELP			/* print help file */
};

#define MAXFN 32        /*  max length of key part of source file name */
			/*  must be in agree with adb.ddl,cel.ddl */
#define MAXCELN 16        /*  max length of key part of cell name */

#define MAXUNAM 8        /*  user group & user name  size */

#define MAXDBUF 128    /* buffer size for dynamic operations */

#define EDFCONT 1       /* context number for edif file representation */

#define MAXIDN 16       /*  key part of identifier */
			/*  must be in agree with cel.ddl */
#define MAXIDS 256	/* identifier total size */

#define DEFBUF  long  d[MAXDBUF]


#define UPDATE_PDB	1	/* update mode for database manipulation */
#define RETRIE_PDB	0	/* retrieval mode for database manipulation */


#define NULLCHAR	(char*)0	/* null character pointer 	*/
#define NULLLONG	(long*)0	/* null long integer pointer 	*/
#define NULLINT		(int*)0		/* null int  integer pointer 	*/
#define NULLSHORT	(short*)0	/* null short integer pointer 	*/


#define ADBLIBINI	0	/* initial library number */
#define LBRCELINI	0	/* initial cell number */


#define NAMTERMTOFR	"termTokenofrule"


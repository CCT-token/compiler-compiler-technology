/* metale.h            version of 08.01.91 */

/* extern lexical variables */

extern int     Ch;             /* current source character */
extern int     Nlin;           /* current line number */
extern int     Npos;           /* current position number */
extern int     Epos;           /* current error position number with \t */
extern char    Line [INLINEL]; /* current input line */

extern int     Errn;           /* last error number    */
extern int     Ercn;           /* error counter        */
extern int     Erset [MAXERN]; /* error buffer         */
extern char    Warn;           /* warning indicator    */
extern int     Brlev;          /* bracket level        */

extern char    Id [LENID] ;    /* last identifier      */
extern long    Ival;           /* last integerToken    */
extern char    Strng [LENSTR]; /* last stringToken     */
extern short   Kword;          /* last key word number */

extern char    Erflag;         /* error flag for source-operator  */
extern char    Ergl;           /* global error flag            */


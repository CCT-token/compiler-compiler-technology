/* metalv.h            version of 08.01.91 */

/* lexical variables */

int	Ch;		/* current source character */
int	Nlin;		/* current line number */
int	Npos;		/* current position number */
int	Epos;		/* current error position number with \t */
char	Line [INLINEL]; /* current input line */ 

int	Errn;		/* last error number	*/
int	Ercn;		/* error counter	*/
int	Erset [MAXERN];	/* error buffer		*/
char	Warn;		/* warning indicator	*/
int	Brlev;		/* bracket level 	*/

char	Id [LENID] ;	/* last identifier 	*/
long    Ival;           /* last integerToken    */
char    Strng [LENSTR]; /* last stringToken     */
short   Kword;          /* last key word number */

char    Erflag;         /* error flag for source-operator  */
char	Ergl;		/* global error flag 		*/

FILE 	*Inpf;

/* fls */
FILE	*Fls;



/* xpdlxsdkt.h                version of 09.01.91 */

char *KeyTab[]=
{

	/*   0*/  "WrongKeyWord"
	/*   1*/, "xsd"
	/*   2*/, "greaterthanTermToken"
	/*   3*/, "floatToken"
	/*   4*/, "equalTermToken"
	/*   5*/, "xmlEndTermToken"
	/*   6*/, "stringToken"
	/*   7*/, "xpdlxsd"
	/*   8*/, "grammar"
	/*   9*/, "identifier"
	/*  10*/, "colonTermToken"
	/*  11*/, "attribute"
	/*  12*/, "attributes"
	/*  13*/, "slashdivideTermToken"
	/*  14*/, "quastionmarkTermToken"
	/*  15*/, "lessthanTermToken"
	/*  16*/, "xsdTag"
	/*  17*/, "xsdTags"
	/*  18*/, "xsdTagsList"
	/*  19*/, "xsdTagEnd"
	/*  20*/, "xmlVersion"
	/*  21*/, "xmlVersionAttributes"
	/*  22*/, "termTokenofrule"
	/*  23*/, "termToken"
	/*  23*/, "quotationTermToken"
	/*  24*/, "sharpTermToken"
	/*  25*/, "ampersandTermToken"
	/*  26*/, "apostropheTermToken"
	/*  27*/, "leftparenthesisTermToken"
	/*  28*/, "rightparenthesisTermToken"
	/*  29*/, "starmultiplyTermToken"
	/*  30*/, "plusTermToken"
	/*  31*/, "commaTermToken"
	/*  32*/, "hyphenminusTermToken"
	/*  33*/, "dotpointperiodTermToken"
	/*  34*/, "semicolonTermToken"
	/*  35*/, "underlineTermToken"
	/*  36*/, "verticalbarTermToken"
	/*  37*/, "exclamationmarkTermToken"
	/*  38*/, "dollarTermToken"
	/*  39*/, "percentTermToken"
	/*  40*/, "commercialatTermToken"
	/*  41*/, "leftsquarebracketTermToken"
	/*  42*/, "leftbackslashTermToken"
	/*  43*/, "rightsquarebracketTermToken"
	/*  44*/, "circumflexTermToken"
	/*  45*/, "graveaccentTermToken"
	/*  46*/, "leftbraceTermToken"
	/*  47*/, "rightbraceTermToken"
	/*  48*/, "tildeTermToken"
	/*  49*/, "arrowTermToken"
	/*  50*/, "doublestarexponentiateTermToken"
	/*  51*/, "variableassignmentTermToken"
	/*  52*/, "inequalityTermToken"
	/*  53*/, "greaterthanorequalTermToken"
	/*  54*/, "lessthanorequalsignalassignmentTermToken"
	/*  55*/, "boxTermToken"
	/*  56*/, "defisTermToken"
};

struct tableItemTermToken tableTermToken[LENTABLETERMTOKEN]={
	{KW_QUOTATIONTERMTOKEN,"\""},
	{KW_SHARPTERMTOKEN,"#"},
	{KW_AMPERSANDTERMTOKEN,"&"},
	{KW_APOSTROPHETERMTOKEN,"'"},
	{KW_LEFTPARENTHESISTERMTOKEN,"("},
	{KW_RIGHTPARENTHESISTERMTOKEN,")"},
	{KW_STARMULTIPLYTERMTOKEN,"*"},
	{KW_PLUSTERMTOKEN,"+"},
	{KW_COMMATERMTOKEN,","},
	{KW_HYPHENMINUSTERMTOKEN,"-"},
	{KW_DOTPOINTPERIODTERMTOKEN,"."},
	{KW_SLASHDIVIDETERMTOKEN,"/"},
	{KW_COLONTERMTOKEN,":"},
	{KW_SEMICOLONTERMTOKEN,";"},
	{KW_LESSTHANTERMTOKEN,"<"},
	{KW_EQUALTERMTOKEN,"="},
	{KW_GREATERTHANTERMTOKEN,">"},
	{KW_UNDERLINETERMTOKEN,"_"},
	{KW_VERTICALBARTERMTOKEN,"|"},
	{KW_EXCLAMATIONMARKTERMTOKEN,"!"},
	{KW_DOLLARTERMTOKEN,"$"},
	{KW_PERCENTTERMTOKEN,"%"},
	{KW_QUASTIONMARKTERMTOKEN,"?"},
	{KW_COMMERCIALATTERMTOKEN,"@"},
	{KW_LEFTSQUAREBRACKETTERMTOKEN,"["},
	{KW_LEFTBACKSLASHTERMTOKEN,"\\"},
	{KW_RIGHTSQUAREBRACKETTERMTOKEN,"]"},
	{KW_CIRCUMFLEXTERMTOKEN,"^"},
	{KW_GRAVEACCENTTERMTOKEN,"`"},
	{KW_LEFTBRACETERMTOKEN,"{"},
	{KW_RIGHTBRACETERMTOKEN,"}"},
	{KW_TILDETERMTOKEN,"~"},
	{KW_ARROWTERMTOKEN,"=>"},
	{KW_DOUBLESTAREXPONENTIATETERMTOKEN,"**"},
	{KW_VARIABLEASSIGNMENTTERMTOKEN,":="},
	{KW_INEQUALITYTERMTOKEN,"/="},
	{KW_GREATERTHANOREQUALTERMTOKEN,">="},
	{KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN,"<="},
	{KW_BOXTERMTOKEN,"<>"},
	{KW_DEFISTERMTOKEN,"::="},
	{KW_XMLENDTERMTOKEN,"</"}
};
int KeyTabkeyword[LENTABLEKEYWORD]= {
	KW_XSD
};

/* metaacts.h		version of 24.07.91 */

/* 			version of 02.08.91 */
/* OptMode		version of 04.09.91 */

/*
  actions for metaar & metacomp
*/


char* 	SourceFileNameGet();
void 	SourceFileNameSet(char*);

#define MAXFN_SIZE	16*1024

#define METAOPENDB()	\
        celoptmod(0);\
	if(s= celopen(UPDATE_PDB)) return(s)

#define METACLOSDB()	\
	celclos(s)


#define METAEXTSOU	".xpd"
#define METAEXTGSOU	".c"
#define METAEXTLIS	".lis"
#define METAEXTUNL	".ugr"
#define METAEXTFGR	".fgr"

#define   METASTOREDB(f)	\
   static char ll[MAXFN_SIZE];\
   static char fn[MAXFN_SIZE];\
   register int s;\
   char *c,*l;\
   int y;\
\
  if((strlen((f))+1) >= MAXFN_SIZE)\
    {\
      fprintf(stderr,"*** too long source file name\n");\
      *((f)+MAXFN_SIZE-1)= '\0';\
    }\
\
  y= 1;\
  strcpy(fn,(f));\
  fprintf(stdout, "Compiling:1:'%s'\n", fn);\
  if(c= strrchr(fn,'/'))\
    {\
      l= c+1;\
      *c= '\0';\
\
      if(((*l) == 'l') || ((*l) == 'L'))\
	{\
	  /* print listing */\
	  y= 1;\
	}\
      else if(((*l) == 'n') || ((*l) == 'N'))\
	{\
	  y= 0;\
	}\
      else\
	{\
	  fprintf(stderr,"***ERROR*** wrong file key:%s\n",(f));\
	  y= 1;\
	}\
    }\
\
  if(!(c= strrchr(fn,'.'))) strcat(fn,METAEXTSOU);\
\
  if(y)\
    {\
      strcpy(ll,fn);\
      if(c= strrchr(ll,'.')) *c= '\0';\
      strcat(ll,METAEXTLIS);\
      l= ll;\
    }\
  else l= 0;\
\
  SourceFileNameSet(fn);\
  fprintf(stdout, "Compiling:2:'%s' '%s'\n", fn, SourceFileNameGet());\
  if(s= metatodb(fn,l)) return(s);\
\
  return(0)



#define	METAMODIFYDB(f) \
   METASTOREDB(f)




#define	METAERASEDB(f) \
static char ll[MAXFN_SIZE];\
static char fn[MAXFN_SIZE];\
register int s;\
\
if(s= fflext((f),fn,ll)) return(s);\
\
return(0)


#define	METAGENER(f,l) \
\
  static char fn[MAXFN_SIZE];\
  static char fu[MAXFN_SIZE];\
  register int s;\
  /*static char  mes[26];*/\
  static char  mes[MAXFN_SIZE];\
  char *c;\
\
  inrType r;\
\
  if((l)) strcpy(fu,(l));\
  else {\
    strcpy(fu,(f));\
    if(c= strrchr(fu,'.')) *c= '\0';\
    strcat(fu,METAEXTGSOU);\
  }\
\
  strcpy(fn,(f));\
  if(c= strrchr(fn,'.')) *c= '\0';\
  strcat(fn,METAEXTFGR);\
\
  if(s= pdbcnmread(&r,fn)) return(s);\
\
  if(s= metagen(r,fu)) return(s);\
  if(s= clsirptr(r)) return(s);\
\
return(0)




#define	METAUNLOAD(f,l) \
\
  static char fn[MAXFN_SIZE];\
  static char fu[MAXFN_SIZE];\
  register int s;\
  /*static char  mes[26];*/\
  static char  mes[MAXFN_SIZE];\
  char *c;\
\
  FILE *ff;\
\
  inrType r;\
\
  if((l)) strcpy(fu,(l));\
  else {\
    strcpy(fu,(f));\
    if(c= strrchr(fu,'.')) *c= '\0';\
    strcat(fu,METAEXTUNL);\
  }\
\
  strcpy(fn,(f));\
  if(c= strrchr(fn,'.')) *c= '\0';\
  strcat(fn,METAEXTFGR);\
\
  if(s= pdbcnmread(&r,fn)) return(s);\
\
  if(!(ff= fopen(fu,"w"))) {\
    sprintf(mes,"file name:%s",fu);\
    pdbmess(mes);\
    pdber(FINOCR);\
  }\
\
  fprintf(stdout,"fu:'%s'\n",fu);\
  if(s= pdbcnmunl(r,ff)) return(s);\
  if(s= clsirptr(r)) return(s);\
\
  if(fclose(ff)) {\
    sprintf(mes,"file name:%s",fu);\
    pdbmess(mes);\
    pdber(FICLOS);\
  }\
\
return(0)



#define	METALISTDB(f,l) \
\
  FILE *ff;\
\
  static char fn[MAXFN_SIZE];\
  register int s;\
\
return(0)




#define MAXSIMALT	32	/* max number of alternative items */
#define MAXTOTFIR	256	/* max number of first symbols     */



#define   METAACTBEG()	\
\
\
  static inrType metair;	/* internal representation */\
\
  long	  metacnt;\
\
  char	  fn[256];\
  enum	KeyNum 	k;\
  unsigned int	n;\
\
  if(s= edfcnst(&metacnt)) return(s);\
  fprintf(stdout, "Starting..................................\n");





/*  if(s= pdbcnmprint(metair)) return(s); */

#define   METAACTEND()	\
\
  /* create meta internal representation */\
  if(s= edfnmst("floatToken",NULLLONG)) return(s); /* 13.11.93 */\
  if(s= edfnmst("xmlToken",NULLLONG)) return(s); /* 2010.06.04 */\
  if(s= edfnmst("integerToken",NULLLONG)) return(s); /* 2010.06.04 */\
  if(s= pdbcnmopen(&metair,(*l))) return(s);\
\
  setlongedf(f+1,k,n);\
\
  /* create file representation */\
  /*?? strcpy(fn,ptrids(metair,n));*/\
  /*strcpy(fn,"bpmnxpdl_31a");*/\
  strcpy(fn,SourceFileNameGet());\
  { char* c; if(c= strrchr(fn,'.')) *c= '\0'; }\
  strcat(fn,".fgr");\
  fprintf(stdout, "fgr:'%s'\n", fn); \
  if(s= pdbcnmwrite(metair,fn)) return(s);\
\
\
  /* create "name".c program - compiler to DB-representation */\
\
/*
  strcpy(fn,ptrids(metair,n));\
  if(s= pdbgkwr(metair,fn)) return(s);\
  strcat(fn,".c");\
  if(s= metagen(metair,fn)) return(s);\
\
  if(s= clsirptr(metair)) return(s) */\
  fprintf(stdout, "Finished..................................\n");






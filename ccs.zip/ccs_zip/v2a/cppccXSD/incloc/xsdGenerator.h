/////////////////////////////////////////////////////////////////////
//  xsdGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_xsd_GENERATOR_H_
#define  _CPPCC_xsd_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace xsd {

	class xsdGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		xsdGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~xsdGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class xsdGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		xsdGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~xsdGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


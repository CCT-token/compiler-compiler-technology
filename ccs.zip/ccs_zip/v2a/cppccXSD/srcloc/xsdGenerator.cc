/////////////////////////////////////////////////////////////////////
//  xsdGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "xsdParser.h"
#include "xsdKeyWordDefinition.h"
#include "xsdGenerator.h"

namespace cppcc {
namespace xsd {

void
xsdGeneratorBinary::generate(const std::string& filename)
{
}

}
}

/////////////////////////////////////////////////////////////////////
//  graphParser.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_graph_PARSER_H_
#define  _CPPCC_graph_PARSER_H_

#include "Parser.h"

namespace cppcc {

namespace cmp {
  class Compiler;
}

namespace graph {

class graphParser
  : public cppcc::syn::Parser
{

public:
  graphParser 
    (cppcc::log::Logger&          logger
    ,cppcc::com::KeyWordsContainer&   theKeyWords
    ,cppcc::com::LanguageTokenizerSet   theLanguage
    ,cppcc::lex::TokenizerReader    theReader)
  : Parser(logger, theKeyWords, theLanguage, theReader)
  {
  }

  ~graphParser()
  {
  }

  void compile
    (const char *sour, const char *list);

  void compile
      (const std::string& filename
      ,const std::string& sourceString
    ,bool         isListing);


  void prog(cppcc::scr::tag::Long& tag);
  void graphs(cppcc::scr::tag::Long& tag);
  void graph_definition(cppcc::scr::tag::Long& tag);
  void graph_element(cppcc::scr::tag::Long& tag);
  void node_edge(cppcc::scr::tag::Long& tag);
  void graph_node(cppcc::scr::tag::Long& tag);
  void graph_edge(cppcc::scr::tag::Long& tag);
  void edge_elements(cppcc::scr::tag::Long& tag);
  void node_elements(cppcc::scr::tag::Long& tag);
  void comma_attribute_value(cppcc::scr::tag::Long& tag);
  void attribute_value(cppcc::scr::tag::Long& tag);
  void value(cppcc::scr::tag::Long& tag);
};

}
}

#endif

/////////////////////////////////////////////////////////////////////
//  graphGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_graph_GENERATOR_H_
#define  _CPPCC_graph_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace graph {

	class graphGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		graphGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~graphGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class graphGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		graphGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~graphGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


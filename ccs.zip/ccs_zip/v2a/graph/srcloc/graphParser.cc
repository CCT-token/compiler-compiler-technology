/////////////////////////////////////////////////////////////////////
//  graphParser.cc 
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "graphParser.h"
#include "graphKeyWordDefinition.h"

namespace cppcc {
namespace graph {

void
graphParser::compile
  (const char *sour, const char *list)
{
  CPPCC_LOG_INFO(logger_,
    << "graphParser::compile() "
    << " source:" << "'" << std::string(sour?sour:"") << "'"
    << " listing:" << "'" << std::string(list?list:"") << "'"
  )

  filename_ = sour?sour:"";
  tokenizer_.start(sour, list);

  prog(axiom_);

  tokenizer_.erfini();
}

void
graphParser::compile
    (const std::string& filename
    ,const std::string& sourceString
  ,bool         isListing)
{
  filename_ = filename;
  tokenizer_.start(sourceString, isListing);

  prog(axiom_);

  tokenizer_.erfini();
}

void
graphParser::prog(cppcc::scr::tag::Long& tag)
/*
( prog ::= 0 = "  METAACTBEG();"= graphs  0 = "  METAACTEND();"= ) 
*/
{
  TagVector f(1);

  METAACTBEG();

  graphs(f[0]);

  crefixe(KW_PROG,f,&tag);
  METAACTEND();


}

void
graphParser::graphs(cppcc::scr::tag::Long& tag)
/*
( graphs ::= { graph_definition } ) 
*/
{
  TagVector d;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_LEFTPARENTHESISTERMTOKEN) {
	    d.push_back(0);
	    graph_definition(d.back());
    }
    else break;

  }

  crelasdyn(KW_GRAPHS,d,&tag);

}

void
graphParser::graph_definition(cppcc::scr::tag::Long& tag)
/*
( graph_definition ::= '(' 'graph' identifier { graph_element } ')' ) 
*/
{
  TagVector d;
  TagVector f(3);

  skipToken(KW_LEFTPARENTHESISTERMTOKEN,f[0]);

  skipKeyWordTerm(KW_GRAPH,f[1]);

  identifier(f[2]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_LEFTPARENTHESISTERMTOKEN) {
	    d.push_back(0);
	    graph_element(d.back());
    }
    else break;

  }

  d.push_back(0);
  skipToken(KW_RIGHTPARENTHESISTERMTOKEN,d.back());
  crelasedp(KW_GRAPH_DEFINITION,f,d,&tag);

}

void
graphParser::graph_element(cppcc::scr::tag::Long& tag)
/*
( graph_element ::= '(' node_edge ')' ) 
*/
{
  TagVector f(3);

  skipToken(KW_LEFTPARENTHESISTERMTOKEN,f[0]);

  node_edge(f[1]);

  skipToken(KW_RIGHTPARENTHESISTERMTOKEN,f[2]);
  crefixe(KW_GRAPH_ELEMENT,f,&tag);


}

void
graphParser::node_edge(cppcc::scr::tag::Long& tag)
/*
( node_edge ::= graph_node | graph_edge ) 
*/
{

    if(kword() == KW_NODE) {
    graph_node(tag);
  }
  else if((kword() == KW_EDGE)
  ){
    graph_edge(tag);
  }
  else {
    pdbkwmis(KW_NODE);
    pdbkwmis(KW_EDGE);
    edber();
  }

}

void
graphParser::graph_node(cppcc::scr::tag::Long& tag)
/*
( graph_node ::= 'node' identifier [ node_elements ] ) 
*/
{
  TagVector f(3);

  skipKeyWordTerm(KW_NODE,f[0]);

  identifier(f[1]);

  f[2]=0;
    if(kword() == KW_IDENTIFIER) {
node_elements(f[2]);
  }
  crefixe(KW_GRAPH_NODE,f,&tag);


}

void
graphParser::graph_edge(cppcc::scr::tag::Long& tag)
/*
( graph_edge ::= 'edge' identifier  identifier  identifier [ edge_elements ] ) 
*/
{
  TagVector f(5);

  skipKeyWordTerm(KW_EDGE,f[0]);

  identifier(f[1]);

  identifier(f[2]);

  identifier(f[3]);

  f[4]=0;
    if(kword() == KW_IDENTIFIER) {
edge_elements(f[4]);
  }
  crefixe(KW_GRAPH_EDGE,f,&tag);


}

void
graphParser::edge_elements(cppcc::scr::tag::Long& tag)
/*
( edge_elements ::= attribute_value { comma_attribute_value } ) 
*/
{
  TagVector d;
  TagVector f(1);

  attribute_value(f[0]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_COMMATERMTOKEN) {
	    d.push_back(0);
	    comma_attribute_value(d.back());
    }
    else break;

  }

  crelasedp(KW_EDGE_ELEMENTS,f,d,&tag);

}

void
graphParser::node_elements(cppcc::scr::tag::Long& tag)
/*
( node_elements ::= attribute_value { comma_attribute_value } ) 
*/
{
  TagVector d;
  TagVector f(1);

  attribute_value(f[0]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_COMMATERMTOKEN) {
	    d.push_back(0);
	    comma_attribute_value(d.back());
    }
    else break;

  }

  crelasedp(KW_NODE_ELEMENTS,f,d,&tag);

}

void
graphParser::comma_attribute_value(cppcc::scr::tag::Long& tag)
/*
( comma_attribute_value ::= ',' attribute_value ) 
*/
{
  TagVector f(2);

  skipToken(KW_COMMATERMTOKEN,f[0]);

  attribute_value(f[1]);
  crefixe(KW_COMMA_ATTRIBUTE_VALUE,f,&tag);


}

void
graphParser::attribute_value(cppcc::scr::tag::Long& tag)
/*
( attribute_value ::= identifier '=' value ) 
*/
{
  TagVector f(3);

  identifier(f[0]);

  skipToken(KW_EQUALTERMTOKEN,f[1]);

  value(f[2]);
  crefixe(KW_ATTRIBUTE_VALUE,f,&tag);


}

void
graphParser::value(cppcc::scr::tag::Long& tag)
/*
( value ::= stringToken | integerToken ) 
*/
{

    if(kword() == KW_STRINGTOKEN) {
    stringToken(tag);
  }
  else if(((kword() == KW_INTEGERTOKEN) || (kword() == KW_FLOATTOKEN))
  ){
    integerToken(tag);
  }
  else {
    pdbkwmis(KW_STRINGTOKEN);
    pdbkwmis(KW_INTEGERTOKEN);
    edber();
  }

}

}

namespace com {
cppcc::syn::Parser* 
makeParser(cppcc::cmp::Compiler& compiler)
{
  CPPCC_LOG_INFO((*compiler.shell_.logger_),
    << "com::makeParser() started..."
    << " tokensSetID:" << compiler.shell_.tokensSetID_
  )

  return
    new cppcc::graph
      ::graphParser
      ((*compiler.shell_.logger_)
      ,compiler.keyWords_
      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_Meta
      ,cppcc::lex::TokenizerReader_File)
    ;
}
}

}

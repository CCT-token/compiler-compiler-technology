/////////////////////////////////////////////////////////////////////
//  graphGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "graphParser.h"
#include "graphKeyWordDefinition.h"
#include "graphGenerator.h"

namespace cppcc {
namespace graph {

void
graphGeneratorBinary::generate(const std::string& filename)
{
}

}
}

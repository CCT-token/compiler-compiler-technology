/////////////////////////////////////////////////////////////////////
//	cppccstd.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#ifndef  _CPPCC_CPPCCSTD_H_
#define  _CPPCC_CPPCCSTD_H_

#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
#include <stdexcept>
#include <string>
#include <sstream>
#include <set>
#include <map>
#include <fstream>
#include <iomanip>
#include <memory>

#include <cstdlib>
#include <cerrno>
#include <cmath>

////#include <syslog.h>
#include <time.h>

#include <cstring>

///////////////////////////////////////////////////////////////////////////////
// Report source file name and line number.
///////////////////////////////////////////////////////////////////////////////
#define CPPCC_FILE_LINE(erstring) \
{ \
    std::ostringstream o; \
    o \
	  << " File:'" \
	  << __FILE__ \
	  << "' Line:'" \
	  << __LINE__ \
	  << "'" \
	  << " Function:'" \
	  << __PRETTY_FUNCTION__ \
	; \
    (erstring).append(o.str()); \
}

///////////////////////////////////////////////////////////////////////////////
// Logger macros.
///////////////////////////////////////////////////////////////////////////////
#define  CPPCC_LOG_ERROR(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_ERROR) \
{std::ostringstream o;o message;(logger).logError(o.str());}

#define  CPPCC_LOG_WARNING(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_WARNING) \
{std::ostringstream o;o message;(logger).logWarning(o.str());}

#define  CPPCC_LOG_INFO(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_INFO) \
{std::ostringstream o;o message;(logger).logInfo(o.str());}

#define  CPPCC_LOG_DEBUG(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_DEBUG) \
{std::ostringstream o;o message;(logger).logDebug(o.str());}

#define  CPPCC_THROW_EXCEPTION(message) \
{std::ostringstream o;o message;std::string	error(o.str());CPPCC_FILE_LINE(error);throw cppcc::com::CPPCCException(error);}


#endif


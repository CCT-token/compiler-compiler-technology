/////////////////////////////////////////////////////////////////////
//	SyntaxControlledRuntime.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_SYNTAX_CONTROLLED_RUNTIME_H_
#define  _CPPCC_SYNTAX_CONTROLLED_RUNTIME_H_

#include "cppccstd.h"
#include "CommonRoutines.h"
#include "SystemRoutines.h"

namespace cppcc {

namespace log {
	class Logger;
}


namespace scr {

////////////////////////////////////////////////////////////////////////////
//	scr - Syntax Controlled Runtime
////////////////////////////////////////////////////////////////////////////
//       
//
//      sys |--------|        |--------|cnm     |--------|nam
//          |        |------->| cnmnum |------->| namnum |
//          |        |  cnms  |        |  namn  | namkey |
//          |        |        |        |------->| namend |*
//          |        |        |        |  nams  | namsou |*
//          |--------|        |--------|        |--------|
//                                |kwns
//                                V
//                            |--------|kwn     |--------|edp
//                            | kwnnum |------->| edpnum |
//                            |        |  edps  | edpfix |*
//                            |--------|        | edpdyn |*
//                                              |--------|
//
////////////////////////////////////////////////////////////////////////////


namespace tag {

#ifdef _CPPCC_TAG_32BITS_
//////#ifndef _CPPCC_TAG_32BITS_

typedef unsigned long	ULong;
typedef long	     	Long;
typedef float     		Real;

struct	TypeInstance {
  ULong		t:10;
  ULong		d:22;	  	
};

#else

typedef unsigned long long	ULong;
typedef long long	       	Long;
typedef double            	Real;

struct	TypeInstance {
  ULong		t:16;
  ULong		d:48;	
};

#endif

inline void setedflong(tag::Long* ll, tag::Long tt, tag::Long dd)
{
  if (ll) {
    ((TypeInstance*)ll)->t = tt;
    ((TypeInstance*)ll)->d = dd;
  }
}

inline void setlongedf(tag::Long* ll, tag::Long& tt, tag::Long& dd)
{
  if (ll) {
    tt = ((TypeInstance*)ll)->t;
    dd = ((TypeInstance*)ll)->d;
  }
}

inline std::vector<tag::Long> makeTagLongBuffer(const std::string& t)
{
  //std::vector<tag::Long> r((t.size()+1+sizeof(tag::Long))/sizeof(tag::Long));
  std::vector<tag::Long> r((t.size()+sizeof(tag::Long))/sizeof(tag::Long));
  memcpy(&r[0], t.c_str(), t.size()+1);
  
  //std::cout
  //<< "makeTagLongBuffer:"
  //<< " t:" << "'" << t << "'"
  //<< " ts:" << (t.size()+1)
  //<< " r:" << "'" << ((char*)(&r[0])) << "'"
  //<< " rs:" << r.size()
  //<< std::endl;
  
  return r;
}

struct      KeyWords {
  typedef   tag::Long                         	KeyWordID;
  typedef   std::map<std::string, KeyWordID>   	KeyWordMap;
  typedef   std::vector<std::string>           	KeyWordVector;
  
  KeyWordMap       name2index;
  KeyWordVector    index2name;
  
  KeyWords()
    :  name2index()
    ,  index2name()
  {}
  
  std::string  word(tag::Long  index) const {
    return
      ((index >= 0) && (index < static_cast<tag::Long>(index2name.size())))
        ? index2name[index]
        : std::string("")
    ;
  }
  
  bool lookup(const std::string& kw, tag::Long& idx) const {
    KeyWordMap::const_iterator  iter = name2index.find(kw);
	    
    if (iter == name2index.end()) {
      return false;
    }

	idx = iter->second;
	return true;
  }
     
};

template<typename D, typename K = std::string>
struct      MapVectorContainer 
{
	
  //typedef   MapVectorContainer<D,K> Container;
  typedef   K                       Key;
  typedef   tag::Long            	Index;
  typedef   std::map<Key, Index>    Map;
  typedef   std::vector<Key>        Vector;
  typedef   std::vector<D>          Data;
    
  Map       name2index;
  Vector    index2name;
  Data      index2data;
    
  MapVectorContainer ()
    : name2index()
    , index2name()
    , index2data()
  {}
  
  K   lastKey(tag::Long* l, const K& defaultKey) {
    return
      l
        ? (
          index2name.size()
            ? index2name[index2name.size()-1]
            : defaultKey
        )
        : defaultKey
    ;
  }

  
  K   lastKey(const K& defaultKey) {
    return
		index2name.size()
			? index2name[index2name.size()-1]
            : defaultKey
    ;
  }

  
  D&  dataByIndex(Index  index) {
          
    if ((index < 0) || (index >= static_cast<Index>(index2data.size()))) {
      CPPCC_THROW_EXCEPTION(
        << "MapVectorContainer::dataByIndex("
        << index
        << ")"
        << " - failed! - Argument is out off range: [0.."
        << index2data.size()
        << ")"
      )
    }
              
    return  index2data[index];
  }
  
  D&  dataByKey(const Key&  theKey) {
    Index idx;
    bool z = lookup(theKey, idx);
    
    if (!z) {
      CPPCC_THROW_EXCEPTION(
        << "MapVectorContainer::dataByKey('"
        << theKey
        << "')"
        << " - failed! - data member has not been defined."
      )
    }
    
    return index2data[idx];
  }
  
  void  store(const D&   theData, const Key&  theKey) {
    Index idx;
    bool z = lookup(theKey, idx);
    
    if (z) {
      CPPCC_THROW_EXCEPTION(
        << "MapVectorContainer::store('"
        << theKey
        << "')"
        << " - failed! - data member has been already defined."
      )
    }
    
    idx = static_cast<Index>(index2name.size());
    index2name.push_back(theKey);
    index2data.push_back(theData);
    
    std::pair<typename Map::iterator, bool>
      insertPair = name2index.insert
        (std::pair<const Key, Index>
          (theKey, idx)
        ); 
    
    if (!insertPair.second) {
      CPPCC_THROW_EXCEPTION(
        << "MapVectorContainer::store('"
        << theKey
        << "')"
        << " - assert check failed! - data member has been already defined."
      )
    }
  }
  
  void  update(const D&   theData, const Key&  theKey) {
    Index idx;
    bool z = lookup(theKey, idx);
    
    if (z) {
      index2name[idx] = theKey;
      index2data[idx] = theData;
    } 
    else {
      idx = static_cast<Index>(index2name.size());
      index2name.push_back(theKey);
      index2data.push_back(theData);
    
      std::pair<typename Map::iterator, bool>
        insertPair = name2index.insert
          (std::pair<const Key, Index>
            (theKey, idx)
          ); 
    
      if (!insertPair.second) {
        CPPCC_THROW_EXCEPTION(
          << "MapVectorContainer::update('"
          << theKey
          << "')"
          << " - assert check failed! - data member has been already defined."
        )
      }
    }
  } 

  bool  lookup(const Key& kw, Index& idx) const {
    typename Map::const_iterator  iter = name2index.find(kw);
    
    if(iter == name2index.end()) {
      return false;
    }
    
    idx = iter->second;
    
    return true;
  } 
  
/*
  void    dump() {
    std::cout
      << std::endl;
    
    for (register std::size_t i = 0; i < index2name.size(); i++) {
      std::cout
        << i
        << " "
        << "'"
        << index2name[i]
        << "'"
        << std::endl;
    } 
    std::cout << std::endl;
         
    typename Map::const_iterator    iend = name2index.end();
    typename Map::const_iterator    iter = name2index.begin();
    for (; (iend != iter); ++iter) {
      std::cout
        << iter->second
        << " "
        << "'"
        << iter->first
        << "'"
        << " -> "
        << "'"
        << index2name[iter->second]
        << "'"
        << std::endl;
           
    } 
  }
*/  
  void    dump_(std::ostream& strm)
  {
	  strm
	      << std::endl;
	    
	    for (register std::size_t i = 0; i < index2name.size(); i++) {
	    	strm
	        << i
	        << " "
	        << "'"
	        << index2name[i]
	        << "'"
	        << std::endl;
	    } 
	    strm << std::endl;
	         
	    typename Map::const_iterator    iend = name2index.end();
	    typename Map::const_iterator    iter = name2index.begin();
	    for (; (iend != iter); ++iter) {
	    	strm
	        << iter->second
	        << " "
	        << "'"
	        << iter->first
	        << "'"
	        << " -> "
	        << "'"
	        << index2name[iter->second]
	        << "'"
	        << std::endl;
	           
	    } 	  
  }
        
  void    dump() {
	  dump_(std::cout);
  }
  
  std::string  all() {
    std::string r("");
        
    typename Map::const_iterator    iend = name2index.end();
    typename Map::const_iterator    iter = name2index.begin();

    for (;(iend != iter);++iter) {

      r
        .append(iter->first)
        .append(" ");
 
    }
          
    return r;  
  }
  
  //std::ostream& operator<<
  //	(std::ostream& strm)
  //{
  //	 dump_(strm);
  //   return strm;
  //}
};	



template<typename D, typename K = std::string>
struct      MapPointerVectorContainer  
{
	typedef	MapVectorContainer<D*, K>		MapPointer;
	
	MapPointer			mp_;
	
	MapPointerVectorContainer(std::size_t theSize)
		: mp_(theSize)
	{}
	
	void release() {
		for (register std::size_t i = 0; i < mp_.index2data.size(); i++) {
			D*&		p = mp_.index2data[i];
			if (p) {
				delete p;
				p = 0;
			}
		}		
	}
	
	MapPointerVectorContainer()
		: mp_()
	{}
		
	~MapPointerVectorContainer() 
	{
		release();
	}
	
};



}


struct SyntaxControlledRuntime
{
  //static const tag::Long InitialContextNumber = 1;
  //static const tag::Long InitialContextNumber = 0;
  
  struct cnm;
  struct nam;
  struct kwn;
  struct edp;
  
  //typedef std::map<tag::Long,   cnm> 	SystemContextMap;
  //typedef std::map<std::string, nam> 	ContextNameByKeyMap;
  //typedef std::map<tag::Long,   nam> 	ContextNameByNumberMap;
  //typedef std::map<tag::Long,   kwn> 	ContextKeyWordByNumberMap;
  //typedef std::map<tag::Long,   edp> 	KeyWordRuleDefinitionByNumberMap; 
  typedef tag::MapVectorContainer<cnm,tag::Long>    SystemContextMap;
  typedef tag::MapVectorContainer<nam,std::string>  ContextNameByKeyMap;
  //typedef tag::MapVectorContainer<nam,tag::Long>    ContextNameByNumberMap;
  typedef tag::MapVectorContainer<kwn,tag::Long>    ContextKeyWordByNumberMap;
  typedef tag::MapVectorContainer<edp,tag::Long>    KeyWordRuleDefinitionByNumberMap; 
  
  //typedef tag::MapVectorContainer<nam,std::string>::Map ContextNameByKeyMapMap;
  
  struct nam {
	tag::Long 							cnmnum_;
    //tag::Long 							namnum_;
    std::string							namkey_;
  };
  
  struct edp {
	tag::Long 							cnmnum_;
	tag::Long 							kwnnum_;
    tag::Long 							edpnum_;
    std::vector<tag::Long>				edpfix_;
    std::vector<tag::Long>				edpdyn_;
  };
  
  struct kwn {
	tag::Long 							cnmnum_;
    tag::Long 							kwnnum_;
    KeyWordRuleDefinitionByNumberMap	edps_;
  };
 
  struct cnm {
    tag::Long 							cnmnum_;
    ContextNameByKeyMap					namn_;
    //ContextNameByNumberMap				nams_;
    ContextKeyWordByNumberMap			kwns_;
  };

  /*
  struct decompiler {
	SyntaxControlledRuntime&			runtime_;
	std::string           				filename_;
	tag::Long        					context_;
	tag::Long        					axiom_;
	std::ofstream		    			output_;	
	
	decompiler(SyntaxControlledRuntime&	runtime)
	  : runtime_(runtime)
	  , filename_()
	  , context_(0)
	  , axiom_()
	  , output_()
	{}
	
	~decompiler() {}
	
	void decompile
	  //(const std::string&           filename
	  //,cppcc::scr::tag::Long        context
	  //,cppcc::scr::tag::Long        axiom
	  //);
	  (cppcc::scr::tag::Long        context
	  ,cppcc::scr::tag::Long        axiom
	  );

  };
  */
  
  //cppcc::log::Logger&					logger_;
  SystemContextMap 						cnms_;
  tag::Long 							cnmnumCurrent_;
  int									optimizationMode_;
  int									debug_;
  //decompiler 							decompiler_;
  
  //SyntaxControlledRuntime(cppcc::log::Logger&	logger)
  //	  : logger_(logger)
  //	  , cnms_()
  //	  , cnmnumCurrent_(0)
  //{}
  //~SyntaxControlledRuntime()
  //{}
  
  SyntaxControlledRuntime()
  	  : cnms_()
  	  , cnmnumCurrent_(0)
	  , optimizationMode_(0)
      //, debug_(1)
	  , debug_(0)
	  //, decompiler_(*this) 
  {}
  
  SyntaxControlledRuntime(int optimizationMode)
  	  : cnms_()
  	  , cnmnumCurrent_(0)
	  , optimizationMode_(optimizationMode)
	  //, debug_(1)
	  , debug_(0)
	  //, decompiler_(*this) 
  {}
  
  ~SyntaxControlledRuntime()
  {}

/*  
  void decompile
	  //(const std::string&           filename
	  //,cppcc::scr::tag::Long        context
	  //,cppcc::scr::tag::Long        axiom
	  //)
  (cppcc::scr::tag::Long        context
  ,cppcc::scr::tag::Long        axiom
  )
  
  {
	  //if (filename.size() && ("" != filename)) {
	  //  decompiler_.decompile(filename, context, axiom);
	  //}
	  decompiler_.decompile(context, axiom);
  }
*/
  
  // SyntaxControlledRuntime API:
  kwn& 	kwnLookup(tag::Long 	k);
  
  void 	edfcnst(tag::Long* l);
  void 	celcnmstr(tag::Long* l) { edfcnst(l); }
  void 	edfepst(tag::Long k,tag::Long* l);
  void 	celedpstr(tag::Long k,tag::Long* l) { edfepst(k,l); }
  
  //int 	celedpfnd(tag::Long* kn);
  //int	celkwnnum(tag::Long k);
  //int	celedpnum(tag::Long n);
  edp&	celedpfnd(tag::Long* kn);
  
  void 	edfeptd(edp& e, tag::Long d[],tag::Long m,tag::Long sh);
  void 	edfeptd(edp& e, const std::vector<tag::Long>& d);
  void 	celedpmit(edp& e, tag::Long d[],tag::Long m,tag::Long sh) 
	  {edfeptd(e,d,m,sh);}
  
  void 	edfepfx(edp& e, tag::Long d[],tag::Long m,tag::Long sh);
  void 	edfepfx(edp& e, const std::vector<tag::Long>& f);
  void 	celedpmfx(edp& e, tag::Long d[],tag::Long m,tag::Long sh) 
	  {edfepfx(e,d,m,sh);}

  //bool 	celnamkey(const std::string& n, tag::Long& idx);
  void 	edfnmst(const std::string& n, tag::Long* l);
  void 	celnamstr(const std::string& n, tag::Long* l) 
	  {edfnmst(n,l); }

  void 	celedpfst_
	  (int 			flag
	  ,tag::Long 	k
	  ,tag::Long*	l
	  ,std::vector<tag::Long>& v);

  void 	celedpfst
	  (int 			flag
	  ,tag::Long 	k
	  ,tag::Long*	l
	  ,tag::Long	t[]
	  ,tag::Long	m)
  {
	std::vector<tag::Long> 	fixed(t, t+m);
	return celedpfst_(flag,k,l,fixed);
  }
  
  void 	celedpfst
	  (int 			flag
	  ,tag::Long 	k
	  ,tag::Long*	l
	  ,std::vector<tag::Long>& v)
  {
	return celedpfst_(flag,k,l,v);
  }


  
  void 	celedpfss(tag::Long k, tag::Long*l, const std::string& t);

  ///---------------------------------------------------------------
  /// API to run decompile method.
  ///---------------------------------------------------------------
  ///std::string	grammarName(tag::Long        axiom);
  
  
  void dump(std::ostream& f);
  void dumpToken(std::ostream& f, tag::Long kn);
};


inline
std::ostream& operator<<
	(std::ostream& 					strm
	,const SyntaxControlledRuntime& t)
{
	strm
		<< "Runtime="
		<< "("
		<< "c:" << t.cnmnumCurrent_
		<< " s:" << t.cnms_.index2data.size()
		<< ")"
		<< std::endl;
	;
	
	return strm;
}

inline
std::ostream& operator<<
	(std::ostream& 							strm
	,const SyntaxControlledRuntime::nam& 	t)
{
	strm
		<< "nam="
		<< "("
		<< "c:" << t.cnmnum_
		<< " n:" << "'" << t.namkey_ << "'"
		<< ")"
		<< std::endl;
	;
	
	return strm;
}

inline
std::ostream& operator<<
	(std::ostream& 							strm
	,const SyntaxControlledRuntime::edp& 	t)
{
	strm
		<< "edp="
		<< "("
		<< "c:" << t.cnmnum_
		<< " k:" << t.kwnnum_
		<< " e:" << t.edpnum_
		<< " sf:" << "'" << t.edpfix_.size() << "'"
		<< " sd:" << "'" << t.edpdyn_.size() << "'"
		<< ")"
		<< std::endl;
	;
	
	for (register std::size_t i = 0, s = t.edpfix_.size(); i < s; i++) {
		strm
			<< "edp="
			<< "("
			<< "c:" << t.cnmnum_
			<< " k:" << t.kwnnum_
			<< " e:" << t.edpnum_
			<< " i:" << i
			<< " f:" << t.edpfix_[i]
			  << "(" 
			    << (((tag::TypeInstance*)&t.edpfix_[i])->t)
			    << " " <<(((tag::TypeInstance*)&t.edpfix_[i])->d)
			  << ")"
			<< ")"
			<< std::endl;
		;
		
	}
	
	for (register std::size_t i = 0, s = t.edpdyn_.size(); i < s; i++) {
		strm
			<< "edp="
			<< "("
			<< "c:" << t.cnmnum_
			<< " k:" << t.kwnnum_
			<< " e:" << t.edpnum_
			<< " i:" << i
			<< " d:" << t.edpdyn_[i]
			  << "(" 
			    << (((tag::TypeInstance*)&t.edpdyn_[i])->t)
			    << " " <<(((tag::TypeInstance*)&t.edpdyn_[i])->d)
			  << ")"
			<< ")"
			<< std::endl;
		;
		
	}
	
	return strm;
}


inline
std::ostream& operator<<
	(std::ostream& 							strm
	,const SyntaxControlledRuntime::kwn& 	t)
{
	strm
		<< "kwn="
		<< "("
		<< "c:" << t.cnmnum_
		<< " k:" << t.kwnnum_
		<< " s:" << "'" << t.edps_.index2data.size() << "'"
		<< ")"
		<< std::endl;
	;
	
	return strm;
}


inline
std::ostream& operator<<
	(std::ostream& 							strm
	,const SyntaxControlledRuntime::cnm& 	t)
{
	strm
		<< "cnm="
		<< "("
		<< "c:" << t.cnmnum_
		<< " sn:" << "'" << t.namn_.index2data.size() << "'"
		<< " sk:" << "'" << t.kwns_.index2data.size() << "'"
		<< ")"
		<< std::endl;
	;
	
	return strm;
}


}
}

#endif

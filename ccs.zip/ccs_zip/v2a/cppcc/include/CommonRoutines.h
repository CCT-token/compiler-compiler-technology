/////////////////////////////////////////////////////////////////////
//	CommonRoutines.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_COMMON_ROUTINES_H_
#define  _CPPCC_COMMON_ROUTINES_H_

#include "cppccstd.h"

namespace cppcc {

namespace syn {
	class Parser;
}

namespace cmp {
	class Compiler;
}

namespace gen {
//	class Generator;
//	//class IRuntimeGenerator; 
//	//class IBinaryGenerator; 
//	class Generator::Runtime;
//	class Generator::Binary;

  class Generator;
	class GeneratorRuntime;
	class GeneratorBinary;
}

namespace com {

enum SHELL_CMD
{
  SHELL_CMD_UNDEFINED
  ,SHELL_CMD_COMPILE
  ,SHELL_CMD_UNLOAD
};

enum LOGGER_LEVEL
{
	LOGGER_LEVEL_UNDEFINED
	,LOGGER_LEVEL_ERROR
	,LOGGER_LEVEL_WARNING
	,LOGGER_LEVEL_INFO
	,LOGGER_LEVEL_DEBUG
	,LOGGER_LEVEL_SIZE
};

enum PREDEFINED_LANGUAGE_SYMBOLS {
	  PLS_WRONG_KEY_WORD
	  ,PLS_IDENTIFIER
	  ,PLS_STRING_TOKEN
	  ,PLS_INTEGER_TOKEN
	  ,PLS_FLOAT_TOKEN
	  ,PLS_TEXT_TOKEN
	  ,PLS_TERMINAL_TOKEN
	  ,PLS_TERMTOKENOFRULE_TOKEN
	  ,PLS_TERMINALS_START
};

enum LanguageTokenizerSet
{
  LanguageTokenizerSet_Undefined
  ,LanguageTokenizerSet_Meta
  ,LanguageTokenizerSet_XML
  //,LanguageTokenizerSet_CPP
  //,LanguageTokenizerSet_C
  //,LanguageTokenizerSet_VHDL
};

class CPPCCException : public std::range_error {

  int 	errorNo_;
	
public:

  CPPCCException(const std::string& theError)
    : std::range_error(theError)
    , errorNo_(0)
  {}

  CPPCCException(const std::string& theError, int theTokenizerError)
	: std::range_error(theError)
	, errorNo_(theTokenizerError)
  {}
	  
  static std::string systemError();
  
  int	errorID() { return errorNo_; }
};

class IRun
{
public:
	virtual void run() = 0;
};


struct	KeyWordsContainer {
	typedef std::vector<std::string> NameVector;
	
	NameVector	predefined_;
	NameVector	tokens_;
	NameVector	keyWords_;
  NameVector	keyWordsGenerated_;
	NameVector	nonTerminals_;
	
  void finalize();

	std::size_t	size() const {
	  return
	    predefined_.size()
	    +tokens_.size()
	    +keyWordsGenerated_.size()
	    +nonTerminals_.size()
	  ;
	}
};

std::size_t predefinedKeyWord(const std::string& kw);
std::string predefinedKeyWord(std::size_t e);

std::string 					getCurrentTime();

cppcc::com::KeyWordsContainer 	makeCompilerKeyWords();
cppcc::syn::Parser*				makeParser(cppcc::cmp::Compiler& 	compiler);

//cppcc::gen::Generator*			makeGenerator(cppcc::syn::Parser& 	parser);

cppcc::gen::GeneratorRuntime*
makeRuntimeGenerator(cppcc::gen::Generator&   generator);
cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator);

}
}

std::ostream& operator<<(std::ostream& o, const cppcc::com::KeyWordsContainer::NameVector& nv);
std::ostream& operator<<(std::ostream& o, const cppcc::com::KeyWordsContainer& kwc);


#endif
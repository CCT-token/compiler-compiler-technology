/////////////////////////////////////////////////////////////////////
//	Shell.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_SHELL_H_
#define  _CPPCC_SHELL_H_

#include "cppccstd.h"
#include "CommonRoutines.h"
#include "SystemRoutines.h"

namespace cppcc {

namespace log {
	class Logger;
}

namespace cmp {
	class Compiler;
}

namespace cmd {

class Shell 
	: private cppcc::sys::noncopyable
	, public cppcc::com::IRun
{
	
public:

  typedef std::vector<cppcc::cmp::Compiler*> Compilers;

  cppcc::com::SHELL_CMD		cmd_;
  std::vector<std::string> 	files_;
  std::string				name_;
  cppcc::log::Logger*		logger_;
  Compilers					compilers_;
  //cppcc::lex::LanguageTokenizerSet  tokensSetID_;
  cppcc::com::LanguageTokenizerSet tokensSetID_;
  
  Shell(int argc, char** argv);
  virtual ~Shell();
  
  void run();

private:
  void  makeCompilers();
};

}
}

#endif



/////////////////////////////////////////////////////////////////////
//	Logger.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_LOGGER_H_
#define  _CPPCC_LOGGER_H_

#include "cppccstd.h"
#include "CommonRoutines.h"
#include "SystemRoutines.h"

/*
#define  CPPCC_LOG_ERROR(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_ERROR) \
{std::ostringstream o;o message;(logger).logError(o.str());}

#define  CPPCC_LOG_WARNING(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_WARNING) \
{std::ostringstream o;o message;(logger).logWarning(o.str());}

#define  CPPCC_LOG_INFO(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_INFO) \
{std::ostringstream o;o message;(logger).logInfo(o.str());}

#define  CPPCC_LOG_DEBUG(logger,message) \
if ((logger).level()>=cppcc::com::LOGGER_LEVEL_DEBUG) \
{std::ostringstream o;o message;(logger).logDebug(o.str());}
*/

namespace cppcc {
namespace log {

class Logger : private cppcc::sys::noncopyable
{

	int							level_;
	std::ostream*				streamPointer_;
	std::ofstream				streamHandler_;
	std::string     			logFileName_;
	std::string  				programName_;
	std::vector<std::string>	levelText_;

	void	validate(int	theLevel);
	void  	setlogger(const char*  theLogname);
	void	log(int	theLevel, const std::string& theError);
	void	setLevelTest();
   
public:
	
	Logger(int	theLevel, std::ostream*		theStream)
	  : level_(theLevel)
	  , streamPointer_(theStream)
	  , streamHandler_()
	  , logFileName_()
	  , programName_()
	  , levelText_(cppcc::com::LOGGER_LEVEL_SIZE)
	{
		setLevelTest();
		validate(theLevel);
	}

	Logger(int	theLevel, const std::string& theLogname)
	  : level_(theLevel)
	  , streamPointer_(0)
	  , streamHandler_()
	  , logFileName_(theLogname)
	  , programName_()
	  , levelText_(cppcc::com::LOGGER_LEVEL_SIZE)
	{
	  setLevelTest();
	  validate(theLevel);
	  setLogger(theLogname);
	}

	Logger
	  (int	theLevel
	  ,const std::string& theLogname
	  ,const std::string& theProgram)
		: level_(theLevel)
		, streamPointer_(0)
	    , streamHandler_()
	    , logFileName_(theLogname)
	    , programName_(theProgram)
	    , levelText_(cppcc::com::LOGGER_LEVEL_SIZE)
	{
	  setLevelTest();
	  validate(theLevel);
	  setLogger(theLogname);
	}
	
  ~Logger()
  {}
  
  // Set program name.
  void  setProgramName(const std::string& theProgramName)
  { 
    programName_ = theProgramName;
  }
    
  void  setLogger(const std::string&  theLogName)
	  { setlogger(("" == theLogName)?0:theLogName.c_str()); }
	
  operator std::ostream* ()	{ return streamPointer_; }

  void	setStream(std::ostream* theStream) { streamPointer_ = theStream; }

  void	level(int	theLevel) {
    validate(theLevel);
	level_ = theLevel;
  }
  int 	level() const { return level_; }

  void	logError
	(const std::string& theError) { log(cppcc::com::LOGGER_LEVEL_ERROR, theError); }
  void	logWarning
	(const std::string& theError) { log(cppcc::com::LOGGER_LEVEL_WARNING, theError); }
  void	logInfo
	(const std::string& theError) { log(cppcc::com::LOGGER_LEVEL_INFO, theError); }
  void	logDebug
	(const std::string& theError) { log(cppcc::com::LOGGER_LEVEL_DEBUG, theError); }

};

}
}

#endif


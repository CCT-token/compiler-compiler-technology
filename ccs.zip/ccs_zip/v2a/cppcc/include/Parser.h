/////////////////////////////////////////////////////////////////////
//	Parser.h
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_PARSER_H_
#define  _CPPCC_PARSER_H_

//#include "Tokenizer.h"
//#include "SyntaxControlledBinary.h"
#include "Generator.h"


namespace cppcc {

namespace log {
	class Logger;
}

namespace com {
	class KeyWordsContainer;
}

//namespace gen {
//	class Generator;
//}

namespace syn {

class IParser
{
public:
  virtual void compile
	  (const char *sour, const char *list)    = 0;
  
  virtual void compile
    (const std::string& filename
    ,const std::string& sourceString
	,bool 				isListing)    = 0;
  
  //11// virtual void decompile(const std::string& filename) = 0;
  //virtual void writeBinary(const std::string& filename) = 0;
  //virtual void readBinary(const std::string& filename) = 0;
};

class Parser : IParser
{

void prolog();
void epilog() throw();
	
//protected:
public:
  cppcc::log::Logger&                   logger_;
  cppcc::com::KeyWordsContainer&		grammarSymbols_;
  cppcc::scr::SyntaxControlledRuntime   runtime_;
  cppcc::scb::SyntaxControlledBinary    binary_;
  cppcc::lex::Tokenizer                 tokenizer_;
  cppcc::scr::tag::Long					context_;
  cppcc::scr::tag::Long					axiom_;
  //std::string							filename_;
  cppcc::gen::Generator 				generator_;
  std::string							filename_;
  bool									debug_;
  bool 									isXmlTokenFlag_;
  //cppcc::com::LanguageTokenizerSet 		tokenizerSet_;
  
public:
  
  typedef std::vector<cppcc::scr::tag::Long>	TagVector;
  
  Parser
	(cppcc::log::Logger&  				logger
	,cppcc::com::KeyWordsContainer& 	theKeyWords
	,cppcc::com::LanguageTokenizerSet 	theLanguage
	,cppcc::lex::TokenizerReader 	 	theReader);
  
  virtual ~Parser() { epilog(); }
  
  virtual void compile
	  (const char *sour, const char *list)    = 0;
  
  virtual void compile
    (const std::string& filename
    ,const std::string& sourceString
	,bool 				isListing)    = 0;
  
  //xml// 
  void xmlTokenOff() 	{ isXmlTokenFlag_ = false; }
  //xml// 
  void xmlTokenOn() 	{ isXmlTokenFlag_ = true; }
  // xml //
  bool isXmlTokenFlag() { return isXmlTokenFlag_; }
  
  void writeBinary(const std::string& filename) {
    binary_.writeBinary(filename);
  }
  
  void readBinary(const std::string& filename) {
	binary_.readBinary(filename);
  }
  
  void decompile(const std::string& filename) {
	binary_.readBinary(filename);
	//// generator_.decompileRuntime(filename);	
	std::string dName =  filename + ".ubr";
	generator_.decompileBinary(dName);	  
  }
  
//protected:  
  void  	skipToken(const int t, cppcc::scr::tag::Long& f)
  {
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			cppcc::lex::Token& tok  = tokenizer_.language_->getToken(t);
			std::ostringstream o;
		  	o
		  	    << "skipToken " << t << " "
		        << "ch='"
		  		//<< static_cast<char>(tokenizer_.ch_)
		  		<< tokenizer_.ch_
		  		<< "'"
		  		<< ":" << "'" << static_cast<char>(tokenizer_.ch_) << "'"
		  		<< " " << tok
	  		;
		  	tokenizer_.reader_->put(o.str());
		}		  
	}
		
	tokenizer_.language_->skipToken(t,f);
  }
  
  bool		iseof()
  {
	return tokenizer_.iseof();
  }
  
  int		kword() const 
  {
	return tokenizer_.kword_;
  }
  
  void 		METAACTBEG()
  {
	  runtime_.edfcnst(&context_);
  }
  
  void 		generateBinaryFromRuntime();
  
  void		METAACTEND()
  {
	  // (A)
	  /*
	   *   static std::string   predef_[] =
  {
    "WrongKeyWord"
    ,"identifier"
    ,"stringToken"
    ,"integerToken"
    ,"floatToken"
    ,"textToken"
    ,"termToken"
    ,"termTokenOfRule"
  };
	   */
	  runtime_.edfnmst("floatToken",0);
	  //runtime_.edfnmst("xmlToken",0);
	  runtime_.edfnmst("textToken",0);
	  runtime_.edfnmst("integerToken",0);
	  //runtime_.edfnmst("identifier",0);
	  
	  // (A.1) - decompile binary - new phase v.s. ccc
	  // check shell flag.
	  // bool isRuntimeDecompiled = compiler_.shell_.isRuntimeDecompiled_;
	  // bool isRuntimeDecompiled = true;
	  // if (isRuntimeDecompiled) {
	  //	  //std::string decompilingRuntime = filename_ + ".urt";
	  //	  //runtime_.decompile(decompilingRuntime, context_, axiom_);
	  // runtime_.decompile(context_, axiom_);
	  //}
	  bool isRuntimeDecompiled = true;
	  if (isRuntimeDecompiled) {
		  std::string decompilingRuntime = filename_ + ".urt";
		  generator_.decompileRuntime(decompilingRuntime);
	  }

	  // (B)
	  // Make binary_ generation
	  // generateBinary();
	  //if (generator_) {
	  //  generator_->generateBinaryFromRuntime();
	  //}
	  generateBinaryFromRuntime();
	  bool isTesting = false;
	  if (isTesting) {
		  std::string dName =  filename_ + ".ubrt";
		  generator_.decompileBinary(dName);   		  
	  }
		  	  
	  // (C) unload binary_ into *.fgr file
	  // unloadBinary();
	  std::string binaryFilaName = filename_ + ".fgr";
	  binary_.writeBinary(binaryFilaName);
	  
	  // (D)
	  // generateParser();
	  // create <>Parser.cc
	  // create <>Parser.h
	  
	  // D.1
	  bool isGeneratedFromBinary = true;
	  if (isGeneratedFromBinary) {
		  generator_.generateFromBinary(filename_);
	  }
	  
	  // D.2
	  bool isGeneratedFromRuntime = true;
	  if (isGeneratedFromRuntime) {
		  generator_.generateFromRuntime(filename_);
	  }
  }

/*  
  void		crenxtedp
	(int 		k
	,int&		i
	,int&		sh
	,TagVector&	d
	,cppcc::scr::tag::Long* l
	)
  {
	  
  }
  
  void		crelasedp
	(int 		k
	,int&		i
	,int&		sh
	,TagVector&	d
	,cppcc::scr::tag::Long* l
	)
  {
	  
  }
*/
  void		crelasedp
	(int 		k
	,TagVector&	f
	,TagVector&	d
	,cppcc::scr::tag::Long* l
	)
  {
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			std::ostringstream o;
		  	o
		  	    << "crelasedp:0: " 
		  	    << " k:" << k 
		  	    << " f:" << f.size()
		  	    << " d:" << d.size()
	  		;
		  	tokenizer_.reader_->put(o.str());
		}		  
	}
	  
	cppcc::scr::tag::Long r;
	  
	runtime_.celedpfst(0, k, &r, f); 
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			std::ostringstream o;
			o
			  	    << "crelasedp:1: " 
			  	    << " k:" << k 
			  	    << " f:" << f.size()
			  	    << " d:" << d.size()
			  	    << " r:" << r
		 	;
			tokenizer_.reader_->put(o.str());
		}		  
	}
	  
	cppcc::scr::SyntaxControlledRuntime::edp& e = runtime_.celedpfnd(&r);
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			std::ostringstream o;
		  	o
		  	    << "crelasedp:2: " 
		  	    << " k:" << k 
		  	    << " f:" << f.size()
		  	    << " d:" << d.size()
		  	    << " r:" << r
	  		;
		  	tokenizer_.reader_->put(o.str());
		}		  
	}
	  
	runtime_.edfeptd(e, d);
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			std::ostringstream o;
		  	o
		  	    << "crelasedp:3: " 
		  	    << " k:" << k 
		  	    << " f:" << f.size()
		  	    << " d:" << d.size()
		  	    << " r:" << r
	  		;
		  	tokenizer_.reader_->put(o.str());
		}		  


	}
	  
	if (l) *l = r;

  if(tokenizer_.debug_) {
    dump_(k, f, l);
    dump_(k, d, l);
  }

  } 
  
  void 		crefixe
    (int		k
    ,TagVector&	f
    ,cppcc::scr::tag::Long* l
	)
  {
	  runtime_.celedpfst(1, k, l, f);
  }

/*
  void		crenxtdyn
	(int 		k
	,int&		i
	,int&		sh
	,TagVector&	d
	,cppcc::scr::tag::Long* l
	)
  {
	  
  }


  void		crelasdyn
	(int 		k
	,int&		i
	,int&		sh
	,TagVector&	d
	,cppcc::scr::tag::Long* l
	)
  {
	  
  }
*/
  
  // ub:
  void		dump_
	(int 					k
	,TagVector&				d
	,cppcc::scr::tag::Long* l
	);

  void		crelasdyn
	(int 					k
	,TagVector&				d
	,cppcc::scr::tag::Long* l
	)
  {
	  std::vector<cppcc::scr::tag::Long> f;
	  cppcc::scr::tag::Long r;
	  runtime_.celedpfst(0, k, &r, f);  
	  cppcc::scr::SyntaxControlledRuntime::edp& e = runtime_.celedpfnd(&r);
	  runtime_.edfeptd(e, d);
	  if (l) *l = r;	  

    // ub:
    int isDebug = 1;
    if (isDebug) {
      dump_(k, d, l);
    }
  }
  
  void pdbkwmis(const int k)
  {
	cppcc::lex::Token&	t = tokenizer_.language_->getToken(k);
    std::ostringstream o;
    o << t << " is missing.";
    tokenizer_.errorMessage(o.str());
  }
  
  void edberkwsdf(const int k)
  {
	cppcc::lex::Token&	t = tokenizer_.language_->getToken(k);
    std::ostringstream o;
    //o << t << " is missing.";
    o << "second definition of key word '" << t << "'" << " ";
    tokenizer_.errorMessage(o.str());
  }

  void edber()
  {
	std::ostringstream o;
	o << "Wrong key word:" <<  tokenizer_.kword_;
	tokenizer_.infoMessage(o.str());
  }
  
  void		identifierAction(cppcc::scr::tag::Long&	tag)
  {
	  cppcc::scr::tag::Long n;
	  runtime_.edfnmst(tokenizer_.id_, &n);
	  
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "identifier:" 
			<< " kw:" << tokenizer_.kword_
			<< " id:" << tokenizer_.id_
			<< " n:" << n
		;
		tokenizer_.infoMessage(o.str());		  
	  }
	  
	  //cppcc::scr::tag::setedflong(&tag, KW_IDENTIFIER_TOKEN, n);
	  cppcc::scr::tag::setedflong(&tag, cppcc::com::PLS_IDENTIFIER, n);
	  
	  //tokenizer_.getNextToken();
  }
  
  void		identifier(cppcc::scr::tag::Long&	tag)
  {
	  identifierAction(tag);
	  tokenizer_.getNextToken();
  }

  
  void		integerTokenAction(cppcc::scr::tag::Long&	tag)
  {
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "integerToken:0:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.ival_
		;
		tokenizer_.infoMessage(o.str());		  
	  }

	  
	  if(cppcc::com::PLS_INTEGER_TOKEN != tokenizer_.kword_) {
		  tokenizer_.infoMessage("here must be integer or float token!");
		  tokenizer_.errorMessage("wrong token!");
		  return;
	  }
	  
	  if (!tokenizer_.modeintfloat_) {
		  cppcc::scr::tag::Long	value = tokenizer_.ival_;
		  //runtime_.celedpfst(0, KW_INTEGER_TOKEN, &tag, &value, 1);
		  runtime_.celedpfst
			  (0, cppcc::com::PLS_INTEGER_TOKEN, &tag, &value, 1);

		  if (tokenizer_.debug_) {
			std::ostringstream o;
			o 
				<< "integerToken:1:celedpfst:" 
				<< " kw:" << tokenizer_.kword_
				<< " iv:" << tokenizer_.ival_
				<< " tag:" << tag
			;
			tokenizer_.infoMessage(o.str());		  
		  }

	  } else {
		  cppcc::scr::tag::Real value = tokenizer_.rval_;
		  //runtime_.celedpfst(0, KW_INTEGER_TOKEN, &tag, &value, 1);
		  runtime_.celedpfst
			  (0, cppcc::com::PLS_FLOAT_TOKEN, &tag, 
			  reinterpret_cast<cppcc::scr::tag::Long*>(&value), 1);
	  }
	  
	  //tokenizer_.getNextToken();
  }
  
  void		integerToken(cppcc::scr::tag::Long&	tag)
  {
	  integerTokenAction(tag);
	  tokenizer_.getNextToken();
  }
  
  void 		stringTokenAction(cppcc::scr::tag::Long&	tag)
  {
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "stringToken:0:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.strng_
		;
		tokenizer_.infoMessage(o.str());		  
	  }

	  if(cppcc::com::PLS_STRING_TOKEN != tokenizer_.kword_) {
		  tokenizer_.infoMessage("here must be string token!");
		  tokenizer_.errorMessage("wrong token!");
		  return;
	  }
	  
	  //runtime_.celedpfst(1, cppcc::lex::Language::PLS_STRING_TOKEN, &tag, f);
	  runtime_.celedpfss
		(cppcc::com::PLS_STRING_TOKEN
		,&tag
		,tokenizer_.strng_
		);
	  
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "stringToken:1:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.strng_
		;
		tokenizer_.infoMessage(o.str());		  
	  }
	  
	  //tokenizer_.getNextToken();
  }
 
  void 		stringToken(cppcc::scr::tag::Long&	tag)
  {
	  stringTokenAction(tag);
	  tokenizer_.getNextToken();
  }
  
  // XML ----------------------------
  // textToken -- KW_TEXTTOKEN
  void 		textTokenAction(cppcc::scr::tag::Long&	tag)
  {
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "textToken:0:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.termString_
		;
		tokenizer_.infoMessage(o.str());		  
	  }

	  //if(cppcc::com::PLS_TEXT_TOKEN != tokenizer_.kword_) {
	  //	  tokenizer_.infoMessage("here must be text (XML) token!");
	  //  tokenizer_.errorMessage("wrong token!");
	  //  return;
	  //}
	  
	  //runtime_.celedpfst(1, cppcc::lex::Language::PLS_STRING_TOKEN, &tag, f);
	  runtime_.celedpfss
		(cppcc::com::PLS_STRING_TOKEN
		,&tag
		,tokenizer_.termString_
		);
	  
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "textToken:1:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.termString_
		;
		tokenizer_.infoMessage(o.str());		  
	  }
	  
	  //tokenizer_.getNextToken();
  }
 
  void 		textToken(cppcc::scr::tag::Long&	tag)
  {
	  textTokenAction(tag);
	  //??// tokenizer_.getNextToken();
  }
  
  // XML .............................
  
  void 		termToken(cppcc::scr::tag::Long&	tag)
  {
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "termToken:0:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.termString_
		;
		tokenizer_.infoMessage(o.str());	
		std::cout << o.str() << std::endl;
	  }

	  if(cppcc::com::PLS_TERMINAL_TOKEN != tokenizer_.kword_) {
		  tokenizer_.infoMessage("here must be terminal token!");
		  tokenizer_.errorMessage("wrong token!");
		  return;
	  }
	  
	  // find tokenizer_.termString_
	  // in tokenizer_.language_->tokens_
	  cppcc::lex::Tokens::Name2IndexMap::const_iterator cIter = 
	    tokenizer_.language_->tokens_.name2index_.find(tokenizer_.termString_);
	  
	  std::string e("");
	  std::string&	t =
	    (tokenizer_.language_->tokens_.name2index_.end() == cIter) 
	      ? tokenizer_.termString_
	      : (
	        ((cIter->second >= 0) 
	        && (cIter->second < 
	          static_cast<int>(tokenizer_.language_->tokens_.tokens_.size())))
	          ? (tokenizer_.language_->tokens_.tokens_[cIter->second]
	            ? tokenizer_.language_->tokens_.tokens_[cIter->second]->name_
	            : e
	          )
	          : e
	      )
	  ;
	    
	  /*
	    // xml // ------------------------------//
	    // add lookup in global scope: TokenNames.h & TokenNames.cc
	    if (e == t) {
	      cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd = 
	        tokenizer_.defaultTokenNames_.tokenNames_.end();
	      cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
	        tokenizer_.defaultTokenNames_.tokenNames_.find
	          (tokenizer_.termString_);
	      if (cEnd == cIter) {
	        CPPCC_THROW_EXCEPTION(
	          << "termToken() assert check failed:"
	          << " Token:'" << t << "'"
	          << " does not have corresponding name defined in TokenNames!"
	        )       
	      }
	    
	      t = cIter->second;    
	    }
	    // xml // ------------------------------//
	    */
	  
	  if (e == t) {
	     tokenizer_.errorMessage("could not process terminal token:");
	     tokenizer_.infoMessage(tokenizer_.termString_);
	     return;
	  }
	  
	  cppcc::scr::tag::Long n;	  
	  runtime_.edfnmst(t, &n);
	  
	  if (tokenizer_.debug_) {
		std::ostringstream o;
		o 
			<< "termToken:1:" 
			<< " kw:" << tokenizer_.kword_
			<< " iv:" << tokenizer_.termString_
			<< " n:" << n
		;
		tokenizer_.infoMessage(o.str());		  
	  }
	  
	  cppcc::scr::tag::setedflong
	    (&tag 
		,cppcc::com::PLS_TERMTOKENOFRULE_TOKEN
	    ,n);
  
	  tokenizer_.getNextToken();
  }
  
  void 		skipKeyWordTerm(const int t, cppcc::scr::tag::Long& tag)
  {
	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
			std::ostringstream o;
		  	o
		  	    << "skipKeyWordTerm " << t << " "
		  	    << " kw:" << tokenizer_.kword_
		        << "ch='"
		  		<< tokenizer_.ch_
		  		<< "'"
		  		<< ":" << "'" << static_cast<char>(tokenizer_.ch_) << "'"
	  		;
		  	tokenizer_.reader_->put(o.str());
		}		  
	}

    //if(cppcc::com::PLS_TERMINAL_TOKEN != tokenizer_.kword_) {
    if(t != tokenizer_.kword_) {
		tokenizer_.infoMessage("here must be key word terminal token!");
		tokenizer_.errorMessage("wrong token!");
		return;
    }

	cppcc::scr::tag::setedflong
	    (&tag 
		,cppcc::com::PLS_TERMINAL_TOKEN
	    ,t);
	
	//tokenizer_.language_->skipKeyWordTerm(t,f);
	tokenizer_.getNextToken();
  }
  
  
public:
  
  std::string	grammarName()
  {
	std::string gn("");
	cppcc::scr::tag::Long 	kk; 
	cppcc::scr::tag::Long 	nn;
	cppcc::scr::tag::setlongedf(&generator_.parser_.axiom_,kk,nn);
		  
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  runtime_.cnms_.dataByKey
	    (runtime_.cnmnumCurrent_);
	cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	  runtime_.kwnLookup(kk);
	cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
	  kwnInstance.edps_.dataByKey(nn);
	if (edpInstance.edpfix_.size() >= 2) {
		cppcc::scr::tag::Long k;
		cppcc::scr::tag::Long n;
	 	cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
	  	if (cppcc::com::PLS_IDENTIFIER == k) {
	  		cppcc::scr::SyntaxControlledRuntime::nam namInstance=
	   	      currentContext.namn_.dataByIndex(n);
	        gn = namInstance.namkey_;
	 	}
	}
		
	return gn;			  
  }
  
};

}
}

#endif


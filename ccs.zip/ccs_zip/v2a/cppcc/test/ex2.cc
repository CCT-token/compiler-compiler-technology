#include <iostream>
#include <vector>
#include <algorithm>
#include <limits>
#include <stdexcept>
#include <string>
#include <sstream>
#include <set>
#include <map>
#include <fstream>
#include <iomanip>
#include <memory>

#include <cstdlib>
#include <cerrno>
#include <cmath>

#include <syslog.h>
#include <time.h>

#include <cstring>

union A
{
	float 	f_;
	int		i_;
	char	*s_;
	
};

int main (int argc, char** argv)
{
	float   f= 348.43f;
	char	d[1024];
	
	memcpy(d, &f, sizeof(f));
	
	A a;
	a.f_ = *(float*)d;
	
	fprintf(stdout, "%f vs %f \n", f, a.f_);
	fprintf(stdout, "a:%ld f:%ld\n", sizeof(A), sizeof(float));
}

class GenerateKeyWordDefinitionH
{
	cppcc::gen::GeneratorBinary&				binary_;
	std::string 								filename_;
    cppcc::scb::SyntaxControlledBinary&     	bin_;
    cppcc::scb::SyntaxControlledBinary::Helper  help_;
    cppcc::lex::Tokenizer&            			tok_;
		
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionHCodeStartSize; i++) {
			output << line(KeyWordDefinitionHCodeStart[i], gn) << std::endl;
		}
			
		std::size_t cnt = 0;
		for (std::size_t i = 0; i < predefSize_; i++) {
			output << "  // " << cnt+i << std::endl;
			output 
				<< "  " 
				<< std::string(i?",":"")
				
			    //22// << prefix << upper(predef_[i]) 
				//22// // B: no suffix..... << predefinedSuffix
			    //kw// << predefinedKeyWord(predef_[i])
			    << prefixKeyWord(predef_[i])
				
				<< std::endl;
		}		
		cnt += predefSize_;
		
		std::size_t tokensSize = 
		  binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  //kw// << tokenKeyWord(cIter->second)
			  << prefixKeyWord(cIter->second)
			  << std::endl;
		}	
		cnt += tokensSize;
		
    bool isGeneratedFromIDs = false;
    if (isGeneratedFromIDs) {
		  std::size_t keyWordsSize = 
			  binary_.generator_.parser_.grammarSymbols_.keyWords_.size();
		  for (std::size_t i = 0; i < keyWordsSize; i++) {
			  const std::string& 	rw = 
				  binary_.generator_.parser_.grammarSymbols_.keyWords_[i];
		
			  output << "  // " << cnt+i << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;
			
		  }
		  cnt += keyWordsSize;
    } else {
      // loop for all context identifiers.
      cppcc::scr::tag::Long ids_size = bin_.head()->cntnid;
      cppcc::scr::tag::Long sz = 0;
      for (cppcc::scr::tag::Long i = 0; i < ids_size; i++) {
        //std::string 	rw = bin_.ptrids(i);
        std::string 	rw = bin_.ptridn(i);

        if(isPredefined(rw)) {
          continue;
        }

        ///output << "  // " << cnt+i << std::endl;
        output << "  // " << cnt+sz << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;

        sz++;
      }

      cnt += sz;
    }
		
		///--------------------------------------
	    
	    bool isGeneratedFromGrammarSymbols = false;
	    if (isGeneratedFromGrammarSymbols) {
			std::size_t nonTerminalsSize = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
			for (std::size_t i = 0; i < nonTerminalsSize; i++) {
				const std::string& 	nont = 
					binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
			
				output << "  // " << cnt+i << std::endl;
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(nont)
					<< std::endl;
			}
			cnt += nonTerminalsSize;
	    }
		else {
      bool doit = false;
      if (doit) {
		      // Extract rule names from grammar definition.    
		   cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		        help_.k(KW_RULE);
		   if (k) {
		      for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		        cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		        cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		        if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		          tok_.errorMessage(errorNoIdentifierFound);
		           CPPCC_THROW_EXCEPTION(
		             << errorNoIdentifierFound
		             << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		           )
		        }
		        
		        output << "  // " << cnt+nnrule << std::endl;  
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(bin_.ptrids(kn.d))
					<< std::endl;
		        
		       }
		   }			
		   cnt += k.edps_.size();
      }
		}
		///------------------------------------

		
		output << "  // " << cnt << " -- Total"<< std::endl;
		output 
			<< "  " 
			<< ","
			//kw// << totalKeyWord()
			<< prefixKeyWord(totalSuffix)
			<< std::endl;
		
		
		for (std::size_t i = 0; i < KeyWordDefinitionHCodeFinishSize; i++) {
			output << line(KeyWordDefinitionHCodeFinish[i], gn) << std::endl;
		}		
	}		

	
public:
	GenerateKeyWordDefinitionH
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
        , bin_(binary.generator_.parser_.binary_)
        , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
        , tok_(binary_.generator_.parser_.tokenizer_)
	{
		generate();
	}	
};



/////////////////

struct GenerateKeyWordsContainer
{
	cppcc::gen::GeneratorBinary&                binary_;
	std::string                                 filename_;
  cppcc::scb::SyntaxControlledBinary&         bin_;
  cppcc::scb::SyntaxControlledBinary::Helper  help_;
  cppcc::lex::Tokenizer&                      tok_;
  cppcc::com::KeyWordsContainer               kwc_;
  int                                         isDebug_;

  // grammarKeyWords_IDENTMISS(s, nnrule, tdi.d);
  void
  grammarKeyWords_IDENTMISS
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_IDENTMISS).k_,n);
    if (e && bin_.fixed(e)) {
      if (KW_IDENTALT != bin_.fixed(e,1).t) {
        tok_.errorMessage(errorHereMustBeIdentAlt);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule 
          << " tag:" << bin_.fixed(e,1).t
          << " should be:" << KW_IDENTALT
          << " for:" << KW_IDENTMISS << " " << n << " "
          << errorHereMustBeIdentAlt    
        )  
      }
      grammarKeyWords_IDENTALT(s, nnrule, bin_.fixed(e,1).d);
    }
  }

  //grammarKeyWords_ALTERNATIVE(s, nnrule, tdi.d);
  void
  grammarKeyWords_ALTERNATIVE
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_ALTERNATIVE).k_,n);
    if (e && bin_.fixed(e)) {
      if (KW_IDENTALT != bin_.fixed(e,1).t) {
        tok_.errorMessage(errorHereMustBeIdentAlt);
        CPPCC_THROW_EXCEPTION(
          << " rule:" << nnrule << " "
          << " tag:" << bin_.fixed(e,1).t
          << " should be:" << KW_IDENTALT
          << " for:" << KW_ALTERNATIVE << " " << n << " "
          << errorHereMustBeIdentAlt    
        )  
      }
      grammarKeyWords_IDENTALT(s, nnrule, bin_.fixed(e,1).d);
    }

  }

  // grammarKeyWords_IDENTALT(s, nnrule, tdi.d);
  void
  grammarKeyWords_IDENTALT
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   n)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_IDENTALT).k_,n);
    if (e) {
      if (bin_.fixed(e)) {
        if (KW_NTERMTERMACT != bin_.fixed(e, 0).t) {
          //ruleError(output, nnrule, errorHereMustINtermTermAct);
          tok_.errorMessage(errorHereMustINtermTermAct);
          CPPCC_THROW_EXCEPTION(
            << " rule:" << nnrule << " "
            << " tag:" << bin_.fixed(e, 0).t
            << " should be:" << KW_NTERMTERMACT
            << " for:" << KW_IDENTALT << n << " "
            << errorHereMustINtermTermAct    
          )
        }

        cppcc::scb::SyntaxControlledBinary::edpirType* eact =
          bin_.ptredp(help_.k(KW_NTERMTERMACT).k_, bin_.fixed(e, 0).d);
        if (eact) {
          if (bin_.fixed(eact)) {

            //if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
            //  s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
            //}

            if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == bin_.fixed(eact, 0).t) {
              std::string kw = bin_.ptrids(bin_.fixed(eact, 0).d);

              if (isDebug_) {
                std::cout
                  << "rule:" << nnrule
                  << " id:" << "'" << kw << "'"
                  << std::endl;
              }

              s.insert(kw);
            }
          }
        }
      }

      if (bin_.dynamic(e)) {
        for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
          cppcc::scr::tag::TypeInstance& tdi = bin_.dynamic(e, i);
          if (KW_ALTPART != tdi.t) {
            tok_.errorMessage(errorHereMustBeAltpart);
            CPPCC_THROW_EXCEPTION(
              << " rule:" << nnrule << " "
              << " tag:" << tdi.t
              << " should be:" << KW_ALTPART
              << " for:" << KW_IDENTALT << " " << n << " "
              << errorHereMustBeAltpart    
            ) 
          }

          cppcc::scb::SyntaxControlledBinary::edpirType* ee =
            bin_.ptredp(help_.k(KW_ALTPART).k_,tdi.d);
          if (ee && bin_.fixed(ee)) {
        	  if (KW_NTERMTERMACT != bin_.fixed(ee, 1).t) {
        	    tok_.errorMessage(errorHereMustINtermTermAct);	
                CPPCC_THROW_EXCEPTION(
                  << " rule:" << nnrule << " "
                  << " tag:" << bin_.fixed(ee, 1).t
                  << " should be:" << KW_NTERMTERMACT
                  << " for:" << tdi.t << " " << tdi.d << " "
                  << errorHereMustINtermTermAct    
                )       		
        	  } 

            cppcc::scb::SyntaxControlledBinary::edpirType* eact =
              bin_.ptredp(help_.k(KW_NTERMTERMACT).k_, bin_.fixed(ee, 1).d);
            if (eact) {
              if (bin_.fixed(eact)) {

                //if (cppcc::com::PLS_IDENTIFIER == bin_.fixed(eact, 0).t) {
                //  s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
                //}

                if (cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == bin_.fixed(eact, 0).t) {
                  //s.insert(bin_.ptrids(bin_.fixed(eact, 0).d));
                  std::string kw = bin_.ptrids(bin_.fixed(eact, 0).d);

                  if (isDebug_) {
                    std::cout
                      << "rule:" << nnrule
                      << " i:" << i
                      << " id:" << "'" << kw << "'"
                      << std::endl;
                  }

                  s.insert(kw);
                }
              }
            }

          }
        }
      }
    }
  }

  //grammarKeyWordsRight(s, nnrule, kr.d);
  void
  grammarKeyWordsRight
    (std::set<std::string>&   s
    ,std::size_t              nnrule
    ,cppcc::scr::tag::ULong   nright)
  {
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
      bin_.ptredp(help_.k(KW_RIGHT).k_,nright);

    if (e && bin_.dynamic(e)) {
      for (cppcc::scr::tag::Long i = 0, z = e->dl; i < z; i++) {
        cppcc::scr::tag::TypeInstance& tdi = bin_.dynamic(e, i);

        if (KW_ITERATION == tdi.t) {
        }
        else if (KW_IDENTMISS == tdi.t) {
          grammarKeyWords_IDENTMISS(s, nnrule, tdi.d);
        }
        else if (KW_ALTERNATIVE == tdi.t) {
          grammarKeyWords_ALTERNATIVE(s, nnrule, tdi.d);
        }
        else if (KW_ACTION == tdi.t) {

        }
        else if (KW_IDENTALT == tdi.t) {
          grammarKeyWords_IDENTALT(s, nnrule, tdi.d);
        }
      }
    }
  }

  cppcc::com::KeyWordsContainer::NameVector 
  grammarKeyWords()
  {
    std::set<std::string>                     s;

		cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		  help_.k(KW_RULE);
    if (k) {
		  for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		    cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		    cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		    if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		      tok_.errorMessage(errorNoIdentifierFound);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		        )
		    }

        cppcc::scr::tag::TypeInstance&  kr  = eru.fixed(3);
        if(KW_RIGHT != kr.t) {
		      tok_.errorMessage(errorHereMustBeRight);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kr.t << " n:" << kr.d
		        )
        }

		    //kwc_.nonTerminals_.push_back(bin_.ptrids(kn.d));    
        grammarKeyWordsRight(s, nnrule, kr.d);
		  }
	  }

    cppcc::com::KeyWordsContainer::NameVector r(s.begin(), s.end());
    return r;
  }

  // kwc_.keyWords_ = finalize(kwc_.predefined_, kwc_.nonTerminals_, allKeyWords);
  cppcc::com::KeyWordsContainer::NameVector 
  finalize
    (const cppcc::com::KeyWordsContainer::NameVector& predefined
    ,const cppcc::com::KeyWordsContainer::NameVector& nonTerminals
    ,const cppcc::com::KeyWordsContainer::NameVector& allKeyWords)
  {
    cppcc::com::KeyWordsContainer::NameVector r;

    std::set<std::string> predefined_(predefined.begin(), predefined.end());
    std::set<std::string> nonTerminals_(nonTerminals.begin(), nonTerminals.end());

    if (isDebug_) {
      {
        std::cout
          << "predefined_.size()=" << predefined_.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = predefined_.begin();
        std::set<std::string>::const_iterator ce = predefined_.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "predefined_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }

      {
        std::cout
          << "nonTerminals_.size()=" << nonTerminals_.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = nonTerminals_.begin();
        std::set<std::string>::const_iterator ce = nonTerminals_.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "nonTerminals_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }
    }

    for (std::size_t i = 0, z = allKeyWords.size(); i < z; i++) {
      const std::string& n = allKeyWords[i];

      std::set<std::string>::const_iterator iPredefined = predefined_.find(n);
      bool yPredefined = (iPredefined == predefined_.end());

      std::set<std::string>::const_iterator iNonTerminals = nonTerminals_.find(n);
      bool yNonTerminals = (iNonTerminals == nonTerminals_.end());
      
      if (yNonTerminals && yPredefined) {
        r.push_back(n);
      }

      if (isDebug_) {
        std::cout
          << "kw:" << "'" << n << "'"
          << " yPredefined:" << yPredefined
          << " yNonTerminals:" << yNonTerminals
          << std::endl;
      }
    }

    return r;
  }

  void generate()
	{

    // 	typedef std::vector<std::string> NameVector;
	  // 	
	  // 	NameVector	predefined_;
	  // 	NameVector	tokens_;
	  // 	NameVector	keyWords_;
	  // 	NameVector	nonTerminals_;

    // 	NameVector	predefined_;
    for (std::size_t i = 0, z = cppcc::com::PLS_TERMINALS_START; i < z; i++) {
      kwc_.predefined_.push_back(cppcc::com::predefinedKeyWord(i));
    }

	  // 	NameVector	tokens_;
    /*
    cppcc::scb::SyntaxControlledBinary::kwnirType*	kwnTerminalTokens = 
      ptrkwn(cppcc::com::PLS_TERMINAL_TOKEN);
    for(cppcc::scr::tag::Long i = 0, z = kwnTerminalTokens->l; i < z; i++)
    {
      cppcc::scb::SyntaxControlledBinary::edpirType* edpTerminalTokens =
        ptredp(kwnTerminalTokens, i);

      if (fixed(edpTerminalTokens)) {
         std::cout
           << " i:" << i 
           << " fl:" << edpTerminalTokens->fl
           << " dl:" << edpTerminalTokens->dl
           << " d:" << edpTerminalTokens->d
           << " tf[0]:" << fixed(edpTerminalTokens, 0).t
                        << ":"
                        << fixed(edpTerminalTokens, 0).d
           << std::endl;
      }

      if (dynamic(edpTerminalTokens)) {
         std::cout
           << " i:" << i 
           << " fl:" << edpTerminalTokens->fl
           << " dl:" << edpTerminalTokens->dl
           << " d:" << edpTerminalTokens->d
           << " td[0]:" << dynamic(edpTerminalTokens, 0).t
                        << ":"
                        << dynamic(edpTerminalTokens, 0).d
           << std::endl;
      }

    }
    */
    cppcc::tnm::TokenNameContainer	defaultTokenNames;
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator ci = 
      defaultTokenNames.tokenNames_.begin();
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator ce = 
      defaultTokenNames.tokenNames_.end();
    for(std::size_t i = 0; ce != ci; ++ci, i++) {
      const std::string& n = (ci->second);

      kwc_.tokens_.push_back(n);
    }

	  // 	NameVector	keyWords_; ===>>>
	  // 	NameVector	nonTerminals_;
	  // 	First, generate nonTerminals_ from rule names.
	  // 	Second, generate keyWords_ that are from ptrids 
	  // 	but not in predefined_, neither in tokens_, neither in nonTerminals_.
		
    // Extract rule names from grammar definition.    
		cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		  help_.k(KW_RULE);
    if (k) {
		  for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		    cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		    cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		    if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		      tok_.errorMessage(errorNoIdentifierFound);
		        CPPCC_THROW_EXCEPTION(
		          << errorNoIdentifierFound
		          << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		        )
		    }

		    kwc_.nonTerminals_.push_back(bin_.ptrids(kn.d));      
		  }
	  }		

    // 	NameVector	keyWords_;    
    //  Key Words must be extracted from Grammar
    //  processing all rules looking for the righ part having 'xyz'...
    //111// cppcc::com::KeyWordsContainer::NameVector allKeyWords = grammarKeyWords();
    //111// kwc_.keyWords_ = finalize(kwc_.predefined_, kwc_.nonTerminals_, allKeyWords);
    kwc_.keyWords_ = grammarKeyWords();
    cppcc::com::KeyWordsContainer::NameVector genKeyWords =
      finalize(kwc_.predefined_, kwc_.nonTerminals_, kwc_.keyWords_);

    // Dump kwc_
    if (isDebug_) {
      std::cout
        << "GenerateKeyWordsContainer::generate:" 
        << " genKeyWords:" << genKeyWords
        << " kwc:" << kwc_
        << std::endl;
    }
  }

	GenerateKeyWordsContainer
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
    , bin_(binary.generator_.parser_.binary_)
    , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
    , tok_(binary_.generator_.parser_.tokenizer_)
    , kwc_()
    , isDebug_(1)
	{
		generate();
	}
};
/////////////////



struct GenerateKeyWordsContainer
{
	cppcc::gen::GeneratorBinary&                binary_;
	std::string                                 filename_;
  cppcc::scb::SyntaxControlledBinary&         bin_;
  cppcc::scb::SyntaxControlledBinary::Helper  help_;
  cppcc::lex::Tokenizer&                      tok_;
  cppcc::com::KeyWordsContainer               kwc_;
  int                                         isDebug_;
. . . 
////////////////
void        
metaFirstGeneratorBinary::generate(const std::string& filename)
{
  GenerateKeyWordsContainer g0(*this, filename);

	GenerateGeneratorH 				g1(*this, filename);
	
	//GenerateKeyWordDefinitionH 		g2(*this, filename);
	V2GenerateKeyWordDefinitionH 		g2(g0);

	GenerateParserH					g3(*this, filename);
	GenerateGeneratorCC				g4(*this, filename);
	
	//GenerateKeyWordDefinitionCC		g5(*this, filename);
	V2GenerateKeyWordDefinitionCC		g5(g0);

	GenerateMakeGeneratorsCC		g6(*this, filename);
	GenerateParserCC				g7(*this, filename);
}

////////////////

////////////////////
....................
  
class GenerateKeyWordDefinitionH
{
	cppcc::gen::GeneratorBinary&				binary_;
	std::string 								filename_;
    cppcc::scb::SyntaxControlledBinary&     	bin_;
    cppcc::scb::SyntaxControlledBinary::Helper  help_;
    cppcc::lex::Tokenizer&            			tok_;
		
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionHCodeStartSize; i++) {
			output << line(KeyWordDefinitionHCodeStart[i], gn) << std::endl;
		}
			
		std::size_t cnt = 0;
		for (std::size_t i = 0; i < predefSize_; i++) {
			output << "  // " << cnt+i << std::endl;
			output 
				<< "  " 
				<< std::string(i?",":"")
				
			    //22// << prefix << upper(predef_[i]) 
				//22// // B: no suffix..... << predefinedSuffix
			    //kw// << predefinedKeyWord(predef_[i])
			    << prefixKeyWord(predef_[i])
				
				<< std::endl;
		}		
		cnt += predefSize_;
		
		std::size_t tokensSize = 
		  binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  //kw// << tokenKeyWord(cIter->second)
			  << prefixKeyWord(cIter->second)
			  << std::endl;
		}	
		cnt += tokensSize;
		
    bool isGeneratedFromIDs = false;
    if (isGeneratedFromIDs) {
		  std::size_t keyWordsSize = 
			  binary_.generator_.parser_.grammarSymbols_.keyWords_.size();
		  for (std::size_t i = 0; i < keyWordsSize; i++) {
			  const std::string& 	rw = 
				  binary_.generator_.parser_.grammarSymbols_.keyWords_[i];
		
			  output << "  // " << cnt+i << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;
			
		  }
		  cnt += keyWordsSize;
    } else {
      // loop for all context identifiers.
      cppcc::scr::tag::Long ids_size = bin_.head()->cntnid;
      cppcc::scr::tag::Long sz = 0;
      for (cppcc::scr::tag::Long i = 0; i < ids_size; i++) {
        //std::string 	rw = bin_.ptrids(i);
        std::string 	rw = bin_.ptridn(i);

        if(isPredefined(rw)) {
          continue;
        }

        ///output << "  // " << cnt+i << std::endl;
        output << "  // " << cnt+sz << std::endl;
			  output 
				  << "  " 
				  << ","
				  //kw// << reservedKeyWord(rw)
				  << prefixKeyWord(rw)
				  << std::endl;

        sz++;
      }

      cnt += sz;
    }
		
		///--------------------------------------
	    
	    bool isGeneratedFromGrammarSymbols = false;
	    if (isGeneratedFromGrammarSymbols) {
			std::size_t nonTerminalsSize = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
			for (std::size_t i = 0; i < nonTerminalsSize; i++) {
				const std::string& 	nont = 
					binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
			
				output << "  // " << cnt+i << std::endl;
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(nont)
					<< std::endl;
			}
			cnt += nonTerminalsSize;
	    }
		else {
      bool doit = false;
      if (doit) {
		      // Extract rule names from grammar definition.    
		   cppcc::scb::SyntaxControlledBinary::Helper::kwn& k = 
		        help_.k(KW_RULE);
		   if (k) {
		      for (std::size_t nnrule = 0, z = k.edps_.size(); nnrule < z; nnrule++) {
		        cppcc::scb::SyntaxControlledBinary::Helper::edp& eru = k.e(nnrule);
		                  
		        cppcc::scr::tag::TypeInstance&  kn  = eru.fixed(1);
		        if (cppcc::com::PLS_IDENTIFIER != kn.t) {
		          tok_.errorMessage(errorNoIdentifierFound);
		           CPPCC_THROW_EXCEPTION(
		             << errorNoIdentifierFound
		             << " rule:" << nnrule << " k:" << kn.t << " n:" << kn.d
		           )
		        }
		        
		        output << "  // " << cnt+nnrule << std::endl;  
				output 
					<< "  " 
					<< ","
					//kw// << nonTerminalKeyWord(nont)
					<< prefixKeyWord(bin_.ptrids(kn.d))
					<< std::endl;
		        
		       }
		   }			
		   cnt += k.edps_.size();
      }
		}
		///------------------------------------

		
		output << "  // " << cnt << " -- Total"<< std::endl;
		output 
			<< "  " 
			<< ","
			//kw// << totalKeyWord()
			<< prefixKeyWord(totalSuffix)
			<< std::endl;
		
		
		for (std::size_t i = 0; i < KeyWordDefinitionHCodeFinishSize; i++) {
			output << line(KeyWordDefinitionHCodeFinish[i], gn) << std::endl;
		}		
	}		

	
public:
	GenerateKeyWordDefinitionH
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
        , bin_(binary.generator_.parser_.binary_)
        , help_(cppcc::scb::SyntaxControlledBinary::Helper(bin_,KW_KEYWORDS_TOTAL))
        , tok_(binary_.generator_.parser_.tokenizer_)
	{
		generate();
	}	
};
....................
////////////////////


/////////////////////
	//GenerateKeyWordDefinitionCC		g5(*this, filename);
	V2GenerateKeyWordDefinitionCC		g5(g0);

/////////////////////


///////-----------------------------------

class GenerateKeyWordDefinitionCC
{
	cppcc::gen::GeneratorBinary&	binary_;
	std::string 				filename_;
	
	
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.cc";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeStartSize; i++) {
			output << line(KeyWordDefinitionCCCodeStart[i], gn) << std::endl;
		}
		output << std::endl;
		
		output << "  static std::string   predef_[] =" << std::endl;
		output << "  {" << std::endl;
		for (std::size_t i = 0; i < predefSize_; i++) {
			output 
				<< "    " 
				<< std::string(i?",":"")				
			    << "\"" << predef_[i] << "\""				
				<< std::endl;
		}		
		output << "  };" << std::endl;
		output << "  static std::size_t  predefSize_ =" << std::endl; 
		output << "  sizeof(predef_)/sizeof(predef_[0]);" << std::endl; 
		output << std::endl;
		
		output << "  static std::string   charTokens_[] =" << std::endl;
		output << "  {" << std::endl;		
		std::size_t tokensSize = 
		  binary_.generator_.parser_.grammarSymbols_.tokens_.size();
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output 
			  << "    " 
			  << std::string(i?",":"")	
			  //<< tokenKeyWord(cIter->second)
		      << "\"" 
		         << (("\"" == cIter->first)?("\\"):(""))
		         << cIter->first 
		      << "\""		
			  << std::endl;
		}	
		output << "  };" << std::endl;
		output << "  static std::size_t  charTokensSize_ =" << std::endl; 
		output << "  sizeof(charTokens_)/sizeof(charTokens_[0]);" << std::endl; 
		output << std::endl;
		
		std::size_t keyWordsSize = 
			binary_.generator_.parser_.grammarSymbols_.keyWords_.size();

	    output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "  static std::string   keyWords_[] =" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  {" << std::endl;
			
		for (std::size_t i = 0; i < keyWordsSize; i++) {
				const std::string& 	rw = 
				binary_.generator_.parser_.grammarSymbols_.keyWords_[i];
		
				output
					<< "    " 
					<< std::string(i?",":"")	
					<< "\""  << rw << "\"" 
					<< std::endl;
		}
			
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  };" << std::endl;
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  static std::size_t  keyWordsSize_ =" << std::endl; 
		output
		  << ((keyWordsSize > 0)?(""):("// "))
		  << "  sizeof(keyWords_)/sizeof(keyWords_[0]);" << std::endl; 
		
		output 
		  << ((keyWordsSize > 0)?(""):("// "))
		  << std::endl;
		
		
		output << "  static std::string   non_Terminals_[] =" << std::endl;
		output << "  {" << std::endl;
		std::size_t nonTerminalsSize = 
			binary_.generator_.parser_.grammarSymbols_.nonTerminals_.size();
		for (std::size_t i = 0; i < nonTerminalsSize; i++) {
			const std::string& 	nont = 
				binary_.generator_.parser_.grammarSymbols_.nonTerminals_[i];
		
			output 
				<< "    " 
				<< std::string(i?",":"")	
				<< "\""  << nont << "\"" 
				<< std::endl;
			
		}
		output << "  };" << std::endl;
	    output << "  static std::size_t  non_TerminalsSize_ =" << std::endl; 
	    output << "  sizeof(non_Terminals_)/sizeof(non_Terminals_[0]);" << std::endl; 
	    output << std::endl;
		

	    //---
	    output << "}" << std::endl;
	    output << "" << std::endl;
	    output << "cppcc::com::KeyWordsContainer makeKeyWordsContainer()" << std::endl;
	    output << "{" << std::endl;
	    output << "  cppcc::com::KeyWordsContainer result;" << std::endl;
	    output << "  result.predefined_.assign(predef_,predef_+predefSize_);" << std::endl;
	    output << "  result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);" << std::endl;
	    
	    output 
	      << ((keyWordsSize > 0)?(""):("// "))
	      << "result.keyWords_.assign(keyWords_,keyWords_+keyWordsSize_);" << std::endl;
	    
	    output << "  result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);" << std::endl;
	    output << "  return result;" << std::endl;
	    //---
		
		for (std::size_t i = 0; i < KeyWordDefinitionCCCodeFinishSize; i++) {
			output << line(KeyWordDefinitionCCCodeFinish[i], gn) << std::endl;
		}		
	}			
	
public:
	GenerateKeyWordDefinitionCC
		(cppcc::gen::GeneratorBinary&	binary
		,const std::string& 		filename)
		: binary_(binary)
		, filename_(filename)
	{
		generate();
	}	
};
///////...................................

///////...................................

// V2GenerateKeyWordDefinitionH +++++++++++++++++++++++
class V2GenerateKeyWordDefinitionH
{
	// cppcc::gen::GeneratorBinary&                binary_;
	// std::string                                 filename_;
  // cppcc::scb::SyntaxControlledBinary&         bin_;
  // cppcc::scb::SyntaxControlledBinary::Helper  help_;
  // cppcc::lex::Tokenizer&                      tok_;
  GenerateKeyWordsContainer&  gkwc_;
		
	void generate()
	{
		std::string 	ext = "KeyWordDefinition.h";
		//std::size_t   	dot = filename_.find_last_of('.');
		std::string 	gn  = name(gkwc_.filename_);
		std::string 	fn  = gn+ext;
		//std::string 	prefix = "KW_";
		
		// B: no suffix
		//std::string 	predefinedSuffix = "_TOKEN";
		
		std::ofstream 	output;  	
			
		output.open(fn.c_str());
		if (!output) {
			std::string   syserr = cppcc::com::CPPCCException::systemError();     
			CPPCC_THROW_EXCEPTION(
			  << "Can't open file for writing gnerated code:'"
			  << fn
			  << "' - Reason:'"
			  << syserr
			  << "'"
			)
		}

		for (std::size_t i = 0; i < KeyWordDefinitionHCodeStartSize; i++) {
			output << line(KeyWordDefinitionHCodeStart[i], gn) << std::endl;
		}
			
		std::size_t cnt = 0;
    std::size_t predefinedSize = gkwc_.kwc_.predefined_.size();
		for (std::size_t i = 0; i < predefinedSize; i++) {
			output << "  // " << cnt+i << std::endl;
			output 
        << "  " 
        << std::string(i?",":"")
        << prefixKeyWord(gkwc_.kwc_.predefined_[i])
        << std::endl;
		}		
		cnt += predefinedSize;
		
		std::size_t tokensSize = 
		  gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_.size();
    std::size_t tokensSizeReal = 0;
		cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd=
		  gkwc_.binary_.generator_.parser_.tokenizer_.
		    defaultTokenNames_.tokenNames_.end();
		for (std::size_t i = 0; i < tokensSize; i++) {
		  const std::string& 	t = 
		    gkwc_.binary_.generator_.parser_.grammarSymbols_.tokens_[i];  
		  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
			gkwc_.binary_.generator_.parser_.tokenizer_.
			  defaultTokenNames_.tokenNames_.find(t);
		  if (cEnd == cIter) {
			  continue;
		  }
		  
		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  //kw// << tokenKeyWord(cIter->second)
			  << prefixKeyWord(cIter->second)
			  << std::endl;
      tokensSizeReal++;
		}	
		cnt += tokensSizeReal;
		
    ///++++++++++++++++++++++++++++++++++++++
    /// termToken instances
    ///......................................
    /// Loop through gkwc_.kwc_.keyWordsGenerated_
    std::size_t keyWordsGeneratedSize = gkwc_.kwc_.keyWordsGenerated_.size();
    for (std::size_t i = 0; i < keyWordsGeneratedSize; i++) {
      const std::string& 	n = gkwc_.kwc_.keyWordsGenerated_[i];

		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  << prefixKeyWord(n)
			  << std::endl;
    }
    cnt += keyWordsGeneratedSize;
		
		///++++++++++++++++++++++++++++++++++++++
    // nonTerminals
		///......................................
    /// Loop through gkwc_.kwc_.nonTerminals_
    std::size_t nonTerminalsdSize = gkwc_.kwc_.nonTerminals_.size();
    for (std::size_t i = 0; i < nonTerminalsdSize; i++) {
      const std::string& 	n = gkwc_.kwc_.nonTerminals_[i];

		  output << "  // " << cnt+i << std::endl;
		  output 
			  << "  " 
			  << ","
			  << prefixKeyWord(n)
			  << std::endl;
    }
    cnt += nonTerminalsdSize;
		
		output << "  // " << cnt << " -- Total"<< std::endl;
		output 
			<< "  " 
			<< ","
			//kw// << totalKeyWord()
			<< prefixKeyWord(totalSuffix)
			<< std::endl;
			
		for (std::size_t i = 0; i < KeyWordDefinitionHCodeFinishSize; i++) {
			output << line(KeyWordDefinitionHCodeFinish[i], gn) << std::endl;
		}		
	}		

	
public:
	V2GenerateKeyWordDefinitionH
		(GenerateKeyWordsContainer&   gkwc)
		: gkwc_(gkwc)
	{
		generate();
	}	
};

// V2GenerateKeyWordDefinitionH -----------------------
///////...................................

// V2GenerateKeyWordDefinitionH +++++++++++++++++++++++
class GenerateKeyWordDefinitionCC
{
	// cppcc::gen::GeneratorBinary&                binary_;
	// std::string                                 filename_;
  // cppcc::scb::SyntaxControlledBinary&         bin_;
  // cppcc::scb::SyntaxControlledBinary::Helper  help_;
  // cppcc::lex::Tokenizer&                      tok_;
  GenerateKeyWordsContainer&  gkwc_;
/////////////////////////////////////////////////////////////////////
//	metaFirstMakeGenerators.cc 
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metaFirstParser.h"
#include "metaFirstKeyWordDefinition.h"
#include "metaFirstGenerator.h"

namespace cppcc {


namespace com {
   
cppcc::gen::GeneratorRuntime*    
makeRuntimeGenerator(cppcc::gen::Generator&   generator)
{
	return new cppcc::metafirst::metaFirstGeneratorRuntime(generator);
}

cppcc::gen::GeneratorBinary*
makeBinaryGenerator(cppcc::gen::Generator&   generator)
{
	return new cppcc::metafirst::metaFirstGeneratorBinary(generator);	
}
}



}


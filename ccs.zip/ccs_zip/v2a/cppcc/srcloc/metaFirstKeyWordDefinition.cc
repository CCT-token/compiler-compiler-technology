/////////////////////////////////////////////////////////////////////
//	KeyWordDefinition.cc <- metaaKeyWordDefinition.cc
/////////////////////////////////////////////////////////////////////


#include "metaFirstKeyWordDefinition.h"

namespace cppcc {
namespace metafirst {

namespace {
  static std::string   predef_[] =
  {
    "WrongKeyWord"
    ,"identifier"
    ,"stringToken"
    ,"integerToken"
    ,"floatToken"
    ,"textToken"
    ,"termToken"
    ,"termTokenOfRule"
  };
  static std::size_t	predefSize_ = 
    sizeof(predef_)/sizeof(predef_[0]);
  
  static std::string   charTokens_[] =
  {
	"\""
    ,"'" 
    ,"("
    ,")"
    ,"<"
    ,"="
    ,">"
    ,"["
    ,"]"
    ,"|"
    ,"{"
    ,"}"
    
    /* ++++
    ,"?"
    ,"/"
    ,"</"
    // ----
     * 
     */
    
    ,"::="
    ////
    // xml :::::::::::
    ,":"
    ,"?"
    ,"/"
    ,"</"
    // xml ...........
    ////
    
    // dot::::::::::::
    ,","
    ,";"
    ,"->"
    //,"digraph"
    //,"subgraph"
    // dot ...........
    
  };
  static std::size_t	charTokensSize_ = 
    sizeof(charTokens_)/sizeof(charTokens_[0]);
 
  static std::string   non_Terminals_[] =
  {
    "grammar"
	//,"grammerNameDef"
	,"grammarNameDef"
	,"rule"
	,"nterm"
	,"right"
	,"element"
	,"action"
	,"actions"
	,"identAlt"
	,"Altpart"
	,"ntermtermact"
	,"ntermterm"
	,"alternative"
	,"identMiss"
	,"iteration"
	,"iterItems"
	,"altIterItem"
	,"iterItemact"
	,"iterItem"
	,"maybeNterm"
  };
  static std::size_t	non_TerminalsSize_ = 
    sizeof(non_Terminals_)/sizeof(non_Terminals_[0]);  
}

cppcc::com::KeyWordsContainer makeKeyWordsContainer()
{
	cppcc::com::KeyWordsContainer result;
	
	result.predefined_.assign(predef_,predef_+predefSize_);
	result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);
	//result.keyWords_.assign(keyWords_,keyWords_+keyWordsSize_);
	result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);
	
	return result;
}



}

namespace com {
cppcc::com::KeyWordsContainer
makeCompilerKeyWords()
{
	return cppcc::metafirst::makeKeyWordsContainer();
}
}

}


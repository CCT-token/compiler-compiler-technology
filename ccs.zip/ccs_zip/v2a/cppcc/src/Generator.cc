////////////////////////////////////////////////////////////////////////
// Generator.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Generator.h"
#include "Parser.h"

#include "CommonRoutines.h"

namespace cppcc {
namespace gen {


namespace {
	//const std::string oneTab("\t");
	const std::string oneTab("  ");
	  
	  int     spaces[][cppcc::com::PLS_TERMINALS_START] = {
	    {0, 0, 0, 0, 0, 0, 0, 0}
	    ,{0, 1, 1, 1, 1, 0, 0, 1}
	    ,{0, 1, 1, 1, 1, 0, 0, 1}
	    ,{0, 1, 1, 1, 1, 0, 0, 1}
	    ,{0, 1, 1, 1, 1, 0, 0, 1}
	    //,{0, 1, 1, 1, 1, 0, 0, 0}
	    ,{0, 0, 0, 0, 0, 0, 0, 0}
	    ,{0, 0, 0, 1, 1, 0, 0, 1}
	    ,{0, 0, 0, 1, 1, 0, 0, 1}
	  };

	  //std::string specialCharacterConversion(const char* s)
	  std::string specialCharacterConversion(const std::string& s)
	  {
	    std::string r;
	    for (std::size_t i = 0; i < s.size(); i++) {
	      char c = s[i];
	    //while (char c = *s++) {

	      if ('<' == c) {
	        r.push_back('&');
	        r.push_back('l');
	        r.push_back('t');
	        r.push_back(';');
	      } else {
	        r.push_back(c);
	      }
	    }

	    return r;
	  }
}



/*
  Generator(cppcc::syn::Parser&     parser)
    : binary_(cppcc::com::makeBinaryGenerator(*this))
    , runtime_(cppcc::com::makeRuntimeGenerator(*this))
    , parser_(parser)
  {
	  prolog();
  }
*/
/*
Generator::Generator(cppcc::syn::Parser&     parser)
// 444 // : binary_(cppcc::com::makeBinaryGenerator(*this))
// 444 // , runtime_(cppcc::com::makeRuntimeGenerator(*this))
// 444 //, parser_(parser)
	 : binary_(cppcc::com::makeBinaryGenerator(parser))
	 , runtime_(cppcc::com::makeRuntimeGenerator(parser))
{
  prolog();
}
*/

void
Generator::prolog()
{
}

void
Generator::epilog() throw()
{
}

/*
void 
Generator::decompileRuntime(const std::string& filename)
	  { runtime_->decompile(filename); }

void 
Generator::decompileBinary(const std::string& filename)
	  { binary_->decompile(filename); }

void 
Generator::generateFromRuntime(const std::string& filename)
	  { runtime_->generate(filename); }

void 
Generator::generateFromBinary(const std::string& filename)
	  { binary_->generate(filename); }
*/

//------------------------------------------------------


void
GeneratorRuntime::generate(const std::string& filename)
{

}

std::string
GeneratorRuntime::grammarName()
{
/*
	//return "metafirst";
	std::string gn("");
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  generator_.parser_.runtime_.cnms_.dataByKey
		(generator_.parser_.runtime_.cnmnumCurrent_);
	cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	  generator_.parser_.runtime_.kwnLookup(KW_RULE_NON_TERMINAL);
	cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
	  kwnInstance.edps_.dataByIndex(0);
	//if (2 == edpInstance.edpfix_.size()) {
	if (edpInstance.edpfix_.size() >= 2) {
	  cppcc::scr::tag::Long k;
	  cppcc::scr::tag::Long n;
      cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
      if (KW_IDENTIFIER_TOKEN == k) {
        cppcc::scr::SyntaxControlledRuntime::nam namInstance=
   	      currentContext.namn_.dataByIndex(n);
        gn = namInstance.namkey_;
      }
	}
	
	return gn;
*/
// Returns 'grammar' since
// 
//	  (rule ::= 	'(' nterm '::=' right ')'
//	  )
//
//	  (nterm	 ::= identifier
//	  )
//
//
	std::string gn("");
	cppcc::scr::tag::Long 	kk; 
	cppcc::scr::tag::Long 	nn;
	cppcc::scr::tag::setlongedf(&generator_.parser_.axiom_,kk,nn);
	  
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  generator_.parser_.runtime_.cnms_.dataByKey
		(generator_.parser_.runtime_.cnmnumCurrent_);
	cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	  generator_.parser_.runtime_.kwnLookup(kk);
	cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
	  kwnInstance.edps_.dataByKey(nn);
	//if (2 == edpInstance.edpfix_.size()) {
	if (edpInstance.edpfix_.size() >= 2) {
	  cppcc::scr::tag::Long k;
	  cppcc::scr::tag::Long n;
      cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
      if (cppcc::com::PLS_IDENTIFIER == k) {
        cppcc::scr::SyntaxControlledRuntime::nam namInstance=
   	      currentContext.namn_.dataByIndex(n);
        gn = namInstance.namkey_;
      }
	}
	
	return gn;
	
}

void
GeneratorRuntime::decompile(const std::string& fname)
{
  std::string	gName = grammarName();
  filename_ = 
	(!fname.size() || ("" == fname))	  
     ? (gName + ".urt")
     : fname
  ;
 
  if (0) {
	  if (generator_.parser_.runtime_.debug_ || debug_) {
		std::cout 
		<< "Runtime::decompile:0:"
		<< " ctx:" << generator_.parser_.context_
		<< " a:" << generator_.parser_.axiom_
		<< " n:" << "'" << gName << "'"
		<< " cnmnumCurrent_:" << generator_.parser_.runtime_.cnmnumCurrent_
		<< " filename:" << "'" << filename_ << "'"
		<< std::endl;   
	  }
  }
  
  output_.open(filename_.c_str());
  if (!output_) {
      std::string   syserr = cppcc::com::CPPCCException::systemError();     
      CPPCC_THROW_EXCEPTION(
      << "Can't open file for runtime decompiling:'"
      << filename_
      << "' - Reason:'"
      << syserr
      << "'"
      )
  }
  
  // Dump the content first.
  int isDump = 0;
  if (isDump) {
	  generator_.parser_.runtime_.dump(output_);
  }
  
  scDecompileMain();
}


void
GeneratorRuntime::scDecompileMain_(std::ofstream&	output)
{
  scDecompile_(output, generator_.parser_.axiom_);
  if (StateLine_) {
	  output << std::endl;
  } 
  
  output << std::endl;
}


/*
//////////////////////////////////////////////
// version that works, but it has 
//  < ? xml version =
//    < xs : annotation .... etc...
// In generic scDecompile_ there is not supposed to be any blanks
//  between tokens.
//////////////////////////////////////////////
void
GeneratorRuntime::scDecompile_
	(std::ofstream&				output
	,cppcc::scr::tag::Long& 	tag)
{
	
	
  if(!tag) return;
  
  cppcc::scr::tag::Long rrr = tag;
  cppcc::scr::tag::Long kkk;
  cppcc::scr::tag::Long nnn;
  cppcc::scr::tag::setlongedf(&rrr,kkk,nnn);

  StateLine_= 1;
  
  cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	generator_.parser_.runtime_.cnms_.dataByKey
     (generator_.parser_.runtime_.cnmnumCurrent_);
  cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	generator_.parser_.runtime_.kwnLookup(kkk);

  
  if(cppcc::com::PLS_IDENTIFIER == kkk) {
	cppcc::scr::SyntaxControlledRuntime::nam namInstance=
        currentContext.namn_.dataByIndex(nnn);
	
	output << " " << namInstance.namkey_ ;

    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == kkk) {
    cppcc::scr::SyntaxControlledRuntime::nam namInstance=
      currentContext.namn_.dataByIndex(nnn);
    
    std::string tn = namInstance.namkey_;
    bool y = false;
    for (std::size_t j = 0, 
      z = generator_.parser_.tokenizer_.language_->tokens_.tokens_.size();
      j < z; j++
    ) {
      lex::Token* token = 
        generator_.parser_.tokenizer_.
    	  language_->tokens_.tokens_[j];
      if (token && (namInstance.namkey_ == token->name_)) {
    	  tn = token->token_;
    	  y = true;
    	  break;
      }
    }
    
    output << " " 
    		<< (y?std::string("'"):std::string("")) 
    		<< tn << (y?std::string("'"):std::string(""))
    ;
    
    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMINAL_TOKEN == kkk) {
    cppcc::lex::Token& token = 
      generator_.parser_.tokenizer_.language_->getToken(nnn);
    output << " " << token.token_;
    
    makeAlignment(token);
    
    LastKey_= kkk;
    //Lasty_= 1;
    //Lasti_= i;
    Lastnnn_= nnn;
    return;    
  }
  
  cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
      kwnInstance.edps_.dataByKey(nnn);

  switch (kkk) 
  {
    case cppcc::com::PLS_STRING_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
    	output << " " << "\"" << ((char*)&edpInstance.edpfix_[0]) << "\"";
        LastKey_= kkk;
      }
      return;
    }
    case cppcc::com::PLS_INTEGER_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
        output << " " << edpInstance.edpfix_[0];
        LastKey_= kkk;
      }
      return;
    }
    case cppcc::com::PLS_FLOAT_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
        output << " " << (*((cppcc::scr::tag::Real*)&edpInstance.edpfix_[0]));
        LastKey_= kkk;
      }
      return;
    }  
    default:
    {
	  if (edpInstance.edpfix_.size()) {
	    for (std::size_t i = 0, z = edpInstance.edpfix_.size(); i < z; i++) {
	  	  scDecompile_(output,edpInstance.edpfix_[i]);
	    }
	  }
	  
	  if (edpInstance.edpdyn_.size()) {
	    for (std::size_t i = 0, z = edpInstance.edpdyn_.size(); i < z; i++) {
	      scDecompile_(output,edpInstance.edpdyn_[i]);
	    }	  
	  }	  
    }
  }
}
//////////////////////////////////
*/

void 
GeneratorRuntime::scDecompileSpace
  (std::ofstream&         output
  ,cppcc::scr::tag::Long  kkk)
{
  if ((kkk < 0) || (kkk >= cppcc::com::PLS_TERMINALS_START)) return;
  
  int numberOfSpaces = spaces[kkk][LastKKK_];
  if (1 == numberOfSpaces) {
    output << " ";
  }
  
  LastKKK_ = kkk;
}

void
GeneratorRuntime::scDecompile_
	(std::ofstream&				output
	,cppcc::scr::tag::Long& 	tag)
{
	
	
  if(!tag) return;
  
  cppcc::scr::tag::Long rrr = tag;
  cppcc::scr::tag::Long kkk;
  cppcc::scr::tag::Long nnn;
  cppcc::scr::tag::setlongedf(&rrr,kkk,nnn);

  scDecompileSpace(output, kkk);
  
  StateLine_= 1;

  //if(kkk == KW_TEXTTOKEN) {
  // 999.1 : //
  //if(kkk == cppcc::com::PLS_TEXT_TOKEN) {
  //  StringXmlTokenMode_ = 1;
  //}
  // 999.1 . //
  
  cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	generator_.parser_.runtime_.cnms_.dataByKey
     (generator_.parser_.runtime_.cnmnumCurrent_);
  cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	generator_.parser_.runtime_.kwnLookup(kkk);

  
  if(cppcc::com::PLS_IDENTIFIER == kkk) {
	cppcc::scr::SyntaxControlledRuntime::nam namInstance=
        currentContext.namn_.dataByIndex(nnn);
	
	//99//  output << " " << namInstance.namkey_ ;
	//99.1// 
  // ub:
	//output << namInstance.namkey_ ;
  output << namInstance.namkey_ << " " ;

    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == kkk) {
    cppcc::scr::SyntaxControlledRuntime::nam namInstance=
      currentContext.namn_.dataByIndex(nnn);
    
    std::string tn = namInstance.namkey_;

    // ub:
    /*
    bool y = false;
    for (std::size_t j = 0, 
      z = generator_.parser_.tokenizer_.language_->tokens_.tokens_.size();
      j < z; j++
    ) {
      lex::Token* token = 
        generator_.parser_.tokenizer_.
    	  language_->tokens_.tokens_[j];
      if (token && (namInstance.namkey_ == token->name_)) {
    	  tn = token->token_;
    	  y = true;
    	  break;
      }
    }
    

    //99// 
    /////output << " " 
    // 99.1// 
    output 
    	  // 99.2// output << std::string(y?"":" ")
        // BUG: ub
    		// << (y?std::string("'"):std::string("")) 
    		// << tn << (y?std::string("'"):std::string(""))
        // ==>>
        << "'" << tn << "'"
    ;
    */
    // Verify that PLS_TERMTOKENOFRULE_TOKEN goes with '{', '}', etc...
    //
    /*
    cppcc::lex::Tokens::Name2IndexMap::const_iterator cf = 
      generator_.parser_.tokenizer_.language_->tokens_.name2index_.find(tn);
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ce =
      generator_.parser_.tokenizer_.language_->tokens_.name2index_.end();
    bool y = (ce != cf);
    //
    std::string tn2;
    if (y) {
      cppcc::lex::Token* token = 
        generator_.parser_.tokenizer_.language_->tokens_.tokens_
          [cf->second];
      if (token)
      {
        tn2 = token->token_;
      }
      else {
        // exception !
      }
    } else {
      tn2 = tn;
    }
    */
    std::string tn2 = generator_.parser_.tokenizer_.language_->tokens_.gid(tn);


    output 
      << "'" << tn2 << "'"
    ;

    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMINAL_TOKEN == kkk) {
    cppcc::lex::Token& token = 
      generator_.parser_.tokenizer_.language_->getToken(nnn);
    /*
    //99// output << " " << token.token_;
    //99.1// 
    // ub:
    ///// output << token.token_;
    output << token.name_ << " " ;
    */
    // Verify that PLS_TERMINAL_TOKEN goes with termToken, i.e. 'case', 'swithc', etc...
    output << token.gid() << " " ;

    makeAlignment(token);
    
    
    LastKey_= kkk;
    //Lasty_= 1;
    //Lasti_= i;
    Lastnnn_= nnn;
    return;    
  }
  
  /*
  ///// should be another method similar to makeAlignment.
  if (cppcc::com::PLS_TERMINAL_TOKEN == LastKey_) {
	cppcc::lex::Token& lastToken = 
	  generator_.parser_.tokenizer_.language_->getToken(Lastnnn_);
	
	if ((">" == lastToken.token_) && ((kkk != cppcc::com::PLS_TEXT_TOKEN))) {
	  output << std::endl;
	  for (scr::tag::Long j = 0; j < Level_; j++)
	  {
		 output << oneTab;
	  }		
	}
  }
  /////
   */

  //--!!!!!!!!!!!!!!  
  // BUG: ub
  cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
      kwnInstance.edps_.dataByKey(nnn);
  // ==>>>>
  /*
  try {
    cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
      kwnInstance.edps_.dataByKey(nnn);
  */

  switch (kkk) 
  {
    case cppcc::com::PLS_STRING_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
    	
    	// 999.1 : //
    	// if (StringXmlTokenMode_) {
    	//   output << ((char*)&edpInstance.edpfix_[0]); 
    	//   StringXmlTokenMode_ = 0;
    	// }
    	// else {
    	//   //99// output << " " << "\"" << ((char*)&edpInstance.edpfix_[0]) << "\"";
    	//   //99.1// 
    	//   output << "\"" << ((char*)&edpInstance.edpfix_[0]) << "\"";
    	// }
    	// 999.1 : //
    	output << "\"" << ((char*)&edpInstance.edpfix_[0]) << "\"";
    	
        LastKey_= kkk;
      }
      return;
    }
    case cppcc::com::PLS_INTEGER_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
    	//99// output << " " << edpInstance.edpfix_[0];
        //99.1// 
    	output << edpInstance.edpfix_[0];
        LastKey_= kkk;
      }
      return;
    }
    case cppcc::com::PLS_FLOAT_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
    	//99// output << " " << (*((cppcc::scr::tag::Real*)&edpInstance.edpfix_[0]));
        //99.1/
    	output << (*((cppcc::scr::tag::Real*)&edpInstance.edpfix_[0]));
        LastKey_= kkk;
      }
      return;
    }  
    case cppcc::com::PLS_TEXT_TOKEN:
    {
      if(edpInstance.edpfix_.size()) {
    	if(2 == edpInstance.edpfix_.size()) {
    		
    	  cppcc::scr::tag::Long kkk0;
    	  cppcc::scr::tag::Long nnn0;
    	  cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[0],kkk0,nnn0);
   				
    	  cppcc::scr::tag::Long kkk1;
    	  cppcc::scr::tag::Long nnn1;
    	  cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],kkk1,nnn1);
   		
    	  if((cppcc::com::PLS_TERMINAL_TOKEN == kkk0)
    	    && (cppcc::com::PLS_STRING_TOKEN == kkk1)) {
    	       cppcc::lex::Token& token0 = 
    	          generator_.parser_.tokenizer_.language_->getToken(nnn0);
    	       
    	       cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext1 = 
    	     	generator_.parser_.runtime_.cnms_.dataByKey
    	          (generator_.parser_.runtime_.cnmnumCurrent_);
    	       cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance1 = 
    	     	generator_.parser_.runtime_.kwnLookup(kkk1);

    	       cppcc::scr::SyntaxControlledRuntime::edp& edpInstance1 = 
    	           kwnInstance1.edps_.dataByKey(nnn1);

    	       output 
    	         << token0.token_ 
    	         //special// << ((char*)&edpInstance1.edpfix_[0]);
    	         << specialCharacterConversion((char*)&edpInstance1.edpfix_[0]);
    
    	  }
    	}
 
        LastKey_= kkk;     
        //Lastnnn_= nnn;
      }
      return;
    }
    default:
    {
	  if (edpInstance.edpfix_.size()) {
	    for (std::size_t i = 0, z = edpInstance.edpfix_.size(); i < z; i++) {
	  	  scDecompile_(output,edpInstance.edpfix_[i]);
	    }
	  }
	  
	  if (edpInstance.edpdyn_.size()) {
	    for (std::size_t i = 0, z = edpInstance.edpdyn_.size(); i < z; i++) {
	      scDecompile_(output,edpInstance.edpdyn_[i]);
	    }	  
	  }	  
    }
  }

  /*
  ///===>>>
  } 
  catch(const std::exception& e)
  {
    std::cerr << e.what() << std::endl;
	  return;
  }
  catch(...) {
	  std::cerr << "uncaught exception!" << std::endl;
	  return;	
  } 
  //--!!!!!!!!!!!!!!
  */
}

//////////////////////////////////////////////////////////////////////
//
// GeneratorRuntime::GeneratorRuntimeStyle
// GeneratorRuntime::GeneratorRuntimeStyleXML
// GeneratorRuntime::GeneratorRuntimeStyleMeta
//
//////////////////////////////////////////////////////////////////////

/*
void
GeneratorRuntime::makeAlignment(cppcc::lex::Token& token)
{

	if (")" == token.token_) Level_--; 
	if ("(" == token.token_) Level_++; 

	if (
	  (")" == token.token_)	
	  || ("]" == token.token_)	
	  || ("|" == token.token_)	
	  || ("::=" == token.token_)	
	  || ("}" == token.token_)	
	)
	{
	  output_ << std::endl;
	  for (scr::tag::Long j = 0; j < Level_; j++)
	  {
	    output_ << oneTab;
	  }
	}
}
*/

void
GeneratorRuntime::GeneratorRuntimeStyleXML::makeAlignment
  (cppcc::lex::Token& token)
{
    //std::cout << "n:" << token.name_ << " t:" << token.token_ << std::endl;
	
	if ("</" == token.token_) generator_runtime_.Level_--; 
	if ("/" == token.token_) generator_runtime_.Level_--; 
	
	//// 
	if ("<" == token.token_) generator_runtime_.Level_++; 
	//if (("<" == token.token_) 
	//		&& (cppcc::com::PLS_TEXT_TOKEN != generator_runtime_.LastKey_)) {
	//  generator_runtime_.Level_++;
	//}

	if (
	  ("}" == token.token_)	
	  || (";" == token.token_)	
	  //// 
	  || (">" == token.token_)	
	  || ("," == token.token_)	
	)
	{
		generator_runtime_.output_ << std::endl;
	  for (scr::tag::Long j = 0; j < generator_runtime_.Level_; j++)
	  {
		  generator_runtime_.output_ << oneTab;
	  }
	}
}

void
GeneratorRuntime::GeneratorRuntimeStyleMeta::makeAlignment
  (cppcc::lex::Token& token)
{

	if (")" == token.token_) generator_runtime_.Level_--; 
	if ("(" == token.token_) generator_runtime_.Level_++; 

	if (
	  (")" == token.token_)	
	  || ("]" == token.token_)	
	  || ("|" == token.token_)	
	  || ("::=" == token.token_)	
	  || ("}" == token.token_)	
	)
	{
		generator_runtime_.output_ << std::endl;
	  for (scr::tag::Long j = 0; j < generator_runtime_.Level_; j++)
	  {
		  generator_runtime_.output_ << oneTab;
	  }
	}
}

GeneratorRuntime::GeneratorRuntime(Generator& generator)
	: generator_(generator)
    , style_(makeStyle(generator.tokenizerSet_))
	, filename_()
	, output_()
	, debug_(false)
	, Level_(0)
 	, StateLine_(0)
	, StateBlun_(0)
 	//, Lasty_(0)
	, Lastnnn_(0)
   	//, Lasti_(0)
  	, LastKey_(0)
    , StringXmlTokenMode_(0)
	, LastKKK_(0)
{}

GeneratorRuntime::GeneratorRuntimeStyle*		
GeneratorRuntime::makeStyle(cppcc::com::LanguageTokenizerSet 	tokenizerSet)
{
  //switch (generator_.parser_.tokenizer_.language_->tokenizerSet_) {
  //switch (generator_.parser_.tokenizerSet_) {
	
    //std::cout << "makeStyle:" << tokenizerSet << std::endl;	
	
  switch (tokenizerSet) {
  case cppcc::com::LanguageTokenizerSet_Undefined:
  case cppcc::com::LanguageTokenizerSet_Meta:
		return new GeneratorRuntime::GeneratorRuntimeStyleMeta(*this);
		break;
  case cppcc::com::LanguageTokenizerSet_XML:
	    return new GeneratorRuntime::GeneratorRuntimeStyleXML(*this);
		break;
  default:
	CPPCC_THROW_EXCEPTION(
		  << "GeneratorRuntime::makeStyle() failed"
		  << " wrong tokenizer set id:"
		  << generator_.parser_.tokenizer_.language_->tokenizerSet_
		  << " should be on of ["
		  << cppcc::com::LanguageTokenizerSet_Undefined
		  << " " << cppcc::com::LanguageTokenizerSet_Meta
		  << " " << cppcc::com::LanguageTokenizerSet_Meta
		  << "]!"
	)	  	  
  }
}

///////////////////////////////////////////////////////////////////////

/*
void
GeneratorBinary::makeAlignment(cppcc::lex::Token& token)
{

	if (")" == token.token_) Level_--; 
	if ("(" == token.token_) Level_++; 

	if (
	  (")" == token.token_)	
	  || ("]" == token.token_)	
	  || ("|" == token.token_)	
	  || ("::=" == token.token_)	
	  || ("}" == token.token_)	
	)
	{
	  output_ << std::endl;
	  for (scr::tag::Long j = 0; j < Level_; j++)
	  {
	    output_ << oneTab;
	  }
	}
}
*/
////////////////---------------------------------

void
GeneratorBinary::GeneratorBinaryStyleXML::makeAlignment
  (cppcc::lex::Token& token)
{
    //std::cout << "n:" << token.name_ << " t:" << token.token_ << std::endl;
	
	if ("</" == token.token_) generator_binary_.Level_--; 
	if ("/" == token.token_) generator_binary_.Level_--; 
	
	//// 
	if ("<" == token.token_) generator_binary_.Level_++; 
	//if (("<" == token.token_) 
	//		&& (cppcc::com::PLS_TEXT_TOKEN != generator_runtime_.LastKey_)) {
	//  generator_runtime_.Level_++;
	//}

	if (
	  ("}" == token.token_)	
	  || (";" == token.token_)	
	  //// 
	  || (">" == token.token_)	
	  || ("," == token.token_)	
	)
	{
		generator_binary_.output_ << std::endl;
	  for (scr::tag::Long j = 0; j < generator_binary_.Level_; j++)
	  {
		  generator_binary_.output_ << oneTab;
	  }
	}
}

void
GeneratorBinary::GeneratorBinaryStyleMeta::makeAlignment
  (cppcc::lex::Token& token)
{

	if (")" == token.token_) generator_binary_.Level_--; 
	if ("(" == token.token_) generator_binary_.Level_++; 

	if (
	  (")" == token.token_)	
	  || ("]" == token.token_)	
	  || ("|" == token.token_)	
	  || ("::=" == token.token_)	
	  || ("}" == token.token_)	
	)
	{
		generator_binary_.output_ << std::endl;
	  for (scr::tag::Long j = 0; j < generator_binary_.Level_; j++)
	  {
		  generator_binary_.output_ << oneTab;
	  }
	}
}

GeneratorBinary::GeneratorBinary(Generator& generator)
	: generator_(generator)
    , style_(makeStyle(generator.tokenizerSet_))
	, filename_()
	, output_()
	, debug_(false)
	, Level_(0)
 	, StateLine_(0)
	, StateBlun_(0)
 	//, Lasty_(0)
	, Lastnnn_(0)
   	//, Lasti_(0)
  	, LastKey_(0)
    , StringXmlTokenMode_(0)
	, LastKKK_(0)
{
}

GeneratorBinary::GeneratorBinaryStyle*		
GeneratorBinary::makeStyle(cppcc::com::LanguageTokenizerSet 	tokenizerSet)
{
  //switch (generator_.parser_.tokenizer_.language_->tokenizerSet_) {
  //switch (generator_.parser_.tokenizerSet_) {
	
    //std::cout << "makeStyle:" << tokenizerSet << std::endl;	
	
  switch (tokenizerSet) {
  case cppcc::com::LanguageTokenizerSet_Undefined:
  case cppcc::com::LanguageTokenizerSet_Meta:
		return new GeneratorBinary::GeneratorBinaryStyleMeta(*this);
		break;
  case cppcc::com::LanguageTokenizerSet_XML:
	    return new GeneratorBinary::GeneratorBinaryStyleXML(*this);
		break;
  default:
	CPPCC_THROW_EXCEPTION(
		  << "GeneratorRuntime::makeStyle() failed"
		  << " wrong tokenizer set id:"
		  << generator_.parser_.tokenizer_.language_->tokenizerSet_
		  << " should be on of ["
		  << cppcc::com::LanguageTokenizerSet_Undefined
		  << " " << cppcc::com::LanguageTokenizerSet_Meta
		  << " " << cppcc::com::LanguageTokenizerSet_Meta
		  << "]!"
	)	  	  
  }
}

///////////////////////////////////////////////////////////////////////
////////////////---------------------------------


//void
//GeneratorBinary::decompile(const std::string& filename)
//{
//
//}

void
GeneratorBinary::generate(const std::string& filename)
{
	
}


std::string
GeneratorBinary::grammarName()
{
/*
	//return "metafirst";
	std::string gn("");
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  generator_.parser_.runtime_.cnms_.dataByKey
		(generator_.parser_.runtime_.cnmnumCurrent_);
	cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	  generator_.parser_.runtime_.kwnLookup(KW_RULE_NON_TERMINAL);
	cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
	  kwnInstance.edps_.dataByIndex(0);
	//if (2 == edpInstance.edpfix_.size()) {
	if (edpInstance.edpfix_.size() >= 2) {
	  cppcc::scr::tag::Long k;
	  cppcc::scr::tag::Long n;
      cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
      if (KW_IDENTIFIER_TOKEN == k) {
        cppcc::scr::SyntaxControlledRuntime::nam namInstance=
   	      currentContext.namn_.dataByIndex(n);
        gn = namInstance.namkey_;
      }
	}
	
	return gn;
*/
// Returns 'grammar' since
// 
//	  (rule ::= 	'(' nterm '::=' right ')'
//	  )
//
//	  (nterm	 ::= identifier
//	  )
//
//
	
	
	std::string gn("");
/***
	cppcc::scr::tag::Long 	kk; 
	cppcc::scr::tag::Long 	nn;
	cppcc::scr::tag::setlongedf(&generator_.parser_.axiom_,kk,nn);
	  
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  generator_.parser_.runtime_.cnms_.dataByKey
		(generator_.parser_.runtime_.cnmnumCurrent_);
	cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
	  generator_.parser_.runtime_.kwnLookup(kk);
	cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
	  kwnInstance.edps_.dataByKey(nn);
	//if (2 == edpInstance.edpfix_.size()) {
	if (edpInstance.edpfix_.size() >= 2) {
	  cppcc::scr::tag::Long k;
	  cppcc::scr::tag::Long n;
      cppcc::scr::tag::setlongedf(&edpInstance.edpfix_[1],k,n);
      if (cppcc::com::PLS_IDENTIFIER == k) {
        cppcc::scr::SyntaxControlledRuntime::nam namInstance=
   	      currentContext.namn_.dataByIndex(n);
        gn = namInstance.namkey_;
      }
	}
**/
	
	return gn;
	
}

void
GeneratorBinary::decompile(const std::string& fname)
{
  std::string	gName = grammarName();
  filename_ = 
	(!fname.size() || ("" == fname))	  
     ? (gName + ".ubr")
     : fname
  ;
 
  if (0) {
	  if (generator_.parser_.runtime_.debug_ || debug_) {
		std::cout 
		<< "Binary::decompile:0:"
		<< " ctx:" << generator_.parser_.context_
		<< " a:" << generator_.parser_.axiom_
		<< " n:" << "'" << gName << "'"
		//<< " cnmnumCurrent_:" << generator_.parser_.runtime_.cnmnumCurrent_
		<< " filename:" << "'" << filename_ << "'"
		<< std::endl;   
	  }
  }
  
  output_.open(filename_.c_str());
  if (!output_) {
      std::string   syserr = cppcc::com::CPPCCException::systemError();     
      CPPCC_THROW_EXCEPTION(
      << "Can't open file for binary decompiling:'"
      << filename_
      << "' - Reason:'"
      << syserr
      << "'"
      )
  }
  
  // Dump the content first.
  //int isDump = 0;
  //if (isDump) {
  //  generator_.parser_.runtime_.dump(output_);
  //}
  
  scDecompileMain();
}


void
GeneratorBinary::scDecompileMain_(std::ofstream&	output)
{
  //scDecompile(generator_.parser_.axiom_);
  //if (StateLine_) {
  //	  output_ << std::endl;
  //}
	
  cppcc::scb::SyntaxControlledBinary& bin = 
	generator_.parser_.binary_;
  
  cppcc::scr::tag::Long axiom = bin.head()->cntbeg;
  scDecompile_(output, axiom);
  if (StateLine_) {
  	  output << std::endl;
  }
  
  output << std::endl;
}



void 
GeneratorBinary::scDecompileSpace
  (std::ofstream&         output
  ,cppcc::scr::tag::Long  kkk)
{
  if ((kkk < 0) || (kkk >= cppcc::com::PLS_TERMINALS_START)) return;
  
  int numberOfSpaces = spaces[kkk][LastKKK_];
  if (1 == numberOfSpaces) {
    output << " ";
  }
  
  LastKKK_ = kkk;
}

void
GeneratorBinary::scDecompile_
	(std::ofstream&			output
	,cppcc::scr::tag::Long& tag)
{
	bool _isDebug_ = false;
	
	if (_isDebug_) {
	  std::cout
	  << "scDecompile"
	  << " tag:" << tag
	  << std::endl;
	}
	
  if(!tag) return;
  
  //cppcc::scr::tag::Long rrr = tag;
  cppcc::scr::tag::Long kkk;
  cppcc::scr::tag::Long nnn;
  //cppcc::scr::tag::setlongedf(&rrr,kkk,nnn);
  cppcc::scr::tag::setlongedf(&tag,kkk,nnn);

	if (_isDebug_) {
	  std::cout
	  << "scDecompile"
	  << " k:" << kkk
	  << " n:" << nnn
	  << " s:" << generator_.parser_.grammarSymbols_.size()
	  << std::endl;
	}
	
  if ((kkk <0) || (kkk >= generator_.parser_.grammarSymbols_.size())) {
	  return;
  }
  
  scDecompileSpace(output, kkk);
  
  StateLine_= 1;

  // 999.1 : //
  //if(kkk == KW_TEXTTOKEN) {
  //if(kkk == cppcc::com::PLS_TEXT_TOKEN) {
  //  StringXmlTokenMode_ = 1;
  //}
  // 999.1 . //

  
  ///cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
  //	generator_.parser_.runtime_.cnms_.dataByKey
  //   (generator_.parser_.runtime_.cnmnumCurrent_);
  //cppcc::scr::SyntaxControlledRuntime::kwn&  kwnInstance = 
  //	generator_.parser_.runtime_.kwnLookup(kkk);

  cppcc::scb::SyntaxControlledBinary& bin = 
	generator_.parser_.binary_;
  
  if(cppcc::com::PLS_IDENTIFIER == kkk) {
	//cppcc::scr::SyntaxControlledRuntime::nam namInstance=
    //    currentContext.namn_.dataByIndex(nnn);
	//
	//output << " " << namInstance.namkey_ ;	  
    //99// output << " " << bin.ptrids(nnn);

    // ub:
	  // output << bin.ptrids(nnn);
    output << bin.ptrids(nnn) << " ";
	
    if (_isDebug_) {
		  std::cout
		  << "scDecompile"
		  << " k:" << kkk
		  << " n:" << nnn
		  << " s:" << generator_.parser_.grammarSymbols_.size()
		  << " id:" << "'" << bin.ptrids(nnn) << "'"
		  << std::endl;
	  }

    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMTOKENOFRULE_TOKEN == kkk) {
    //cppcc::scr::SyntaxControlledRuntime::nam namInstance=
    //  currentContext.namn_.dataByIndex(nnn);
    //
    //std::string tn = namInstance.namkey_;
    std::string tn = bin.ptrids(nnn);  
	  
    // ub:
    /*
    bool y = false;
    for (std::size_t j = 0, 
      z = generator_.parser_.tokenizer_.language_->tokens_.tokens_.size();
      j < z; j++
    ) {
      lex::Token* token = 
        generator_.parser_.tokenizer_.
    	  language_->tokens_.tokens_[j];
      if (token && (tn == token->name_)) {
    	  tn = token->token_;
    	  y = true;
    	  break;
      }
    }
    
    ////output << " " 
    output 
            // 99.2// << std::string(y?"":" ")
        // BUG: ub
    		//<< (y?std::string("'"):std::string("")) 
    		//<< tn << (y?std::string("'"):std::string(""))
        // ==>>
        << "'" << tn << "'"
    ;
    */
    // Verify that PLS_TERMTOKENOFRULE_TOKEN goes with '{', '}', etc...
    //
    /*
    cppcc::lex::Tokens::Name2IndexMap::const_iterator cf = 
      generator_.parser_.tokenizer_.language_->tokens_.name2index_.find(tn);
    cppcc::lex::Tokens::Name2IndexMap::const_iterator ce =
      generator_.parser_.tokenizer_.language_->tokens_.name2index_.end();
    bool y = (ce != cf);

    std::string tn2;
    if (y) {
      cppcc::lex::Token* token = 
        generator_.parser_.tokenizer_.language_->tokens_.tokens_
          [cf->second];
      if (token)
      {
        tn2 = token->token_;
      }
      else {
        // exception !
      }
    } else {
      tn2 = tn;
    }
    */
    std::string tn2 = generator_.parser_.tokenizer_.language_->tokens_.gid(tn);

    output 
      << "'" 
      << tn2
      << "'"
    ;
    
    LastKey_= kkk;
    return;
  }
  
  if(cppcc::com::PLS_TERMINAL_TOKEN == kkk) {
    cppcc::lex::Token& token = 
      generator_.parser_.tokenizer_.language_->getToken(nnn);
    /*
    //99// output << " " << token.token_;
    
    // ub:
    //output << token.token_;
    output << token.name_ << " " ;
    */
    // Verify that PLS_TERMINAL_TOKEN goes with termToken, i.e. 'case', 'swithc', etc...
    output << token.gid() << " " ;

    makeAlignment(token);
    
    LastKey_= kkk;
    //Lasty_= 1;
    //Lasti_= i;
    Lastnnn_= nnn;
    return;    
  }
  
  //cppcc::scr::SyntaxControlledRuntime::edp& edpInstance = 
  //    kwnInstance.edps_.dataByKey(nnn);
  cppcc::scb::SyntaxControlledBinary::kwnirType*	k = 
    bin.setptrkwn(kkk);
  if(k) {  
	
	  if (_isDebug_) {	  
		  std::cout
		  << "scDecompile"
		  << " tag:" << tag
		  << " k:" << kkk
		  << " n:" << nnn
		  << " kwn:" << (*k)
		  << std::endl;
	  }
	  
	  
    cppcc::scb::SyntaxControlledBinary::edpirType* e =
	  bin.ptredp(k, nnn);
    if (e) {
  	  if (_isDebug_) {	   	
		  std::cout
		  << "scDecompile"
		  << " tag:" << tag
		  << " k:" << kkk
		  << " n:" << nnn
			<< " kwn:" << (*k)
			<< " edp:" << (*e)
		  << std::endl;
  	  }
   	
    	
      //cppcc::scb::SyntaxControlledBinary::ruleType u =
	  //	bin.setrule(k,e);
	  //; 
      //33// cppcc::scr::tag::Long* uf = 
  	  //33//   e->fl
  	  //33//     ?(
  	  //33//        ((e->d >= 0) && (e->d < bin.memory_.size()))
  	  //33//       ? &bin.memory_[e->d]
  	  //33//        : 0
  	  //33//     )
  	  //33//     :0
  	  //33// ;
      cppcc::scr::tag::Long* uf = bin.fixed(e);

      //33// cppcc::scr::tag::Long* ud = 
      //33//   e->dl
      //33//     ?(
      //33//         (((e->d + e->fl) >= 0) 
      //33//       	&& ((e->d + e->fl) < bin.memory_.size()))
      //33//   	  ? &bin.memory_[e->d + e->fl]
      //33//   	  : 0
      //33//     )
      //33//     :0
      //33// ;
      cppcc::scr::tag::Long* ud = bin.dynamic(e);
      
	  switch (kkk) 
	  {
	    case cppcc::com::PLS_TEXT_TOKEN:
	    {
	    	if (e->fl && (2 == e->fl)) {
	    	  cppcc::scr::tag::Long kkk0 = bin.fixed(e, 0).t;
	    	  cppcc::scr::tag::Long nnn0 = bin.fixed(e, 0).d;
	    	  
	    	  cppcc::scr::tag::Long kkk1 = bin.fixed(e, 1).t;
	    	  cppcc::scr::tag::Long nnn1 = bin.fixed(e, 1).d;
	    	  
	          if((cppcc::com::PLS_TERMINAL_TOKEN == kkk0)
	             && (cppcc::com::PLS_STRING_TOKEN == kkk1)) {
	                cppcc::lex::Token& token0 = 
	                   generator_.parser_.tokenizer_.language_->getToken(nnn0);
	                
	                cppcc::scb::SyntaxControlledBinary::kwnirType*	k111 = 
	                  bin.setptrkwn(kkk1);
	             if(k111) {  
	                  cppcc::scb::SyntaxControlledBinary::edpirType* e111 =
	              	  bin.ptredp(k111, nnn1);
	                  cppcc::scr::tag::Long* u111f = bin.fixed(e111);
	                  
	                  output 
	                    << token0.token_ 
	                    //special// << ((char*)u111f);
	                    << specialCharacterConversion((char*)u111f);
	                
	                  LastKey_= kkk;     
	              }
	           }
	    	}
	    	return;
	    }
	    case cppcc::com::PLS_STRING_TOKEN:
	    {
	      //if(edpInstance.edpfix_.size()) {
	      //33// if(u.f) {
	      if(uf) {	    
	    	// 999.1 : //
	    	//if (StringXmlTokenMode_)
	    	//{
	    	//  output  << ((char*)uf);
	    	//  StringXmlTokenMode_ = 0;
	    	//}
	    	//else {
		    //  //output << " " << "\"" << ((char*)&edpInstance.edpfix_[0]) << "\"";
    	    //  output << " " << "\"" << ((char*)uf) << "\"";
	    	//}
	    	// 999.1 : //
	    	//99// output << " " << "\"" << ((char*)uf) << "\"";
	    	output << "\"" << ((char*)uf) << "\"";  
	    	  
            LastKey_= kkk;
          }
          return;
        }
        case cppcc::com::PLS_INTEGER_TOKEN:
        {
          if(uf) {
            //output_ << " " << (*(u.f));
            //output_ << " " << (*((cppcc::scr::tag::Long*)&uf));
            //99// output << " " << (*((cppcc::scr::tag::Long*)uf));
            output << (*((cppcc::scr::tag::Long*)uf));
            LastKey_= kkk;
          }
          return;
        }
        case cppcc::com::PLS_FLOAT_TOKEN:
        {
          if(uf) {
            //99// output << " " << (*((cppcc::scr::tag::Real*)uf));
            output << (*((cppcc::scr::tag::Real*)uf));
            LastKey_= kkk;
          }
          return;
        }  
        default:
        {
	      if (uf) {
	        for (std::size_t i = 0, z = e->fl; i < z; i++) {
	  	      //scDecompile(*(cppcc::scr::tag::Long*)(&u.f[i]));
	  	      scDecompile_(output, uf[i]);
	        }
	      }
	  
	      if (ud) {
	        for (std::size_t i = 0, z = e->dl; i < z; i++) {
	          //scDecompile(*(cppcc::scr::tag::Long*)(&u.d[i]));
	          scDecompile_(output, ud[i]);
	        }	  
	      }	  
        }
      }
    }
  }
}

//-------------------------- rrr
}
}


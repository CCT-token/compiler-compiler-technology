////////////////////////////////////////////////////////////////////////
// CommonRoutines.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "CommonRoutines.h"

namespace cppcc {
namespace com {

  namespace {
   // B - no suffix
   std::string   predef_[] =
   {
     "Wrong_Key_Word"
     ,"identifier"
     ,"stringToken"
     ,"integerToken"
     ,"floatToken"
     ,"textToken"
     //BUG// ,"terminalToken"
     ,"termToken"
     ,"terminalTokenOfRule"
   };

   std::size_t	predefSize_ = 
     sizeof(predef_)/sizeof(predef_[0]);

   std::size_t predefined_(const std::string& kw) {

     for (std::size_t i = 0; i < predefSize_; i++) {
       if (kw == predef_[i]) {
         return i;
       }
     }

     return predefSize_;
   }

   std::string predefined_(std::size_t e) {
     return
       (e >= predefSize_)
       ? std::string()
       : predef_[e]
     ;
   }
  }
  // namespace

  std::size_t predefinedKeyWord(const std::string& kw) {
    return predefined_(kw);
  }

  std::string predefinedKeyWord(std::size_t e)
  {
    return predefined_(e);
  }

std::string
CPPCCException::systemError()
{
  static const int SYSTEM_ERROR_MESSAGE_SIZE = 1024;

  std::vector<char> errorBuf(SYSTEM_ERROR_MESSAGE_SIZE, ' ');
  
  return 
    std::string(strerror_r(errno, &errorBuf[0], errorBuf.size()))
  ;

}

std::string getCurrentTime() 
{
  // Get current time. 
  time_t    current = time(0);
  if (((time_t)-1) == current) {
    std::string   syserr = CPPCCException::systemError();
    CPPCC_THROW_EXCEPTION(
	  << "System call to time(0) failed! - Reason:'"
	  << syserr
	  << "'"
    )
  }
  
  // Convert current time to local.
  struct tm *currentLocal = localtime(&current);
  if (!currentLocal) {
    std::string   syserr = CPPCCException::systemError();
       CPPCC_THROW_EXCEPTION(
	     << "System call to localtime(0) failed! - Reason:'"
		 << syserr
	     << "'"
	   )
  }  
	
  // Temp text buffer size.
  static const int      TEMP_SHORT_BUFFER_SIZE = 1024;
	  
  // Format local time.
  std::vector<char>  currentTimeBuffer(TEMP_SHORT_BUFFER_SIZE, ' ');       
  const char*   currentTimeFormat = "%Y:%m:%d:%H:%M:%S";
  if (!strftime
	    (&currentTimeBuffer[0]
	    , currentTimeBuffer.size()
	    , currentTimeFormat
	    , currentLocal)) { 
		  std::string   syserr = CPPCCException::systemError();
	      CPPCC_THROW_EXCEPTION(
	        << "System call to strftime() failed! - Reason:'"
		    << syserr
	        << "'"
		  )
  }	
	 
  return std::string(&currentTimeBuffer[0]);
}

  //
  //  predefined_, nonTerminals_, keyWords_ ==>> keyWordsGenerated_
  //
  void 
  KeyWordsContainer::finalize()
  {
    bool isDebug_ = true;
    std::set<std::string> predefined_set(predefined_.begin(), predefined_.end());
    std::set<std::string> nonTerminals_set(nonTerminals_.begin(), nonTerminals_.end());
    std::set<std::string> tokens_set(tokens_.begin(), tokens_.end());

    if (isDebug_) {
      {
        std::cout
          << "predefined_.size()=" << predefined_set.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = predefined_set.begin();
        std::set<std::string>::const_iterator ce = predefined_set.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "predefined_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }

      {
        std::cout
          << "nonTerminals_.size()=" << nonTerminals_set.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = nonTerminals_set.begin();
        std::set<std::string>::const_iterator ce = nonTerminals_set.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "nonTerminals_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }

      {
        std::cout
          << "tokens_.size()=" << tokens_set.size()
          << std::endl;
        std::set<std::string>::const_iterator ci = tokens_set.begin();
        std::set<std::string>::const_iterator ce = tokens_set.end();
        for (std::size_t cnt =0; ce != ci; ++ci, cnt++) {
          std::cout
            << "tokens_[" << cnt << "] = " << (*ci)
            << std::endl;
        }
      }
    }

    for (std::size_t i = 0, z = keyWords_.size(); i < z; i++) {
      const std::string& n = keyWords_[i];

      std::set<std::string>::const_iterator iPredefined = predefined_set.find(n);
      bool yPredefined = (iPredefined == predefined_set.end());

      std::set<std::string>::const_iterator iNonTerminals = nonTerminals_set.find(n);
      bool yNonTerminals = (iNonTerminals == nonTerminals_set.end());

      std::set<std::string>::const_iterator iTokens = tokens_set.find(n);
      bool yTokens = (iTokens == tokens_set.end());
      
      if (yNonTerminals && yPredefined && yTokens) {
        keyWordsGenerated_.push_back(n);
      }

      if (isDebug_) {
        std::cout
          << "kw:" << "'" << n << "'"
          << " yPredefined:" << yPredefined
          << " yNonTerminals:" << yNonTerminals
          << " yTokens:" << yTokens
          << std::endl;
      }
    }
  }

}
}


std::ostream& operator<<(std::ostream& o, const cppcc::com::KeyWordsContainer::NameVector& nv)
{
  std::size_t z = nv.size();
  o 
    << "size:" 
    << z
    << std::endl;
  
  for(std::size_t i = 0; i < z; i++) {
    o
      << " i:" << i << "'" << nv[i] << "'"
      << std::endl;
  }

  return o;
}

std::ostream& operator<<(std::ostream& o, const cppcc::com::KeyWordsContainer& kwc)
{
  o << "predefined_:"         << kwc.predefined_        << std::endl;
  o << "tokens_:"             << kwc.tokens_            << std::endl;
  o << "keyWords_:"           << kwc.keyWords_          << std::endl;
  o << "keyWordsGenerated_:"  << kwc.keyWordsGenerated_ << std::endl;
  o << "nonTerminals_:"       << kwc.nonTerminals_      << std::endl;

  return o;
}
////////////////////////////////////////////////////////////////////////
// Tokenizer.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Tokenizer.h"
#include "Parser.h"

namespace cppcc {
namespace lex {

namespace {
static const int MAX_MANTISSA = 11;

static const std::string WrongSpecialCharacterError
(
"ERROR - Wrong special character representation. "
"Should be %XWZ where XWZ represents 3 digits ASCII code (from 0 to 127)."
);

static const std::string EndOfStringQuoteIsMissingError
(
"ERROR - End of string literal is expeceted, quotation mark '\"' is missing."
);


static const std::string StringQuoteIsMissingError
(
"ERROR - String literal is expeceted, quotation mark '\"' is missing."
);

static const std::string IdentifierIsMissingError
(
"ERROR - Here must be identifier."
);

static const std::string IntegerOverflowError
(
"ERROR - Integer overflow - too big value."
);

static const std::string NoEndOfCommentError
(
"ERROR - No end of comment in line:"
);

static const std::string TooManyDigitsAfterDecimalPointError
(
"ERROR - Too many digits after decimal point."
);


static const std::string TermEndOfStringQuoteIsMissingError
(
"ERROR - End of terminal string literal is expeceted, quotation mark ' is missing."
);


static const std::string TermStringQuoteIsMissingError
(
"ERROR - Terminal string literal is expeceted, quotation mark ' is missing."
);

static const std::string EndOfXmlElementIsMissingError
(
"ERROR - End of XML element, <, is missing."
);

static std::size_t 	maxTokenSize = 3;
}

///////////////////////////////////////////////////////////////////////////////
// Open FileLineReader source and listing files.
///////////////////////////////////////////////////////////////////////////////
void
FileLineReader::openFiles()
{
	CPPCC_LOG_INFO((tok.logger_),
		  << "FileLineReader::openFiles:"
		  << " file:" << "'" << fileName_ << "'"
		  << " listing:" << "'" << listName_ << "'"
	)
	
	inpf_.open(fileName_.c_str());
	if (!inpf_) {
	    std::string   syserr = cppcc::com::CPPCCException::systemError();			
	    CPPCC_THROW_EXCEPTION(
	    	<< "Can't open file:'"
			<< fileName_
			<< "' - Reason:'"
			<< syserr
			<< "'"
		)
	}
	
	if ("" != listName_) {
		lstf_.open(listName_.c_str());
		if (!lstf_) {
		    std::string   syserr = cppcc::com::CPPCCException::systemError();			
		    CPPCC_THROW_EXCEPTION(
				<< "Can't open listing file:'"
				<< listName_
				<< "' - Reason:'"
				<< syserr
				<< "'"
		    )
		}
		
		listingFlag_ = true;
	}
}

void
Tokenizer::prolog() {
	CPPCC_LOG_INFO((logger_),
	  << "Tokenizer started."
	)
}

void 
Tokenizer::epilog() throw() {
	try {
		CPPCC_LOG_INFO((logger_),
		  << "Tokenizer finished."
		)
		
		if (reader_) {
			  delete reader_;
			  reader_ = 0;
		}
	}
	catch(...) 
	{
	}	
}

void
Tokenizer::getnewl() {
	
  if (reader_->get(line_)) {
    nline_++;
	  	
	if (reader_->hasListing()) {
		std::ostringstream o; 	
		o
			<< std::setw(5) 
			<< nline_
			<< "   "
			<< line_
		;
				
		reader_->put(o.str());
	}
			
	if (debug_) {
		std::cout
			<< std::setw(5) 
			<< nline_
			<< "   "
			<< line_
			<< std::endl
		;				
	}
			
	ch_ 	= ' ';
	npos_ 	= -1;
	epos_ 	= -1;
  } else { 
	line_.push_back('\0');
	line_.push_back('\0');
	line_.push_back('\0');		
	ch_ = EOF;
  }
}

void
Tokenizer::start(const char *sour, const char *list) {
  CPPCC_LOG_INFO((logger_),
	  << "Tokenizer:FileMode:"
	  << " file:" << "'" << std::string(sour?sour:"") << "'"
	  << " listing:" << "'" << std::string(list?list:"") << "'"
  )
	
  //reader_ = new FileLineReader
  //  (*this
  //  ,std::string(sour?sour:"")
  //  ,std::string(list?list:"")
  //  );
  std::string ssour(sour?sour:"");
  std::string slist(list?list:"");
  reader_->start(ssour, slist);

  startAction();
}

void		      
Tokenizer::start(const std::string& sour, bool list) {
	CPPCC_LOG_INFO((logger_),
		  << "Tokenizer:StringMode:"
		  << " listing:" << list
	)
	
  //reader_ = new StringLineReader
  //  (*this
  //	,std::string(sour)
  //  ,list
  //	);
  reader_->start(sour, list);
  startAction();
}

void
Tokenizer::erfini() {
  if (ercn_) {
	if (reader_->hasListing()) {
	  std::ostringstream o;
	  o
		<< std::endl
		<< ercn_
		<< " errors/warnings detected"
		<< std::endl
	  ;
	  reader_->put(o.str());
	}  
  }
}


void
Tokenizer::startAction() {
  nline_ 	= 0;
  getnewl();
  erflag_ 	= 0;
  ergl_		= 0;
  warn_		= 0;
  brlev_	= 0;
  flushBlanks();
  getNextToken();
}

void 	
Tokenizer::errorMessage(const std::string& mes)
{
	static const int startPosition = 5;
	std::string s;
	register int i = 0;
	
	for (; i < startPosition; i++) {
	  s.push_back('*');
	}
	for (startPosition; i < epos_ + startPosition; i++) {
	  s.push_back(' ');
	}
	
	if (reader_->hasListing()) {
	    std::ostringstream o;
	    o
			<< s
			<< " $ "
			<< std::endl
			<< mes
		;
		reader_->put(o.str());
	}

	flush();	
	erflag_ = 1;
	ergl_ = 1;
	ercn_++;
}

void 	
Tokenizer::infoMessage(const std::string& mes)
{
  if (reader_->hasListing()) {
	  reader_->put(mes); 
  }
}

Language*	  
Tokenizer::makeLanguage(cppcc::com::LanguageTokenizerSet languageID)
{
	switch(languageID)
	{
	case cppcc::com::LanguageTokenizerSet_Meta:
		return new LanguageMeta(*this, languageID);
	case cppcc::com::LanguageTokenizerSet_XML:
		return new LanguageXML(*this, languageID);
	default:
		return 0;
	}
}

LineReader* 
Tokenizer::makeLineReader(TokenizerReader readerID)
{
	switch (readerID)
	{
	case TokenizerReader_File:
		return new FileLineReader(*this);
	case TokenizerReader_String:
		return new StringLineReader(*this);
	default:
    // ub:
		// return 0;
    return new FileLineReader(*this);
	}
}

void 
LanguageMeta::getchr()
{
  if (tokenizer_.iseof()) return;

  if (tokenizer_.npos_ == static_cast<int>(tokenizer_.line_.size()))
  {
	  tokenizer_.ch_ = '\0';
  } else {
	  tokenizer_.npos_++;
	  tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];
  }

  if (tokenizer_.ch_ == '\t') {
	  tokenizer_.epos_ = (tokenizer_.epos_&~7) + 8; 
  } else {
	  tokenizer_.epos_++;
  }

  if ((tokenizer_.ch_ == '\t') || (tokenizer_.ch_ == '\f')) {
	  tokenizer_.ch_= ' ';
  }

  /*
  if (!tokenizer_.isString_
	&& ((tokenizer_.ch_ == '/') 
    && ((tokenizer_.npos_ 
    	<= static_cast<int>(tokenizer_.line_.size())) 
	&& ('/' == tokenizer_.line_[tokenizer_.npos_+1])))) {
  	ch_ = '\0';
  }
  */
  if (!tokenizer_.isString_ 
    && !tokenizer_.isTermString_ 
	&& ((tokenizer_.ch_ == '-') 
    && (((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size())) 
    		&& ('-' == tokenizer_.line_[tokenizer_.npos_+1])))) {
	  tokenizer_.ch_ = '\0';
  }

  if ((tokenizer_.ch_ == '\0') 
		  || (tokenizer_.ch_ == '\n') 
		  || (tokenizer_.ch_ == '\r')) {
    if (!tokenizer_.reader_->isEof()) {
    	tokenizer_.ch_ = EOF;
    } else {
    	tokenizer_.getnewl();
    }
  }
}


void 
LanguageMeta::getid()
{
	tokenizer_.flushBlanks();

	if(!(isalnum(tokenizer_.ch_))) {
		if(tokenizer_.debug_) {
			if (tokenizer_.reader_->hasListing()) {
		      std::ostringstream o;
		      o
		        << "ch='"
		  		//<< static_cast<char>(tokenizer_.ch_)
		  		<< tokenizer_.ch_
		  		<< "'"
		  		<< ":" << "'" << static_cast<char>(tokenizer_.ch_) << "'"
	  		  ;
		      tokenizer_.reader_->put(o.str());
			}		  
		}
	    
		tokenizer_.errorMessage(IdentifierIsMissingError);
	    return;
	}

	tokenizer_.id_ = "";

	while(isalnum(tokenizer_.ch_) || (tokenizer_.ch_ == '_')) {
	  tokenizer_.id_.push_back(tokenizer_.ch_);
	  getchr();
	}

	tokenizer_.flushBlanks();

	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
		    std::ostringstream o;
		    o
		  		<< "id='"
		  		<< tokenizer_.id_
		  		<< "'"
	  		;
		    tokenizer_.reader_->put(o.str());
		}
	}

	return;
}

void 
LanguageMeta::getint()
{
  register int 	i = 0;
  register int 	b;					// base
  register int 	a = 0;				// current digit
  register int 	j;

  register int	overflow = 0;		// overflow flag
  register unsigned long	n;		// current value
  register unsigned long	nd;		// new value
  register unsigned long	over_base_max;	// max value devided by base

  //double 	r,t;

  tokenizer_.modeintfloat_ = 0;
  tokenizer_.flushBlanks();

  n = 0;

  if(isdigit(tokenizer_.ch_)) {

    b = 10;
    if('0' == tokenizer_.ch_) {
      b = 8;
      getchr();
      if(('x' == tokenizer_.ch_) || ('X' == tokenizer_.ch_)) {
		b = 16;
		getchr();
      }

      if(!(
        isdigit(tokenizer_.ch_) 
        || ('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_)
		|| ('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_)
	 	|| ('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_)
	 	|| ('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_)
	 	|| ('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)
	  	|| ('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_)
		)
      ) {
      			
    	  if('.' != tokenizer_.ch_) {
    	    tokenizer_.flushBlanks();
    	    tokenizer_.ival_ = 0;
			return;
		  }

	      b = 10;
      }
    }

    tokenizer_.flushBlanks();

	over_base_max = ((unsigned long)(-1)) / b;

	i = 0;

	if(b != 16) {
		while(isdigit(tokenizer_.ch_)) {
			i++;

			a = ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
			nd = n * b + a;
			// overflow |= (over_base_max < n) | (nd < n);
			{
				int	t1 = (nd < n);
				int	t2 = (over_base_max < n);

//				overflow |= (over_base_max < n) | (nd < n);
				overflow |= t2 | t1;

			}

			n = nd;

			getchr();
      	}
	} else {
		while(isdigit(tokenizer_.ch_) 
		|| ('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_)
		|| ('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_)
	  	|| ('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_)
	 	|| ('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_)
	 	|| ('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)
	   	|| ('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_)
	  	) {

			i++;
			if(isdigit(tokenizer_.ch_))
	  			a = ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
			else if (('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_))
	  			a = 10;
			else if (('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_))
	  			a = 11;
			else if (('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_))
	  			a = 12;
			else if (('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_))
	  			a = 13;
			else if (('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_))
	  			a = 14;
			else if (('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_))
	  			a = 15;

			// Ival = Ival * b + a;
			nd = n * b + a;
			{
				int	t1 = (nd < n);
				int	t2 = (over_base_max < n);

//				overflow |= (over_base_max < n) | (nd < n);
				overflow |= t2 | t1;

			}
			n = nd;
				
			getchr();
      	}
 	}

	if(('l' == tokenizer_.ch_) || ('L' == tokenizer_.ch_)) {
		getchr();
	}

	tokenizer_.flushBlanks();

	if(overflow) {
		tokenizer_.errorMessage(IntegerOverflowError);
		return;
	}

	if((long)n < 0) {
		tokenizer_.errorMessage(IntegerOverflowError);
		return;
	}
	
	tokenizer_.ival_ = n;
  }

  if(tokenizer_.debug_) {
	  if (tokenizer_.reader_->hasListing()) {
	    std::ostringstream o;
		o
			<< "ival="
			<< tokenizer_.ival_
		;
	    tokenizer_.reader_->put(o.str());
	  }
  }

  return;	
}

void 
LanguageMeta::getstring()
{
  tokenizer_.flushBlanks();
  if(!tokenizer_.isQuote()) {
	tokenizer_.errorMessage(StringQuoteIsMissingError);
	return;
  }

  getchr(); 	
  tokenizer_.strng_ = "";
  tokenizer_.isString_ = true;
  	
  for(;;) {
    if(tokenizer_.iseof()) {
    	tokenizer_.errorMessage(EndOfStringQuoteIsMissingError);
    	return;
    }

	if(tokenizer_.isQuote()) break;

    if('%' == tokenizer_.ch_) {
    	getchr();

	  	for(;;) {
	  	  tokenizer_.flushBlanks();
	      if(tokenizer_.iseof()) {
	      	tokenizer_.errorMessage(EndOfStringQuoteIsMissingError);
	      	return;
	      }

	      if(isdigit(tokenizer_.ch_)) {
			register int j= 0;
		 	register int chc= 0;

			while(isdigit(tokenizer_.ch_)) {
				if(3 == j) {
			      tokenizer_.errorMessage(WrongSpecialCharacterError);
			      return;
			    }

		      	j++;
		      	chc = chc * 10 + ((unsigned)tokenizer_.ch_ - (unsigned)'0');
		      	getchr();
		 	}

			if(chc > 127)  {
				tokenizer_.errorMessage(WrongSpecialCharacterError);
				return;
			}
			
			tokenizer_.strng_.push_back((char)chc);
	      } else {
	    	  tokenizer_.errorMessage(WrongSpecialCharacterError);
	    	  return;
	      }

	      tokenizer_.flushBlanks();
	      if('%' == tokenizer_.ch_) break;

	    }

	  	if('%' != tokenizer_.ch_) {
	  		tokenizer_.errorMessage(WrongSpecialCharacterError);
	    	return;
	    }
	  	getchr();
	} else {
		tokenizer_.strng_.push_back(tokenizer_.ch_);
		getchr();
	}		
  }

  tokenizer_.flushQuote();
  tokenizer_.isString_ = false;

  if(tokenizer_.debug_) {
    if (tokenizer_.reader_->hasListing()) {
    	std::ostringstream o;
    	o
			<< "strng='"
			<< tokenizer_.strng_
			<< "'"
  		;
    	tokenizer_.reader_->put(o.str());
	  }		  
  }

  return;	
}

void 
Language::getTermString()
//LanguageMeta::getTermString(
{
  tokenizer_.flushBlanks();
  if(!tokenizer_.isSingleQuote()) {
	tokenizer_.errorMessage(TermStringQuoteIsMissingError);
	return;
  }

  getchr(); 	
  tokenizer_.termString_ = "";
  tokenizer_.isTermString_ = true;
  	
  for(;;) {
    if(tokenizer_.iseof()) {
      tokenizer_.errorMessage(TermEndOfStringQuoteIsMissingError);
      return;
    }

	if(tokenizer_.isSingleQuote()
	  && (
	    (tokenizer_.npos_ > 0)
	    && ('\\' != tokenizer_.line_[tokenizer_.npos_-1])
	  )
	) break;

	tokenizer_.termString_.push_back(tokenizer_.ch_);
	getchr();	
  }

  tokenizer_.flushSingleQuote();
  tokenizer_.isTermString_ = false;

  if(tokenizer_.debug_) {
    if (tokenizer_.reader_->hasListing()) {
    	std::ostringstream o;
    	o
			<< "strng='"
			<< tokenizer_.termString_
			<< "'"
  		;
    	tokenizer_.reader_->put(o.str());
	  }		  
  }

  return;	
}

bool	
Language::isDefinedToken()
{
/*
	if(tokenizer_.debug_) {
	  //static bool isDebug = true;
	  //if (isDebug) {
		for (register std::size_t i=0, z = tokens_.tokens_.size(); i < z; i++) {
			Token*	t = tokens_.tokens_[i];
	    	std::ostringstream o;
	    	o
				<< "isDefinedToken="
				<< " i:" << i
				<< " " << (*t)
	  		;
	    	tokenizer_.reader_->put(o.str());
		}
		//isDebug = false;
	  //}
	}
*/
	
	for (register std::size_t i=0, z = tokens_.tokens_.size(); i < z; i++) {
		Token*	t = tokens_.tokens_[i];
		
		if(t && t->isToken()) {
			return true;
		}
	}	

	return false;
}

bool	
Language::isKeyWord(const std::string& id)
{
  bool r = (keyWords_.name2index_.end() != keyWords_.name2index_.find(id));
  if(tokenizer_.debug_) {
    if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "isKeyWord() "
        << " r:" << r
        << " id:" << id
      ;
      tokenizer_.reader_->put(o.str());
    }
  }

	return r;
}

void	
Language::setNextToken()
{
  std::size_t z = tokens_.tokens_.size();
  
  for (register std::size_t k = maxTokenSize; k > 0; k--)
  {
	for (register std::size_t i=0, z = tokens_.tokens_.size(); i < z; i++)
	{
		Token*  t = tokens_.tokens_[i];
		
		if(t && (k == t->token_.size()) && t->isToken()) {
			
			// xml.22 // 
			t->flushToken();
		    //if (!tokenizer_.parser_.isXmlTokenFlag()) {
		    //  t->flushToken();
		    //}
			
			tokenizer_.kword_ = t->symbol_;

			if(tokenizer_.debug_) {
				if (tokenizer_.reader_->hasListing()) {
				    std::ostringstream o;
				    o
				        << "setNextToken() "
				  		<< (*t)
			  		;
				    tokenizer_.reader_->put(o.str());
				}
			}

			return;
		}
	}	
  }

  CPPCC_THROW_EXCEPTION(
	<< "setNextToken() failed to identify token!"
  )
}

/*
// xml.11 // 
inline
void 
OneCharXmlGreaterThanToken::flushToken() 
{
  if (isToken()) {
	    
	    //if (1) {
	    //	std::cout 
	    //	<< "b:"
	    //	<< " c:" << "'" << ((char)tokenizer_.ch_)<< "'"
	    //	<< " f:" << tokenizer_.parser_.isXmlTokenFlag()
	    //	<< std::endl;
	    //}
	  
    tokenizer_.getchr();
    ///tokenizer_.flushBlanks();
    
    //if (1) {
    //	std::cout 
    //	<< "a:"
    //	<< " c:" << "'" << ((char)tokenizer_.ch_)<< "'"
    //	<< " f:" << tokenizer_.parser_.isXmlTokenFlag()
    //	<< std::endl;
    //}
    
    //if (!tokenizer_.parser_.isXmlTokenFlag()) {
      tokenizer_.flushBlanks();
    //}
  }
} 
*/

void	
Language::setKeyWord(const std::string& id)
{
  Tokens::Name2IndexMap::const_iterator keyWordIter = keyWords_.name2index_.find(id);
  if (keyWords_.name2index_.end() == keyWordIter) {
	  CPPCC_THROW_EXCEPTION(
	    << "setKeyWord() failed to identify key word"
	    << " " << "'" << id << "'"
	    << "!"
	  )	  
  }
  
  if ((keyWordIter->second < 0) 
    || (keyWordIter->second >= keyWords_.tokens_.size())) {
		CPPCC_THROW_EXCEPTION(
		  << "setKeyWord() failed"
		  << " " << "'" << id << "'" << " has an index:"
		  << keyWordIter->second
		  << " that is out off range:[0.."
		  << keyWords_.tokens_.size()
		  << ")!"
		)	  	  
  }

  if(tokenizer_.debug_) {
	  if (tokenizer_.reader_->hasListing()) {

		  std::ostringstream o;
		  o
			  << "setKeyWord:"
        << " id:" << id
        << " idx:" << keyWordIter->second
        << " size:" << keyWords_.tokens_.size()
	  	  ;
		  tokenizer_.reader_->put(o.str());

	  }
  }

  Token* t = keyWords_.tokens_[keyWordIter->second];
  if (!t)
  {
		CPPCC_THROW_EXCEPTION(
		  << "setKeyWord() failed"
		  << " " << "'" << id << "'" << " has an index:"
		  << keyWordIter->second
		  << " BUT Token is not set!!"
		)	
  }

  tokenizer_.kword_ = keyWords_.tokens_[keyWordIter->second]->symbol_; 
  if(tokenizer_.debug_) {
	  if (tokenizer_.reader_->hasListing()) {
      {
		    std::ostringstream o;
		    o
			    << (*t)
	  	  ;
		    tokenizer_.reader_->put(o.str());
      }

      {
		    std::ostringstream o;
		    o
			    << "setKeyWord:"
          << " id:" << id
          << " kword:" << tokenizer_.kword_
	  	    ;
		    tokenizer_.reader_->put(o.str());
      }

    }
  }  
}


void LanguageMeta::getNextToken()
{
	  if(tokenizer_.debug_) {
	    if (tokenizer_.reader_->hasListing()) {
	      //cppcc::lex::Token& tok  = tokenizer_.language_->getToken(t);
	      std::ostringstream o;
	        o
	            << "getNextToken(0) " 
	            << "ch='"
	          //<< static_cast<char>(tokenizer_.ch_)
	          << tokenizer_.ch_
	          << "'"
	          << ":" << "'" << static_cast<char>(tokenizer_.ch_) << "'"
	          << " kw:" << tokenizer_.kword_
	          << " s:" << isStringToken()
	          << " i:" << isIntegerToken()
	          << " t:" << isTerminalStringToken()
	          << " d:" << isDefinedToken()
	          << " tokens:" << tokens_.tokens_.size()
	        ;
	        tokenizer_.reader_->put(o.str());
	        
			/**********
	        for (register std::size_t i=0, z = tokens_.tokens_.size(); 
	        		i < z; i++) {
	    		Token*	t = tokens_.tokens_[i];
	    	    	std::ostringstream o;
	    	    	o
	    				<< "isDefinedToken="
	    				<< " i:" << i
	    				<< " " << (*t)
	    	  		;
	    	    	tokenizer_.reader_->put(o.str());
	        }
			***************/
	    }     
	  }

  if(tokenizer_.iseof()) {
	tokenizer_.kword_ = cppcc::com::PLS_WRONG_KEY_WORD;
	return;
  }

  if (isStringToken()) {
	getstring();
	tokenizer_.kword_ = cppcc::com::PLS_STRING_TOKEN;
  } else if (isIntegerToken()) {
	getint();
	tokenizer_.kword_ = cppcc::com::PLS_INTEGER_TOKEN;
  } else if (isTerminalStringToken()) {
	getTermString();
	tokenizer_.kword_ = cppcc::com::PLS_TERMINAL_TOKEN;
  } else if (isDefinedToken()) {
	setNextToken();
  } else {
	getid();
	if (isKeyWord(tokenizer_.id_)) {
		setKeyWord(tokenizer_.id_);
	} else {
		tokenizer_.kword_ = cppcc::com::PLS_IDENTIFIER;
	}
  }
  
  if(tokenizer_.debug_) {
    if (tokenizer_.reader_->hasListing()) {
      //cppcc::lex::Token& tok  = tokenizer_.language_->getToken(t);
      std::ostringstream o;
        o
            << "getNextToken(999) " 
            << "ch='"
          //<< static_cast<char>(tokenizer_.ch_)
          << tokenizer_.ch_
          << "'"
          << ":" << "'" << static_cast<char>(tokenizer_.ch_) << "'"
          << " kw:" << tokenizer_.kword_
        ;
        tokenizer_.reader_->put(o.str());
    }     
  }

}

void LanguageMeta::flush()
{
  while(!((')' == tokenizer_.ch_) || tokenizer_.iseof())) {
    getchr();
  }
}

void 
Language::populateTerminals()
{
	int terminalSymbolID = cppcc::com::PLS_TERMINALS_START;
	
	for (register std::size_t i=0, z = tokens_.tokens_.size(); i < z; i++) {
	    Token*  t = tokens_.tokens_[i];
	    if (t) {
	    	t->symbol_ = terminalSymbolID;
	    	terminalSymbolID++;
	    }
	}	

	for (register std::size_t i=0, z = keyWords_.tokens_.size(); i < z; i++) {
	    Token*  t = keyWords_.tokens_[i];
	    if (t) {
	    	t->symbol_ = terminalSymbolID;
	    	terminalSymbolID++;
	    }
	}	
	
	for (register std::size_t i=0, z = nonTerminals_.tokens_.size(); i < z; i++) {
	    Token*  t = nonTerminals_.tokens_[i];
	    if (t) {
	    	t->symbol_ = terminalSymbolID;
	    	terminalSymbolID++;
	    }
	}	
		
}

Token*
LanguageMeta::makeToken
	(const std::string& t
	,const std::string& n)
{
  Token* 		r = 0;
  std::size_t 	z = t.size();
  
  if (1 == z) {
	  r = new OneCharToken(tokenizer_, t, n);
  } else if (2 == z) {
	  r = new TwoCharToken(tokenizer_, t, n);
  } else if (3 == z) {
	  r = new ThreeCharToken(tokenizer_, t, n);
  } else {
	  
  }
  
  if (!r) {
	CPPCC_THROW_EXCEPTION(
	  << "LanguageMeta::makeToken() assert check failed:"
	  << " Token:" << "'" << t << "'"
	  << " : "  << "'" << n << "'"
	  << " has a wrong size:" << z
	  << " it should be one of 1,2,or 3!"
	)	  	  
  }
  
  return r;
}

void 
LanguageMeta::populate()
{
/**************************************
  //11// tokens_["\""] = new OneCharToken(tokenizer_,"\"", "quote");
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"\"", "quote"));
  tokens_.name2index_["\""] = tokens_.tokens_.size()-1;
  
  // tokens_["#"] 	= new OneCharToken(tokenizer_,"#");
  //tokens_["&"] 	= new OneCharToken(tokenizer_,"&");
   
  //11// tokens_["'"] 	= new OneCharToken(tokenizer_,"'", "apostrophe");
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"'", "apostrophe"));
  tokens_.name2index_["'"] = tokens_.tokens_.size()-1;
  
  //11// tokens_["("] 	= new OneCharToken(tokenizer_,"(", "leftParenthesis");
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"(", "leftParenthesis"));
  tokens_.name2index_["("] = tokens_.tokens_.size()-1;
  
  //11// tokens_[")"] 	= new OneCharToken(tokenizer_,")", "rightParenthesis");
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,")", "rightParenthesis"));
  tokens_.name2index_[")"] = tokens_.tokens_.size()-1;
  
  //tokens_["*"] 	= new OneCharToken(tokenizer_,"*");
  //tokens_["+"] 	= new OneCharToken(tokenizer_,"+");
  //tokens_[","] 	= new OneCharToken(tokenizer_,",");
  //tokens_["-"] 	= new OneCharToken(tokenizer_,"-");
  //tokens_["."] 	= new OneCharToken(tokenizer_,".");
  //tokens_["/"] 	= new OneCharToken(tokenizer_,"/");
  //tokens_[":"] 	= new OneCharToken(tokenizer_,":");  
  //tokens_[";"] 	= new OneCharToken(tokenizer_,";");  
  
  //11// tokens_["<"] 	= new OneCharToken(tokenizer_,"<", "lessThen");  
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"<", "lessThan"));
  tokens_.name2index_["<"] = tokens_.tokens_.size()-1;
  
  //11// tokens_["="] 	= new OneCharToken(tokenizer_,"=", "equal");  
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"=", "equal"));
  tokens_.name2index_["="] = tokens_.tokens_.size()-1;
  
  //11// tokens_[">"] 	= new OneCharToken(tokenizer_,">", "greaterThen"); 
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,">", "greaterThan"));
  tokens_.name2index_[">"] = tokens_.tokens_.size()-1;
  
  //tokens_["_"] 	= new OneCharToken(tokenizer_,"_");  
  //tokens_["!"] 	= new OneCharToken(tokenizer_,"!");  
  //tokens_["$"] 	= new OneCharToken(tokenizer_,"$");  
  //tokens_["%"] 	= new OneCharToken(tokenizer_,"%");  
  //tokens_["?"] 	= new OneCharToken(tokenizer_,"?"); 
  //tokens_["@"] 	= new OneCharToken(tokenizer_,"@"); 
  
  //11// tokens_["["] 	= new OneCharToken(tokenizer_,"[", "leftSquareBracket"); 
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"[", "leftSquareBracket"));
  tokens_.name2index_["["] = tokens_.tokens_.size()-1;
  
  //tokens_["\\"] 	= new OneCharToken(tokenizer_,"\\"); 
  
  //11// tokens_["]"] 	= new OneCharToken(tokenizer_,"]", "rightSquareBracket"); 
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"]", "rightSquareBracket"));
  tokens_.name2index_["]"] = tokens_.tokens_.size()-1;
  
  //tokens_["^"] 	= new OneCharToken(tokenizer_,"^"); 
  //tokens_["`"] 	= new OneCharToken(tokenizer_,"`"); 
  //tokens_["{"] 	= new OneCharToken(tokenizer_,"}"); 
  //tokens_["~"] 	= new OneCharToken(tokenizer_,"~"); 
  
  //11// tokens_["|"] 	= new OneCharToken(tokenizer_,"|", "verticalBar"); 
  tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"|", "verticalBar"));
  tokens_.name2index_["|"] = tokens_.tokens_.size()-1;
  
  //tokens_["=>"] 	= new TwoCharToken(tokenizer_,"=>"); 
  //tokens_["**"] 	= new TwoCharToken(tokenizer_,"**"); 
  //tokens_[":="] 	= new TwoCharToken(tokenizer_,":="); 
  //tokens_["/="] 	= new TwoCharToken(tokenizer_,"/="); 
  //tokens_[">="] 	= new TwoCharToken(tokenizer_,">="); 
  //tokens_["<="] 	= new TwoCharToken(tokenizer_,"<="); 
  //tokens_["<>"] 	= new TwoCharToken(tokenizer_,"<>"); 

  //11// tokens_["::="] 	= new ThreeCharToken(tokenizer_,"::=", "definitionIs"); 
  tokens_.tokens_.push_back(new ThreeCharToken(tokenizer_,"::=", "definitionIs"));
  tokens_.name2index_["::="] = tokens_.tokens_.size()-1;
**********************************/
  if (cppcc::com::PLS_TERMINALS_START !=
	tokenizer_.grammarSymbols_.predefined_.size()) {
	  CPPCC_THROW_EXCEPTION(
	    	  << "LanguageMeta::populate() assert check failed:"
			  << cppcc::com::PLS_TERMINALS_START
			  << " != "
			  << tokenizer_.grammarSymbols_.predefined_.size()
			  << " !"
	  )	  
  }
  

  // populate tokens_
  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd = 
    tokenizer_.defaultTokenNames_.tokenNames_.end();
  
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.tokens_.size(); i < s; i++
  ) {
    const std::string& t = tokenizer_.grammarSymbols_.tokens_[i];
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
      tokenizer_.defaultTokenNames_.tokenNames_.find(t);
    if (cEnd == cIter) {
    	CPPCC_THROW_EXCEPTION(
    	  << "LanguageMeta::populate() assert check failed:"
    	  << " Token:'" << t << "'"
    	  << " does not have corresponding name defined in TokenNames!"
    	)	     	
    }
    
    const std::string& n = cIter->second;
    tokens_.tokens_.push_back(makeToken(t,n));
    tokens_.name2index_[t] = tokens_.tokens_.size()-1;
    tokens_.id2index_[n] = tokens_.tokens_.size()-1;

    int isDebug = 1;
    if (isDebug) {
      std::cout
        << "i:" << i
        << " t:" << "'" << t << "'"
        << " n:" << "'" << n << "'"
        << " x:" << tokens_.tokens_.size()-1
        << std::endl;
    }
  }

  // ub:
  // populate key words !!!!!!!!!!!!
  // const std::string& t = tokenizer_.grammarSymbols_.nonTerminals_[i];	 
  // keyWordsGenerated_
  // 
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.keyWordsGenerated_.size(); i < s; i++
  ) {
	  const std::string& t = tokenizer_.grammarSymbols_.keyWordsGenerated_[i];	  

	  //keyWords_.tokens_.push_back(0);
    keyWords_.tokens_.push_back(makeToken(" ",t));
	  keyWords_.name2index_[t] = keyWords_.tokens_.size()-1;
    keyWords_.id2index_[t] = tokens_.tokens_.size()-1;
  }

  // populate nonTerminals_
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.nonTerminals_.size(); i < s; i++
  ) {
	  const std::string& t = tokenizer_.grammarSymbols_.nonTerminals_[i];	  

	  //nonTerminals_.tokens_.push_back(0);
    nonTerminals_.tokens_.push_back(makeToken(" ",t));
	  nonTerminals_.name2index_[t] = nonTerminals_.tokens_.size()-1;
    nonTerminals_.id2index_[t] = nonTerminals_.tokens_.size()-1;
  }

 
  populateTerminals();

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "tokens_: " << tokens_
      ;
      tokenizer_.reader_->put(o.str());

      std::cout
        << "tokens_: " << tokens_
        << std::endl;
    //}
  }

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "keyWords_: " << keyWords_
      ;
      tokenizer_.reader_->put(o.str());

      std::cout
        << "keyWords_: " << keyWords_
        << std::endl;
    //}
  }

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "nonTerminals_: " << nonTerminals_
      ;
      tokenizer_.reader_->put(o.str());

      std::cout
        << "nonTerminals_: " << nonTerminals_
        << std::endl;
    //}
  }  
  
}

void 
LanguageXML::getchr()
{
	if (tokenizer_.iseof()) return;

	if (tokenizer_.npos_ == static_cast<int>(tokenizer_.line_.size()))
	{
		tokenizer_.ch_ = '\0';
	} else {
		tokenizer_.npos_++;
		tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];
	}

	if (tokenizer_.ch_ == '\t') {
		tokenizer_.epos_ = (tokenizer_.epos_&~7) + 8; 
	} else {
		tokenizer_.epos_++;
	}

	if ((tokenizer_.ch_ == '\t') || (tokenizer_.ch_ == '\f')) {
		tokenizer_.ch_= ' ';
	}
	
	if (!tokenizer_.isString_ 
	    && !tokenizer_.isTermString_ 
		&& ((tokenizer_.ch_ == '<') 
	       && (((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size())) 
	           && ('!' == tokenizer_.line_[tokenizer_.npos_+1])
	       )
	       && (((tokenizer_.npos_+2) < static_cast<int>(tokenizer_.line_.size())) 
	           && ('-' == tokenizer_.line_[tokenizer_.npos_+2])
	       )
	       && (((tokenizer_.npos_+3) < static_cast<int>(tokenizer_.line_.size())) 
	           && ('-' == tokenizer_.line_[tokenizer_.npos_+3])
	       )
		)
	) {
		std::string commentLine 		= tokenizer_.line_;
		int			commentLineNumber 	= tokenizer_.nline_;
		
		tokenizer_.npos_++;
		tokenizer_.npos_++;
		tokenizer_.npos_++;
		
		for(;;) {
		  if (!tokenizer_.reader_->isEof()) {
		    std::ostringstream o;
			o
			  << NoEndOfCommentError
			  << commentLineNumber
			  << " " << commentLine
			;

		    tokenizer_.errorMessage(o.str());
		    tokenizer_.ch_ = EOF;
		    return;
		  }
		  
		  tokenizer_.npos_++;
		  tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];
		  
		  if((tokenizer_.ch_ == '-') 
		  	       && (((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size())) 
		  	           && ('-' == tokenizer_.line_[tokenizer_.npos_+1])
		  	       )
		  	       && (((tokenizer_.npos_+2) < static_cast<int>(tokenizer_.line_.size())) 
		  	           && ('>' == tokenizer_.line_[tokenizer_.npos_+2])
		  	       )
		  		)
		  {
		    tokenizer_.npos_++;
			tokenizer_.npos_++;
			tokenizer_.npos_++;
			tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];
			break;
		  }
				
			if(tokenizer_.ch_ == '\t') {
				tokenizer_.epos_= (tokenizer_.epos_&~7)+8; 
			}
			else tokenizer_.epos_++;
			
			if (
				(tokenizer_.ch_ == '\0') 
				//xmlEolMode_// || ((tokenizer_.ch_ == '\n') && (!tokenizer_.xmlEolMode_))
				|| (tokenizer_.ch_ == '\n')
				|| (tokenizer_.ch_ == '\r')
			) 
			{
			  if (!tokenizer_.reader_->isEof()) {
				  tokenizer_.ch_ = EOF;
			  } else {
				  tokenizer_.getnewl();
			  }
			}
		}
		
		//tokenizer_.ch_ = '\0';
		tokenizer_.npos_++;
		tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];

	}

	if (
		(tokenizer_.ch_ == '\0') 
		|| (tokenizer_.ch_ == '\n') 
		|| (tokenizer_.ch_ == '\r')) {
	  if (!tokenizer_.reader_->isEof()) {
		  tokenizer_.ch_ = EOF;
	  } else {
		  tokenizer_.getnewl();
	  }
	}
}	


void 
LanguageXML::getid()
{
	tokenizer_.flushBlanks();

	if(!(isalnum(tokenizer_.ch_))) {
		if(tokenizer_.debug_) {
			if (tokenizer_.reader_->hasListing()) {
		      std::ostringstream o;
		      o
		        << "ch='"
		  		//<< static_cast<char>(tokenizer_.ch_)
		  		<< tokenizer_.ch_
		  		<< "'"
	  		  ;
		      tokenizer_.reader_->put(o.str());
			}		  
		}
	    
		tokenizer_.errorMessage(IdentifierIsMissingError);
	    return;
	}

	tokenizer_.id_ = "";

	while(isalnum(tokenizer_.ch_) || (tokenizer_.ch_ == '_')) {
	  tokenizer_.id_.push_back(tokenizer_.ch_);
	  getchr();
	}

	tokenizer_.flushBlanks();

	if(tokenizer_.debug_) {
		if (tokenizer_.reader_->hasListing()) {
		    std::ostringstream o;
		    o
		  		<< "id='"
		  		<< tokenizer_.id_
		  		<< "'"
	  		;
		    tokenizer_.reader_->put(o.str());
		}
	}

	return;
}


void 
LanguageXML::getint()
{
  register int 	i = 0;
  register int 	b;					// base
  register int 	a = 0;				// current digit
  register int 	j;

  register int	overflow = 0;		// overflow flag
  register unsigned long	n;		// current value
  register unsigned long	nd;		// new value
  register unsigned long	over_base_max;	// max value devided by base

  double 	r,t;

  tokenizer_.modeintfloat_ = 0;
  tokenizer_.flushBlanks();

  n = 0;

  if(isdigit(tokenizer_.ch_)) {

    b = 10;
    if('0' == tokenizer_.ch_) {
      b = 8;
      getchr();
      if(('x' == tokenizer_.ch_) || ('X' == tokenizer_.ch_)) {
		b = 16;
		getchr();
      }

      if(!(
        isdigit(tokenizer_.ch_) 
        || ('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_)
		|| ('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_)
	 	|| ('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_)
	 	|| ('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_)
	 	|| ('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)
	  	|| ('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_)
		)
      ) {
      			
    	  if('.' != tokenizer_.ch_) {
    	    tokenizer_.flushBlanks();
    	    tokenizer_.ival_ = 0;
			return;
		  }

	      b = 10;
      }
    }

    tokenizer_.flushBlanks();

	over_base_max = ((unsigned long)(-1)) / b;

	i = 0;

	if(b != 16) {
		while(isdigit(tokenizer_.ch_)) {
			i++;

			a = ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
			nd = n * b + a;
			// overflow |= (over_base_max < n) | (nd < n);
			{
				int	t1 = (nd < n);
				int	t2 = (over_base_max < n);

//				overflow |= (over_base_max < n) | (nd < n);
				overflow |= t2 | t1;

			}

			n = nd;

			getchr();
      	}
	} else {
		while(isdigit(tokenizer_.ch_) 
		|| ('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_)
		|| ('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_)
	  	|| ('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_)
	 	|| ('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_)
	 	|| ('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)
	   	|| ('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_)
	  	) {

			i++;
			if(isdigit(tokenizer_.ch_))
	  			a = ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
			else if (('a' == tokenizer_.ch_) || ('A' == tokenizer_.ch_))
	  			a = 10;
			else if (('b' == tokenizer_.ch_) || ('B' == tokenizer_.ch_))
	  			a = 11;
			else if (('c' == tokenizer_.ch_) || ('C' == tokenizer_.ch_))
	  			a = 12;
			else if (('d' == tokenizer_.ch_) || ('D' == tokenizer_.ch_))
	  			a = 13;
			else if (('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_))
	  			a = 14;
			else if (('f' == tokenizer_.ch_) || ('F' == tokenizer_.ch_))
	  			a = 15;

			// Ival = Ival * b + a;
			nd = n * b + a;
			{
				int	t1 = (nd < n);
				int	t2 = (over_base_max < n);

//				overflow |= (over_base_max < n) | (nd < n);
				overflow |= t2 | t1;

			}
			n = nd;
				
			getchr();
      	}
 	}

	if(('l' == tokenizer_.ch_) || ('L' == tokenizer_.ch_)) {
		getchr();
	}

	tokenizer_.flushBlanks();

	if(overflow) {
		tokenizer_.errorMessage(IntegerOverflowError);
		return;
	}

	if((long)n < 0) {
		tokenizer_.errorMessage(IntegerOverflowError);
		return;
	}
	
	tokenizer_.ival_ = n;
  }

  if('.' == tokenizer_.ch_) {
	  getchr();
	  tokenizer_.modeintfloat_ = 1;

    	r = 0.0;
    	if(isdigit(tokenizer_.ch_)) {
      		i = 0;
      		j = 0;

      		while(isdigit(tokenizer_.ch_)) {
				if(i >= MAX_MANTISSA) {
					tokenizer_.errorMessage
					(TooManyDigitsAfterDecimalPointError);
					return;
				}

				i++;
				j = j * 10 + ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
				getchr();
      		}

      		r= (double)j*std::pow((double)10,(double)(-i));

			if(tokenizer_.debug_) {

				if (tokenizer_.reader_->hasListing()) {
					std::ostringstream o;
					o
  						<< "r="
  						<< r
  						<< " j="
  						<< j
  						<< " i="
  						<< i
  						;
					tokenizer_.reader_->put(o.str());
				}		
			}

			tokenizer_.flushBlanks();
    	}

    	tokenizer_.rval_= ((double)tokenizer_.ival_ + (double)r);

		if(tokenizer_.debug_) {

	      if (tokenizer_.reader_->hasListing()) {
	        std::ostringstream o;
	        o
  					<< "Rval="
  					<< tokenizer_.rval_
  					<< std::endl;
  		    ;
  		  tokenizer_.reader_->put(o.str());
	      }
 
		}


    	if(('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)) {
    		getchr();

      		a = 1;
      		if(('+' == tokenizer_.ch_) || ('-' == tokenizer_.ch_)) {
				if('-' == tokenizer_.ch_) a = (-1);

				tokenizer_.getchr();
      		}

      		i  = 0;
      		j= 0;
      		while(isdigit(tokenizer_.ch_)) {
				if(i >= MAX_MANTISSA) {
					tokenizer_.errorMessage
					(TooManyDigitsAfterDecimalPointError);
					return;
				}

				i++;
				j = j * 10 + ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
				getchr();
      		}

      		t= (double) (a*j);

      		tokenizer_.rval_= tokenizer_.rval_ * pow((double)10.0,(double)t);

			if(tokenizer_.debug_) {

			   	if (tokenizer_.reader_->hasListing()) {
			   		std::ostringstream o;
			   		o
			   			<< "Rval="
			   			<< tokenizer_.rval_
			   			<< " man="
			   			<< ((double)tokenizer_.ival_+(double)r)
			   			<< " exp="
			   			<< t
			   			;
			   		tokenizer_.reader_->put(o.str());
			   	}
			}

			tokenizer_.flushBlanks();
    	}
  	}
	else if(('e' == tokenizer_.ch_) || ('E' == tokenizer_.ch_)) {
		tokenizer_.modeintfloat_ = 1;
		tokenizer_.rval_= ((double)tokenizer_.rval_);

		if(tokenizer_.debug_) {
	      if (tokenizer_.reader_->hasListing()) {
	        std::ostringstream o;
	        o
   					<< "Rval="
  					<< tokenizer_.rval_
 		      ;
	        tokenizer_.reader_->put(o.str());
	      }  			
		}

		getchr();

     	a = 1;
     	if(('+' == tokenizer_.ch_) || ('-' == tokenizer_.ch_)) {
     		if('-' == tokenizer_.ch_) a = (-1);

     		getchr();
      	}

      	i= 0;
      	j= 0;
      	while(isdigit(tokenizer_.ch_)) {
			if(i >= MAX_MANTISSA) {
				tokenizer_.errorMessage
				(TooManyDigitsAfterDecimalPointError);
				return;
			}

			i++;
			j = j * 10 + ( ((unsigned)tokenizer_.ch_) - ((unsigned)'0') );
			getchr();
      	}

      	t= (double) (a*j);

      	tokenizer_.rval_= tokenizer_.rval_ * pow((double)10.0,(double)t);

		if(tokenizer_.debug_) {
	      if (tokenizer_.reader_->hasListing()) {
	        std::ostringstream o;
	        o
		   			<< "Rval="
		   			<< tokenizer_.rval_
		   			<< " man="
		   			<< ((double)tokenizer_.ival_+(double)r)
		   			<< " exp="
		   			<< t
  		    ;
	        tokenizer_.reader_->put(o.str());
	      }		   	
		}

		tokenizer_.flushBlanks();
    }

	if(tokenizer_.debug_) {
	  if (tokenizer_.reader_->hasListing()) {
	    std::ostringstream o;
		o
			<< "ival="
			<< tokenizer_.ival_
		;
	    tokenizer_.reader_->put(o.str());
	  }
		

	  if(tokenizer_.modeintfloat_) {

	      if (tokenizer_.reader_->hasListing()) {
	        std::ostringstream o;
	        o
  					<< "rval="
  					<< tokenizer_.rval_
  		    ;
	        tokenizer_.reader_->put(o.str());
	      }
  			
	  }
	}

	return;	
}

void 
LanguageXML::getstring()
{
  tokenizer_.flushBlanks();
  if(!tokenizer_.isQuote()) {
	tokenizer_.errorMessage(StringQuoteIsMissingError);
	return;
  }

  getchr(); 	
  tokenizer_.strng_ = "";
  tokenizer_.isString_ = true;
  	
  for(;;) {
    if(tokenizer_.iseof()) {
    	tokenizer_.errorMessage(EndOfStringQuoteIsMissingError);
    	return;
    }

	if(tokenizer_.isQuote()) break;

	tokenizer_.strng_.push_back(tokenizer_.ch_);
	getchr();
  }

  tokenizer_.flushQuote();
  tokenizer_.isString_ = false;

  if(tokenizer_.debug_) {
    if (tokenizer_.reader_->hasListing()) {
    	std::ostringstream o;
    	o
			<< "strng='"
			<< tokenizer_.strng_
			<< "'"
  		;
    	tokenizer_.reader_->put(o.str());
	  }		  
  }

  return;	
}


void 
LanguageXML::convertSpecialCharacters()
{
	tokenizer_.convertSpecialCharacters();
}

void 
Tokenizer::convertSpecialCharacters()
{
  if ('&' == ch_) {
	int currentLineSize = static_cast<int>(line_.size());
	  
	// &  &amp; 
	if (
		(
			((npos_+1) < currentLineSize)
			&& ('a' == line_[npos_+1])
		)
        && (
        	((npos_+2) < currentLineSize)
			&& ('m' == line_[npos_+2]) 
        )
        && (
         	((npos_+3) < currentLineSize)
        	&& ('p' == line_[npos_+3]) 
        )
        && (
        	((npos_+4) < currentLineSize)
        	&& (';' == line_[npos_+4]) 
        )
	) {
		npos_ += 4;
        ch_ = '&';
 	} 
	// <  &lt; 
	else if (
		(
			((npos_+1) < currentLineSize)
			&& ('l' == line_[npos_+1])
		)
	    && (
	    	((npos_+2) < currentLineSize)
			&& ('t' == line_[npos_+2]) 
	 	)
	 	&& (
	     	((npos_+3) < currentLineSize)
	     	&& (';' == line_[npos_+3]) 
	 	)
	) {
		npos_  += 3;
        ch_ = '<';
	}
	// >   &gt; 
	else if (
		(
				((npos_+1) < currentLineSize)
				&& ('g' == line_[npos_+1])
		)
		&& (
		    	((npos_+2) < currentLineSize)
				&& ('t' == line_[npos_+2]) 
		)
		&& (
		     	((npos_+3) < currentLineSize)
		     	&& (';' == line_[npos_+3]) 
		)
	) {
		npos_ += 3;
        ch_ = '>';
	}
	// nonbreak space &nbsp; 
	else if (
			(
				((npos_+1) < currentLineSize)
				&& ('n' == line_[npos_+1])
			)
	        && (
	        	((npos_+2) < currentLineSize)
				&& ('b' == line_[npos_+2]) 
	        )
	        && (
	         	((npos_+3) < currentLineSize)
	        	&& ('s' == line_[npos_+3]) 
	        )
	        && (
	        	((npos_+4) < currentLineSize)
	        	&& ('p' == line_[npos_+4]) 
	        )
	        && (
	        	((npos_+5) < currentLineSize)
	        	&& (';' == line_[npos_+5]) 
	        )
	) {
		npos_ += 5;
        ch_ = ' ';
	}
	// apostrophe '      &apos; 
	else if (
			(
				((npos_+1) < currentLineSize)
				&& ('a' == line_[npos_+1])
			)
	        && (
	        	((npos_+2) < currentLineSize)
				&& ('p' == line_[npos_+2]) 
	        )
	        && (
	         	((npos_+3) < currentLineSize)
	        	&& ('o' == line_[npos_+3]) 
	        )
	        && (
	        	((npos_+4) < currentLineSize)
	        	&& ('s' == line_[npos_+4]) 
	        )
	        && (
	        	((npos_+5) < currentLineSize)
	        	&& (';' == line_[npos_+5]) 
	        )
	) {
		npos_ += 5;
        ch_ = '\'';
	}
	//Quotation mark "  &quot; 
	else if (
			(
				((npos_+1) < currentLineSize)
				&& ('q' == line_[npos_+1])
			)
	        && (
	        	((npos_+2) < currentLineSize)
				&& ('u' == line_[npos_+2]) 
	        )
	        && (
	         	((npos_+3) < currentLineSize)
	        	&& ('o' == line_[npos_+3]) 
	        )
	        && (
	        	((npos_+4) < currentLineSize)
	        	&& ('t' == line_[npos_+4]) 
	        )
	        && (
	        	((npos_+5) < currentLineSize)
	        	&& (';' == line_[npos_+5]) 
	        )
	) {
		npos_ += 5;
        ch_ = '"';
	}
  }

  return;	
}

/********************************
void 
LanguageXML::getchrXmlData()
{
  if (tokenizer_.iseof()) return;
  
  //if (
  //  (tokenizer_.ch_ == '\n') 
  //) {
  //  if (!tokenizer_.reader_->isEof()) {
  //    tokenizer_.ch_ = EOF;
  //  } else {
  //    tokenizer_.getnewl();
  //  }
  //  
  //  return;
  //}

  if (tokenizer_.npos_ == static_cast<int>(tokenizer_.line_.size()))
  {
    //44// 
	tokenizer_.ch_ = '\0';
    //tokenizer_.ch_ = '\n';
    //return;
  } else {
    tokenizer_.npos_++;
    tokenizer_.ch_ = tokenizer_.line_[tokenizer_.npos_];
  }

  if (tokenizer_.ch_ == '\t') {
    tokenizer_.epos_ = (tokenizer_.epos_&~7) + 8; 
  } else {
    tokenizer_.epos_++;
  }

  if ((tokenizer_.ch_ == '\t') || (tokenizer_.ch_ == '\f')) {
    tokenizer_.ch_= ' ';
  }

  if(tokenizer_.ch_ == '\r') {
	tokenizer_.ch_ = '\n';
  }
  
  if (
    (tokenizer_.ch_ == '\0') 
    //|| (tokenizer_.ch_ == '\n') 
    /////|| (tokenizer_.ch_ == '\r')
  ) {
    if (!tokenizer_.reader_->isEof()) {
      tokenizer_.ch_ = EOF;
    } else {
      tokenizer_.getnewl();
    }
  }
  
//std::cout << "getchrXmlData():" 
//		  << "c:'" << ((char)tokenizer_.ch_)  << "'"
//		  << "e:" << (tokenizer_.ch_ == '\n')
//		  << std::endl;
} 


void 
LanguageMeta::getchrXmlData()
{
  getchr();
}
**/

void 
LanguageXML::getXmlDataString()
{
	tokenizer_.getXmlDataString();
}

void 
Tokenizer::getXmlDataString()
{
  termString_ = "";
  isTermString_ = true;
  
  bool isNewLine = false;
  for(;;) {
    if(iseof()) {
    	errorMessage(EndOfXmlElementIsMissingError);
    	return;
    }

/*
    if (1) {
    	static int cnt = 0;
    	static int max = 1000;
    	
    	cnt++;
    	if (cnt == max) {
    		exit(0);
    	}
    	
    	std::cout
    	<< "c:" << "'" << ((char)ch_) << "'" 
    	<< " eol:" << (ch_ == '\n')
    	<< " n:" << npos_ << "(" << line_.size() << ")"
    	<< std::endl;
    }
 */   

	if('<' == ch_) break;

	convertSpecialCharacters();
	
	////////////////termString_.push_back(ch_);	
	//xmlEolMode_ = true;
	//getchr();
	///////////////////getchrXmlData();
	
	///////////////////std::cout << termString_ << std::endl;
	//xmlEolMode_ = false;
	
	if (npos_ == static_cast<int>(line_.size())) {
	  ch_ = '\n';
	} 
	
	if (!isNewLine) {
		termString_.push_back(ch_);	
	}
	else {
		isNewLine = false;
	}
	
	if (npos_ == static_cast<int>(line_.size())) {
	  ch_ = '\n';
	} 
	else {
	  npos_++;
	  ch_ = line_[npos_];
	}
	
	if (
	    (ch_ == '\n') 
	    //|| (tokenizer_.ch_ == '\n') 
	    /////|| (tokenizer_.ch_ == '\r')
	) {
	    if (!reader_->isEof()) {
	      ch_ = EOF;
	    } else {
	      getnewl();
	      isNewLine = true;
	    }
	}
  } // for(;;)

  isTermString_ = false;

  if(1 || debug_) {
    if (reader_->hasListing()) {
    	std::ostringstream o;
    	o
			<< "termString='"
			<< termString_
			<< "'"
  		;
    	reader_->put(o.str());
	  }		  
  }

  return;	
}


void 
LanguageXML::flush()
{
	while(!(
		(
		  ('<' == tokenizer_.ch_) 
		  && (
			((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size()))
			&& ('/' == tokenizer_.line_[tokenizer_.npos_+1])
		  )
		)
		|| tokenizer_.iseof())
	) {
		getchr();
	}
}

void LanguageXML::getNextToken()
{
  if(tokenizer_.iseof()) {
	tokenizer_.kword_ = cppcc::com::PLS_WRONG_KEY_WORD;
	return;
  }

  if (isStringToken()) {
	getstring();
	tokenizer_.kword_ = cppcc::com::PLS_STRING_TOKEN;
  } else if (isIntegerToken()) {
	getint();
	tokenizer_.kword_ = cppcc::com::PLS_INTEGER_TOKEN;
  } else if (isTerminalStringToken()) {
	getTermString();
	tokenizer_.kword_ = cppcc::com::PLS_TERMINAL_TOKEN;	
  } else if (isDefinedToken()) {
	setNextToken();
  } else {
	
	//std::cout << "ch:" << tokenizer_.ch_ 
	//		<< " t:" << ((char)tokenizer_.ch_)
	//		<< std::endl;
	  
	getid();
	if (isKeyWord(tokenizer_.id_)) {
		setKeyWord(tokenizer_.id_);
	} else {
		tokenizer_.kword_ = cppcc::com::PLS_IDENTIFIER;
	}
  }
}

Token*
LanguageXML::makeToken
	(const std::string& t
	,const std::string& n)
{
  Token* 		r = 0;
  std::size_t 	z = t.size();
  
  if (1 == z) {
	  if (">" == t) {
		  r = new OneCharXmlGreaterThanToken(tokenizer_, t, n);
	  } else {
		  r = new OneCharToken(tokenizer_, t, n);
	  }
  } else if (2 == z) {
	  r = new TwoCharToken(tokenizer_, t, n);
  } else if (3 == z) {
	  r = new ThreeCharToken(tokenizer_, t, n);
  } else {
	  
  }
  
  if (!r) {
	CPPCC_THROW_EXCEPTION(
	  << "LanguageXML::makeToken() assert check failed:"
	  << " Token:" << "'" << t << "'"
	  << " : "  << "'" << n << "'"
	  << " has a wrong size:" << z
	  << " it should be one of 1,2,or 3!"
	)	  	  
  }
  
  return r;
}


void 
LanguageXML::populate()
{
/*
	//11// tokens_["\""] = new OneCharToken(tokenizer_,"\"");
	tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"\"", "quote"));
	tokens_.name2index_["\""] = tokens_.tokens_.size()-1;
	  
	  //tokens_["#"] 	= new OneCharToken(tokenizer_,"#");
	  //tokens_["&"] 	= new OneCharToken(tokenizer_,"&");
	  //tokens_["'"] 	= new OneCharToken(tokenizer_,"'");
	  //tokens_["("] 	= new OneCharToken(tokenizer_,"(");
	  //tokens_[")"] 	= new OneCharToken(tokenizer_,")");
	  //tokens_["*"] 	= new OneCharToken(tokenizer_,"*");
	  //tokens_["+"] 	= new OneCharToken(tokenizer_,"+");
	  //tokens_[","] 	= new OneCharToken(tokenizer_,",");
	  //tokens_["-"] 	= new OneCharToken(tokenizer_,"-");
	  //tokens_["."] 	= new OneCharToken(tokenizer_,".");
	  //tokens_["/"] 	= new OneCharToken(tokenizer_,"/");
	  //tokens_[":"] 	= new OneCharToken(tokenizer_,":");  
	  //tokens_[";"] 	= new OneCharToken(tokenizer_,";");  
	
	//11// tokens_["<"] 	= new OneCharToken(tokenizer_,"<");   
	tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"<", "lessThan"));
	tokens_.name2index_["<"] = tokens_.tokens_.size()-1;
		
	//11// tokens_["="] 	= new OneCharToken(tokenizer_,"=");  
	tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"=", "equal"));
	tokens_.name2index_["="] = tokens_.tokens_.size()-1;
	
	//11// tokens_[">"] 	= new OneCharToken(tokenizer_,">");  
	//22// tokens_.tokens_.push_back(new OneCharToken(tokenizer_,">", "greaterThan"));
	tokens_.tokens_.push_back(new OneCharXmlGreaterThanToken(tokenizer_,">", "greaterThan"));
	tokens_.name2index_[">"] = tokens_.tokens_.size()-1;

	  
	  //tokens_["_"] 	= new OneCharToken(tokenizer_,"_");  
	
	//11// tokens_["!"] 	= new OneCharToken(tokenizer_,"!");  
	tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"!", "exclamationMark"));
	tokens_.name2index_["!"] = tokens_.tokens_.size()-1;
	
	  //tokens_["$"] 	= new OneCharToken(tokenizer_,"$");  
	  //tokens_["%"] 	= new OneCharToken(tokenizer_,"%");  
	
	//11// tokens_["?"] 	= new OneCharToken(tokenizer_,"?"); 
	tokens_.tokens_.push_back(new OneCharToken(tokenizer_,"?", "questionMark"));
	tokens_.name2index_["?"] = tokens_.tokens_.size()-1;
	
	  //tokens_["@"] 	= new OneCharToken(tokenizer_,"@"); 
	  //tokens_["["] 	= new OneCharToken(tokenizer_,"["); 
	  //tokens_["\\"] 	= new OneCharToken(tokenizer_,"\\"); 
	  //tokens_["]"] 	= new OneCharToken(tokenizer_,"]"); 
	  //tokens_["^"] 	= new OneCharToken(tokenizer_,"^"); 
	  //tokens_["`"] 	= new OneCharToken(tokenizer_,"`"); 
	  //tokens_["{"] 	= new OneCharToken(tokenizer_,"}"); 
	  //tokens_["~"] 	= new OneCharToken(tokenizer_,"~"); 
	  
	  //tokens_["=>"] 	= new TwoCharToken(tokenizer_,"=>"); 
	  //tokens_["**"] 	= new TwoCharToken(tokenizer_,"**"); 
	  //tokens_[":="] 	= new TwoCharToken(tokenizer_,":="); 
	  //tokens_["/="] 	= new TwoCharToken(tokenizer_,"/="); 
	  //tokens_[">="] 	= new TwoCharToken(tokenizer_,">="); 
	  //tokens_["<="] 	= new TwoCharToken(tokenizer_,"<="); 
	  //tokens_["<>"] 	= new TwoCharToken(tokenizer_,"<>"); 
	  
	//11// tokens_["</"] 	= new TwoCharToken(tokenizer_,"</"); 	
	tokens_.tokens_.push_back(new TwoCharToken(tokenizer_,"</", "xmlEnd"));
	tokens_.name2index_["</"] = tokens_.tokens_.size()-1;
*/

  if (cppcc::com::PLS_TERMINALS_START !=
  tokenizer_.grammarSymbols_.predefined_.size()) {
  CPPCC_THROW_EXCEPTION(
        << "LanguageXML::populate() assert check failed:"
      << cppcc::com::PLS_TERMINALS_START
      << " != "
      << tokenizer_.grammarSymbols_.predefined_.size()
      << " !"
  )   
  }
  
  // populate tokens_
  cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cEnd = 
    tokenizer_.defaultTokenNames_.tokenNames_.end();
  
  
  // xml //  :::::::::::::::::
  //tokenizer_.grammarSymbols_.tokens_.push_back(":");
  //tokenizer_.grammarSymbols_.tokens_.push_back("?");
  //tokenizer_.grammarSymbols_.tokens_.push_back("/");
  //tokenizer_.grammarSymbols_.tokens_.push_back("</");
  // xml //  .................

  
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.tokens_.size(); i < s; i++
  ) {
    const std::string& t = tokenizer_.grammarSymbols_.tokens_[i];
    cppcc::tnm::TokenNameContainer::TokenNameMap::const_iterator cIter = 
      tokenizer_.defaultTokenNames_.tokenNames_.find(t);
    if (cEnd == cIter) {
      CPPCC_THROW_EXCEPTION(
        << "LanguageXML::populate() assert check failed:"
        << " Token:'" << t << "'"
        << " does not have corresponding name defined in TokenNames!"
      )       
    }
    
    const std::string& n = cIter->second;
    tokens_.tokens_.push_back(makeToken(t,n));
    tokens_.name2index_[t] = tokens_.tokens_.size()-1;
    tokens_.id2index_[n] = tokens_.tokens_.size()-1;
  }
  
  // xml //  :::::::::::::::::
  bool isDebugDump = false;
  if (isDebugDump) {
	  for (register std::size_t i = 0
	    ,s = tokenizer_.grammarSymbols_.tokens_.size(); i < s; i++
	  ) {
	    const std::string& t = tokenizer_.grammarSymbols_.tokens_[i];
	   
	    std::cout << "i:" << i << " t:" << "'" << t << "'" << std::endl;
	   
	  }
	  
	  for (register std::size_t i = 0
	    ,s = tokens_.tokens_.size(); i < s; i++
	  ) {
	    Token* t = tokens_.tokens_[i];
	   
	    std::cout << "i:" << i
	    		<< " t:" << "'" << t->token_ << "'" 
	    		<< " n:" << "'" << t->name_ << "'" 
	    		<< std::endl;
	   
	  }	  
  }
  // xml //  .................



  // ub:
  // populate key words !!!!!!!!!!!!
  // const std::string& t = tokenizer_.grammarSymbols_.nonTerminals_[i];	 
  // keyWordsGenerated_
  // 
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.keyWordsGenerated_.size(); i < s; i++
  ) {
	  const std::string& t = tokenizer_.grammarSymbols_.keyWordsGenerated_[i];	  

	  //keyWords_.tokens_.push_back(0);
    keyWords_.tokens_.push_back(makeToken(t,t));
	  keyWords_.name2index_[t] = keyWords_.tokens_.size()-1;
    tokens_.id2index_[t] = tokens_.tokens_.size()-1;
  }

  // populate nonTerminals_
  for (register std::size_t i = 0
    ,s = tokenizer_.grammarSymbols_.nonTerminals_.size(); i < s; i++
  ) {
    const std::string& t = tokenizer_.grammarSymbols_.nonTerminals_[i];   

    nonTerminals_.tokens_.push_back(0);
    nonTerminals_.name2index_[t] = nonTerminals_.tokens_.size()-1;
    nonTerminals_.id2index_[t] = nonTerminals_.tokens_.size()-1;
  }
     
  populateTerminals();

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "tokens_: " << tokens_
      ;
      tokenizer_.reader_->put(o.str());
    //}
  }

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "keyWords_: " << keyWords_
      ;
      tokenizer_.reader_->put(o.str());
    //}
  }

  if(tokenizer_.debug_) {
    //if (tokenizer_.reader_->hasListing()) {
      std::ostringstream o;
      o
        << "nonTerminals_: " << nonTerminals_
      ;
      tokenizer_.reader_->put(o.str());
    //}
  }
}

/*
void  
Language::skipToken
	(const int 				t
	,cppcc::scr::tag::Long& l)
{
	Token& 	token = getToken(t);
	token.skipToken(t, l);
	//!!!// getNextToken();
    if (!tokenizer_.parser_.isXmlTokenFlag()) {
	  getNextToken();
    }	
}
*/

void 
OneCharXmlGreaterThanToken::processGreaterThanAndXmlTermToken
	(cppcc::scr::tag::Long& l)
{

  // xml //
  // xml // if (isXmlTokenFlag_) {
  if (tokenizer_.parser_.isXmlTokenFlag()) {
	if ('<' != tokenizer_.ch_) {
		//register int s;
		//long f[2];
		//
		//setedflong((f),KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
		//if(s= xmlDataSegmentAsStringToken(f+1)) return(s);
		//crefixe(KW_XMLTOKEN);
		std::vector<cppcc::scr::tag::Long> f(2);
		cppcc::scr::tag::setedflong(&f[0],cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
		
		//33// std::string result;
		//33// xmlDataSegmentAsStringToken(result);
		// result -> &f[1]
		tokenizer_.getXmlDataString();
		// tokenizer_.termString_ ==>> &f[1]
		tokenizer_.parser_.textToken(f[1]);
		
		//crefixe(KW_XMLTOKEN);
		tokenizer_.parser_.crefixe(cppcc::com::PLS_TEXT_TOKEN,f,&l);
	} else {
		//setedflong(l,KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
		cppcc::scr::tag::setedflong(&l,cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
	}
    
	tokenizer_.parser_.xmlTokenOff();
  } else {
    //setedflong(l,KW_TERMTOKEN,KW_GREATERTHANTERMTOKEN);
	cppcc::scr::tag::setedflong(&l,cppcc::com::PLS_TERMINAL_TOKEN,symbol_);
  }
  
  return;
}

/*
bool
OneCharToken::isToken() 
{
  return tokenizer_.ch_ == token_[0];
}

void 
OneCharToken::flushToken() 
{
  if (isToken()) {
    tokenizer_.getchr();
    tokenizer_.flushBlanks();
  }
} 

bool 
TwoCharToken::isToken() {
	return 
	  (tokenizer_.ch_ == token_[0])
	  && (
	    ((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size()))
	    &&
		(tokenizer_.line_[tokenizer_.npos_+1] == token_[1])
	  )
	;
}
void 
TwoCharToken::flushToken() {
	  if (isToken()) {
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.flushBlanks();
	  }
} 

bool 
ThreeCharToken::isToken() {
	return 
	  (tokenizer_.ch_ == token_[0])
	  && (
			((tokenizer_.npos_+1) < static_cast<int>(tokenizer_.line_.size()))
			&&  
			(tokenizer_.line_[tokenizer_.npos_+1] == token_[1])
	  )
	  && (
			((tokenizer_.npos_+2) < static_cast<int>(tokenizer_.line_.size()))
			&&  
			(tokenizer_.line_[tokenizer_.npos_+2] == token_[2])
	  )
	;
}

void 
ThreeCharToken::flushToken() {
	  if (isToken()) {
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.getchr();
		  tokenizer_.flushBlanks();
	  }
} 
*/



}
}


//std::ostream& operator<<(std::ostream& out, const cppcc::lex::Token& t)
//{
//  // std::string  	token_;
//  // std::string  	name_;
//  // int			symbol_;
//  out
//    << "Token:" << "'" << t.token_ << "'"
//    << " name:" << "'" << t.name_ << "'"
//    << " symbol:" << "'" << t.symbol_ << "'"
//    << std::endl;
//  return out;
//}

/*
std::ostream& operator<<(std::ostream& out, const cppcc::lex::Tokens& ts)
{
  out
	<< "name2index_.size:" << ts.name2index_.size()
	<< " tokens_.size:" << ts.tokens_.size()
	<< std::endl;

  const cppcc::lex::Tokens::Name2IndexMap::const_iterator ci =
	ts.name2index_.begin();  
  const cppcc::lex::Tokens::Name2IndexMap::const_iterator ce = 
	ts.name2index_.end();
  for (; ce != ci; ++ci) {
    int idx = ci->second;

    out
      << " index:" << idx;

	  if((idx < 0) || (idx >= ts.tokens_.size())) {
      out << std::endl;
	    continue;
	  }

	  cppcc::lex::Token* t = ts.tokens_[idx];
    out << (*) << std::endl;
  }

  return out;
}
*/
////////////////////////////////////////////////////////////////////////
// TokenNames.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "TokenNames.h"


namespace cppcc {
namespace tnm {

namespace {

	struct tn {
	   const char*	t;
	   const char*	n;
	};
	
	static tn tn_[]= {
	  {"\"", "quoteTermToken"}
	  ,{"'", "apostropheTermToken"}
	  ,{"(", "leftParenthesisTermToken"}
	  ,{")", "rightParenthesisTermToken"}
	  ,{"<", "lessThenTermToken"}
	  ,{"=", "equalTermToken"}
	  ,{">", "greaterThenTermToken"}
	  ,{"[", "leftSquareBracketTermToken"}
	  ,{"]", "rightSquareBracketTermToken"}
	  ,{"|", "verticalBarTermToken"}
	  ,{"!", "exclamationMarkTermToken"}
	  ,{"?", "questionMarkTermToken"}
	  ,{"{", "leftBraceTermToken"}
	  ,{"}", "rightBraceTermToken"}
	  ,{"</", "xmlEndTermToken"}
	  
	  ,{"#", "sharpMarkTermToken"}
	  ,{"&", "ampersandTermToken"}
	  ,{"*", "starMarkTermToken"}
	  ,{"+", "plusMarkTermToken"}
	  ,{"-", "minusMarkTermToken"}
	  ,{".", "dotMarkTermToken"}
	  ,{",", "commaMarkTermToken"}
	  ,{":", "colonMarkTermToken"}
	  ,{";", "semicolonMarkTermToken"}
	  
	  // xml //
	  ,{"/", "slashMarkTermToken"}	  
	  // xml //
	  
	  // dot //
	  ,{",", "commaTermToken"}
	  ,{";", "semicolonTermToken"}
	  ,{"->", "edgeOpTermToken"}
	  //,{"digraph", "digraphTermToken"}
	  //,{"subgraph", "subgraphTermToken"}
	  // dot //
	  
	  ,{"::=", "defisTermToken"}
	};
	
	std::size_t sz_ = sizeof(tn_)/sizeof(tn_[0]);

}

void
TokenNameContainer::populate()
{
	for (register std::size_t i = 0; i < sz_; i++) {
		tn&	e = tn_[i];
		tokenNames_[e.t] = e.n; 
	}
}

}
}


////////////////////////////////////////////////////////////////////////
// Shell.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

namespace cppcc {
namespace cmp {

Compiler::Action*		
Compiler::makeAction(cppcc::cmd::Shell& sh)
{
	switch(sh.cmd_)
	{
	case cppcc::com::SHELL_CMD_COMPILE:
	  return new Compiler::ActionCompile(*this);
	case cppcc::com::SHELL_CMD_UNLOAD:
	  return new Compiler::ActionUnload(*this);
	default:
	  return 0;
	}
}

void
Compiler::ActionUnload::run()
{
	CPPCC_LOG_INFO((*compiler_.shell_.logger_),
	  << "Unloading "
	)
	
    for (register std::size_t i = 0, 
    	s = compiler_.shell_.files_.size(); i < s; i++) {
    	CPPCC_LOG_INFO((*compiler_.shell_.logger_),
    	  << "Unloading "
    	  << compiler_.shell_.files_[i]
    	)	
    	
       	compiler_.parser_->decompile(compiler_.shell_.files_[i]);
    }
	
}

void
Compiler::ActionCompile::run()
{
	CPPCC_LOG_INFO((*compiler_.shell_.logger_),
	  << "Compiling"
	)
	
    for (register std::size_t i = 0, 
    	s = compiler_.shell_.files_.size(); i < s; i++) {
    	const std::string& filename = compiler_.shell_.files_[i];
    	CPPCC_LOG_INFO((*compiler_.shell_.logger_),
    	  << "Compiling "
    	  << filename
    	)	
    	
    	// set debug_ to true.
    	compiler_.parser_->tokenizer_.debug_ = 1;
    	//compiler_.parser_->tokenizer_.debug_ = 0;
    	
    	std::string	listingFile = filename+".lis";
    	//compiler_.parser_->tokenizer_.start(filename.c_str(), listingFile.c_str());
       	compiler_.parser_->compile(filename.c_str(), listingFile.c_str());
       	
    }
	
}

void 
Compiler::run() {
  if (!action_) return;
  action_->run();
}

/*
cppcc::syn::Parser*	
Compiler::makeParser(cppcc::cmd::Shell& sh)
{
	switch(sh.cmd_)
	{
	case cppcc::com::SHELL_CMD_COMPILE:
	  //return new Compiler::ActionCompile(*this);
		return 0;
	case cppcc::com::SHELL_CMD_UNLOAD:
	  return 0;
	default:
	  return 0;
	}
}
*/

void 
Compiler::prolog() {
	CPPCC_LOG_INFO((*shell_.logger_),
	  << "Compiler started @ "
	  <<  cppcc::com::getCurrentTime() 
	)
}


void 
Compiler::epilog() throw() {
  try {
	CPPCC_LOG_INFO((*shell_.logger_),
	  << "Compiler finished @ "
	  <<  cppcc::com::getCurrentTime() 
	)
	
	if (action_) {
		delete action_;
		action_ = 0;
	}
	
	if (parser_) {
		delete parser_;
		parser_ = 0;
	}
	
  }
  catch(...) 
  {
  }
}


}
}


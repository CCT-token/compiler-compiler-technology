////////////////////////////////////////////////////////////////////////
// Logger.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "Logger.h"


namespace cppcc {
namespace log {

void
Logger::setLevelTest()
{
	const	char*	levelText[] =
	{
		""
		,"ERROR"
		,"WARNING"
		,"INFO"
		,"DEBUG"
	};
	std::size_t levelTextSize = sizeof(levelText)/sizeof(levelText[0]);
	
	if (levelTextSize != levelText_.size()) {
	  CPPCC_THROW_EXCEPTION(
			<< "*** ERROR *** Wrong levelTextSize:"
			<< levelTextSize
			<< " should be equal to:"
			<< levelText_.size()
	  )		
	}
	
	for (std::size_t i = 0, s = levelText_.size(); i < s; i++) {
		levelText_[i] = levelText[i];
	}
}


void
Logger::validate(int	theLevel) 
{

	if ((theLevel <= cppcc::com::LOGGER_LEVEL_UNDEFINED) 
	  || (theLevel >= cppcc::com::LOGGER_LEVEL_SIZE)) {
		  CPPCC_THROW_EXCEPTION(
			<< "*** ERROR *** Wrong log level:"
			<< theLevel
			<< " - out off range:("
			<< cppcc::com::LOGGER_LEVEL_UNDEFINED
			<< ".."
			<< cppcc::com::LOGGER_LEVEL_SIZE
			<< ")"
		  )
	}
} 

void 
Logger::setlogger(const char*  theLogname)
{ 
  if (!theLogname) {
	  streamPointer_ = &(std::cerr);
  } else {
	  streamHandler_.open(theLogname);
	  if (!streamHandler_) {
	    std::string   syserr = cppcc::com::CPPCCException::systemError();
			
	    CPPCC_THROW_EXCEPTION(
			<< "Can't open log file:'"
			<< theLogname
			<< "' - Reason:'"
			<< syserr
			<< "'"
		)
	  }
		  
	  streamPointer_ = &streamHandler_;	  
  }
}

void
Logger::log(int	theLevel, const std::string& theError) 
{
	
	if (!streamPointer_) return;
		
	validate(theLevel);
	if (theLevel > level_) {
		return;
	}
		
	std::ostringstream	o;
	o
	  << programName_
	  << " [" << levelText_[theLevel] << "] "
	  << theError
	;
		
	(*streamPointer_) << o.str() << std::endl;
} 



}
}

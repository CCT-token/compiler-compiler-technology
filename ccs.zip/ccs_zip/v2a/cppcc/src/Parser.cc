////////////////////////////////////////////////////////////////////////
// Parser.cc
//
//	Change history:
//		2010.06.12		- Initial version
//
////////////////////////////////////////////////////////////////////////

#include "CommonRoutines.h"
#include "Parser.h"
#include "Generator.h"

//#include "SyntaxControlledBinary.h"
// ub: move cppcc::tag::TypeInstance* out of SyntaxControlledRuntime.h!
//#include "SyntaxControlledRuntime.h"

namespace cppcc {
namespace syn {

// ub:
    
  void		
  Parser::dump_
	(int 					k
	,TagVector&				d
	,cppcc::scr::tag::Long* l
	)
  {
    /*
	  std::vector<cppcc::scr::tag::Long> f;
	  cppcc::scr::tag::Long r;
	  runtime_.celedpfst(0, k, &r, f);  
	  cppcc::scr::SyntaxControlledRuntime::edp& e = runtime_.celedpfnd(&r);
	  runtime_.edfeptd(e, d);
	  if (l) *l = r;	
    */

    //int isDebug = 1;
    //if (isDebug) {
      std::ostringstream o;
      o 
        << "k:" << k
        << " l->t:" << (l?(((cppcc::scr::tag::TypeInstance*)l)->t):0)
        << " l->d:" << (l?(((cppcc::scr::tag::TypeInstance*)l)->d):0)
        << " d.size():" << d.size()
        << std::endl;

      if(d.size()) {
        for (std::size_t i = 0, z = d.size(); i < z; i++) {
          cppcc::scr::tag::TypeInstance* ti = (cppcc::scr::tag::TypeInstance*)(&d[i]);
          o
            << "d["<<i<<"]" << "=" << "(" << "t:"<< ti->t << " d:" << ti->d << ")"
            << std::endl;
        }
      }

      tokenizer_.infoMessage(o.str());
      std::cout << o.str();
    //}

  }

Parser::Parser
	(cppcc::log::Logger&  				logger
	,cppcc::com::KeyWordsContainer& 	theKeyWords
	,cppcc::com::LanguageTokenizerSet 	theLanguage
	,cppcc::lex::TokenizerReader 	 	theReader)
: logger_(logger)
, grammarSymbols_(theKeyWords)
//, runtime_(theKeyWords.size())
, runtime_()
, binary_()
, tokenizer_(*this, logger, theKeyWords, theLanguage, theReader)
, context_(0)
, axiom_(0)
//, filename_()
, generator_(*this, theLanguage)
, filename_()
, debug_(false)
, isXmlTokenFlag_(false)
//, tokenizerSet_(theLanguage)
{}
	
void 
Parser::prolog()
{
}

void 
Parser::epilog() throw()
{
  try {
  } 
  catch(...)
  {}
}

void 
Parser::generateBinaryFromRuntime()
{
	//bool isLocalDebug = true;
	bool isLocalDebug = false;
	
	cppcc::scr::SyntaxControlledRuntime::cnm&  currentContext = 
	  runtime_.cnms_.dataByKey
		(runtime_.cnmnumCurrent_);
	
	cppcc::scr::tag::ULong lenidn = currentContext.namn_.index2data.size();
	
	cppcc::scr::tag::ULong lenids = 0;
	for (std::size_t i = 0, z = currentContext.namn_.index2data.size();
	  i < z; i++
	) {
	  cppcc::scr::SyntaxControlledRuntime::nam& namCurrent = 
	    currentContext.namn_.index2data[i];
	  lenids += binary_.lenofedpchar(namCurrent.namkey_.size()+1);
	  
	  if (isLocalDebug || debug_) {
		  std::cout
		  << " i:" << i
		  << " lenids:" << lenids
		  << " nam:" << namCurrent
		  << std::endl;
	  }
	}
	
	cppcc::scr::tag::ULong lensts = 0;
	cppcc::scr::tag::ULong lenstn = currentContext.kwns_.index2data.size();
	if (lenstn > 0) {
	      
		for (std::size_t kwnIndex=0, 
	  		kwnSize = currentContext.kwns_.index2data.size();
	  		kwnIndex <  kwnSize;  kwnIndex++
		) {
			cppcc::scr::SyntaxControlledRuntime::kwn& kwnCurrent = 
					currentContext.kwns_.index2data[kwnIndex];
	  		
	  		if (isLocalDebug || debug_) {
	  			std::cout
	  			    << "lensts:0:" << lensts
	  			    << " lenstn:" << lenstn
	  			    << " cnm:" << runtime_.cnmnumCurrent_ 
	  				<< " kwn:" << kwnIndex 
	  				<< " " << kwnCurrent
	  				<< " edps:" << kwnCurrent.edps_.index2data.size()
	  				<< std::endl;
	  		}
	  		
	  		cppcc::scr::tag::ULong lenkwnl =
	  		  kwnCurrent.edps_.index2data.size();
	  		
	  		lensts += lenkwnl*binary_.SOFEDP();
	  		
	  		if (isLocalDebug || debug_) {
	  			std::cout
	  			    << "lensts:1:" << lensts
	  			    << " lenstn:" << lenstn
	  			    << " lenkwnl:" << lenkwnl
	  			    << " cnm:" << runtime_.cnmnumCurrent_ 
	  				<< " kwn:" << kwnIndex 
	  				<< " " << kwnCurrent
	  				<< " edps:" << kwnCurrent.edps_.index2data.size()
	  				<< std::endl;
	  		}
	  	    
	  	    for (std::size_t edpIndex=0, 
	    		edpSize = kwnCurrent.edps_.index2data.size();
	    		edpIndex <  edpSize;  edpIndex++
	    	  ) {
	  	    	cppcc::scr::SyntaxControlledRuntime::edp& edpCurrent = 
	  	    	  kwnCurrent.edps_.index2data[edpIndex];
	    		
		  		if (isLocalDebug || debug_) {
	    		  std::cout 
	  			    << "lensts:2:" << lensts
	  			    << " lenstn:" << lenstn
	    		    << " cnm:" << runtime_.cnmnumCurrent_ 
	    	        << " kwn:" << kwnIndex << " " << kwnCurrent.kwnnum_
	    	        << " edp:" << edpIndex << " " << edpCurrent.edpnum_
	    	        << " " 
	    	        << edpCurrent
	    	        << std::endl;
		  		}
		  		
		  		bool isDumpToken = false && debug_;
		  		if (isDumpToken) {
		  			cppcc::scr::tag::Long kn;
		  			cppcc::scr::tag::setedflong(&kn,kwnCurrent.kwnnum_,edpCurrent.edpnum_);
		  			runtime_.dumpToken(std::cout, kn);
		  		}
		  		
		  		lensts += edpCurrent.edpfix_.size();
		  		lensts += edpCurrent.edpdyn_.size();
		  		
		  		if (isLocalDebug || debug_) {
	    		  std::cout 
	  			    << "lensts:3:" << lensts
	  			    << " lenstn:" << lenstn
	    		    << " cnm:" << runtime_.cnmnumCurrent_ 
	    	        << " kwn:" << kwnIndex << " " << kwnCurrent.kwnnum_
	    	        << " edp:" << edpIndex << " " << edpCurrent.edpnum_
	    	        << " " 
	    	        << edpCurrent
	    	        << std::endl;
		  		}

	  	    }  
		}		
	}
	
	cppcc::scr::tag::ULong len =
	  binary_.SOFCNT()
	  + 3*lenidn
	  + lenids
	  + lenstn*binary_.SOFKWN()
	  + lensts
	;
	
	binary_.memory_.resize(len);
	
	cppcc::scb::SyntaxControlledBinary::contextType*	h = 
	  binary_.uhead();
	h->cntlen = len;
	h->cntcur = 0;
	h->cntbeg = axiom_;
	h->cntnid = lenidn;
	h->cntdid = binary_.SOFCNT();
	h->cntnkw = lenstn;
	h->cntdkw = binary_.SOFCNT() + 3*lenidn + lenids;
	
	if (lenidn > 0) {
		cppcc::scr::tag::ULong lenidss= 
		  binary_.SOFCNT() + 3*lenidn;
		for (std::size_t namIndex=0, 
	      namSize = currentContext.namn_.index2data.size();
	      namIndex < namSize; namIndex++
		) {
			cppcc::scr::SyntaxControlledRuntime::nam& namCurrent = 
			  currentContext.namn_.index2data[namIndex];
			
	  		if (isLocalDebug || debug_) {
    		  std::cout 
    		    << "cnm:" << runtime_.cnmnumCurrent_ 
	            << " nam:0:" << namIndex << " " << namCurrent
	            << std::endl;
	  		}
	  		
	  		memcpy(
	  		  &binary_.memory_[lenidss]
	  		  ,namCurrent.namkey_.c_str()
	  		  ,(namCurrent.namkey_.size()+1)
	  		);
	  		
	  		binary_.memory_
	  		  [binary_.SOFCNT() + namIndex] =
	  			lenidss
	  		;
	  		
	  		if (isLocalDebug || debug_) {
    		  std::cout 
    		    << "cnm:" << runtime_.cnmnumCurrent_ 
	            << " nam:1:" << namIndex << " " << namCurrent
	            << " lenidss:" << lenidss
	            << " b[]=" << binary_.memory_[binary_.SOFCNT() + namIndex]
	            << " bn()=" << "'" << ((char*)(&binary_.memory_[lenidss])) << "'"
	            << std::endl;
	  		}
	  		
	  		lenidss += binary_.lenofedpchar(namCurrent.namkey_.size()+1);
		}	
		

		cppcc::scr::SyntaxControlledRuntime::ContextNameByKeyMap::Map::const_iterator 
		//std::map<std::string,cppcc::scr::tag::Long>::const_iterator 
		    cIter = 
	          currentContext.namn_.name2index.begin();
		cppcc::scr::SyntaxControlledRuntime::ContextNameByKeyMap::Map::const_iterator 
	    //std::map<std::string,cppcc::scr::tag::Long>::const_iterator 
	        cEnd = 
	      	  currentContext.namn_.name2index.end();
		for (std::size_t namIndex=0;cEnd != cIter; ++cIter,namIndex++) 
		{
			cppcc::scr::SyntaxControlledRuntime::nam& namCurrent = 
					currentContext.namn_.index2data[cIter->second];
			
	  		if (isLocalDebug || debug_) {
    		  std::cout 
    		    << "cnm:" << runtime_.cnmnumCurrent_ 
	            << " nam:" << namIndex << " " << namCurrent
	            << " iter:" << "'" << cIter->first << "'"
	                        << " " << cIter->second
	            << std::endl;
	  		}
	  		
	  		binary_.memory_[binary_.SOFCNT() + lenidn + 2*namIndex]= 	
	            binary_.memory_[binary_.SOFCNT() + cIter->second];
	  		binary_.memory_[binary_.SOFCNT() + lenidn + 2*namIndex+1]= 
	  		    cIter->second;
		}
		
		// dump ids
		if (isLocalDebug || debug_) {
			std::cout << "+++++++++++++++++++++++++++++++++++++++++++"
			<< std::endl;
			std::cout << "+++++++++++++++++++++++++++++++++++++++++++"
			<< std::endl;
			
			for (cppcc::scr::tag::Long j = 0, z = binary_.head()->cntnid
			  ; j < z; j++) {
				std::cout 
				<< "i:" << j
				<< " n:" << "'" << binary_.ptrids(j) << "'"
				<< std::endl;
				
			}
			
			for (cppcc::scr::tag::Long j = 0, z = binary_.head()->cntnid
			  ; j < z; j++) {
				std::cout 
				<< "i:" << j
				<< " x:" <<  binary_.ptridnum(j)
				<< " n:" << "'" << binary_.ptridn(j) << "'"
				<< std::endl;
				
			}
			
			std::cout << "+++++++++++++++++++++++++++++++++++++++++++"
			<< std::endl;
			std::cout << "+++++++++++++++++++++++++++++++++++++++++++"
			<< std::endl;
			
		}
	}
		
	if (lenstn > 0) {
		cppcc::scr::tag::ULong lenidss= 
		  binary_.head()->cntdkw + lenstn*binary_.SOFKWN()
		;
	     
		//cppcc::scr::tag::ULong ikwn = 0;
		
		for (std::size_t kwnIndex=0, 
	  		kwnSize = currentContext.kwns_.index2data.size();
	  		kwnIndex <  kwnSize;  kwnIndex++
		) {
			cppcc::scr::SyntaxControlledRuntime::kwn& kwnCurrent = 
					currentContext.kwns_.index2data[kwnIndex];
	  		
	  		if (isLocalDebug || debug_) {
	  			std::cout << "cnm:" << runtime_.cnmnumCurrent_ 
	  				<< " kwn:" << kwnIndex << " " << kwnCurrent
	  				<< " edps:" << kwnCurrent.edps_.index2data.size()
	  				<< std::endl;
	  		}
	  		cppcc::scr::tag::ULong lenkwnl =
	  		  kwnCurrent.edps_.index2data.size();
	  		
	  		if (lenkwnl >0) {
	  		cppcc::scb::SyntaxControlledBinary::kwnirType* pkwn =
	  		  binary_.ptrkwn(kwnIndex);
	  			  		
	  		pkwn->l = lenkwnl;
	  		pkwn->k = kwnCurrent.kwnnum_;
	  		pkwn->d = lenidss;
	  		
	  		// QQQ
	  		lenidss += (lenkwnl * binary_.SOFEDP());
	  	    
	  	    for (std::size_t edpIndex=0, 
	    		//edpSize = kwnCurrent.edps_.index2data.size();
		    	edpSize = lenkwnl;
	    		edpIndex <  edpSize;  edpIndex++
	    	  ) {
	  	    	cppcc::scr::SyntaxControlledRuntime::edp& edpCurrent = 
	  	    	  kwnCurrent.edps_.index2data[edpIndex];
	    		
		  		if (isLocalDebug || debug_) {
	    		  std::cout 
	    		    << "cnm:" <<runtime_.cnmnumCurrent_ 
	    	        << " kwn:" << kwnIndex << " " << kwnCurrent.kwnnum_
	    	        << " edp:" << edpIndex << " " << edpCurrent.edpnum_
	    	        << " " 
	    	        << edpCurrent
	    	        << std::endl;
		  		}
		  		
		  		bool isDumpToken = false && debug_;
		  		if (isDumpToken) {
		  			cppcc::scr::tag::Long kn;
		  			cppcc::scr::tag::setedflong(&kn,kwnCurrent.kwnnum_,edpCurrent.edpnum_);
		  			runtime_.dumpToken(std::cout, kn);
		  		}

		  		cppcc::scb::SyntaxControlledBinary::edpirType* pedp =
		  		  binary_.ptredp(pkwn,edpIndex);

		  		pedp->fl = edpCurrent.edpfix_.size();
		  		pedp->dl = edpCurrent.edpdyn_.size();
		  		
		  		pedp->d  = lenidss;
		  		
		  		if (pedp->fl) {
		  		  //std::copy
		  		  //	(edpCurrent.edpfix_.begin()
		  		  //	,edpCurrent.edpfix_.end()
		  		  //	,&binary_.memory_[lenidss])
		  		  //;
		  		  //memcpy(
		  		  //  &binary_.memory_[lenidss]
		  		  //  ,&edpCurrent.edpfix_[0]
		  		  //  ,(edpCurrent.edpfix_.size()*
		  		  //    sizeof(cppcc::scr::tag::Long))
		  		  //);	
				
		  		  std::copy
			  	    (edpCurrent.edpfix_.begin()
			  	    ,edpCurrent.edpfix_.end()
			  	    ,(binary_.memory_.begin() + lenidss))
			  	  ;
		  			
		  		}
		  		
		  		if (pedp->dl) {
			  	  //std::copy
			  	  //  (edpCurrent.edpdyn_.begin()
			  	  //  ,edpCurrent.edpdyn_.end()
			  	  //  ,&binary_.memory_[lenidss+pedp->fl])
			  	  //;		  
			  		  // memcpy(
			  		  //   &binary_.memory_[lenidss+pedp->fl]
			  		  //  ,&edpCurrent.edpdyn_[0]
			  		  //  ,(edpCurrent.edpdyn_.size()*
			  		  //    sizeof(cppcc::scr::tag::Long))
			  		  //);	
				  std::copy
				    (edpCurrent.edpdyn_.begin()
				    ,edpCurrent.edpdyn_.end()
				    ,(binary_.memory_.begin() + lenidss+pedp->fl))
				  ;		  

		  		}
		  		
		  		if (isLocalDebug || debug_) {
	    		  std::cout 
	    		    << "cnm~~~~~~~~~~~~~~~~~~~~~~~~~~~:" 
	    		    <<runtime_.cnmnumCurrent_ 
	    	        << " kwn:" << kwnIndex << " " << kwnCurrent.kwnnum_
	    	        << " edp:" << edpIndex << " " << edpCurrent.edpnum_
	    	        << " " 
	    	        << edpCurrent
	    	        << " lenidss:" << lenidss
	    	        << " pedp:" 
						<< "(" 
							<< pedp->fl 
							<< " " << pedp->dl
							<< " " << pedp->d
						<< ")"
	    	        << std::endl;
		  		}
		  		
		  		lenidss += (edpCurrent.edpfix_.size() + edpCurrent.edpdyn_.size());
	  	    }  
	  	    
	  	    // QQQ
	  	    //lenidss += (lenkwnl * binary_.SOFEDP());

			//if (1 || isLocalDebug || debug_) {
			if (isLocalDebug || debug_) {
				std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
				<< std::endl;

				std::cout 
				<< "pkw: (" 
					<< pkwn->l
					<< " " << pkwn->k
					<< " " << pkwn->d
				<< ")"
				<< std::endl;

				
				cppcc::scr::tag::Long  numberOfedps=
					pkwn->l;
				for (cppcc::scr::tag::Long j = 0; j < numberOfedps; j++) {
			  		
					cppcc::scb::SyntaxControlledBinary::edpirType* ppedp =
			  		  binary_.ptredp(pkwn,j);

					
					std::cout 
					<< "j:0:" << j
					<< " edp:" 
						<< ppedp->fl 
						<< " " << ppedp->dl
						<< " " << ppedp->d
						//<< " " << (*ppedp)
						//<< binary_.edpDump(*ppedp)
					<< std::endl;
					
					binary_.edpDump(std::cout, *ppedp);
					
					cppcc::scb::SyntaxControlledBinary::ruleType rul = 
					  //binary_.setrule(pkwn,ppedp);
					  binary_.setrule(ppedp);
					
					std::cout 
					<< "j:1:" << j
					<< " edp:" 
						<< ppedp->fl 
						<< " " << ppedp->dl
						<< " " << ppedp->d
					<< "rul:" 
						<< " f:" 
	<< ((rul.f - reinterpret_cast<cppcc::scb::SyntaxControlledBinary::TagInstance*>(&binary_.memory_[0]))/
			sizeof(cppcc::scb::SyntaxControlledBinary::TagInstance))
			<< " d:" 
<< ((rul.d - reinterpret_cast<cppcc::scb::SyntaxControlledBinary::TagInstance*>(&binary_.memory_[0]))/
sizeof(cppcc::scb::SyntaxControlledBinary::TagInstance))
                     //<< " " << (*ppedp)
					//<< binary_.edpDump(*ppedp)
			<< std::endl;
					binary_.edpDump(std::cout, *ppedp);
				}
				
				// Check pkwn->k & setptrkwn
		  		cppcc::scb::SyntaxControlledBinary::kwnirType* ppppkwn =
		  		  binary_.setptrkwn(pkwn->k);
				
		  		std::cout
		  		<< " +++++++++++++++++++++++++++ "
		  		<< std::endl;
		  		
		  		std::cout
		  		<< " pkwn->k:" << pkwn->k
		  		<< std::endl;
		  		if (ppppkwn) {
		  			std::cout
		  			<< "ppppkwn:" << (*ppppkwn)
		  			<< std::endl;
		  		} else {
			  		std::cout
			  		<< " ERROR - NO kwn rep for " << pkwn->k
			  		<< std::endl;		  			
		  		}
		  		
		  		
		  		std::cout
		  		<< " +++++++++++++++++++++++++++ "
		  		<< std::endl;

		  		std::cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
				<< std::endl;
				
			}	  	    
	  	    
	  		}
		}		
	}		
}


}
}


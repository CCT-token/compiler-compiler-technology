/////////////////////////////////////////////////////////////////////
//  meta_v2_NNubrGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_meta_v2_NNubr_GENERATOR_H_
#define  _CPPCC_meta_v2_NNubr_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace meta_v2_NNubr {

	class meta_v2_NNubrGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		meta_v2_NNubrGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~meta_v2_NNubrGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class meta_v2_NNubrGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		meta_v2_NNubrGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~meta_v2_NNubrGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


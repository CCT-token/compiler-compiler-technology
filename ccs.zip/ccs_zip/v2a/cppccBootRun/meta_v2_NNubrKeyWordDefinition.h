/////////////////////////////////////////////////////////////////////
//  meta_v2_NNubrKeyWordDefinition.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_meta_v2_NNubr_KEYWORDDEFINITION_H_
#define  _CPPCC_meta_v2_NNubr_KEYWORDDEFINITION_H_

#include "CommonRoutines.h"

namespace cppcc {
namespace meta_v2_NNubr {

enum KeyWords
{
  // 0
  KW_WRONG_KEY_WORD
  // 1
  ,KW_IDENTIFIER
  // 2
  ,KW_STRINGTOKEN
  // 3
  ,KW_INTEGERTOKEN
  // 4
  ,KW_FLOATTOKEN
  // 5
  ,KW_TEXTTOKEN
  // 6
  ,KW_TERMTOKEN
  // 7
  ,KW_TERMINALTOKENOFRULE
  // 8
  ,KW_QUOTETERMTOKEN
  // 9
  ,KW_APOSTROPHETERMTOKEN
  // 10
  ,KW_LEFTPARENTHESISTERMTOKEN
  // 11
  ,KW_RIGHTPARENTHESISTERMTOKEN
  // 12
  ,KW_LESSTHENTERMTOKEN
  // 13
  ,KW_EQUALTERMTOKEN
  // 14
  ,KW_GREATERTHENTERMTOKEN
  // 15
  ,KW_LEFTSQUAREBRACKETTERMTOKEN
  // 16
  ,KW_RIGHTSQUAREBRACKETTERMTOKEN
  // 17
  ,KW_VERTICALBARTERMTOKEN
  // 18
  ,KW_LEFTBRACETERMTOKEN
  // 19
  ,KW_RIGHTBRACETERMTOKEN
  // 20
  ,KW_DEFISTERMTOKEN
  // 21
  ,KW_COLONMARKTERMTOKEN
  // 22
  ,KW_QUESTIONMARKTERMTOKEN
  // 23
  ,KW_SLASHMARKTERMTOKEN
  // 24
  ,KW_XMLENDTERMTOKEN
  // 25
  ,KW_COMMATERMTOKEN
  // 26
  ,KW_SEMICOLONTERMTOKEN
  // 27
  ,KW_EDGEOPTERMTOKEN
  // 28
  ,KW_GRAMMAR
  // 29
  ,KW_GRAMMARNAMEDEF
  // 30
  ,KW_RULE
  // 31
  ,KW_NTERM
  // 32
  ,KW_RIGHT
  // 33
  ,KW_ELEMENT
  // 34
  ,KW_ACTION
  // 35
  ,KW_ACTIONS
  // 36
  ,KW_IDENTALT
  // 37
  ,KW_ALTPART
  // 38
  ,KW_NTERMTERMACT
  // 39
  ,KW_NTERMTERM
  // 40
  ,KW_ALTERNATIVE
  // 41
  ,KW_IDENTMISS
  // 42
  ,KW_ITERATION
  // 43
  ,KW_ITERITEMS
  // 44
  ,KW_ALTITERITEM
  // 45
  ,KW_ITERITEMACT
  // 46
  ,KW_ITERITEM
  // 47
  ,KW_MAYBENTERM
  // 48 -- Total
  ,KW_KEYWORDS_TOTAL
};

cppcc::com::KeyWordsContainer makeKeyWordsContainer();

}
}

#endif


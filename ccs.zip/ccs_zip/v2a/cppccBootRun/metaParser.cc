/////////////////////////////////////////////////////////////////////
//  metaParser.cc 
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "metaParser.h"
#include "metaKeyWordDefinition.h"

namespace cppcc {
namespace meta {

void
metaParser::compile
  (const char *sour, const char *list)
{
  CPPCC_LOG_INFO(logger_,
    << "metaParser::compile() "
    << " source:" << "'" << std::string(sour?sour:"") << "'"
    << " listing:" << "'" << std::string(list?list:"") << "'"
  )

  filename_ = sour?sour:"";
  tokenizer_.start(sour, list);

  grammar(axiom_);

  tokenizer_.erfini();
}

void
metaParser::compile
    (const std::string& filename
    ,const std::string& sourceString
  ,bool         isListing)
{
  filename_ = filename;
  tokenizer_.start(sourceString, isListing);

  grammar(axiom_);

  tokenizer_.erfini();
}

void
metaParser::grammar(cppcc::scr::tag::Long& tag)
/*
(grammar::=0 ="  METAACTBEG();"='(' grammarNameDef{rule}')' 0 ="  METAACTEND();"=)
*/
{
  TagVector d;
  TagVector f(2);

  METAACTBEG();

  skipToken(KW_LEFTPARENTHESISTERMTOKEN,f[0]);

  grammarNameDef(f[1]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_LEFTPARENTHESISTERMTOKEN) {
	  d.push_back(0);
	  rule(d.back());
    }
    else break;

  }

  d.push_back(0);
  skipToken(KW_RIGHTPARENTHESISTERMTOKEN,d.back());
  crelasedp(KW_GRAMMAR,f,d,&tag);
  METAACTEND();

}

void
metaParser::grammarNameDef(cppcc::scr::tag::Long& tag)
/*
(grammarNameDef::=identifier)
*/
{

  identifier(tag);

}

void
metaParser::rule(cppcc::scr::tag::Long& tag)
/*
(rule::='(' nterm'::=' right')' )
*/
{
  TagVector f(5);

  skipToken(KW_LEFTPARENTHESISTERMTOKEN,f[0]);

  nterm(f[1]);

  skipToken(KW_DEFISTERMTOKEN,f[2]);

  right(f[3]);

  skipToken(KW_RIGHTPARENTHESISTERMTOKEN,f[4]);
  crefixe(KW_RULE,f,&tag);


}

void
metaParser::nterm(cppcc::scr::tag::Long& tag)
/*
(nterm::=identifier)
*/
{

  identifier(tag);

}

void
metaParser::right(cppcc::scr::tag::Long& tag)
/*
(right::={element})
*/
{
  TagVector d;

  for(;;) {
    if(iseof()) break;

    if( (kword() == KW_LEFTPARENTHESISTERMTOKEN)
      || (kword() == KW_IDENTIFIER)
      || ((kword() == KW_INTEGERTOKEN) || (kword() == KW_FLOATTOKEN))
      || (kword() == KW_TERMTOKEN)
      || (kword() == KW_LEFTSQUAREBRACKETTERMTOKEN)
      || (kword() == KW_LEFTBRACETERMTOKEN)
    ){
	  d.push_back(0);
	  element(d.back());
    }
    else break;

  }

  crelasdyn(KW_RIGHT,d,&tag);

}

void
metaParser::element(cppcc::scr::tag::Long& tag)
/*
(element::=identAlt|alternative|identMiss|iteration|action)
*/
{

  if((kword() == KW_IDENTIFIER)
   || (kword() == KW_TERMTOKEN)
  ){
    identAlt(tag);
  }
  else if((kword() == KW_LEFTPARENTHESISTERMTOKEN)
  ){
    alternative(tag);
  }
  else if((kword() == KW_LEFTSQUAREBRACKETTERMTOKEN)
  ){
    identMiss(tag);
  }
  else if((kword() == KW_LEFTBRACETERMTOKEN)
  ){
    iteration(tag);
  }
  else if(((kword() == KW_INTEGERTOKEN) || (kword() == KW_FLOATTOKEN))
  ){
    action(tag);
  }
  else {
    pdbkwmis(KW_LEFTPARENTHESISTERMTOKEN);
    pdbkwmis(KW_IDENTIFIER);
    pdbkwmis(KW_INTEGERTOKEN);
    pdbkwmis(KW_TERMTOKEN);
    pdbkwmis(KW_LEFTSQUAREBRACKETTERMTOKEN);
    pdbkwmis(KW_LEFTBRACETERMTOKEN);
    edber();
  }

}

void
metaParser::action(cppcc::scr::tag::Long& tag)
/*
(action::=integerToken'=' {stringToken}'=' )
*/
{
  TagVector d;
  TagVector f(2);

  integerToken(f[0]);

  skipToken(KW_EQUALTERMTOKEN,f[1]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_STRINGTOKEN) {
	  d.push_back(0);
	  stringToken(d.back());
    }
    else break;

  }

  d.push_back(0);
  skipToken(KW_EQUALTERMTOKEN,d.back());
  crelasedp(KW_ACTION,f,d,&tag);

}

void
metaParser::actions(cppcc::scr::tag::Long& tag)
/*
(actions::='=' {action}'=' )
*/
{
  TagVector d;
  TagVector f(1);

  skipToken(KW_EQUALTERMTOKEN,f[0]);

  for(;;) {
    if(iseof()) break;

    if((kword() == KW_INTEGERTOKEN) || (kword() == KW_FLOATTOKEN)) {
	  d.push_back(0);
	  action(d.back());
    }
    else break;

  }

  d.push_back(0);
  skipToken(KW_EQUALTERMTOKEN,d.back());
  crelasedp(KW_ACTIONS,f,d,&tag);

}

void
metaParser::identAlt(cppcc::scr::tag::Long& tag)
/*
(identAlt::=ntermtermact{Altpart})
*/
{
  TagVector d;
  TagVector f(1);

  ntermtermact(f[0]);

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_VERTICALBARTERMTOKEN) {
	  d.push_back(0);
	  Altpart(d.back());
    }
    else break;

  }

  crelasedp(KW_IDENTALT,f,d,&tag);

}

void
metaParser::Altpart(cppcc::scr::tag::Long& tag)
/*
(Altpart::='|' ntermtermact)
*/
{
  TagVector f(2);

  skipToken(KW_VERTICALBARTERMTOKEN,f[0]);

  ntermtermact(f[1]);
  crefixe(KW_ALTPART,f,&tag);


}

void
metaParser::ntermtermact(cppcc::scr::tag::Long& tag)
/*
(ntermtermact::=ntermterm[actions])
*/
{
  TagVector f(2);

  ntermterm(f[0]);

  f[1]=0;
    if(kword() == KW_EQUALTERMTOKEN) {
actions(f[1]);
  }
  crefixe(KW_NTERMTERMACT,f,&tag);


}

void
metaParser::ntermterm(cppcc::scr::tag::Long& tag)
/*
(ntermterm::=nterm|termToken)
*/
{

    if(kword() == KW_IDENTIFIER) {
    nterm(tag);
  }
  else if((kword() == KW_TERMTOKEN)
  ){
    termToken(tag);
  }
  else {
    pdbkwmis(KW_IDENTIFIER);
    pdbkwmis(KW_TERMTOKEN);
    edber();
  }

}

void
metaParser::alternative(cppcc::scr::tag::Long& tag)
/*
(alternative::='(' identAlt')' )
*/
{
  TagVector f(3);

  skipToken(KW_LEFTPARENTHESISTERMTOKEN,f[0]);

  identAlt(f[1]);

  skipToken(KW_RIGHTPARENTHESISTERMTOKEN,f[2]);
  crefixe(KW_ALTERNATIVE,f,&tag);


}

void
metaParser::identMiss(cppcc::scr::tag::Long& tag)
/*
(identMiss::='[' identAlt']' )
*/
{
  TagVector f(3);

  skipToken(KW_LEFTSQUAREBRACKETTERMTOKEN,f[0]);

  identAlt(f[1]);

  skipToken(KW_RIGHTSQUAREBRACKETTERMTOKEN,f[2]);
  crefixe(KW_IDENTMISS,f,&tag);


}

void
metaParser::iteration(cppcc::scr::tag::Long& tag)
/*
(iteration::='{' iterItemact iterItems'}' )
*/
{
  TagVector f(4);

  skipToken(KW_LEFTBRACETERMTOKEN,f[0]);

  iterItemact(f[1]);

  iterItems(f[2]);

  skipToken(KW_RIGHTBRACETERMTOKEN,f[3]);
  crefixe(KW_ITERATION,f,&tag);


}

void
metaParser::iterItems(cppcc::scr::tag::Long& tag)
/*
(iterItems::={altIterItem})
*/
{
  TagVector d;

  for(;;) {
    if(iseof()) break;

    if(kword() == KW_VERTICALBARTERMTOKEN) {
	  d.push_back(0);
	  altIterItem(d.back());
    }
    else break;

  }

  crelasdyn(KW_ITERITEMS,d,&tag);

}

void
metaParser::altIterItem(cppcc::scr::tag::Long& tag)
/*
(altIterItem::='|' iterItemact)
*/
{
  TagVector f(2);

  skipToken(KW_VERTICALBARTERMTOKEN,f[0]);

  iterItemact(f[1]);
  crefixe(KW_ALTITERITEM,f,&tag);


}

void
metaParser::iterItemact(cppcc::scr::tag::Long& tag)
/*
(iterItemact::=iterItem[actions])
*/
{
  TagVector f(2);

  iterItem(f[0]);

  f[1]=0;
    if(kword() == KW_EQUALTERMTOKEN) {
actions(f[1]);
  }
  crefixe(KW_ITERITEMACT,f,&tag);


}

void
metaParser::iterItem(cppcc::scr::tag::Long& tag)
/*
(iterItem::=nterm|maybeNterm)
*/
{

    if(kword() == KW_IDENTIFIER) {
    nterm(tag);
  }
  else if((kword() == KW_LESSTHENTERMTOKEN)
  ){
    maybeNterm(tag);
  }
  else {
    pdbkwmis(KW_IDENTIFIER);
    pdbkwmis(KW_LESSTHENTERMTOKEN);
    edber();
  }

}

void
metaParser::maybeNterm(cppcc::scr::tag::Long& tag)
/*
(maybeNterm::='<' nterm'>' )
*/
{
  TagVector f(3);

  skipToken(KW_LESSTHENTERMTOKEN,f[0]);

  nterm(f[1]);

  skipToken(KW_GREATERTHENTERMTOKEN,f[2]);
  crefixe(KW_MAYBENTERM,f,&tag);


}

}

namespace com {
cppcc::syn::Parser* 
makeParser(cppcc::cmp::Compiler& compiler)
{
  CPPCC_LOG_INFO((*compiler.shell_.logger_),
    << "com::makeParser() started..."
    << " tokensSetID:" << compiler.shell_.tokensSetID_
  )

  return
    new cppcc::meta
      ::metaParser
      ((*compiler.shell_.logger_)
      ,compiler.keyWords_
      ,compiler.shell_.tokensSetID_? compiler.shell_.tokensSetID_ : cppcc::com::LanguageTokenizerSet_Meta
      ,cppcc::lex::TokenizerReader_File)
    ;
}
}

}

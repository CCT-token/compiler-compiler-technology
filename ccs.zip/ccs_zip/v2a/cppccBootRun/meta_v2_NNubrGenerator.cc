/////////////////////////////////////////////////////////////////////
//  meta_v2_NNubrGenerator.cc 
//
//	Change history:
//		2010.06.12		- Initial version
//
/////////////////////////////////////////////////////////////////////


#include "Shell.h"
#include "Logger.h"
#include "Compiler.h"
#include "Parser.h"

#include "meta_v2_NNubrParser.h"
#include "meta_v2_NNubrKeyWordDefinition.h"
#include "meta_v2_NNubrGenerator.h"

namespace cppcc {
namespace meta_v2_NNubr {

void
meta_v2_NNubrGeneratorBinary::generate(const std::string& filename)
{
}

}
}

/* metake.h                version of 09.01.91 */

extern char 	*KeyTab[];
extern struct 	tableItemTermToken tableTermToken[];
extern int 	KeyTabkeyword[];



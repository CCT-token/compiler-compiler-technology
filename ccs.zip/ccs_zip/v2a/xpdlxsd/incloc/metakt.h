/* xpdlxsdkt.h                version of 09.01.91 */

char *KeyTab[]=
{

	/*   0*/  "WrongKeyWord"
	/*   1*/, "xsd"
	/*   2*/, "greaterthanTermToken"
	/*   3*/, "floatToken"
	/*   4*/, "equalTermToken"
	/*   5*/, "xmlEndTermToken"
	/*   6*/, "integerToken"
	/*   7*/, "stringToken"
	/*   8*/, "xpdlxsd"
	/*   9*/, "grammar"
	/*  10*/, "dummyRule"
	/*  11*/, "identifier"
	/*  12*/, "colonTermToken"
	/*  13*/, "attribute"
	/*  14*/, "attributes"
	/*  15*/, "attributeExtention"
	/*  16*/, "slashdivideTermToken"
	/*  17*/, "quastionmarkTermToken"
	/*  18*/, "lessthanTermToken"
	/*  19*/, "xsdTag"
	/*  20*/, "xsdTags"
	/*  21*/, "xsdTagsList"
	/*  22*/, "xsdTagEnd"
	/*  23*/, "xmlVersion"
	/*  24*/, "xmlVersionAttributes"
	/*  25*/, "termTokenofrule"
	/*  26*/, "termToken"
	/*  26*/, "quotationTermToken"
	/*  27*/, "sharpTermToken"
	/*  28*/, "ampersandTermToken"
	/*  29*/, "apostropheTermToken"
	/*  30*/, "leftparenthesisTermToken"
	/*  31*/, "rightparenthesisTermToken"
	/*  32*/, "starmultiplyTermToken"
	/*  33*/, "plusTermToken"
	/*  34*/, "commaTermToken"
	/*  35*/, "hyphenminusTermToken"
	/*  36*/, "dotpointperiodTermToken"
	/*  37*/, "semicolonTermToken"
	/*  38*/, "underlineTermToken"
	/*  39*/, "verticalbarTermToken"
	/*  40*/, "exclamationmarkTermToken"
	/*  41*/, "dollarTermToken"
	/*  42*/, "percentTermToken"
	/*  43*/, "commercialatTermToken"
	/*  44*/, "leftsquarebracketTermToken"
	/*  45*/, "leftbackslashTermToken"
	/*  46*/, "rightsquarebracketTermToken"
	/*  47*/, "circumflexTermToken"
	/*  48*/, "graveaccentTermToken"
	/*  49*/, "leftbraceTermToken"
	/*  50*/, "rightbraceTermToken"
	/*  51*/, "tildeTermToken"
	/*  52*/, "arrowTermToken"
	/*  53*/, "doublestarexponentiateTermToken"
	/*  54*/, "variableassignmentTermToken"
	/*  55*/, "inequalityTermToken"
	/*  56*/, "greaterthanorequalTermToken"
	/*  57*/, "lessthanorequalsignalassignmentTermToken"
	/*  58*/, "boxTermToken"
	/*  59*/, "defisTermToken"
};

struct tableItemTermToken tableTermToken[LENTABLETERMTOKEN]={
	{KW_QUOTATIONTERMTOKEN,"\""},
	{KW_SHARPTERMTOKEN,"#"},
	{KW_AMPERSANDTERMTOKEN,"&"},
	{KW_APOSTROPHETERMTOKEN,"'"},
	{KW_LEFTPARENTHESISTERMTOKEN,"("},
	{KW_RIGHTPARENTHESISTERMTOKEN,")"},
	{KW_STARMULTIPLYTERMTOKEN,"*"},
	{KW_PLUSTERMTOKEN,"+"},
	{KW_COMMATERMTOKEN,","},
	{KW_HYPHENMINUSTERMTOKEN,"-"},
	{KW_DOTPOINTPERIODTERMTOKEN,"."},
	{KW_SLASHDIVIDETERMTOKEN,"/"},
	{KW_COLONTERMTOKEN,":"},
	{KW_SEMICOLONTERMTOKEN,";"},
	{KW_LESSTHANTERMTOKEN,"<"},
	{KW_EQUALTERMTOKEN,"="},
	{KW_GREATERTHANTERMTOKEN,">"},
	{KW_UNDERLINETERMTOKEN,"_"},
	{KW_VERTICALBARTERMTOKEN,"|"},
	{KW_EXCLAMATIONMARKTERMTOKEN,"!"},
	{KW_DOLLARTERMTOKEN,"$"},
	{KW_PERCENTTERMTOKEN,"%"},
	{KW_QUASTIONMARKTERMTOKEN,"?"},
	{KW_COMMERCIALATTERMTOKEN,"@"},
	{KW_LEFTSQUAREBRACKETTERMTOKEN,"["},
	{KW_LEFTBACKSLASHTERMTOKEN,"\\"},
	{KW_RIGHTSQUAREBRACKETTERMTOKEN,"]"},
	{KW_CIRCUMFLEXTERMTOKEN,"^"},
	{KW_GRAVEACCENTTERMTOKEN,"`"},
	{KW_LEFTBRACETERMTOKEN,"{"},
	{KW_RIGHTBRACETERMTOKEN,"}"},
	{KW_TILDETERMTOKEN,"~"},
	{KW_ARROWTERMTOKEN,"=>"},
	{KW_DOUBLESTAREXPONENTIATETERMTOKEN,"**"},
	{KW_VARIABLEASSIGNMENTTERMTOKEN,":="},
	{KW_INEQUALITYTERMTOKEN,"/="},
	{KW_GREATERTHANOREQUALTERMTOKEN,">="},
	{KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN,"<="},
	{KW_BOXTERMTOKEN,"<>"},
	{KW_DEFISTERMTOKEN,"::="},
	{KW_XMLENDTERMTOKEN,"</"}
};
int KeyTabkeyword[LENTABLEKEYWORD]= {
	KW_XSD
};

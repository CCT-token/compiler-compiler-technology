/* metaexms.h		version of 25.07.91 */



/*
  external errors -> included in metaerm.c
*/
"METAFATERR",
"metacompiler fatal error",
METAFATERR,

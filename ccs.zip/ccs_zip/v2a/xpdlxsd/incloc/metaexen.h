/* metaexen.h		version of 25.07.91 */



/*
  external errors -> included in metaer.h
*/

METAFATERR,


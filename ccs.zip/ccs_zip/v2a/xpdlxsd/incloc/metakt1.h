/* metaakt.h                version of 09.01.91 */

char *KeyTab[]=
{

	/*   0*/  "WrongKeyWord"
	/*   1*/, "action"
	/*   2*/, "actions"
	/*   3*/, "alternative"
	/*   4*/, "altIterItem"
	/*   5*/, "Altpart"
	/*   6*/, "defisTermToken"
	/*   7*/, "element"
	/*   8*/, "equalTermToken"
	/*   9*/, "floatToken"
	/*  10*/, "grammer"
	/*  11*/, "grammerNameDef"
	/*  12*/, "greaterthanTermToken"
	/*  13*/, "identAlt"
	/*  14*/, "identifier"
	/*  15*/, "identMiss"
	/*  16*/, "integerToken"
	/*  17*/, "iteration"
	/*  18*/, "iterItem"
	/*  19*/, "iterItemact"
	/*  20*/, "iterItems"
	/*  21*/, "leftbraceTermToken"
	/*  22*/, "leftparenthesisTermToken"
	/*  23*/, "leftsquarebracketTermToken"
	/*  24*/, "lessthanTermToken"
	/*  25*/, "maybeNterm"
	/*  26*/, "metaa"
	/*  27*/, "nterm"
	/*  28*/, "ntermterm"
	/*  29*/, "ntermtermact"
	/*  30*/, "right"
	/*  31*/, "rightbraceTermToken"
	/*  32*/, "rightparenthesisTermToken"
	/*  33*/, "rightsquarebracketTermToken"
	/*  34*/, "rule"
	/*  35*/, "stringToken"
	/*  36*/, "termToken"
	/*  37*/, "verticalbarTermToken"
	/*  38*/, "termTokenofrule"
	/*  39*/, "quotationTermToken"
	/*  40*/, "sharpTermToken"
	/*  41*/, "ampersandTermToken"
	/*  42*/, "apostropheTermToken"
	/*  43*/, "starmultiplyTermToken"
	/*  44*/, "plusTermToken"
	/*  45*/, "commaTermToken"
	/*  46*/, "hyphenminusTermToken"
	/*  47*/, "dotpointperiodTermToken"
	/*  48*/, "slashdivideTermToken"
	/*  49*/, "colonTermToken"
	/*  50*/, "semicolonTermToken"
	/*  51*/, "underlineTermToken"
	/*  52*/, "exclamationmarkTermToken"
	/*  53*/, "dollarTermToken"
	/*  54*/, "percentTermToken"
	/*  55*/, "quastionmarkTermToken"
	/*  56*/, "commercialatTermToken"
	/*  57*/, "leftbackslashTermToken"
	/*  58*/, "circumflexTermToken"
	/*  59*/, "graveaccentTermToken"
	/*  60*/, "tildeTermToken"
	/*  61*/, "arrowTermToken"
	/*  62*/, "doublestarexponentiateTermToken"
	/*  63*/, "variableassignmentTermToken"
	/*  64*/, "inequalityTermToken"
	/*  65*/, "greaterthanorequalTermToken"
	/*  66*/, "lessthanorequalsignalassignmentTermToken"
	/*  67*/, "boxTermToken"
};

struct tableItemTermToken tableTermToken[LENTABLETERMTOKEN]={
	{KW_QUOTATIONTERMTOKEN,"\""},
	{KW_SHARPTERMTOKEN,"#"},
	{KW_AMPERSANDTERMTOKEN,"&"},
	{KW_APOSTROPHETERMTOKEN,"'"},
	{KW_LEFTPARENTHESISTERMTOKEN,"("},
	{KW_RIGHTPARENTHESISTERMTOKEN,")"},
	{KW_STARMULTIPLYTERMTOKEN,"*"},
	{KW_PLUSTERMTOKEN,"+"},
	{KW_COMMATERMTOKEN,","},
	{KW_HYPHENMINUSTERMTOKEN,"-"},
	{KW_DOTPOINTPERIODTERMTOKEN,"."},
	{KW_SLASHDIVIDETERMTOKEN,"/"},
	{KW_COLONTERMTOKEN,":"},
	{KW_SEMICOLONTERMTOKEN,";"},
	{KW_LESSTHANTERMTOKEN,"<"},
	{KW_EQUALTERMTOKEN,"="},
	{KW_GREATERTHANTERMTOKEN,">"},
	{KW_UNDERLINETERMTOKEN,"_"},
	{KW_VERTICALBARTERMTOKEN,"|"},
	{KW_EXCLAMATIONMARKTERMTOKEN,"!"},
	{KW_DOLLARTERMTOKEN,"$"},
	{KW_PERCENTTERMTOKEN,"%"},
	{KW_QUASTIONMARKTERMTOKEN,"?"},
	{KW_COMMERCIALATTERMTOKEN,"@"},
	{KW_LEFTSQUAREBRACKETTERMTOKEN,"["},
	{KW_LEFTBACKSLASHTERMTOKEN,"\\"},
	{KW_RIGHTSQUAREBRACKETTERMTOKEN,"]"},
	{KW_CIRCUMFLEXTERMTOKEN,"^"},
	{KW_GRAVEACCENTTERMTOKEN,"`"},
	{KW_LEFTBRACETERMTOKEN,"{"},
	{KW_RIGHTBRACETERMTOKEN,"}"},
	{KW_TILDETERMTOKEN,"~"},
	{KW_ARROWTERMTOKEN,"=>"},
	{KW_DOUBLESTAREXPONENTIATETERMTOKEN,"**"},
	{KW_VARIABLEASSIGNMENTTERMTOKEN,":="},
	{KW_INEQUALITYTERMTOKEN,"/="},
	{KW_GREATERTHANOREQUALTERMTOKEN,">="},
	{KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN,"<="},
	{KW_BOXTERMTOKEN,"<>"},
	{KW_DEFISTERMTOKEN,"::="}
};
int KeyTabkeyword[1]= {0};

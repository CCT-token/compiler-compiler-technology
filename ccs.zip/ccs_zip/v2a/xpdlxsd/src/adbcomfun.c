/*  adbcomfun.c          version of 22.05.91 */

/*  if MLAN          	 version of 20.07.93 */

#include "metaer.h"
#include "metaarts.h"

/*
#include "metakw.h"
#include "metake.h"
*/


#if MLAN
#define	metatolower(a)    (/*tolower*/(a))
#else
#define	metatolower(a)    tolower(a)
#endif



int metaletterequal(KeyTabik,Idk)
char	KeyTabik,Idk;
{

#if MLAN
  return(KeyTabik == Idk);
#else
  return((KeyTabik == Idk) ||
	   (toupper(KeyTabik) == Idk) ||
	   (KeyTabik == toupper(Idk)));
#endif
}




int adbttkk(t,k,m)
char *t;
char *k;
int m;
{
	register int i,l;

  l= strlen(t)+1;
  if(l > m) {
    for(i=0; i < m-1; i++) k[i]= metatolower(t[i]);
    k[m-1]=  '\0';
  }
  else {
    for(i=0; i < l; i++) k[i]= metatolower(t[i]);
    if( l < m) {
      for(i= l; i < m; i++) k[i]= '\0';
    }
  }

  return(0);
}

int adbttee(t,e,m)
char *t;
char *e;
int m;
{
	register int i,s;

	e[0]= '\0';
	if((strlen(t)+1) > m)
	  for(i= m-1; i<strlen(t)+1; i++)         /* = m */
	     e[i-m+1]= metatolower(t[i]);	  /* i-m */		

	return(0);
}






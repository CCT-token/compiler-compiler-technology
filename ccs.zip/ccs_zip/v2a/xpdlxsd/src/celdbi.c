/*  celdbi.dml          version of 28.01.91 */
/*                      version of 29.01.91 */

/*                      version of 04.02.91 */

/*                      version of 21.05.91 */
/*                      version of 18.06.91 */
/*                      version of 19.06.91 */
/*                      version of 27.06.91 */

/*                      version of 01.07.91 */
/*                      version of 02.07.91 */

/*                      version of 07.07.91 */
/*                      version of 10.07.91 */
/*                      version of 15.07.91 */
/*                      version of 16.07.91 */
/*                      version of 19.07.91 */

/*  OptMode             version of 04.09.91 */


/*                      version of 24.01.92 */





/* ODB			version of 08.06.92 */

/* celsetsch . . .	version of 17.07.92 */


/* 
	database manipulation interface for edifar
*/

/*
*
*       
*      sys |--------|        |--------|cnm     |--------|nam
*          |        |------->| cnmnum |------->| namnum |
*          |        |  cnms  |        |  namn  | namkey |
*          |        |        |        |------->| namend |*
*          |        |        |        |  nams  | namsou |*
*          |--------|        |--------|        |--------|
*                                |kwns
*                                V
*                            |--------|kwn     |--------|edp
*                            | kwnnum |------->| edpnum |
*                            |        |  edps  | edpfix |*
*                            |--------|        | edpdyn |*
*                                              |--------|
*
*/




#include "metaer.h"
#include "metaarts.h"

#include "celuwt.h"
#include "celuw.h"

#include "metakw.h"
#include "metake.h"

#include "pdbts.h"

/* set	schema pointer */
void	celsetsch(sch)
dbsch	sch;
{
	cel.cel= sch;
}

/* get	schema pointer */
dbsch	celgetsch()
{
	return(cel.cel);
}

/* open for update */
int celopen(mode)
int mode;
{
	register int s;

#if	!ODB
	pdbmrsquo();      /* set buffer sizes */
#endif


	if(mode == UPDATE_PDB)
	{
		if(s= odbrsbopn(&cel.cel,"cel",1)) edbier(s,CELDBOPEN);

		if(s= odbrsrget(cel.cel,0,(char*)0))
		{
			if(s= odbrsrstr(cel.cel,0,(char*)0)) edbier(s,CELDBSSYS);
		}
	}
	else if(mode == RETRIE_PDB)
	{
		if(s= odbrsbopn(&cel.cel,"cel",0)) edbier(s,CELDBOPEN);
		if(s= odbrsrget(cel.cel,0,(char*)0))  edbier(s,CELDBSSYS);
	}
	else pdber(CELDBOPEN);


	return(0);
}

/* close with rollback or commit */
int celclos(m)
int m;
{
	register int s;

#if	!ODB
	if(m)
	{
#endif

		if(s= odbrsbrlb(cel.cel)) edbier(s,CELDBROLL);

#if	!ODB
	}
#endif


	if(s= odbrsbcls(cel.cel)) edbier(s,CELDBCLOS);
	
	return(0);
}

/* rollback */
int celroll()
{
	register int s;

	if(s= odbrsbrlb(cel.cel)) edbier(s,CELDBROLL);

	return(0);
}

/* keep */
int celkeep()
{
	register int s;

	if(s= odbrsbkep(cel.cel)) edbier(s,CELDBKEEP);

	return(0);
}



/* store context */
int edfcnst(l)
long *l;        /* internal context number */
{
	register int s;

	if(!l)
	{
		/* file context creation */
		cel.cnm.cnmnum= EDFCONT;
	}
	else
	{
		if(!odbrsslst(cel.cel,0))
		{
			if(s= odbrsrgti(cel.cel,1,0,(char*)&cel.cnm.cnmnum)) edbier(s,CELDBMCNM);
		}
		else
			cel.cnm.cnmnum= EDFCONT;

		cel.cnm.cnmnum++;
		*l= cel.cnm.cnmnum;
	}

	if(s= odbrsrstr(cel.cel,1,(char*)&cel.cnm)) edbier(s,CELDBMCNM);

	return(0);
}

int celcnmstr(l)
long *l;        /* internal context number */
{
	return(edfcnst(l));
}

/* edif definition parts manipulation for current context */
int edfepst(k,l)
int k;          /* key number in KeyTab */
long *l;        /* return number        */
{
	register int s;

	cel.kwn.kwnnum= (short)k;
	if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum))
	{
		if(s= odbrsrstr(cel.cel,3,(char*)&cel.kwn)) {
			sprintf(mes,"key number:%d key word:%s",k,KeyTab[k]);
			pdbmess(mes);
			edbier(s,CELDBMKWN);
		}
	}

	cel.edp.edpnum= (long)0;
	if(!odbrsslst(cel.cel,4))
	{
		if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
		cel.edp.edpnum++;
	}


/*	if(l) *l= cel.edp.edpnum; */
	setedflong(l,k,cel.edp.edpnum);
	if(s= odbrsrstr(cel.cel,4,(char*)&cel.edp)) edbier(s,CELDBMEDP);


	return(0);
}

int celedpstr(k,l)
int k;          /* key number in KeyTab */
long *l;        /* return number        */
{
	return(edfepst(k,l));
}

int copylong(from,too,len)
long from[];
long too[];
int  len;
{
	register int i;

	for(i= 0; i < len; i++) too[i]= from[i]; 

	return(0);
}

/* set current edp */
int celedpfnd(kn)
		/* key number : KeyNum  */
long  *kn;	/* edp number		*/
{
  register int s;
  short	k;
  long  n;

  setlongedf(kn,k,n);

  if(s= celkwnnum(k)) pdber(s);
  if(s= celedpnum(n)) pdber(s);


  return(0);
}

/* modify dyn representation of file part definition */
int edfeptd(d,m,sh)
long  d[];
int   m,sh;
{
  register int s;
  long  *bd;
  int l;

  if(m == 0) return(0);

  if(d)
  {

    if(sh)
    {
      if(s= odbrsrgtd(cel.cel,4,2,&l,(char*)0))
      edbier(s,CELDBMEDP);

      if(l > 0) {
/**/
	if(!(bd= (long*)malloc(l*sizeof(long)))) pdber(METNOMEMO);

	if(s= odbrsrgtd(cel.cel,4,2,(int*)0,bd))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmdd(cel.cel,4,2,l+m,(char*)0))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmds(cel.cel,4,2,l,0,bd))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmds(cel.cel,4,2,m,l,d))
	edbier(s,CELDBMEDP);

	free(bd);
/**/
/*
	if(!(bd= (long*)malloc((l+m)*sizeof(long)))) pdber(METNOMEMO);

	if(s= odbrsrgtd(cel.cel,4,2,(int*)0,bd))
	edbier(s,CELDBMEDP);

	copylong(d,bd+l,m);

	if(s= odbrsrmdd(cel.cel,4,2,l+m,bd))
	edbier(s,CELDBMEDP);

	free(bd);
*/

      }
      else {
        if(s= odbrsrmdd(cel.cel,4,2,m,d))
        edbier(s,CELDBMEDP);
      }
    }
    else
    {
	if(s= odbrsrmdd(cel.cel,4,2,m,d))
	edbier(s,CELDBMEDP);
    }
  }

  return(0);
}


int celedpmit(d,m,sh)
long d[];
int m,sh;
{
	return(edfeptd(d,m,sh));
}


/* modify fix representation of file part definition */
int edfepfx(t,m,sh)
long *t;
int m,sh;
{
  register int s;
  long *b;
  int l;

  if(m == 0) return(0);

  if(sh)
  {
     if(s= odbrsrgtd(cel.cel,4,1,&l,(char*)0))
     edbier(s,CELDBMEDP);

     if(l > 0) {
	if(!(b= (long*)malloc(l*sizeof(long)))) pdber(METNOMEMO);

	if(s= odbrsrgtd(cel.cel,4,1,(int*)0,b))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmdd(cel.cel,4,1,l+m,(char*)0))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmds(cel.cel,4,1,l,0,b))
	edbier(s,CELDBMEDP);

	if(s= odbrsrmds(cel.cel,4,1,m,l,t))
	edbier(s,CELDBMEDP);

	free(b);
     }
     else {
       if(s= odbrsrmdd(cel.cel,4,1,m,t))
       edbier(s,CELDBMEDP);
     }
  }
  else
  {
     if(s= odbrsrmdd(cel.cel,4,1,m,t))
     edbier(s,CELDBMEDP);
  }

  return(0);
}

int celedpmfx(t,m,sh)
long *t;
int m,sh;
{
	return(edfepfx(t,m,sh));
}



/* find name (nam) in set namn  by its key part  */
int celnamkey(n)
char *n;
{
	register int i,s;
	static char e[MAXIDS];
	static char k[MAXIDS];
	static char l[MAXIDS];
	int len;

	adbttkk(n,k,MAXIDN);
	if(odbrsskey(cel.cel,1,(char*)k)) return(CELDBMNAM);
	adbttee(n,e,MAXIDN);
	if(!e[0]) return(0);

	/* duplicates */
	for(;;) {
	  if(s= odbrsrgtd(cel.cel,2,2,&len,(char*)0)) 
	  edbier(s,CELDBMNAM);
	  if(len > 0) {
	    if(s= odbrsrgtd(cel.cel,2,2,(int*)0,l)) 
	    edbier(s,CELDBMNAM);
	    if(!strcmp(e,l)) return(0);
	  }

	  if(odbrssnxt(cel.cel,1)) return(CELDBMNAM);
	  if(odbrsrgti(cel.cel,2,1,(char*) cel.nam.namkey)) return(CELDBMNAM);
	  if(strcmp(cel.nam.namkey,k)) return(CELDBMNAM);
	}
}

/* store identifier representation */
int edfnmst(n,l)
char *n;
long *l;
{
	register int s;
	char e[MAXIDS];

if(celnamkey(n)) {

	adbttkk(n,cel.nam.namkey,MAXIDN);
	adbttee(n,e,MAXIDN);

	cel.nam.namnum= (long)0;
	if(!odbrsslst(cel.cel,2))
	{
		if(s= odbrsrgti(cel.cel,2,0,(char*)&cel.nam.namnum)) edbier(s,CELDBMNAM);
		cel.nam.namnum++;
	}


	if(s= odbrsrstr(cel.cel,2,(char*)&cel.nam)) edbier(s,CELDBMNAM);

	if(s= odbrsrmdd(cel.cel,2,3,strlen(n)+1,n))
	edbier(s,CELDBMNAM);

	if(e[0])
	{
if(s= odbrsrmdd(cel.cel,2,2,strlen(e)+1,e))
		edbier(s,CELDBMNAM);
	}
}
else
{
	if(s= odbrsrgti(cel.cel,2,0,(char*)&cel.nam.namnum)) edbier(s,CELDBMNAM);
}

	if(l) *l= cel.nam.namnum;

	return(0);
}


int celnamstr(n,l)
char *n;
long *l;
{
	return(edfnmst(n,l));
}



int celkwnnum(n)
short n;
{
  cel.kwn.kwnnum= n;
  if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum)) return(CELDBMKWN);

  return(0);
}


int celedpnum(n)
long n;
{
  cel.edp.edpnum= n;
  if(odbrsskey(cel.cel,4,(char*)&cel.edp.edpnum)) return(CELDBMEDP);

  return(0);
}



int celnamnum(n)
long n;
{
  cel.nam.namnum= n;
  if(odbrsskey(cel.cel,2,(char*)&cel.nam.namnum)) return(CELDBMNAM);

  return(0);
}


int celedpgit(n,fix,fixl,dpd,tdl)
long *n;
long *fix;
int  *fixl;
long  *dpd;
int   *tdl;
{
  register int s;

  if(n) {
    if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
    *n= cel.edp.edpnum;
  }

  if(fixl) {
    if(s= odbrsrgtd(cel.cel,4,1,fixl,(char*)0)) edbier(s,CELDBMEDP);
  }

  if(fix) {
    if(s= odbrsrgtd(cel.cel,4,1,(int*)0,fix)) edbier(s,CELDBMEDP);
  }

  if(tdl) {
    if(s= odbrsrgtd(cel.cel,4,2,tdl,(char*)0)) edbier(s,CELDBMEDP);
  }

  if(dpd) {
    if(s= odbrsrgtd(cel.cel,4,2,(int*)0,dpd)) edbier(s,CELDBMEDP);
  }

  return(0);
}




/* get length of fixe part of edp */
int celedpfln(fixl)
int	 *fixl;
{
  register int s;

  if(fixl) {
    if(s= odbrsrgtd(cel.cel,4,1,fixl,(char*)0)) edbier(s,CELDBMEDP);
  }

  return(0);
}



/* nam get */
int celnamgit(num,n,a)
long *num;
char *n;
char *a;
{
	register int s;
	int len;

	if(num) {
	  if(s= odbrsrgti(cel.cel,2,0,(char*)&cel.nam.namnum)) edbier(s,CELDBMNAM);
	  *num= cel.nam.namnum;
	}

	if(n) {
	  if(s= odbrsrgti(cel.cel,2,1,(char*) cel.nam.namkey)) edbier(s,CELDBMNAM);
	  strcpy(n,cel.nam.namkey);
	  if(s= odbrsrgtd(cel.cel,2,2,&len,(char*)0))
	  edbier(s,CELDBMNAM);
	  if(len > 0) {
	    if(s= odbrsrgtd(cel.cel,2,2,(int*)0,n+strlen(n)))
	    edbier(s,CELDBMNAM);
	  }
	}

	if(a) {
	  if(s= odbrsrgtd(cel.cel,2,3,(int*)0,a))
	  edbier(s,CELDBMNAM);
	}


	return(0);
}



/* get source name length */
int celnamsln(n)
int	 *n;
{
	register int s;

	if(n) {
	  if(s= odbrsrgtd(cel.cel,2,3,n,(char*)0))
	  edbier(s,CELDBMNAM);
	}


	return(0);
}



/* cnm operations */
/* find first cnm */
int celcnmfir()
{
	if(odbrssfst(cel.cel,0)) return(CELDBMCNM);

	return(0);
}

/* find last cnm */
int celcnmlas()
{
	if(odbrsslst(cel.cel,0)) return(CELDBMCNM);

	return(0);
}

/* find next cnm */
int celcnmnxt()
{
	if(odbrssnxt(cel.cel,0)) return(CELDBMCNM);

	return(0);
}


/* find prior vie */
int celcnmpri()
{
	if(odbrssprr(cel.cel,0)) return(CELDBMCNM);

	return(0);
}


/* find  vie  by key */
int celcnmnum(n)
long n;
{
	cel.cnm.cnmnum= n;
	if(odbrsskey(cel.cel,0,(char*)&cel.cnm.cnmnum)) return(CELDBMCNM);

	return(0);
}


/* get cnm */
int celcnmgit(num)
long *num;
{
	register int s;

	if(num) {
		if(s= odbrsrgti(cel.cel,1,0,(char*)&cel.cnm.cnmnum)) edbier(s,CELDBMCNM);
		*num= cel.cnm.cnmnum;
	}

	return(0);
}





/* nam operations */

/* find first nam in set nams */
int celnamfir()
{
	if(odbrssfst(cel.cel,2)) return(CELDBMNAM);

	return(0);
}

/* find last nam in set nams */
int celnamlas()
{
	if(odbrsslst(cel.cel,2)) return(CELDBMNAM);

	return(0);
}

/* find next nam in set nams */
int celnamnxt()
{
	if(odbrssnxt(cel.cel,2)) return(CELDBMNAM);

	return(0);
}


/* find prior nam in set nams */
int celnampri()
{
	if(odbrssprr(cel.cel,2)) return(CELDBMNAM);

	return(0);
}






/* find first nam in set namn */
int celnamnfir()
{
	if(odbrssfst(cel.cel,1)) return(CELDBMNAM);

	return(0);
}

/* find last nam in set namn */
int celnamnlas()
{
	if(odbrsslst(cel.cel,1)) return(CELDBMNAM);

	return(0);
}

/* find next nam in set namn */
int celnamnnxt()
{
	if(odbrssnxt(cel.cel,1)) return(CELDBMNAM);

	return(0);
}


/* find prior nam in set namn */
int celnamnpri()
{
	if(odbrssprr(cel.cel,1)) return(CELDBMNAM);

	return(0);
}




/* edp operations */

/* find first edp in set edps */
int celedpfir()
{
	if(odbrssfst(cel.cel,4)) return(CELDBMEDP);

	return(0);
}

/* find last edp in set edps */
int celedplas()
{
	if(odbrsslst(cel.cel,4)) return(CELDBMEDP);

	return(0);
}

/* find next edp in set edps */
int celedpnxt()
{
	if(odbrssnxt(cel.cel,4)) return(CELDBMEDP);

	return(0);
}


/* find prior edp in set edps */
int celedppri()
{
	if(odbrssprr(cel.cel,4)) return(CELDBMEDP);

	return(0);
}





/* kwn operations */

/* find first kwn in set kwns */
int celkwnfir()
{
	if(odbrssfst(cel.cel,3)) return(CELDBMKWN);

	return(0);
}

/* find last kwn in set kwns */
int celkwnlas()
{
	if(odbrsslst(cel.cel,3)) return(CELDBMKWN);

	return(0);
}

/* find next kwn in set kwns */
int celkwnnxt()
{
	if(odbrssnxt(cel.cel,3)) return(CELDBMKWN);

	return(0);
}


/* find prior kwn in set kwns */
int celkwnpri()
{
	if(odbrssprr(cel.cel,3)) return(CELDBMKWN);

	return(0);
}



/* get current kwn */
int celkwngit(k)
enum KeyNum *k;
{
	register int s;

	if(s= odbrsrgti(cel.cel,3,0,(char*)&cel.kwn.kwnnum)) {
		sprintf(mes,"key number:%d key word:%s",
			cel.kwn.kwnnum,KeyTab[cel.kwn.kwnnum]);
		pdbmess(mes);
		edbier(s,CELDBMKWN);
	}

	if(k) *k= cel.kwn.kwnnum;

	return(0);
}

/* store kwn */
int celkwnstr(k)
enum KeyNum k;
{
	register int s;

	cel.kwn.kwnnum= (short)k;
	if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum))
	{
		if(s= odbrsrstr(cel.cel,3,(char*)&cel.kwn)) {
			sprintf(mes,"key number:%d key word:%s",k,KeyTab[k]);
			pdbmess(mes);
			edbier(s,CELDBMKWN);
		}

	}


	return(0);
}






/* find integerToken by its value (*i) & and return number */
int celedpifn(l,i)
long *l;        /* return number        */
long *i;        /* value  adress        */
{
	register int s,c,y;
	long v;

	cel.kwn.kwnnum= (short)KW_INTEGERTOKEN;
	if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum))
	{
		if(s= odbrsrstr(cel.cel,3,(char*)&cel.kwn)) {
			pdbmess("integer representation");
			edbier(s,CELDBMKWN);
		}
	}

	y= 1;
	c= odbrssfst(cel.cel,4);
	while(!c)
	{
		if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
		if(s= odbrsrgtd(cel.cel,4,1,(int*)0,&v)) edbier(s,CELDBMEDP);

		if((*i) == v) {y= 0; break;}

		c= odbrssnxt(cel.cel,4);
	}


	if(y) {
		cel.edp.edpnum= (long)0;
		if(!odbrsslst(cel.cel,4))
		{
			if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
			cel.edp.edpnum++;
		}

		if(s= odbrsrstr(cel.cel,4,(char*)&cel.edp)) edbier(s,CELDBMEDP);

		if(s= odbrsrmdd(cel.cel,4,1,1,i)) 
			edbier(s,CELDBMEDP);
	}

	setedflong(l,KW_INTEGERTOKEN,cel.edp.edpnum);

	return(0);
}



/* global optimization mode */
static int OptMode=1;
void celoptmod(m)
{
	OptMode=m;
}




/* edif definition parts manipulation for current context */
int celedpfst(flag,k,l,t,m)
int flag;	/* optimize or not	*/
int k;          /* key number in KeyTab */
long *l;        /* return number        */
long t[];	/* fixe part definition */
int m;
{
	register int s,c,y,yy,i;
	long *ffv;	/* fixe values */
	int   ffl;	/* fixe length */
	int   ddl;	/* def  length */	

	cel.kwn.kwnnum= (short)k;
	if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum))
	{
		if(s= odbrsrstr(cel.cel,3,(char*)&cel.kwn)) {
			sprintf(mes,"key number:%d key word:%s",k,KeyTab[k]);
			pdbmess(mes);
			edbier(s,CELDBMKWN);
		}
	}

	y= 1;

if(flag && OptMode) {
	c= odbrssfst(cel.cel,4);
	while(!c)
	{
		if(s= odbrsrgtd(cel.cel,4,2,&ddl,(char*)0)) 
			edbier(s,CELDBMEDP);
		if(ddl) break;

		if(s= odbrsrgtd(cel.cel,4,1,&ffl,(char*)0)) 
			edbier(s,CELDBMEDP);
		if(ffl == m) {
			if(ffl) {
				if(!(ffv= (long*)malloc(ffl*sizeof(long)))) 
				pdber(METNOMEMO);

				if(s= odbrsrgtd(cel.cel,4,1,(int*)0,ffv)) 
				edbier(s,CELDBMEDP);

				y= 0;
				for(i= 0; i < m; i++) {
					if(t[i] != ffv[i]) {y= 1; break;}
				}

				free(ffv);
			}
			else {
				/* m == ffl == 0 */
				y= 0;
			}

			if(!y) {
				if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) 
				edbier(s,CELDBMEDP);
				break;
			}
		}

		c= odbrssnxt(cel.cel,4);
	}
}


	if(y) {
		cel.edp.edpnum= (long)0;
		if(!odbrsslst(cel.cel,4))
		{
			if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
			cel.edp.edpnum++;
		}

		if(s= odbrsrstr(cel.cel,4,(char*)&cel.edp)) edbier(s,CELDBMEDP);

		if(s= edfepfx(t,m,0)) return(s);
	}

	setedflong(l,k,cel.edp.edpnum);

	return(0);
}





/* edif definition parts manipulation for current context */
/* string representation */
int celedpfss(k,l,t)
int k;          /* key number in KeyTab */
long *l;        /* return number        */
char *t;	/* fixe part definition:string */
{
	register int s,c,y;
	char  ffv[256];	/* fixe values */
	int   ddl;	/* def  length */	

	cel.kwn.kwnnum= (short)k;
	if(odbrsskey(cel.cel,3,(char*)&cel.kwn.kwnnum))
	{
		if(s= odbrsrstr(cel.cel,3,(char*)&cel.kwn)) edbier(s,CELDBMKWN);
	}

	y= 1;
	c= odbrssfst(cel.cel,4);
	while(!c)
	{
		if(s= odbrsrgtd(cel.cel,4,2,&ddl,(char*)0)) 
			edbier(s,CELDBMEDP);
		if(ddl) break;

		if(s= odbrsrgtd(cel.cel,4,1,(int*)0,ffv)) 
		edbier(s,CELDBMEDP);

		y= strcmp(t,ffv);

		if(!y) {
			if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
			break;
		}

		c= odbrssnxt(cel.cel,4);
	}


	if(y) {
		cel.edp.edpnum= (long)0;
		if(!odbrsslst(cel.cel,4))
		{
			if(s= odbrsrgti(cel.cel,4,0,(char*)&cel.edp.edpnum)) edbier(s,CELDBMEDP);
			cel.edp.edpnum++;
		}

		if(s= odbrsrstr(cel.cel,4,(char*)&cel.edp)) edbier(s,CELDBMEDP);

		if(s= edfepfx((long*)t,
			(strlen(t)+1+sizeof(long)-1)/sizeof(long),0)) 
			return(s);
	}

	setedflong(l,k,cel.edp.edpnum);

	return(0);
}




/*      metaaunl.c            version of 28.01.91 */
/*      	              version of 12.08.91 */
/*      	              version of 14.08.91 */

/*      	              version of 16.08.91 */
/*      	              version of 20.08.91 */
/*      	              version of 21.08.91 */
/*      	              version of 23.08.91 */
/*      	              version of 26.08.91 */
/*      	              version of 27.08.91 */
/*      	              version of 28.08.91 */
/*      	              version of 29.08.91 */

/*      	              version of 02.09.91 */
/*      	              version of 12.09.91 */
/*      	              version of 13.09.91 */

/*      	              version of 16.09.91 */
/*      	              version of 17.09.91 */
/*      	              version of 18.09.91 */
/*      	              version of 19.09.91 */
/*      	              version of 20.09.91 */
/*      	              version of 23.09.91 */
/*      	              version of 24.09.91 */
/*      	              version of 25.09.91 */

/*      	              version of 27.09.91 */
/*      	              version of 30.09.91 */


/*      	              version of 01.10.91 */
/*      	              version of 02.10.91 */
/*      	              version of 04.10.91 */
/*      	              version of 08.10.91 */

/*      	              version of 21.11.91 */

/************************** 1992 ******************/

/*      	              version of 13.01.92 */
/*      	              version of 14.01.92 */
/*      	              version of 15.01.92 */

/*  [ '+' | '-' ]             version of 21.01.92 */

/*  pdbgkwr, . .              version of 22.01.92 */

/*  VLAN, MLAN            		    version of 23.09.92 */

/*  r ::=  ('a' |'b')  : metafixe	    version of 25.09.92 */


/*  KW_FLOATTOKEN             	version of 13.11.92 */

/*  SLLAN             		version of 15.03.93 */


/*
	meta generator:
	internal representation of grammer to 
	.c program - language compiler to DB-representation
*/



#include "metaer.h"
#include "metalc.h"
#include "metale.h"
#include "metakw.h"
#include "metake.h"
#include "metaarts.h"

#include "pdbts.h"
#include "metaacts.h"


FILE *ff;

static char Gffnm[MAXFN];
static int  Gffin=0;  




#define	IITT	"INTEGERTOKEN"



int
metagen(r,fn)
inrType r;
char *fn;
{
  register int s;
  char *ccc;

  strcpy(Gffnm,fn);
  if(ccc= strrchr(Gffnm,'.')) *ccc= '\0';

  if(!(ff= fopen(fn,"w"))) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FINOCR);
  }

  /*if(s= metaggnn(r)) return(s);*/

  if(fclose(ff)) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FICLOS);
  }

  return (0);
}


/////////////////////////////////////////////////////////////////////
//  exParser.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_ex_PARSER_H_
#define  _CPPCC_ex_PARSER_H_

#include "Parser.h"

namespace cppcc {

namespace cmp {
  class Compiler;
}

namespace ex {

class exParser
  : public cppcc::syn::Parser
{

public:
  exParser 
    (cppcc::log::Logger&          logger
    ,cppcc::com::KeyWordsContainer&   theKeyWords
    ,cppcc::com::LanguageTokenizerSet   theLanguage
    ,cppcc::lex::TokenizerReader    theReader)
  : Parser(logger, theKeyWords, theLanguage, theReader)
  {
  }

  ~exParser()
  {
  }

  void compile
    (const char *sour, const char *list);

  void compile
      (const std::string& filename
      ,const std::string& sourceString
    ,bool         isListing);


  void prog(cppcc::scr::tag::Long& tag);
  void st(cppcc::scr::tag::Long& tag);
  void a2(cppcc::scr::tag::Long& tag);
  void b2(cppcc::scr::tag::Long& tag);
  void c2(cppcc::scr::tag::Long& tag);
  void d2(cppcc::scr::tag::Long& tag);
};

}
}

#endif

/////////////////////////////////////////////////////////////////////
//  exGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_ex_GENERATOR_H_
#define  _CPPCC_ex_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace ex {

	class exGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		exGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~exGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class exGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		exGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~exGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


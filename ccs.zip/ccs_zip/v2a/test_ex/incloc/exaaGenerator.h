/////////////////////////////////////////////////////////////////////
//  exaaGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_exaa_GENERATOR_H_
#define  _CPPCC_exaa_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace exaa {

	class exaaGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		exaaGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~exaaGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class exaaGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		exaaGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~exaaGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif


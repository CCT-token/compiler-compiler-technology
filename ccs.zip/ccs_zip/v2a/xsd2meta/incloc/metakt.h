/* xsd2metakt.h                version of 09.01.91 */

char *KeyTab[]=
{

	/*   0*/  "WrongKeyWord"
	/*   1*/, "xsd2meta"
	/*   2*/, "greaterthanTermToken"
	/*   3*/, "floatToken"
	/*   4*/, "equalTermToken"
	/*   5*/, "xmlEndTermToken"
	/*   6*/, "integerToken"
	/*   7*/, "stringToken"
	/*   8*/, "grammar"
	/*   9*/, "identifier"
	/*  10*/, "colonTermToken"
	/*  11*/, "attribute"
	/*  12*/, "attributes"
	/*  13*/, "attributeExtention"
	/*  14*/, "slashdivideTermToken"
	/*  15*/, "quastionmarkTermToken"
	/*  16*/, "lessthanTermToken"
	/*  17*/, "xmlTag"
	/*  18*/, "xmlTags"
	/*  19*/, "xmlTagID"
	/*  20*/, "xmlTagIDExtention"
	/*  21*/, "xmlTagsList"
	/*  22*/, "xmlTagEnd"
	/*  23*/, "xmlToken"
	/*  24*/, "xmlVersion"
	/*  25*/, "xmlVersionAttributes"
	/*  26*/, "termTokenofrule"
	/*  27*/, "termToken"
	/*  27*/, "quotationTermToken"
	/*  28*/, "sharpTermToken"
	/*  29*/, "ampersandTermToken"
	/*  30*/, "apostropheTermToken"
	/*  31*/, "leftparenthesisTermToken"
	/*  32*/, "rightparenthesisTermToken"
	/*  33*/, "starmultiplyTermToken"
	/*  34*/, "plusTermToken"
	/*  35*/, "commaTermToken"
	/*  36*/, "hyphenminusTermToken"
	/*  37*/, "dotpointperiodTermToken"
	/*  38*/, "semicolonTermToken"
	/*  39*/, "underlineTermToken"
	/*  40*/, "verticalbarTermToken"
	/*  41*/, "exclamationmarkTermToken"
	/*  42*/, "dollarTermToken"
	/*  43*/, "percentTermToken"
	/*  44*/, "commercialatTermToken"
	/*  45*/, "leftsquarebracketTermToken"
	/*  46*/, "leftbackslashTermToken"
	/*  47*/, "rightsquarebracketTermToken"
	/*  48*/, "circumflexTermToken"
	/*  49*/, "graveaccentTermToken"
	/*  50*/, "leftbraceTermToken"
	/*  51*/, "rightbraceTermToken"
	/*  52*/, "tildeTermToken"
	/*  53*/, "arrowTermToken"
	/*  54*/, "doublestarexponentiateTermToken"
	/*  55*/, "variableassignmentTermToken"
	/*  56*/, "inequalityTermToken"
	/*  57*/, "greaterthanorequalTermToken"
	/*  58*/, "lessthanorequalsignalassignmentTermToken"
	/*  59*/, "boxTermToken"
	/*  60*/, "defisTermToken"
};

struct tableItemTermToken tableTermToken[LENTABLETERMTOKEN]={
	{KW_QUOTATIONTERMTOKEN,"\""},
	{KW_SHARPTERMTOKEN,"#"},
	{KW_AMPERSANDTERMTOKEN,"&"},
	{KW_APOSTROPHETERMTOKEN,"'"},
	{KW_LEFTPARENTHESISTERMTOKEN,"("},
	{KW_RIGHTPARENTHESISTERMTOKEN,")"},
	{KW_STARMULTIPLYTERMTOKEN,"*"},
	{KW_PLUSTERMTOKEN,"+"},
	{KW_COMMATERMTOKEN,","},
	{KW_HYPHENMINUSTERMTOKEN,"-"},
	{KW_DOTPOINTPERIODTERMTOKEN,"."},
	{KW_SLASHDIVIDETERMTOKEN,"/"},
	{KW_COLONTERMTOKEN,":"},
	{KW_SEMICOLONTERMTOKEN,";"},
	{KW_LESSTHANTERMTOKEN,"<"},
	{KW_EQUALTERMTOKEN,"="},
	{KW_GREATERTHANTERMTOKEN,">"},
	{KW_UNDERLINETERMTOKEN,"_"},
	{KW_VERTICALBARTERMTOKEN,"|"},
	{KW_EXCLAMATIONMARKTERMTOKEN,"!"},
	{KW_DOLLARTERMTOKEN,"$"},
	{KW_PERCENTTERMTOKEN,"%"},
	{KW_QUASTIONMARKTERMTOKEN,"?"},
	{KW_COMMERCIALATTERMTOKEN,"@"},
	{KW_LEFTSQUAREBRACKETTERMTOKEN,"["},
	{KW_LEFTBACKSLASHTERMTOKEN,"\\"},
	{KW_RIGHTSQUAREBRACKETTERMTOKEN,"]"},
	{KW_CIRCUMFLEXTERMTOKEN,"^"},
	{KW_GRAVEACCENTTERMTOKEN,"`"},
	{KW_LEFTBRACETERMTOKEN,"{"},
	{KW_RIGHTBRACETERMTOKEN,"}"},
	{KW_TILDETERMTOKEN,"~"},
	{KW_ARROWTERMTOKEN,"=>"},
	{KW_DOUBLESTAREXPONENTIATETERMTOKEN,"**"},
	{KW_VARIABLEASSIGNMENTTERMTOKEN,":="},
	{KW_INEQUALITYTERMTOKEN,"/="},
	{KW_GREATERTHANOREQUALTERMTOKEN,">="},
	{KW_LESSTHANOREQUALSIGNALASSIGNMENTTERMTOKEN,"<="},
	{KW_BOXTERMTOKEN,"<>"},
	{KW_DEFISTERMTOKEN,"::="},
	{KW_XMLENDTERMTOKEN,"</"}
};
int KeyTabkeyword[1]= {0};

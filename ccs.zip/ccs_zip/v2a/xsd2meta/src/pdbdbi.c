/*  pdbdbi.c            version of 19.06.91 */

/*                      version of 20.06.91 */
/*                      version of 26.06.91 */
/*                      version of 27.06.91 */
/*                      version of 28.06.91 */

/*                      version of 01.07.91 */
/*                      version of 03.07.91 */
/*                      version of 07.07.91 */

/*                      version of 12.07.91 */
/*                      version of 17.07.91 */
/*                      version of 18.07.91 */
/*                      version of 19.07.91 */
/*                      version of 22.07.91 */

/*                      version of 02.08.91 */
/*                      version of 06.08.91 */


/*  pdbgkwr             version of 24.09.91 */

/*  iri. . .            version of 26.11.91 */


/*  pdbcnmcrt,pdbirbuffer version of 21.07.92 */

/*  celclos(1) 		version of 23.07.92 */

/*  cnmunl 		version of 02.10.92 */

/*  SLLAN 		version of 15.03.93 */

/*  SPARCALIGN		version of 23.12.94 */
/*
	sofcnt
		3*idn+lenids
			kwns
				edps
*/

/* 
	project database manipulation interface 
	using lbrdbi,adbdbi,celdbi functions
*/


#include "metaer.h"

#include "metaarts.h"

#include "metakw.h"
#include "metake.h"

#include "pdbts.h"


#define SPARCALIGN 1

/*
#define MAXIRBUF 100000
static ptrType irbuffer[MAXIRBUF];
*/

#define MAXIRPOR (long)(102400)
#define MAXIRBUF (long)(MAXIRPOR*20)
static ptrType *irbuffer= 0;

static int ptrIndex=0;



/* malloc buffer for irp */
int	pdbirbuffer(m)
long	m;
{
  register	int  s;
  register	long l;

  if(m <= 0) l= MAXIRBUF; else l= MAXIRPOR * m;

  if(!(irbuffer= (ptrType*)malloc(l))) {
    sprintf(mes,"pdbirbuffer:no memory for malloc:size=%ld",l);
    pdbmess(mes);
    pdber(PDBNOMEMO);
  }

  return(0);
}


/* macro for memory allocation of internal representation */
/*
  inrType t;
  int     l;
*/
#define setirptr(t,l) \
{char m[64];\
if(((l) + ptrIndex) >= MAXIRBUF){\
sprintf(m,"len=%ld\n",(l));\
pdbmess(m);\
pdber(PDBNOMEMO);\
}\
(t)= irbuffer+ptrIndex;\
ptrIndex= ptrIndex+(l);}


int opnirptr(r,l)
inrType (*r);
int     l;
{
  inrType	t;

  setirptr(t,l);

  if(r) *r= t;

/*d*
  printf("opnirptr: last shift:%ld ptrIndex:%ld, size:%ld\n",
	    (long)(t-irbuffer),ptrIndex,l);
**/

  return(0);
}


int clsirptr(r)
inrType r;
{

  static char mes[64];
  register long l;


  unsigned int ak,an;

  l= ((struct contextType*)r)->cntlen;

/*
  printf("  clsirptr: last shift:%ld ptrIndex:%ld, size:%ld\n",
	    (long)(r-irbuffer),ptrIndex,l);

  setlongedf(&(((struct contextType*)r)->cntbeg),ak,an);  
  printf("  clsirptr: axiom: %s %d\n",KeyTab[ak],an);
*/

  if(ptrIndex != ((long)(r - irbuffer) + l) ) {
    sprintf(mes,"wrong last shift:%ld ptrIndex:%d, size:%d\n",
	    (long)(r-irbuffer),ptrIndex,l);
    pdbmess(mes);
    pdber(PDBDBMFAT);
  }


  ptrIndex= ptrIndex - l;

  if(ptrIndex < 0) {
    sprintf(mes,"negative ptrIndex:%d, size:%d\n",ptrIndex,l);
    pdbmess(mes);
    pdber(PDBDBMFAT);
  }



  return(0);
}


int pdbcnmcrt(n,fs,ff)
long n;		/* axiom       */
int  (*fs)();   /* keep        */ 
int  (*ff)();   /* mod dynamic */
{
  register	int s;
  inrType r;

  long	  d[6];

/*
  pdbdatetime(d);
  printf("crt:%d %d %d\n",d[3],d[4],d[5]);
*/

  if(s= pdbcnmopen(&r,n)) return(s);

/*
  pdbdatetime(d);
  printf("cls:%d %d %d\n",d[3],d[4],d[5]);
*/

  if(s= celclos(1)) return(s);		/* 23.07.92 */

/*
  pdbdatetime(d);
  printf("wrt:%d %d %d\n",d[3],d[4],d[5]);
  printf("   len=%ld\n",lenofir(r));
*/

  if(s= (*ff)((char*)r,lenofir(r))) return(s);

/*
  pdbdatetime(d);
  printf("kep:%d %d %d\n",d[3],d[4],d[5]);
*/

  if(s= (*fs)()) return(s);

/*
  pdbdatetime(d);
  printf("end:%d %d %d\n",d[3],d[4],d[5]);
  printf("\n");
*/

  if(s= clsirptr(r)) return(s);

  return(0);
}


/* open & read current context (cnm) */
int pdbcnmopen(r,n)
inrType		(*r);  
long		n;
{
  register	int wwwc,wwws;
  inrType	wwwt;

  int 	len;
  long	lenidn,lenstn,lenidnn,lenstnn,lenkwnl;
  int	lt,lenids,lensts,lenidss,lenstss,nn,fkwn,ldynd,iit,iif,iid;
/*  static char	buf[MAXIDS]; */

  int ikwn,iedp;
  struct kwnirType *pkwn;
  struct edpirType *pedp;
  enum KeyNum 	pkkn;

  register	int c,s;
  inrType	t;

#if SPARCALIGN
	int	tmpptr;
#endif


  lenidn= 0;
  lenids= 0;
  if(!celnamlas()) {
    if(s= celnamgit(&lenidn,NULLCHAR,NULLCHAR)) return(s);
    lenidn++;

    c= celnamfir();
    while(!c) {
      if(s= celnamsln(&lt)) return(s);

      lenids= lenids + lenofedpchar(lt);

      c= celnamnxt();
    }
  }


#if SPARCALIGN
	tmpptr= SOFCNT + 3*lenidn + lenids;
	if((tmpptr)%2) {
		tmpptr++;
	}
#endif



  for(lenstn= 0,c=celkwnfir(); !c; lenstn++,c=celkwnnxt());
  lensts= 0;

#if SPARCALIGN
	tmpptr= tmpptr + lenstn*SOFKWN;
	if((tmpptr)%2) {
		tmpptr++;
	}
#endif


  if(lenstn > 0) {
    c= celkwnfir();
    while(!c) {
      if(!celedplas()) {
	if(s= celedpgit(&lenkwnl,NULLLONG,NULLINT,NULLLONG,NULLINT)) return(s);
	lenkwnl++;

	lensts= lensts + lenkwnl*SOFEDP;


#if SPARCALIGN
	tmpptr= tmpptr + lenkwnl*SOFEDP;
	if((tmpptr)%2) {
		tmpptr++;
	}
#endif



	c= celedpfir();
	while(!c) {
	  if(s= celedpgit(NULLLONG,NULLLONG,&lt,NULLLONG,&ldynd)) return(s);

	  if(lt) {
/*	    lensts= lensts + lenofedp(lt); */
	    lensts= lensts + lt;

#if SPARCALIGN
		tmpptr= tmpptr + lt;
#endif


	  }

	  if(ldynd) {
/*	    lensts= lensts + lenofedp(ldynd); */
	    lensts= lensts + ldynd;

#if SPARCALIGN
		tmpptr= tmpptr + ldynd;
#endif

	  }

	  c= celedpnxt();
	}
      }

      c= celkwnnxt();
    }
  }


#if SPARCALIGN
  len= tmpptr;
#else
  len=  SOFCNT + 3*lenidn + lenids + lenstn*SOFKWN + lensts ;
#endif


/*
  printf(
	  "len= %d fs= %d lenidn= %d lenids= %d lenstn= %d lensts= %d\n",
	  len, SOFCNT, lenidn, lenids, lenstn, lensts);
*/

/*
  if(!(t= (ptrType*)malloc(len))) pdber(PDBNOMEMO);
*/

/*
  if(len >= MAXIRBUF) {
    fprintf(stderr,"len=%ld\n",len);
    pdber(PDBNOMEMO);
  }
  t= irbuffer;
*/

  setirptr(t,len);

/*
  printf("malloc:%ld len:%d\n",t,len);
*/

  ((struct contextType*)t)->cntlen= len;	/* total size 		*/
  ((struct contextType*)t)->cntcur= 0;		/* current index 	*/

  ((struct contextType*)t)->cntbeg= n;		/* axiom */

  ((struct contextType*)t)->cntnid= lenidn;	/* total number of ident's */
  ((struct contextType*)t)->cntdid= SOFCNT;   	/* begin index  of ident's */
  ((struct contextType*)t)->cntnkw= lenstn;	/* total number of kwn's */
  ((struct contextType*)t)->cntdkw= SOFCNT + 3*lenidn + lenids ;
                                                /* begin index  of kwn's */

#if SPARCALIGN
	if((((struct contextType*)t)->cntdkw)%2) {
		((struct contextType*)t)->cntdkw++;
	}
#endif
 

  if(lenidn > 0) {
    /* sequantial order */
    nn= 0;
    lenidss= SOFCNT + 3*lenidn;
    c= celnamfir();
    while(!c) {
      if(s= celnamgit(&lenidnn,NULLCHAR,(char*)(t+lenidss))) return(s);

      /* check sequantial order */
      if(nn != lenidnn) pdber(PDBDBMFAT);

      if(s= celnamsln(&lt)) return(s);

      t[SOFCNT + nn]= lenidss;

      lenidss= lenidss + lenofedpchar(lt);

      nn++;

      c= celnamnxt();
    }

    /* alphabetic order */
    nn= 0;
    c= celnamnfir();
    while(!c) {
      if(s= celnamgit(&lenidss,NULLCHAR,NULLCHAR)) return(s);

      t[SOFCNT + lenidn + 2*nn]= 	t[SOFCNT + lenidss];
      t[SOFCNT + lenidn + 2*nn+1]= 	lenidss;

      nn++;

      c= celnamnnxt();
    }
  }



  
/******
  lenidss=   SOFCNT + 3*lenidn + lenids + lenstn*SOFKWN ;
*******************/

  lenidss= ((struct contextType*)t)->cntdkw + lenstn*SOFKWN ;

#if SPARCALIGN
  if((lenidss)%2) {
	lenidss++;
  }
#endif



  ikwn= 0;
  if(lenstn > 0) {
    c= celkwnfir();
    while(!c) {
      if(!celedplas()) {
	pkwn= ptrkwn(t,ikwn);

	if(s= celedpgit(&lenkwnl,NULLLONG,NULLINT,NULLLONG,NULLINT)) return(s);
	lenkwnl++;
	
	pkwn->l = lenkwnl;

	if(s= celkwngit(&pkkn)) return(s);
	(pkwn->k) = pkkn;


	pkwn->d = lenidss;
/*
printf("ikwn:%d keynam:%s lenkwnl:%d lenidss:%d\n",
ikwn,KeyTab[pkwn->k],pkwn->l,pkwn->d);
*/

/* pppppppp 
if(pkkn == KW_INTEGERTOKEN) {
printf("ikwn:%d keynam:%s lenkwnl:%d lenidss:%d\n",
ikwn,KeyTab[pkwn->k],pkwn->l,pkwn->d);
}
***********/


	lenidss= lenidss + lenkwnl*SOFEDP;


#if SPARCALIGN
	  if((lenidss)%2) {
		lenidss++;
  	  }
#endif



	iedp= 0;
	c= celedpfir();
	while(!c) {
	  pedp= ptredp(t,pkwn,iedp);
/*
printf("1:iedp=%d pedp=%ld t=%ld\n",iedp,pedp,t);
*/
/* pppppppp 
if(pkkn == KW_INTEGERTOKEN) {
printf("1:iedp=%d pedp=%ld t=%ld\n",iedp,pedp,t);
}
***********/

	  if(s= celedpgit(&lenidnn,NULLLONG,&lt,NULLLONG,&ldynd)) return(s);
	  (pedp->fl) = lt;
	  (pedp->dl) = ldynd;

/*
printf("    iedp:%d lenidnn:%d fl:%d dl:%d d:%d\n",
iedp,lenidnn,pedp->fl,pedp->dl,lenidss);
*/
/* pppppppp 
if(pkkn == KW_INTEGERTOKEN) {
printf("    iedp:%d lenidnn:%d fl:%d dl:%d d:%d\n",
iedp,lenidnn,pedp->fl,pedp->dl,lenidss);
}
************/

	  if(iedp != lenidnn) pdber(PDBDBMFAT);

	  pedp->d = lenidss; 

/*	  iif= lenofedp(pedp->fl); */
	  iif= (pedp->fl);
/*  	  iid= lenofedp(pedp->dl); */
  	  iid= (pedp->dl);


	  if(iif) {
	    if(s= celedpgit(NULLLONG,
		    (long*)(t+lenidss),NULLINT,NULLLONG,NULLINT)) return(s);
/* pppppppp 
if(pkkn == KW_INTEGERTOKEN) {
printf("t+lenidss=%ld\n",*((long*)(t+lenidss)));
}
******/
	  }


	  if(iid) {
	    if(s= celedpgit(NULLLONG,
		    NULLLONG,NULLINT,
		    (long*)(t+lenidss+iif),NULLINT)) return(s);
	  }


	  lenidss= lenidss + iif + iid ;
	  if(lenidss > len) {
	    fprintf(stderr,"lenidss = %d > len = %d\n",lenidss,len);
	    pdber(PDBDBMFAT);
	  }

	  iedp++;
	  c= celedpnxt();
	}
      }

      ikwn++;
      c= celkwnnxt();
    }
  }



  if(r) *r= t;


  return(0);
}







/* print PDB internal representation */
int pdbcnmprint(r)
inrType		r;  
{
  register int ii,i,j,n,y;
  struct contextType *t;
  struct kwnirType *k,*kintegerToken,*kstringToken,*kfloatToken;
  struct edpirType *e,*ee;
  struct ruleType u,uu;
  enum KeyNum kkk;
  unsigned int nnn;

  int fixe,ddyn;


  t= (struct contextType*)r;

  printf("t->cntlen= %d\n",t->cntlen);
  printf("t->cntcur= %d\n",t->cntcur);

  setlongedf(&(((struct contextType*)t)->cntbeg),kkk,nnn);	/* axiom */

  printf("t->cntbeg= %d %s %d\n",kkk,KeyTab[kkk],nnn);

  printf("t->cntnid= %d\n",t->cntnid);
  printf("t->cntdid= %d\n",t->cntdid);
  printf("t->cntnkw= %d\n",t->cntnkw);
  printf("t->cntdkw= %d\n",t->cntdkw);

  printf("identifiers in sequantial order:\n");
  for(i=0; i < (t->cntnid); i++) {
      printf("   num:%d name:%s\n",i,ptrids(r,i));
  }


  printf("identifiers in alphabetic order:\n");
  for(i=0; i < (t->cntnid); i++) {
      printf("   i:%d num:%d name:%s\n",i,ptridnum(r,i),ptridn(r,i));
  }


  setptrkwn(r,KW_INTEGERTOKEN,kintegerToken);
  setptrkwn(r,KW_STRINGTOKEN,kstringToken);
  setptrkwn(r,KW_FLOATTOKEN,kfloatToken);

  printf("key words in sequantial order:\n");
  for(i=0; i < (t->cntnkw); i++) {
    k= ptrkwn(r,i);
    if(k) {
      printf("   i:%d num:%d key :%s tot:%d beg:%d\n",i,
	      k->k,
	      KeyTab[k->k],
	      k->l,
	      k->d
	      );

      for(j= 0; j < (k->l); j++) {
	e= ptredp(r,k,j);	
	if(e) {

/*	  fixe= lenofedp(e->fl) ; */
	  fixe= (e->fl) ;
/*	  ddyn= lenofedp(e->dl) ; */
	  ddyn= (e->dl) ;

	  setptrrule(r,k,e,u);

	  printf("     j:%d fl:%d dl:%d\n",j,e->fl,e->dl);


	  switch(k->k) {
	  case KW_STRINGTOKEN:
	    printf("         \"%s\"\n",(char*)u.f);
	    break;
	  case KW_INTEGERTOKEN:
	    printf("         %ld\n",*((long*)(u.f)));
	    break;
	  case KW_FLOATTOKEN:
/*	    printf("         %g\n",*((float*)(u.f)));*/
	    printf("         %e\n",*((float*)(u.f)));
	    break;
	  case KW_TERMTOKEN:
	    printf("         '%s'\n",ptrids(r,j));
	    break;
	  case KW_TERMTOKENOFRULE:
	    printf("         '%s'\n",ptrids(r,j));
	    break;
	  case KW_IDENTIFIER:
	    printf("         %s\n",ptrids(r,j));
	    break;
	  default:
	    if(u.f) {
	      for(n=0; n < (e->fl); n++) {
/*
  setlongedf(&(u.f[n]),kkk,nnn);
  printf("             fix:%d k:%s n:%d\n",n,KeyTab[kkk],nnn);
*/
		kkk= u.f[n].t;
		nnn= u.f[n].d;
		printf("             fix:%d k:%s n:%d",n,KeyTab[kkk],nnn);

		switch(kkk) {
		case KW_STRINGTOKEN:
		  ee= ptredp(r,kstringToken,nnn);
	  	  setptrrule(r,kstringToken,ee,uu);
		  printf(" :\"%s\"",(char*)uu.f);
		  break;
		case KW_INTEGERTOKEN:
		  ee= ptredp(r,kintegerToken,nnn);
	  	  setptrrule(r,kintegerToken,ee,uu);
		  printf(" :%ld",*((long*)(uu.f)));
		  break;
		case KW_FLOATTOKEN:
		  ee= ptredp(r,kfloatToken,nnn);
	  	  setptrrule(r,kfloatToken,ee,uu);
/*		  printf(" :%g",*((float*)(uu.f)));*/
		  printf(" :%e",*((float*)(uu.f)));
		  break;
		case KW_IDENTIFIER:
		  printf(" :%s",ptrids(r,nnn));
		  break;
		case KW_TERMTOKEN:
		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (nnn == tableTermToken[ii].k)) break;
		  }

		  if(!y) {
		    printf(" :%s",KeyTab[nnn]);
		  }
		  else {
		    printf(" :%s",tableTermToken[ii].t);
		  }

		  break;
		case KW_TERMTOKENOFRULE:
/*
		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (nnn == tableTermToken[ii].k)) break;
		  }

		  if(!y) {
		    printf(" :'%s'",KeyTab[nnn]); 
		    printf(" :'%s'",ptrids(r,nnn));
		  }
		  else {
		    printf(" :'%s'",tableTermToken[ii].t);
		  }
*/


		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (!strcmp(ptrids(r,nnn),
				   KeyTab[tableTermToken[ii].k]))) break;
		  }
		  
		  if(!y) {
		    printf(" :'%s'",ptrids(r,nnn));
		  }
		  else {
		    printf(" :'%s'",tableTermToken[ii].t);
		  }

		  break;
		default:
		  break;
		}

		printf("\n");
	      }
	    }

	    printf("\n");

	    if(u.d) {
	      for(n=0; n < (e->dl); n++) {
/*
  setlongedf(&(u.d[n]),kkk,nnn);
  printf("             dyn:%d k:%s n:%d\n",n,KeyTab[kkk],nnn);
*/
		kkk= u.d[n].t;
		nnn= u.d[n].d;
		printf("             dyn:%d k:%s n:%d",n,KeyTab[kkk],nnn);

		switch(kkk) {
		case KW_STRINGTOKEN:
		  ee= ptredp(r,kstringToken,nnn);
	  	  setptrrule(r,kstringToken,ee,uu);
		  printf(" :\"%s\"",(char*)uu.f);
		  break;
		case KW_INTEGERTOKEN:
		  ee= ptredp(r,kintegerToken,nnn);
	  	  setptrrule(r,kintegerToken,ee,uu);
		  printf(" :%ld",*((long*)(uu.f)));
		  break;
		case KW_IDENTIFIER:
		  printf(" :%s",ptrids(r,nnn));
		  break;
		case KW_TERMTOKEN:
		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (nnn == tableTermToken[ii].k)) break;
		  }

		  if(!y) {
		    printf(" :'%s'",KeyTab[nnn]);
		  }
		  else {
		    printf(" :'%s'",tableTermToken[ii].t);
		  }

		  break;
		case KW_TERMTOKENOFRULE:
/*
		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (nnn == tableTermToken[ii].k)) break;
		  }

		  if(!y) {
		    printf(" :'%s'",KeyTab[nnn]); 
		    printf(" :'%s'",ptrids(r,nnn));
		  }
		  else {
		    printf(" :'%s'",tableTermToken[ii].t);
		  }
*/

		  for(ii= 0; ii < LENTABLETERMTOKEN; ii++) {
		    if(y= (!strcmp(ptrids(r,nnn),
				   KeyTab[tableTermToken[ii].k]))) break;
		  }
		  
		  if(!y) {
		    printf(" :'%s'",ptrids(r,nnn));
		  }
		  else {
		    printf(" :'%s'",tableTermToken[ii].t);
		  }

		  break;
		default:
		  break;
		}

		printf("\n");
	      }
	    }
	  
	    printf("\n");
	    break;
	  }
	}
      }
    }
  }

/*
  setptrkwn(r,KW_STRINGTOKEN,k);
  if(k) {
    for(j= 0; j < (k->l); j++) {
      e= ptredp(r,k,j);	
      if(e) {
	setptrrule(r,k,e,u);
	printf("        string:%s\n",(char*)(u.f));
      }
    }
  }
*/  

  printf("\n");

  return(0);
}

/* free dynamic memory */
int pdbcnmfree(r)
inrType		r;  
{

  if(!r) return(0);

/*
  free(r);
*/

  return(0);
}




/* add long value (v) in long array (f) with (l) items */
int pdbaddint(f,l,v)
long 	f[];
int	l;
long	v;
{
  long	k;
  long	n;
  
  if(!f[0]) {		/* first integer */
    setedflong(f,KW_INTEGERTOKEN,0);
  }

  setlongedf(f,k,n);
  if(k != KW_INTEGERTOKEN) pdber(PDBDBMFAT);

  n++;
  if(n == (l-1)) pdber(PDBDBMFAT);
  f[n] = v;

  return(0);
}



/*                      version of 18.07.91 */

/* write internal representation to file */
int pdbcnmwrite(r,fn)
inrType		r;
char 		*fn;	/* file name */
{
  register int s,i;
  char	mes[256];
  long len;
  FILE *f;
  
  if(!(f= fopen(fn,"w"))) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FINOCR);
  }

  len= ((struct contextType*)r)->cntlen;

  for(i= 0; i < len; i++) {
    if(!fprintf(f,"%ld\n",r[i])) {
      sprintf(mes,"file name:%s",fn);
      pdbmess(mes);
      pdber(FIWRIT);
    }
  }

  if(fclose(f)) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FICLOS);
  }

  return(0);
}



/* read internal representation from file */
int pdbcnmread(r,fn)
inrType		(*r);
char 		*fn;	/* file name */
{
  register int s,i;
  char	mes[256];
  inrType	t;
  long len;
  FILE *f;
  
  if(!(f= fopen(fn,"r"))) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FINOFO);
  }

  if(!(fscanf(f,"%ld",&len))) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FINOFO);
  }

  setirptr(t,len);
  t[0]= len;
  for(i= 1; i < len; i++) {
    if(!fscanf(f,"%ld",t+i)) {
      sprintf(mes,"file name:%s",fn);
      pdbmess(mes);
      pdber(FIREAD);
    }
  }

  if(fclose(f)) {
    sprintf(mes,"file name:%s",fn);
    pdbmess(mes);
    pdber(FICLOS);
  }

  if(r) *r= t;

  return(0);
}









#if VLAN

/* generate(unload) PDB internal representation */
int pdbcnmunl_VVVVV(r,f)
inrType		r;
FILE 		*f;  
{
  register int s;

  if(s= pdbcnmtree(r,(((struct contextType*)r)->cntbeg),f)) return(s);

  return(0);
}


/* recursive tree unloading */
int pdbcnmtree_VVVVV(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);
  if(kkk == KW_IDENTIFIER) {
    fprintf(f,"%s",ptrids(r,nnn));
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }

    if(!y) {
/*      fprintf(f,"%s",ptrids(r,nnn)); */

      fprintf(f,"%s",KeyTab[nnn]);

/*2      fprintf(f,"%s",KeyTab[nnn]);*/
    }
    else {
/*1      fprintf(f,"'%s'",tableTermToken[i].t);*/
      fprintf(f,"%s",tableTermToken[i].t);
    }

    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
/*      if(y= (nnn == tableTermToken[i].k)) break; */
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f,"'%s'",ptrids(r,nnn));
/*1      fprintf(f,"'%s'",KeyTab[nnn]);*/
/*2      fprintf(f,"%s",KeyTab[nnn]);*/
    }
    else {
/*1      fprintf(f,"'%s'",tableTermToken[i].t);*/
      fprintf(f,"'%s'",tableTermToken[i].t);
    }

    return(0);
  }


/*  if(!kkk) kkk= KW_TERMTOKEN; */
  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f,"\"%s\"",(char*)u.f);
	break;
      case KW_INTEGERTOKEN:
	fprintf(f,"%ld",*((long*)(u.f))); 
	break;
      case KW_FLOATTOKEN:
/*	fprintf(f,"%g",*((float*)(u.f))); */
	fprintf(f,"%e",*((float*)(u.f))); 
	break;
      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	    fprintf(f," ");
	  }

	  fprintf(f,"\n");
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	    fprintf(f," "); 
	  }

	  fprintf(f,"\n"); 
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}

#endif






/* 24.08.93 */
#if VLAN

static int 	Level;
static int 	StateLine;
static int 	StateBlun;
static int 	Lasty;
static int 	Lastnnn;
static int 	Lasti;
static enum 	KeyNum 	LastKey;

/* generate(unload) PDB internal representation */
int pdbcnmunl(r,f)
inrType		r;
FILE 		*f;  
{
  register int s;


  Level= 0;
  StateLine= 0;
  StateBlun= 0;
  LastKey= 0;
  Lasty= 0;
  Lastnnn= 0;
  Lasti= 0;

  if(s= pdbcnmtree(r,(((struct contextType*)r)->cntbeg),f)) return(s);

  if(StateLine) fprintf(f,"\n"); 

  return(0);
}



#if MMETA
/* for metacompiler */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    fprintf(f," %s",ptrids(r,nnn));

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {
      fprintf(f," %s",KeyTab[nnn]); 
    }
    else {
      fprintf(f," %s",tableTermToken[i].t);

      if(!strcmp(tableTermToken[i].t,")")) Level--;
      if(!strcmp(tableTermToken[i].t,"(")) Level++;

      if(!strcmp(tableTermToken[i].t,")") || 
	 !strcmp(tableTermToken[i].t,"]") || 
	 !strcmp(tableTermToken[i].t,"|") || 
	 !strcmp(tableTermToken[i].t,"::=") || 
	 !strcmp(tableTermToken[i].t,"}")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f,"\t");
      }   
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f," '%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f," '%s'",tableTermToken[i].t);
    }

    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f," \"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	fprintf(f," %ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      case KW_FLOATTOKEN:

/*	fprintf(f," %g",*((float*)(u.f))); */
	fprintf(f," %e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}



#else 

/* for designed compiler    */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    if(LastKey == KW_STRINGTOKEN) {
      fprintf(f,"\n");
      for(j= 0; j < Level; j++) fprintf(f," ");
    }
    else if((LastKey == KW_IDENTIFIER) || 
	    (LastKey == KW_INTEGERTOKEN) || 
	    (LastKey == KW_FLOATTOKEN) || 
	    ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
      fprintf(f," ");
    }

    fprintf(f,"%s",ptrids(r,nnn)); /* 02.10.92 */

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {

      if(LastKey == KW_STRINGTOKEN) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }
      else if((LastKey == KW_IDENTIFIER) || 
	      (LastKey == KW_INTEGERTOKEN) || 
	      (LastKey == KW_FLOATTOKEN) || 
	      ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	fprintf(f," ");
      }

      fprintf(f,"%s",KeyTab[nnn]);  /* 02.10.92 */
    }
    else {

/*
      if((LastKey == KW_TERMTOKEN) && (!Lasty)) {
	fprintf(f," ");
      }
*/

      fprintf(f,"%s",tableTermToken[i].t);

      /* 24.08.93 */
      if(!strcmp(tableTermToken[i].t,"}")) Level--;
      if(!strcmp(tableTermToken[i].t,"{")) Level++;

      if(!strcmp(tableTermToken[i].t,"}") || 
	 !strcmp(tableTermToken[i].t,";") ||
	 !strcmp(tableTermToken[i].t,",")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }   
      /* 02.10.92 */
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f,"'%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f,"'%s'",tableTermToken[i].t);
    }

/*
    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
*/
    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f,"\"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

	fprintf(f,"%ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;
      case KW_FLOATTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

/*	fprintf(f,"%g",*((float*)(u.f)));  */
	fprintf(f,"%e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}

#endif


#endif

/* 24.08.93 */







/* 02.10.92 */
#if MLAN

static int 	Level;
static int 	StateLine;
static int 	StateBlun;
static int 	Lasty;
static int 	Lastnnn;
static int 	Lasti;
static enum 	KeyNum 	LastKey;

/* generate(unload) PDB internal representation */
int pdbcnmunl(r,f)
inrType		r;
FILE 		*f;  
{
  register int s;


  Level= 0;
  StateLine= 0;
  StateBlun= 0;
  LastKey= 0;
  Lasty= 0;
  Lastnnn= 0;
  Lasti= 0;

  if(s= pdbcnmtree(r,(((struct contextType*)r)->cntbeg),f)) return(s);

  if(StateLine) fprintf(f,"\n"); 

  return(0);
}



#if MMETA
/* for metacompiler */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    fprintf(f," %s",ptrids(r,nnn));

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {
      fprintf(f," %s",KeyTab[nnn]); 
    }
    else {
      fprintf(f," %s",tableTermToken[i].t);

      if(!strcmp(tableTermToken[i].t,")")) Level--;
      if(!strcmp(tableTermToken[i].t,"(")) Level++;

      if(!strcmp(tableTermToken[i].t,")") || 
	 !strcmp(tableTermToken[i].t,"]") || 
	 !strcmp(tableTermToken[i].t,"|") || 
	 !strcmp(tableTermToken[i].t,"::=") || 
	 !strcmp(tableTermToken[i].t,"}")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f,"\t");
      }   
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f," '%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f," '%s'",tableTermToken[i].t);
    }

    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f," \"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	fprintf(f," %ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      case KW_FLOATTOKEN:

/*	fprintf(f," %g",*((float*)(u.f))); */
	fprintf(f," %e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}



#else 

/* for designed compiler    */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    if(LastKey == KW_STRINGTOKEN) {
      fprintf(f,"\n");
      for(j= 0; j < Level; j++) fprintf(f," ");
    }
    else if((LastKey == KW_IDENTIFIER) || 
	    (LastKey == KW_INTEGERTOKEN) || 
	    (LastKey == KW_FLOATTOKEN) || 
	    ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
      fprintf(f," ");
    }

    fprintf(f,"%s",ptrids(r,nnn)); /* 02.10.92 */

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {

      if(LastKey == KW_STRINGTOKEN) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }
      else if((LastKey == KW_IDENTIFIER) || 
	      (LastKey == KW_INTEGERTOKEN) || 
	      (LastKey == KW_FLOATTOKEN) || 
	      ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	fprintf(f," ");
      }

      fprintf(f,"%s",KeyTab[nnn]);  /* 02.10.92 */
    }
    else {

/*
      if((LastKey == KW_TERMTOKEN) && (!Lasty)) {
	fprintf(f," ");
      }
*/

      fprintf(f,"%s",tableTermToken[i].t);

      /* 02.10.92 */
      if(!strcmp(tableTermToken[i].t,"}")) Level--;
      if(!strcmp(tableTermToken[i].t,"{")) Level++;

      if(!strcmp(tableTermToken[i].t,"}") || 
	 !strcmp(tableTermToken[i].t,";")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }   
      /* 02.10.92 */
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f,"'%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f,"'%s'",tableTermToken[i].t);
    }

/*
    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
*/
    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f,"\"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

	fprintf(f,"%ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;
      case KW_FLOATTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

/*	fprintf(f,"%g",*((float*)(u.f))); */
	fprintf(f,"%e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}

#endif


#endif

/* 02.10.92 */






/* 15.03.93 */

#if SLLAN

static int 	Level;
static int 	StateLine;
static int 	StateBlun;
static int 	Lasty;
static int 	Lastnnn;
static int 	Lasti;
static enum 	KeyNum 	LastKey;

/* generate(unload) PDB internal representation */
int pdbcnmunl(r,f)
inrType		r;
FILE 		*f;  
{
  register int s;


  Level= 0;
  StateLine= 0;
  StateBlun= 0;
  LastKey= 0;
  Lasty= 0;
  Lastnnn= 0;
  Lasti= 0;

  if(s= pdbcnmtree(r,(((struct contextType*)r)->cntbeg),f)) return(s);

  if(StateLine) fprintf(f,"\n"); 

  return(0);
}



#if MMETA
/* for metacompiler */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    fprintf(f," %s",ptrids(r,nnn));

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {
      fprintf(f," %s",KeyTab[nnn]); 
    }
    else {
      fprintf(f," %s",tableTermToken[i].t);

      if(!strcmp(tableTermToken[i].t,")")) Level--;
      if(!strcmp(tableTermToken[i].t,"(")) Level++;

      if(!strcmp(tableTermToken[i].t,")") || 
	 !strcmp(tableTermToken[i].t,"]") || 
	 !strcmp(tableTermToken[i].t,"|") || 
	 !strcmp(tableTermToken[i].t,"::=") || 
	 !strcmp(tableTermToken[i].t,"}")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f,"\t");
      }   
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f," '%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f," '%s'",tableTermToken[i].t);
    }

    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f," \"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	fprintf(f," %ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      case KW_FLOATTOKEN:

/*	fprintf(f," %g",*((float*)(u.f))); */
	fprintf(f," %e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}



#else 

/* for designed compiler    */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {

    if(LastKey == KW_STRINGTOKEN) {
      fprintf(f,"\n");
      for(j= 0; j < Level; j++) fprintf(f," ");
    }
    else if((LastKey == KW_IDENTIFIER) || 
	    (LastKey == KW_INTEGERTOKEN) || 
	    (LastKey == KW_FLOATTOKEN) || 
	    ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
      fprintf(f," ");
    }

    fprintf(f,"%s",ptrids(r,nnn)); /* 02.10.92 */

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {

      if(LastKey == KW_STRINGTOKEN) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }
      else if((LastKey == KW_IDENTIFIER) || 
	      (LastKey == KW_INTEGERTOKEN) || 
	      (LastKey == KW_FLOATTOKEN) || 
	      ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	fprintf(f," ");
      }

      fprintf(f,"%s",KeyTab[nnn]);  /* 02.10.92 */
    }
    else {

/*
      if((LastKey == KW_TERMTOKEN) && (!Lasty)) {
	fprintf(f," ");
      }
*/

      fprintf(f,"%s",tableTermToken[i].t);

      /* 02.10.92 */
      if(!strcmp(tableTermToken[i].t,"}")) Level--;
      if(!strcmp(tableTermToken[i].t,"{")) Level++;

      if(!strcmp(tableTermToken[i].t,"}") || 
	 !strcmp(tableTermToken[i].t,",") ||	/* 15.03.93 */
	 !strcmp(tableTermToken[i].t,";")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }   
      /* 02.10.92 */
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f,"'%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f,"'%s'",tableTermToken[i].t);
    }

/*
    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
*/
    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f,"\"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

	fprintf(f,"%ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;
      case KW_FLOATTOKEN:

	if(LastKey == KW_STRINGTOKEN) {
	  fprintf(f,"\n");
	  for(j= 0; j < Level; j++) fprintf(f," ");
	}
	else if((LastKey == KW_IDENTIFIER) || 
		(LastKey == KW_INTEGERTOKEN) || 
		(LastKey == KW_FLOATTOKEN) || 
		((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	  fprintf(f," ");
	}

/*	fprintf(f,"%g",*((float*)(u.f))); */
	fprintf(f,"%e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}

#endif


#endif

/* 15.03.93 */




/* 2010.06.02 */
#if XMLLAN

static int 	Level;
static int 	StateLine;
static int 	StateBlun;
static int 	Lasty;
static int 	Lastnnn;
static int 	Lasti;
static enum 	KeyNum 	LastKey;

/* generate(unload) PDB internal representation */
int pdbcnmunl(r,f)
inrType		r;
FILE 		*f;  
{
  register int s;


  Level= 0;
  StateLine= 0;
  StateBlun= 0;
  LastKey= 0;
  Lasty= 0;
  Lastnnn= 0;
  Lasti= 0;

  if(s= pdbcnmtree(r,(((struct contextType*)r)->cntbeg),f)) return(s);

  if(StateLine) fprintf(f,"\n"); 

  return(0);
}



/*#if MMETA*/
#if 0
/* for metacompiler */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;
  
  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);

  StateLine= 1;

  if(kkk == KW_IDENTIFIER) {
	  
    fprintf(f," %s",ptrids(r,nnn));

    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {
      fprintf(f," %s",KeyTab[nnn]); 
    }
    else {
      fprintf(f," %s",tableTermToken[i].t);

      if(!strcmp(tableTermToken[i].t,")")) Level--;
      if(!strcmp(tableTermToken[i].t,"(")) Level++;

      if(!strcmp(tableTermToken[i].t,")") || 
	 !strcmp(tableTermToken[i].t,"]") || 
	 !strcmp(tableTermToken[i].t,"|") || 
	 !strcmp(tableTermToken[i].t,"::=") || 
	 !strcmp(tableTermToken[i].t,"}")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f,"\t");
      }   
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f," '%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f," '%s'",tableTermToken[i].t);
    }

    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
	fprintf(f," \"%s\"",(char*)u.f);
	LastKey= kkk;
	break;
      case KW_INTEGERTOKEN:

	fprintf(f," %ld",*((long*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      case KW_FLOATTOKEN:

/*	fprintf(f," %g",*((float*)(u.f))); */
	fprintf(f," %e",*((float*)(u.f)));  /* 02.10.92 */
	LastKey= kkk;
	break;

      default:
	if(u.f) {
	  for(i= 0; i < (e->fl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
	  }
	}

	if(u.d) {
	  for(i= 0; i < (e->dl); i++){
	    if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
	  }
	}

	break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}



#else 

/* XMLLAN */
/* for designed compiler    */
/* recursive tree unloading */
int pdbcnmtree(r,rule,f)
inrType		r;
long		rule;
FILE 		*f;  
{
  register 	int s,i,j,y;
  struct kwnirType 	*k;
  struct edpirType 	*e;
  struct ruleType 	u;
  enum KeyNum 	kkk;
  unsigned int 	nnn;
  long		rrr;

  static int StringXmlTokenMode = 0;
  
  /*888  fprintf(stdout,"pdbcnmtree:0:identifier\n"); */
  
  /*777   fprintf(f,"pdbcnmtree:0:r:%d\n", rule); */
  
  if(!rule) return(0);

  rrr= rule;
  setlongedf(&rrr,kkk,nnn);
  
  /*777*  fprintf(f,"pdbcnmtree:0:k:%d n:%d\n", kkk, nnn); */
  
  StateLine= 1;
  
  
  if(kkk == KW_XMLTOKEN) {
    StringXmlTokenMode = 1;
  }
 
  
  if(kkk == KW_IDENTIFIER) {
	
	/*888  fprintf(stdout,"pdbcnmtree:1:identifier\n"); */
    if(LastKey == KW_STRINGTOKEN) {
      fprintf(f,"\n");
      for(j= 0; j < Level; j++) fprintf(f," ");
    }
    else if((LastKey == KW_IDENTIFIER) || 
	    (LastKey == KW_INTEGERTOKEN) || 
	    (LastKey == KW_FLOATTOKEN) || 
	    ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
      fprintf(f," ");
    }

    fprintf(f,"%s",ptrids(r,nnn)); /* 02.10.92 */
    
    /*888 fprintf(stdout,"pdbcnmtree:1:identifier '%s'\n", ptrids(r,nnn)); */
    
    LastKey= kkk;
    return(0);
  }

  if(kkk == KW_TERMTOKEN) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (nnn == tableTermToken[i].k)) break;
    }


    if(!y) {

      if(LastKey == KW_STRINGTOKEN) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }
      else if((LastKey == KW_IDENTIFIER) || 
	      (LastKey == KW_INTEGERTOKEN) || 
	      (LastKey == KW_FLOATTOKEN) || 
	      ((LastKey == KW_TERMTOKEN) && (!Lasty))) {
	fprintf(f," ");
      }

      fprintf(f,"%s",KeyTab[nnn]);  /* 02.10.92 */
    }
    else {

/*
      if((LastKey == KW_TERMTOKEN) && (!Lasty)) {
	fprintf(f," ");
      }
*/

      fprintf(f,"%s",tableTermToken[i].t);

      /* 24.08.93 */
      /*
      if(!strcmp(tableTermToken[i].t,"}")) Level--;
      if(!strcmp(tableTermToken[i].t,"{")) Level++;
      */
      /* 2010.06.02 :::: */
      if(!strcmp(tableTermToken[i].t,"</")) Level--;
      if(!strcmp(tableTermToken[i].t,"/")) Level--;
      if(!strcmp(tableTermToken[i].t,"<")) Level++;
      /* 2010.06.02 .... */

      if(!strcmp(tableTermToken[i].t,"}") || 
	 !strcmp(tableTermToken[i].t,";") ||
	 /* 2010.06.02 :::: */
	 !strcmp(tableTermToken[i].t,">") ||
	 /* 2010.06.02 .... */
	 !strcmp(tableTermToken[i].t,",")) {
	fprintf(f,"\n");
	for(j= 0; j < Level; j++) fprintf(f," ");
      }   
      /* 02.10.92 */
    }

    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
    return(0);
  }


  if(kkk == KW_TERMTOKENOFRULE) {
    for(i= 0; i < LENTABLETERMTOKEN; i++) {
      if(y= (!strcmp(ptrids(r,nnn),KeyTab[tableTermToken[i].k]))) break;
    }

    if(!y) {
      fprintf(f,"'%s'",ptrids(r,nnn));
    }
    else {
      fprintf(f,"'%s'",tableTermToken[i].t);
    }

/*
    LastKey= kkk;
    Lasty= y;
    Lasti= i;
    Lastnnn= nnn;
*/
    return(0);
  }


  setptrkwn(r,kkk,k);
  if(k) {
    e= ptredp(r,k,nnn);
    if(e) {
      setptrrule(r,k,e,u);
      switch(kkk) {
      case KW_STRINGTOKEN:
        
		/*fprintf(f,"\"%s\"",(char*)u.f);*/
		if (StringXmlTokenMode) {
			fprintf(f,"%s",(char*)u.f);
			StringXmlTokenMode = 0;
		} else {
			fprintf(f,"\"%s\"",(char*)u.f);
		}
		LastKey= kkk;
        
		break;
	  case KW_INTEGERTOKEN:
	
		if(LastKey == KW_STRINGTOKEN) {
		  fprintf(f,"\n");
		  for(j= 0; j < Level; j++) fprintf(f," ");
		}
		else if((LastKey == KW_IDENTIFIER) || 
			(LastKey == KW_INTEGERTOKEN) || 
			(LastKey == KW_FLOATTOKEN) || 
			((LastKey == KW_TERMTOKEN) && (!Lasty))) {
		  fprintf(f," ");
		}
	
		fprintf(f,"%ld",*((long*)(u.f)));  /* 02.10.92 */
		LastKey= kkk;
		break;
      case KW_FLOATTOKEN:
	
		if(LastKey == KW_STRINGTOKEN) {
		  fprintf(f,"\n");
		  for(j= 0; j < Level; j++) fprintf(f," ");
		}
		else if((LastKey == KW_IDENTIFIER) || 
			(LastKey == KW_INTEGERTOKEN) || 
			(LastKey == KW_FLOATTOKEN) || 
			((LastKey == KW_TERMTOKEN) && (!Lasty))) {
		  fprintf(f," ");
		}
	
	/*	fprintf(f,"%g",*((float*)(u.f)));  */
		fprintf(f,"%e",*((float*)(u.f)));  /* 02.10.92 */
		LastKey= kkk;
	  break;

      default:
		if(u.f) {
		  for(i= 0; i < (e->fl); i++){
			if(s= pdbcnmtree(r,(*(long*)(&u.f[i])),f)) return(s);
		  }
		}
	
		if(u.d) {
		  for(i= 0; i < (e->dl); i++){
			if(s= pdbcnmtree(r,(*(long*)(&u.d[i])),f)) return(s);
		  }
		}
	
		break;
      }
    }
  }
  else {
    /* external definitions */
    fprintf(f,"(UserData ExternalDefinition (%s %d))\n",KeyTab[kkk],nnn);
  }

  return(0);
}

#endif


#endif

/* 2010.06.02 */



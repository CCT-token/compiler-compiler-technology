/* metaar.c              version of 16.07.91  */
/*                       version of 24.07.91  */

/*                       version of 02.08.91  */
/*                       version of 16.08.91  */

#include "metaer.h"
#include "metalc.h"
#include "metale.h"
#include "metakw.h"
#include "metake.h"
#include "metaarts.h"

#include "pdbts.h"
#include "metaacts.h"

int	atoi();

static char SourceFileName_[MAXFN_SIZE];

void SourceFileNameSet(char* fn)
{
	strcpy(SourceFileName_, fn);
}

char* SourceFileNameGet()
{
	return(SourceFileName_);
}

main(argc,argv)
int argc;
char *argv[];
{
  register	int i;

  enum metaarcom com;   /* command 			*/
  char *f;		/* object pointer 		*/
  char *c,*a;		/* command character 		*/
  char *l;		/* output file name pointer 	*/

  long	bufsiz=0;	/* buffer size for inr - default*/
  int	lexdeb=0;

  int   yes= 0;
/*
  l= 0;
  if(argc <= 1) com= C_HELP;
  else
    {
      if(argc == 2)
	{
	  c= argv[1];

	  if(*c != '/')
	    {
	      com= C_STORE;
	      f= argv[1];
	    }
	  else
	    {
	      f= 0;
	      c++;

	      if((*c == 'l') || (*c == 'L')) 
		{
		  com= C_LIST;
		  if(c= strrchr(argv[1],'=')) l= c+1;
		}
	      else if((*c == 'u') || (*c == 'U')) 
		{
		  com= C_UNLOAD;
		  if(c= strrchr(argv[1],'=')) l= c+1;
		}
	      else if((*c == 'g') || (*c == 'G')) 
		{
		  com= C_GENER;
		  if(c= strrchr(argv[1],'=')) l= c+1;
		}
	      else if((*c == 'h') || (*c == 'H')) com= C_HELP;
	      else if((*c == 'e') || (*c == 'E')) com= C_ERASE;
	      else
		{
		  fprintf(stderr,"***ERROR*** no object(s) for:%s\n",
			  argv[1]);
		  com= C_HELP;
		}
	    }
	}
      else
	{
	  f= argv[2];
	  c= argv[1];
	  c++;

	  if((*c == 's') || (*c == 'S')) com= C_STORE;
	  else if((*c == 'm') || (*c == 'M')) com= C_MODIFY;
	  else if((*c == 'l') || (*c == 'L')) 
	    {
	      com= C_LIST;
	      if(c= strrchr(argv[1],'=')) l= c+1;
	    }
	  else if((*c == 'u') || (*c == 'U')) 
	    {
	      com= C_UNLOAD;
	      if(c= strrchr(argv[1],'=')) l= c+1;
	    }
	  else if((*c == 'g') || (*c == 'G')) 
	    {
	      com= C_GENER;
	      if(c= strrchr(argv[1],'=')) l= c+1;
	    }
	  else if((*c == 'e') || (*c == 'E')) com= C_ERASE;
	  else if((*c == 'h') || (*c == 'H')) com= C_HELP;
	  else
	    {
	      fprintf(stderr,"***ERROR*** wrong command:%s\n",
		      argv[1]);
	      com= C_HELP;
	    }
	}
    }
*/


  l= NULLCHAR;
  f= NULLCHAR;
  com= C_HELP;

  for(i= 1; i < argc; i++) {
    c= argv[i];
    if(*c == '-') {

      c++;

      for(;;) {
	switch(*c) {
	case 'b':
	case 'B':
	  c++;
	  break;
	case 'd':
	case 'D':
	  c++;
	  lexdeb= 1;
	  break;
	case '=':
	  c++;
	  bufsiz= atoi(c);
	  c= NULLCHAR;
	  break;
	default:break;
	}

	if(!(*c)) break;
      }
    }
    else if(*c == '/') {

      yes= 1;
      c++;


      if((*c == 's') || (*c == 'S')) com= C_STORE;
      else if((*c == 'm') || (*c == 'M')) com= C_MODIFY;
      else if((*c == 'l') || (*c == 'L')) {
	com= C_LIST;
	if(c= strrchr(argv[1],'=')) l= c+1;
      }
      else if((*c == 'u') || (*c == 'U')) {
	com= C_UNLOAD;
	if(c= strrchr(argv[1],'=')) l= c+1;
      }
      else if((*c == 'g') || (*c == 'G')) {
	com= C_GENER;
	if(c= strrchr(argv[1],'=')) l= c+1;
      }
      else if((*c == 'h') || (*c == 'H')) com= C_HELP;
      else if((*c == 'e') || (*c == 'E')) com= C_ERASE;
      else {
	fprintf(stderr,"***ERROR*** wrong command:%s\n",argv[i]);
	com= C_HELP;
      }
    }
    else {
      f= c;
      if(!yes) com= C_STORE; 
      break;
    }
  }
  
  fprintf(stdout, "Compiling:%d:'%s' '%s'\n"
    ,com, argv[1]?argv[1]:"", f?f:"");
  
  metalexdeb(lexdeb);
  if(pdbirbuffer(bufsiz)) return;
  metacom(com,f,l);
}


metacom(com,f,l)
enum metaarcom com;
char *f;
char *l;
{
  register int s;

  METAOPENDB();

  switch(com)
    {
    case C_STORE:  s= metastore(f);  break;
    case C_MODIFY: s= metamodify(f); break;
    case C_LIST:   s= metalist(f,l);   break;
    case C_UNLOAD: s= metaunload(f,l); break;
    case C_GENER:  s= metagener(f,l); break; 
    case C_ERASE:  s= metaerase(f);  break;
    case C_HELP:   s= metahelp();   break;
    default:break;
    }

  METACLOSDB();

  return(s);
}

/* print help file */
metahelp()
{
  static char *heltab[]=
    {
      "metaar command syntax:",
      "",
      "        metaar [modes] [keys] file",
      "",
      "keys may be:                        modes may be:",
      "        /store                          -[b][d][=integer]",
      "        /buffer=integer",
      "        /list[=filename]",
      "        /unload[=filename]",
      "        /erase",
      "        /modify",
      "        /help",
      "",
      "file may be:",
      "        filename[/filekey]",
      "        *.extantion",
      "        *.*",
      "",
      "filekey may be:",
      "        list",
      "        nolist",
      ""
      };
#define HTLEN (sizeof(heltab)/sizeof(char*))
  register int i;

  for(i=0;i<HTLEN;i++)
    {
      fprintf(stderr,"%s\n",heltab[i]);
    }

  return(0);
}

fflext(f,fn,ll)
char *f;
char *fn;
char *ll;
{
  char *c;

  if((strlen(f)+1) >= MAXFN) *(f+MAXFN) = '\0'; /* ? */
  strcpy(fn,f);
  if(!(c= strrchr(fn,'.'))) strcat(fn,METAEXTSOU);


  if(ll != 0)
    {
      strcpy(ll,f);
      if(c= strrchr(ll,'.')) *c= '\0';
      strcat(ll,METAEXTLIS);
    }

  return(0);
}
	
/* store object to database */
metastore(f)
char *f;
{
   METASTOREDB(f);
}


/* modify object in database */
metamodify(f)
char *f;
{
  METAMODIFYDB(f);
}


/* erase object(s) from database */
metaerase(f)
char *f;
{
  METAERASEDB(f);
}



/* unload  object(s) database representation from database */
metaunload(f,l)
char *f;
char *l;
{
  METAUNLOAD(f,l);
}


/* generate source representation from database representation */
metagener(f,l)
char *f;
char *l;
{
  METAGENER(f,l);
}


/* print object list */
metalist(f,l)
char *f;
char *l;
{
  METALISTDB(f,l);
}










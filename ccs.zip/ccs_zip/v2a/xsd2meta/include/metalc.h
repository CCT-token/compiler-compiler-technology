/* metalc.h            version of 08.01.91 */
/*                     version of 22.07.91 */
/*                     version of 26.07.91 */

/*  vhdl lexical level version of 19.11.91 */

/*  VLAN, MLAN         version of 23.09.91 */

/*  SLLAN	       version of 15.03.93 */

/*  isintegerToken     version of 16.08.93 */

/* sic! */
/* XMLLAN 		version of 2010.05.31 */

/* constants & macros */

/* #define INLINEL 256 */
#define INLINEL 512*1024

#define MAXILEN 11

#define LENID	256

/* #define LENSTR  1024 */
#define LENSTR  512*1024

#define MAXERC	124	/* max value of error counter */
#define MAXERN	EREND	/* max value of total errors  */

/* lexical macros */

#define 	iseof() 	(Ch == EOF)
#define		issign()	((Ch == '+') || (Ch == '-'))
#define		isquota()	(Ch == '"')
#define		isstringToken()	isquota()
#define		issquota()	(Ch == '\'')
#define		istermToken()	issquota()
#define         isdig()         (issign() || isdigit(Ch))
/*#define		isintegerToken()	isdig()*/
/*#define		isintegerToken()	isdigit(Ch)*/

#if MLAN || VLAN || XMLLAN
#define		isintegerToken()	\
(isdigit(Ch) || ((Ch == '.') && (isdigit(Line[Npos+1]))))
#else
#define		isintegerToken()	isdigit(Ch)
#endif

#define         isamper()       (Ch == '&')



#define         flushbl()       while(Ch == ' ') getchr()
#define         flush()	\
while (!(isrightparenthesisTermToken() || iseof())) getchr()

#define         flquota()       if(isquota()){getchr();flushbl();}
#define         flsquota()      if(issquota()){getchr();flushbl();}
#define         flamper()       if(isamper()){getchr();flushbl();}



#define		errexit() 	if(Erflag) return
#define		ergexit() 	if(Ergl) return
#define		edber(s) 	return(edberr(s))
#define		edbskip()	if(Erflag){\
					Erflag= 0;\
				}



/************************* old !!! 
#define         iscolonTermToken()      (Ch == ':')
#define         isdefisTermToken()      (Ch == ':')
#define         isvbarTermToken()       (Ch == '|')
#define         isequalTermToken()      (Ch == '=')
#define		isleftTermToken()	(Ch == '(')
#define		isrighTermToken()	(Ch == ')')
#define		isrleftTermToken()	(Ch == '[')
#define		isrrighTermToken()	(Ch == ']')
#define		isaleftTermToken()	(Ch == '<')
#define		isarighTermToken()	(Ch == '>')
#define		isfleftTermToken()	(Ch == '{')
#define		isfrighTermToken()	(Ch == '}')

#define         flleftTermToken()        \
if(isleftTermToken()){getchr();flushbl();}
#define         flrighTermToken()        \
if(isrighTermToken()){getchr();flushbl();}
#define         flcolonTermToken()       \
if(iscolonTermToken()){getchr();flushbl();}
#define         flvbarTermToken()        \
if(isvbarTermToken()){getchr();flushbl();}
#define         flequalTermToken()       \
if(isequalTermToken()){getchr();flushbl();}
#define         flrleftTermToken()       \
if(isrleftTermToken()){getchr();flushbl();}
#define         flrrighTermToken()       \
if(isrrighTermToken()){getchr();flushbl();}
#define         flaleftTermToken()       \
if(isaleftTermToken()){getchr();flushbl();}
#define         flarighTermToken()       \
if(isarighTermToken()){getchr();flushbl();}
#define         flfleftTermToken()      \
if(isfleftTermToken()){getchr();flushbl();}
#define         flfrighTermToken()      \
if(isfrighTermToken()){getchr();flushbl();}

#define         fldefisTermToken() 	\
flcolonTermToken();flcolonTermToken();flequalTermToken()
*****************************************************************/



#if VLAN || XMLLAN
/* 19.11.91 */
/* is - . . . */

#define    isquotationTermToken() 		(Ch == '"')

#define    issharpTermToken() 			(Ch == '#')

#define    isampersandTermToken() 		(Ch == '&')

#define    isapostropheTermToken() 		issquota()

#define    isleftparenthesisTermToken() 	(Ch == '(')

#define    isrightparenthesisTermToken() 	(Ch == ')')

#define    isstarmultiplyTermToken() 		(Ch == '*')

#define    isplusTermToken() 			(Ch == '+')

#define    iscommaTermToken() 			(Ch == ',')

#define    ishyphenminusTermToken() 		(Ch == '-')

#define    isdotpointperiodTermToken() 		(Ch == '.')

#define    isslashdivideTermToken() 		(Ch == '/')

#define    iscolonTermToken() 			(Ch == ':')

#define    issemicolonTermToken() 		(Ch == ';')

#define    islessthanTermToken() 		(Ch == '<')

#define    isequalTermToken() 			(Ch == '=')

#define    isgreaterthanTermToken() 		(Ch == '>')

#define    isunderlineTermToken() 		(Ch == '_')

#define    isverticalbarTermToken() 		(Ch == '|')

#define    isexclamationmarkTermToken() 	(Ch == '!')

#define    isdollarTermToken() 			(Ch == '$')

#define    ispercentTermToken() 		(Ch == '%')

#define    isquastionmarkTermToken() 		(Ch == '?')

#define    iscommercialatTermToken() 		(Ch == '@')

#define    isleftsquarebracketTermToken() 	(Ch == '[')

#define    isleftbackslashTermToken() 		(Ch == '\\')

#define    isrightsquarebracketTermToken() 	(Ch == ']')

#define    iscircumflexTermToken() 		(Ch == '^')

#define    isgraveaccentTermToken() 		(Ch == '`')

#define    isleftbraceTermToken() 		(Ch == '{')

#define    isrightbraceTermToken() 		(Ch == '}')

#define    istildeTermToken() 			(Ch == '~')


#define    isarrowTermToken()	\
	((Ch == '=') && (Line[Npos+1] == '>'))

#define    isdoublestarexponentiateTermToken() \
	((Ch == '*') && (Line[Npos+1] == '*'))

#define    isvariableassignmentTermToken()	\
	((Ch == ':') && (Line[Npos+1] == '='))

#define    isinequalityTermToken()	\
	((Ch == '/') && (Line[Npos+1] == '='))

#define    isgreaterthanorequalTermToken()	\
	((Ch == '>') && (Line[Npos+1] == '='))

#define    islessthanorequalsignalassignmentTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '='))

#define    isboxTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '>'))

#define    isdefisTermToken()	\
	((Ch == ':') && (Line[Npos+1] == ':') && (Line[Npos+2] == '='))


#define    isxmlEndTermToken() \
	((Ch == '<') && (Line[Npos+1] == '/'))

/* fl - . . . */

#define    flquotationTermToken()	\
if(isquotationTermToken()){getchr();flushbl();}

#define    flsharpTermToken()	\
if(issharpTermToken()){getchr();flushbl();}

#define    flampersandTermToken()	\
if(isampersandTermToken()){getchr();flushbl();}

#define    flapostropheTermToken()	\
if(isapostropheTermToken()){getchr();flushbl();}

#define    flleftparenthesisTermToken()	\
if(isleftparenthesisTermToken()){getchr();flushbl();}

#define    flrightparenthesisTermToken()	\
if(isrightparenthesisTermToken()){getchr();flushbl();}

#define    flstarmultiplyTermToken()	\
if(isstarmultiplyTermToken()){getchr();flushbl();}

#define    flplusTermToken()	\
if(isplusTermToken()){getchr();flushbl();}

#define    flcommaTermToken()	\
if(iscommaTermToken()){getchr();flushbl();}

#define    flhyphenminusTermToken()	\
if(ishyphenminusTermToken()){getchr();flushbl();}

#define    fldotpointperiodTermToken()	\
if(isdotpointperiodTermToken()){getchr();flushbl();}

#define    flslashdivideTermToken()	\
if(isslashdivideTermToken()){getchr();flushbl();}

#define    flcolonTermToken()	\
if(iscolonTermToken()){getchr();flushbl();}

#define    flsemicolonTermToken()	\
if(issemicolonTermToken()){getchr();flushbl();}

#define    fllessthanTermToken()	\
if(islessthanTermToken()){getchr();flushbl();}

#define    flequalTermToken()	\
if(isequalTermToken()){getchr();flushbl();}

#define    flgreaterthanTermToken()	\
if(isgreaterthanTermToken()){getchr();flushbl();}

#define    flunderlineTermToken()	\
if(isunderlineTermToken()){getchr();flushbl();}

#define    flverticalbarTermToken()	\
if(isverticalbarTermToken()){getchr();flushbl();}

#define    flexclamationmarkTermToken()	\
if(isexclamationmarkTermToken()){getchr();flushbl();}

#define    fldollarTermToken()	\
if(isdollarTermToken()){getchr();flushbl();}

#define    flpercentTermToken()	\
if(ispercentTermToken()){getchr();flushbl();}

#define    flquastionmarkTermToken()	\
if(isquastionmarkTermToken()){getchr();flushbl();}

#define    flcommercialatTermToken()	\
if(iscommercialatTermToken()){getchr();flushbl();}

#define    flleftsquarebracketTermToken()	\
if(isleftsquarebracketTermToken()){getchr();flushbl();}

#define    flleftbackslashTermToken()	\
if(isleftbackslashTermToken()){getchr();flushbl();}

#define    flrightsquarebracketTermToken()	\
if(isrightsquarebracketTermToken()){getchr();flushbl();}

#define    flcircumflexTermToken()	\
if(iscircumflexTermToken()){getchr();flushbl();}

#define    flgraveaccentTermToken()	\
if(isgraveaccentTermToken()){getchr();flushbl();}

#define    flleftbraceTermToken()	\
if(isleftbraceTermToken()){getchr();flushbl();}

#define    flrightbraceTermToken()	\
if(isrightbraceTermToken()){getchr();flushbl();}

#define    fltildeTermToken()	\
if(istildeTermToken()){getchr();flushbl();}



#define    flarrowTermToken()	\
if(isarrowTermToken()){getchr();getchr();flushbl();}

#define    fldoublestarexponentiateTermToken()	\
if(isdoublestarexponentiateTermToken()){getchr();getchr();flushbl();}

#define    flvariableassignmentTermToken()	\
if(isvariableassignmentTermToken()){getchr();getchr();flushbl();}

#define    flinequalityTermToken()	\
if(isinequalityTermToken()){getchr();getchr();flushbl();}

#define    flgreaterthanorequalTermToken()	\
if(isgreaterthanorequalTermToken()){getchr();getchr();flushbl();}

#define    fllessthanorequalsignalassignmentTermToken()	\
if(islessthanorequalsignalassignmentTermToken()){getchr();getchr();flushbl();}

#define    flboxTermToken()	\
if(isboxTermToken()){getchr();getchr();flushbl();}



#define    fldefisTermToken()	\
if(isdefisTermToken()){getchr();getchr();getchr();flushbl();}

#define    flxmlEndTermToken()	\
if(isxmlEndTermToken()){getchr();getchr();flushbl();}


#endif









#if MLAN
/* 23.09.91 */
/* is - . . . */

#define    isquotationTermToken() 		(Ch == '"')

#define    issharpTermToken() 			(Ch == '#')

#define    isampersandTermToken() 		(Ch == '&')

#define    isampersandequalTermToken()	\
  ((Ch == '&')  && (Line[Npos+1] == '='))

#define    isampersandampersandTermToken()	\
  ((Ch == '&')  && (Line[Npos+1] == '&'))

#define    isapostropheTermToken() 		issquota()

#define    isleftparenthesisTermToken() 	(Ch == '(')

#define    isrightparenthesisTermToken() 	(Ch == ')')

#define    isstarmultiplyTermToken() 		(Ch == '*')

#define    isstarmultiplyequalTermToken()	\
  ((Ch == '*')  && (Line[Npos+1] == '='))

#define    isplusTermToken() 			(Ch == '+')

#define    isplusplusTermToken()	\
  ((Ch == '+')  && (Line[Npos+1] == '+'))

#define    isplusequalTermToken()	\
  ((Ch == '+')  && (Line[Npos+1] == '='))

#define    iscommaTermToken() 			(Ch == ',')

#define    ishyphenminusTermToken() 		(Ch == '-')

#define    ishyphenminusequalTermToken()	\
  ((Ch == '-')  && (Line[Npos+1] == '='))

#define    ishyphenminusminusTermToken()	\
  ((Ch == '-')  && (Line[Npos+1] == '-'))

#define    ishyphenminusmoreTermToken()		\
  ((Ch == '-')  && (Line[Npos+1] == '>'))


#define    isdotpointperiodTermToken() 		(Ch == '.')

#define    isslashdivideTermToken() 		(Ch == '/')

#define    isslashdivideequalTermToken()	\
  ((Ch == '/')  && (Line[Npos+1] == '='))

#define    iscolonTermToken() 			(Ch == ':')

#define    issemicolonTermToken() 		(Ch == ';')

#define    islessthanTermToken() 		(Ch == '<')

#define    islessthanequalTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '='))

#define    islessthanlessTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '<'))

#define    islessthanlessequalTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '<') && (Line[Npos+2] == '='))

#define    isequalTermToken() 			(Ch == '=')

#define    isequalequalTermToken()	\
  ((Ch == '=')  && (Line[Npos+1] == '='))

#define    isgreaterthanTermToken() 		(Ch == '>')

#define    isgreaterthanequalTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '='))

#define    isgreaterthangreaterTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '>'))

#define    isgreaterthangreaterequalTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '>')  && (Line[Npos+2] == '='))

#define    isunderlineTermToken() 		(Ch == '_')

#define    isverticalbarTermToken() 		(Ch == '|')

#define    isverticalbarbarTermToken()	\
  ((Ch == '|')  && (Line[Npos+1] == '|'))

#define    isverticalbarequalTermToken()	\
  ((Ch == '|')  && (Line[Npos+1] == '='))

#define    isexclamationmarkTermToken() 	(Ch == '!')

#define    isexclamationmarkequalTermToken()	\
  ((Ch == '!')  && (Line[Npos+1] == '='))

#define    isdollarTermToken() 			(Ch == '$')

#define    ispercentTermToken() 		(Ch == '%')

#define    ispercentequalTermToken()	\
  ((Ch == '%')  && (Line[Npos+1] == '='))

#define    isquastionmarkTermToken() 		(Ch == '?')

#define    isquastionmarkcolonTermToken()	\
  ((Ch == '?')  && (Line[Npos+1] == ':'))

#define    iscommercialatTermToken() 		(Ch == '@')

#define    isleftsquarebracketTermToken() 	(Ch == '[')

#define    isleftbackslashTermToken() 		(Ch == '\\')

#define    isrightsquarebracketTermToken() 	(Ch == ']')

#define    iscircumflexTermToken() 		(Ch == '^')

#define    iscircumflexequalTermToken()	\
  ((Ch == '^')  && (Line[Npos+1] == '='))

/*
#define    isgraveaccentTermToken() 		(Ch == '`')
*/

#define    isleftbraceTermToken() 		(Ch == '{')

#define    isrightbraceTermToken() 		(Ch == '}')

#define    istildeTermToken() 			(Ch == '~')

#define    istildeequalTermToken()	\
  ((Ch == '~')  && (Line[Npos+1] == '='))

/*
#define    isarrowTermToken()	\
	((Ch == '=') && (Line[Npos+1] == '>'))
*/

/*
#define    isdoublestarexponentiateTermToken() \
	((Ch == '*') && (Line[Npos+1] == '*'))
*/

/*
#define    isvariableassignmentTermToken()	\
	((Ch == ':') && (Line[Npos+1] == '='))
*/

/*
#define    isinequalityTermToken()	\
	((Ch == '/') && (Line[Npos+1] == '='))
*/

/*
#define    isgreaterthanorequalTermToken()	\
	((Ch == '>') && (Line[Npos+1] == '='))
*/

/*
#define    islessthanorequalsignalassignmentTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '='))
*/


/*
#define    isboxTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '>'))
*/

#define    isdefisTermToken()	\
	((Ch == ':') && (Line[Npos+1] == ':') && (Line[Npos+2] == '='))


/* fl - . . . */

#define    flquotationTermToken()	\
if(isquotationTermToken()){getchr();flushbl();}

#define    flsharpTermToken()	\
if(issharpTermToken()){getchr();flushbl();}


#define    flampersandTermToken()	\
if(isampersandTermToken()){getchr();flushbl();}

#define    flampersandequalTermToken()	\
if(isampersandequalTermToken()){getchr();getchr();flushbl();}

#define    flampersandampersandTermToken()	\
if(isampersandampersandTermToken()){getchr();getchr();flushbl();}



#define    flapostropheTermToken()	\
if(isapostropheTermToken()){getchr();flushbl();}

#define    flleftparenthesisTermToken()	\
if(isleftparenthesisTermToken()){getchr();flushbl();}

#define    flrightparenthesisTermToken()	\
if(isrightparenthesisTermToken()){getchr();flushbl();}


#define    flstarmultiplyTermToken()	\
if(isstarmultiplyTermToken()){getchr();flushbl();}

#define    flstarmultiplyequalTermToken()	\
if(isstarmultiplyequalTermToken()){getchr();getchr();flushbl();}



#define    flplusTermToken()	\
if(isplusTermToken()){getchr();flushbl();}

#define    flplusequalTermToken()	\
if(isplusequalTermToken()){getchr();getchr();flushbl();}

#define    flplusplusTermToken()	\
if(isplusplusTermToken()){getchr();getchr();flushbl();}



#define    flcommaTermToken()	\
if(iscommaTermToken()){getchr();flushbl();}


#define    flhyphenminusTermToken()	\
if(ishyphenminusTermToken()){getchr();flushbl();}

#define    flhyphenminusequalTermToken()	\
if(ishyphenminusequalTermToken()){getchr();getchr();flushbl();}

#define    flhyphenminusminusTermToken()	\
if(ishyphenminusminusTermToken()){getchr();getchr();flushbl();}

#define    flhyphenminusmoreTermToken()	\
if(ishyphenminusmoreTermToken()){getchr();getchr();flushbl();}



#define    fldotpointperiodTermToken()	\
if(isdotpointperiodTermToken()){getchr();flushbl();}


#define    flslashdivideTermToken()	\
if(isslashdivideTermToken()){getchr();flushbl();}

#define    flslashdivideequalTermToken()	\
if(isslashdivideequalTermToken()){getchr();getchr();flushbl();}



#define    flcolonTermToken()	\
if(iscolonTermToken()){getchr();flushbl();}

#define    flsemicolonTermToken()	\
if(issemicolonTermToken()){getchr();flushbl();}



#define    fllessthanTermToken()	\
if(islessthanTermToken()){getchr();flushbl();}

#define    fllessthanequalTermToken()	\
if(islessthanequalTermToken()){getchr();getchr();flushbl();}

#define    fllessthanlessTermToken()	\
if(islessthanlessTermToken()){getchr();getchr();flushbl();}

#define    fllessthanlessequalTermToken()	\
if(islessthanlessequalTermToken()){getchr();getchr();getchr();flushbl();}



#define    flequalTermToken()	\
if(isequalTermToken()){getchr();flushbl();}

#define    flequalequalTermToken()	\
if(isequalequalTermToken()){getchr();getchr();flushbl();}



#define    flgreaterthanTermToken()	\
if(isgreaterthanTermToken()){getchr();flushbl();}

#define    flgreaterthanequalTermToken()	\
if(isgreaterthanequalTermToken()){getchr();getchr();flushbl();}

#define    flgreaterthangreaterTermToken()	\
if(isgreaterthangreaterTermToken()){getchr();getchr();flushbl();}

#define    flgreaterthangreaterequalTermToken()	\
if(isgreaterthangreaterequalTermToken()){getchr();getchr();getchr();flushbl();}



#define    flunderlineTermToken()	\
if(isunderlineTermToken()){getchr();flushbl();}



#define    flverticalbarTermToken()	\
if(isverticalbarTermToken()){getchr();flushbl();}

#define    flverticalbarbarTermToken()	\
if(isverticalbarbarTermToken()){getchr();getchr();flushbl();}

#define    flverticalbarequalTermToken()	\
if(isverticalbarequalTermToken()){getchr();getchr();flushbl();}



#define    flexclamationmarkTermToken()	\
if(isexclamationmarkTermToken()){getchr();flushbl();}

#define    flexclamationmarkequalTermToken()	\
if(isexclamationmarkequalTermToken()){getchr();getchr();flushbl();}



#define    fldollarTermToken()	\
if(isdollarTermToken()){getchr();flushbl();}



#define    flpercentTermToken()	\
if(ispercentTermToken()){getchr();flushbl();}

#define    flpercentequalTermToken()	\
if(ispercentequalTermToken()){getchr();getchr();flushbl();}



#define    flquastionmarkTermToken()	\
if(isquastionmarkTermToken()){getchr();flushbl();}

#define    flquastionmarkcolonTermToken()	\
if(isquastionmarkcolonTermToken()){getchr();getchr();flushbl();}



#define    flcommercialatTermToken()	\
if(iscommercialatTermToken()){getchr();flushbl();}

#define    flleftsquarebracketTermToken()	\
if(isleftsquarebracketTermToken()){getchr();flushbl();}

#define    flleftbackslashTermToken()	\
if(isleftbackslashTermToken()){getchr();flushbl();}

#define    flrightsquarebracketTermToken()	\
if(isrightsquarebracketTermToken()){getchr();flushbl();}



#define    flcircumflexTermToken()	\
if(iscircumflexTermToken()){getchr();flushbl();}

#define    flcircumflexequalTermToken()	\
if(iscircumflexequalTermToken()){getchr();getchr();flushbl();}

/*
#define    flgraveaccentTermToken()	\
if(isgraveaccentTermToken()){getchr();flushbl();}
*/

#define    flleftbraceTermToken()	\
if(isleftbraceTermToken()){getchr();flushbl();}

#define    flrightbraceTermToken()	\
if(isrightbraceTermToken()){getchr();flushbl();}



#define    fltildeTermToken()	\
if(istildeTermToken()){getchr();flushbl();}

#define    fltildeequalTermToken()	\
if(istildeequalTermToken()){getchr();getchr();flushbl();}


/*
#define    flarrowTermToken()	\
if(isarrowTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    fldoublestarexponentiateTermToken()	\
if(isdoublestarexponentiateTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flvariableassignmentTermToken()	\
if(isvariableassignmentTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flinequalityTermToken()	\
if(isinequalityTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flgreaterthanorequalTermToken()	\
if(isgreaterthanorequalTermToken()){getchr();getchr();flushbl();}
*/


/*
#define    fllessthanorequalsignalassignmentTermToken()	\
if(islessthanorequalsignalassignmentTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flboxTermToken()	\
if(isboxTermToken()){getchr();getchr();flushbl();}
*/


#define    fldefisTermToken()	\
if(isdefisTermToken()){getchr();getchr();getchr();flushbl();}


#endif










/* 15.03.93 */


#if SLLAN

/* is - . . . */

#define    isquotationTermToken() 		(Ch == '"')

#define    issharpTermToken() 			(Ch == '#')

#define    isampersandTermToken() 		(Ch == '&')

#define    isampersandequalTermToken()	\
  ((Ch == '&')  && (Line[Npos+1] == '='))

#define    isampersandampersandTermToken()	\
  ((Ch == '&')  && (Line[Npos+1] == '&'))

#define    isapostropheTermToken() 		issquota()

#define    isleftparenthesisTermToken() 	(Ch == '(')

#define    isrightparenthesisTermToken() 	(Ch == ')')

#define    isstarmultiplyTermToken() 		(Ch == '*')

#define    isstarmultiplyequalTermToken()	\
  ((Ch == '*')  && (Line[Npos+1] == '='))

#define    isplusTermToken() 			(Ch == '+')

#define    isplusplusTermToken()	\
  ((Ch == '+')  && (Line[Npos+1] == '+'))

#define    isplusequalTermToken()	\
  ((Ch == '+')  && (Line[Npos+1] == '='))

#define    iscommaTermToken() 			(Ch == ',')

#define    ishyphenminusTermToken() 		(Ch == '-')

#define    ishyphenminusequalTermToken()	\
  ((Ch == '-')  && (Line[Npos+1] == '='))

#define    ishyphenminusminusTermToken()	\
  ((Ch == '-')  && (Line[Npos+1] == '-'))

#define    ishyphenminusmoreTermToken()		\
  ((Ch == '-')  && (Line[Npos+1] == '>'))


#define    isdotpointperiodTermToken() 		(Ch == '.')

#define    isslashdivideTermToken() 		(Ch == '/')

#define    isslashdivideequalTermToken()	\
  ((Ch == '/')  && (Line[Npos+1] == '='))

#define    iscolonTermToken() 			(Ch == ':')

#define    issemicolonTermToken() 		(Ch == ';')

#define    islessthanTermToken() 		(Ch == '<')

#define    islessthanequalTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '='))

#define    islessthanlessTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '<'))

#define    islessthanlessequalTermToken()	\
  ((Ch == '<')  && (Line[Npos+1] == '<') && (Line[Npos+2] == '='))

#define    isequalTermToken() 			(Ch == '=')

#define    isequalequalTermToken()	\
  ((Ch == '=')  && (Line[Npos+1] == '='))

#define    isgreaterthanTermToken() 		(Ch == '>')

#define    isgreaterthanequalTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '='))

#define    isgreaterthangreaterTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '>'))

#define    isgreaterthangreaterequalTermToken()	\
  ((Ch == '>')  && (Line[Npos+1] == '>')  && (Line[Npos+2] == '='))

#define    isunderlineTermToken() 		(Ch == '_')

#define    isverticalbarTermToken() 		(Ch == '|')

#define    isverticalbarbarTermToken()	\
  ((Ch == '|')  && (Line[Npos+1] == '|'))

#define    isverticalbarequalTermToken()	\
  ((Ch == '|')  && (Line[Npos+1] == '='))

#define    isexclamationmarkTermToken() 	(Ch == '!')

#define    isexclamationmarkequalTermToken()	\
  ((Ch == '!')  && (Line[Npos+1] == '='))

#define    isdollarTermToken() 			(Ch == '$')

#define    ispercentTermToken() 		(Ch == '%')

#define    ispercentequalTermToken()	\
  ((Ch == '%')  && (Line[Npos+1] == '='))

#define    isquastionmarkTermToken() 		(Ch == '?')

#define    isquastionmarkcolonTermToken()	\
  ((Ch == '?')  && (Line[Npos+1] == ':'))

#define    iscommercialatTermToken() 		(Ch == '@')

#define    isleftsquarebracketTermToken() 	(Ch == '[')

#define    isleftbackslashTermToken() 		(Ch == '\\')

#define    isrightsquarebracketTermToken() 	(Ch == ']')

#define    iscircumflexTermToken() 		(Ch == '^')

#define    iscircumflexequalTermToken()	\
  ((Ch == '^')  && (Line[Npos+1] == '='))

/*
#define    isgraveaccentTermToken() 		(Ch == '`')
*/

#define    isleftbraceTermToken() 		(Ch == '{')

#define    isrightbraceTermToken() 		(Ch == '}')

#define    istildeTermToken() 			(Ch == '~')

#define    istildeequalTermToken()	\
  ((Ch == '~')  && (Line[Npos+1] == '='))

/*
#define    isarrowTermToken()	\
	((Ch == '=') && (Line[Npos+1] == '>'))
*/

/*
#define    isdoublestarexponentiateTermToken() \
	((Ch == '*') && (Line[Npos+1] == '*'))
*/

/*
#define    isvariableassignmentTermToken()	\
	((Ch == ':') && (Line[Npos+1] == '='))
*/

/*
#define    isinequalityTermToken()	\
	((Ch == '/') && (Line[Npos+1] == '='))
*/

/*
#define    isgreaterthanorequalTermToken()	\
	((Ch == '>') && (Line[Npos+1] == '='))
*/

/*
#define    islessthanorequalsignalassignmentTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '='))
*/


/*
#define    isboxTermToken()	\
	((Ch == '<') && (Line[Npos+1] == '>'))
*/

#define    isdefisTermToken()	\
	((Ch == ':') && (Line[Npos+1] == ':') && (Line[Npos+2] == '='))



/* fl - . . . */

#define    flquotationTermToken()	\
if(isquotationTermToken()){getchr();flushbl();}

#define    flsharpTermToken()	\
if(issharpTermToken()){getchr();flushbl();}


#define    flampersandTermToken()	\
if(isampersandTermToken()){getchr();flushbl();}

#define    flampersandequalTermToken()	\
if(isampersandequalTermToken()){getchr();getchr();flushbl();}

#define    flampersandampersandTermToken()	\
if(isampersandampersandTermToken()){getchr();getchr();flushbl();}



#define    flapostropheTermToken()	\
if(isapostropheTermToken()){getchr();flushbl();}

#define    flleftparenthesisTermToken()	\
if(isleftparenthesisTermToken()){getchr();flushbl();}

#define    flrightparenthesisTermToken()	\
if(isrightparenthesisTermToken()){getchr();flushbl();}


#define    flstarmultiplyTermToken()	\
if(isstarmultiplyTermToken()){getchr();flushbl();}

#define    flstarmultiplyequalTermToken()	\
if(isstarmultiplyequalTermToken()){getchr();getchr();flushbl();}



#define    flplusTermToken()	\
if(isplusTermToken()){getchr();flushbl();}

#define    flplusequalTermToken()	\
if(isplusequalTermToken()){getchr();getchr();flushbl();}

#define    flplusplusTermToken()	\
if(isplusplusTermToken()){getchr();getchr();flushbl();}



#define    flcommaTermToken()	\
if(iscommaTermToken()){getchr();flushbl();}


#define    flhyphenminusTermToken()	\
if(ishyphenminusTermToken()){getchr();flushbl();}

#define    flhyphenminusequalTermToken()	\
if(ishyphenminusequalTermToken()){getchr();getchr();flushbl();}

#define    flhyphenminusminusTermToken()	\
if(ishyphenminusminusTermToken()){getchr();getchr();flushbl();}

#define    flhyphenminusmoreTermToken()	\
if(ishyphenminusmoreTermToken()){getchr();getchr();flushbl();}



#define    fldotpointperiodTermToken()	\
if(isdotpointperiodTermToken()){getchr();flushbl();}


#define    flslashdivideTermToken()	\
if(isslashdivideTermToken()){getchr();flushbl();}

#define    flslashdivideequalTermToken()	\
if(isslashdivideequalTermToken()){getchr();getchr();flushbl();}



#define    flcolonTermToken()	\
if(iscolonTermToken()){getchr();flushbl();}

#define    flsemicolonTermToken()	\
if(issemicolonTermToken()){getchr();flushbl();}



#define    fllessthanTermToken()	\
if(islessthanTermToken()){getchr();flushbl();}

#define    fllessthanequalTermToken()	\
if(islessthanequalTermToken()){getchr();getchr();flushbl();}

#define    fllessthanlessTermToken()	\
if(islessthanlessTermToken()){getchr();getchr();flushbl();}

#define    fllessthanlessequalTermToken()	\
if(islessthanlessequalTermToken()){getchr();getchr();getchr();flushbl();}



#define    flequalTermToken()	\
if(isequalTermToken()){getchr();flushbl();}

#define    flequalequalTermToken()	\
if(isequalequalTermToken()){getchr();getchr();flushbl();}



#define    flgreaterthanTermToken()	\
if(isgreaterthanTermToken()){getchr();flushbl();}

#define    flgreaterthanequalTermToken()	\
if(isgreaterthanequalTermToken()){getchr();getchr();flushbl();}

#define    flgreaterthangreaterTermToken()	\
if(isgreaterthangreaterTermToken()){getchr();getchr();flushbl();}

#define    flgreaterthangreaterequalTermToken()	\
if(isgreaterthangreaterequalTermToken()){getchr();getchr();getchr();flushbl();}



#define    flunderlineTermToken()	\
if(isunderlineTermToken()){getchr();flushbl();}



#define    flverticalbarTermToken()	\
if(isverticalbarTermToken()){getchr();flushbl();}

#define    flverticalbarbarTermToken()	\
if(isverticalbarbarTermToken()){getchr();getchr();flushbl();}

#define    flverticalbarequalTermToken()	\
if(isverticalbarequalTermToken()){getchr();getchr();flushbl();}



#define    flexclamationmarkTermToken()	\
if(isexclamationmarkTermToken()){getchr();flushbl();}

#define    flexclamationmarkequalTermToken()	\
if(isexclamationmarkequalTermToken()){getchr();getchr();flushbl();}



#define    fldollarTermToken()	\
if(isdollarTermToken()){getchr();flushbl();}



#define    flpercentTermToken()	\
if(ispercentTermToken()){getchr();flushbl();}

#define    flpercentequalTermToken()	\
if(ispercentequalTermToken()){getchr();getchr();flushbl();}



#define    flquastionmarkTermToken()	\
if(isquastionmarkTermToken()){getchr();flushbl();}

#define    flquastionmarkcolonTermToken()	\
if(isquastionmarkcolonTermToken()){getchr();getchr();flushbl();}



#define    flcommercialatTermToken()	\
if(iscommercialatTermToken()){getchr();flushbl();}

#define    flleftsquarebracketTermToken()	\
if(isleftsquarebracketTermToken()){getchr();flushbl();}

#define    flleftbackslashTermToken()	\
if(isleftbackslashTermToken()){getchr();flushbl();}

#define    flrightsquarebracketTermToken()	\
if(isrightsquarebracketTermToken()){getchr();flushbl();}



#define    flcircumflexTermToken()	\
if(iscircumflexTermToken()){getchr();flushbl();}

#define    flcircumflexequalTermToken()	\
if(iscircumflexequalTermToken()){getchr();getchr();flushbl();}

/*
#define    flgraveaccentTermToken()	\
if(isgraveaccentTermToken()){getchr();flushbl();}
*/

#define    flleftbraceTermToken()	\
if(isleftbraceTermToken()){getchr();flushbl();}

#define    flrightbraceTermToken()	\
if(isrightbraceTermToken()){getchr();flushbl();}



#define    fltildeTermToken()	\
if(istildeTermToken()){getchr();flushbl();}

#define    fltildeequalTermToken()	\
if(istildeequalTermToken()){getchr();getchr();flushbl();}


/*
#define    flarrowTermToken()	\
if(isarrowTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    fldoublestarexponentiateTermToken()	\
if(isdoublestarexponentiateTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flvariableassignmentTermToken()	\
if(isvariableassignmentTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flinequalityTermToken()	\
if(isinequalityTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flgreaterthanorequalTermToken()	\
if(isgreaterthanorequalTermToken()){getchr();getchr();flushbl();}
*/


/*
#define    fllessthanorequalsignalassignmentTermToken()	\
if(islessthanorequalsignalassignmentTermToken()){getchr();getchr();flushbl();}
*/

/*
#define    flboxTermToken()	\
if(isboxTermToken()){getchr();getchr();flushbl();}
*/


#define    fldefisTermToken()	\
if(isdefisTermToken()){getchr();getchr();getchr();flushbl();}

#endif




/*          end of lexisal macros */








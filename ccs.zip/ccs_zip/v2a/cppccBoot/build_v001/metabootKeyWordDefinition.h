/////////////////////////////////////////////////////////////////////
//  metabootKeyWordDefinition.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_metaboot_KEYWORDDEFINITION_H_
#define  _CPPCC_metaboot_KEYWORDDEFINITION_H_

#include "CommonRoutines.h"

namespace cppcc {
namespace metaboot {

enum KeyWords
{
  // 0
  KW_WRONG_KEY_WORD
  // 1
  ,KW_IDENTIFIER
  // 2
  ,KW_STRINGTOKEN
  // 3
  ,KW_INTEGERTOKEN
  // 4
  ,KW_FLOATTOKEN
  // 5
  ,KW_TEXTTOKEN
  // 6
  ,KW_TERMTOKEN
  // 7
  ,KW_TERMINALTOKENOFRULE
  // 8
  ,KW_QUOTETERMTOKEN
  // 9
  ,KW_APOSTROPHETERMTOKEN
  // 10
  ,KW_LEFTPARENTHESISTERMTOKEN
  // 11
  ,KW_RIGHTPARENTHESISTERMTOKEN
  // 12
  ,KW_LESSTHENTERMTOKEN
  // 13
  ,KW_EQUALTERMTOKEN
  // 14
  ,KW_GREATERTHENTERMTOKEN
  // 15
  ,KW_LEFTSQUAREBRACKETTERMTOKEN
  // 16
  ,KW_RIGHTSQUAREBRACKETTERMTOKEN
  // 17
  ,KW_VERTICALBARTERMTOKEN
  // 18
  ,KW_LEFTBRACETERMTOKEN
  // 19
  ,KW_RIGHTBRACETERMTOKEN
  // 20
  ,KW_DEFISTERMTOKEN
  // 21
  ,KW_COLONMARKTERMTOKEN
  // 22
  ,KW_QUESTIONMARKTERMTOKEN
  // 23
  ,KW_SLASHMARKTERMTOKEN
  // 24
  ,KW_XMLENDTERMTOKEN
  // 25
  ,KW_GRAMMAR
  // 26
  ,KW_GRAMMARNAMEDEF
  // 27
  ,KW_RULE
  // 28
  ,KW_NTERM
  // 29
  ,KW_RIGHT
  // 30
  ,KW_ELEMENT
  // 31
  ,KW_ACTION
  // 32
  ,KW_ACTIONS
  // 33
  ,KW_IDENTALT
  // 34
  ,KW_ALTPART
  // 35
  ,KW_NTERMTERMACT
  // 36
  ,KW_NTERMTERM
  // 37
  ,KW_ALTERNATIVE
  // 38
  ,KW_IDENTMISS
  // 39
  ,KW_ITERATION
  // 40
  ,KW_ITERITEMS
  // 41
  ,KW_ALTITERITEM
  // 42
  ,KW_ITERITEMACT
  // 43
  ,KW_ITERITEM
  // 44
  ,KW_MAYBENTERM
  // 45 -- Total
  ,KW_KEYWORDS_TOTAL
};

cppcc::com::KeyWordsContainer makeKeyWordsContainer();

}
}

#endif


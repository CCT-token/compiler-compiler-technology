/////////////////////////////////////////////////////////////////////
//  metabootKeyWordDefinition.cc
//
//      Change history:
//              2010.06.12              - Initial version
//
/////////////////////////////////////////////////////////////////////

#include "metabootKeyWordDefinition.h"

namespace cppcc {
namespace metaboot {

namespace {

  static std::string   predef_[] =
  {
    "Wrong_Key_Word"
    ,"identifier"
    ,"stringToken"
    ,"integerToken"
    ,"floatToken"
    ,"textToken"
    ,"termToken"
    ,"terminalTokenOfRule"
  };
  static std::size_t  predefSize_ =
  sizeof(predef_)/sizeof(predef_[0]);

  static std::string   charTokens_[] =
  {
    "\""
    ,"'"
    ,"("
    ,")"
    ,"<"
    ,"="
    ,">"
    ,"["
    ,"]"
    ,"|"
    ,"{"
    ,"}"
    ,"::="
    ,":"
    ,"?"
    ,"/"
    ,"</"
  };
  static std::size_t  charTokensSize_ =
  sizeof(charTokens_)/sizeof(charTokens_[0]);

//   static std::string   keyWords_[] =
//   {
//   };
//   static std::size_t  keyWordsSize_ =
//   sizeof(keyWords_)/sizeof(keyWords_[0]);
// 
  static std::string   non_Terminals_[] =
  {
    "grammar"
    ,"grammarNameDef"
    ,"rule"
    ,"nterm"
    ,"right"
    ,"element"
    ,"action"
    ,"actions"
    ,"identAlt"
    ,"Altpart"
    ,"ntermtermact"
    ,"ntermterm"
    ,"alternative"
    ,"identMiss"
    ,"iteration"
    ,"iterItems"
    ,"altIterItem"
    ,"iterItemact"
    ,"iterItem"
    ,"maybeNterm"
  };
  static std::size_t  non_TerminalsSize_ =
  sizeof(non_Terminals_)/sizeof(non_Terminals_[0]);

}

cppcc::com::KeyWordsContainer makeKeyWordsContainer()
{
  cppcc::com::KeyWordsContainer result;
  result.predefined_.assign(predef_,predef_+predefSize_);
  result.tokens_.assign(charTokens_,charTokens_+charTokensSize_);
// result.keyWords_.assign(keyWords_,keyWords_+keyWordsSize_);
  result.nonTerminals_.assign(non_Terminals_,non_Terminals_+non_TerminalsSize_);
  return result;

}
}

namespace com {
cppcc::com::KeyWordsContainer
makeCompilerKeyWords()
{
  return cppcc::metaboot::makeKeyWordsContainer();
}
}

}


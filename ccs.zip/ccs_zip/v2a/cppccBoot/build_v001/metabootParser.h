/////////////////////////////////////////////////////////////////////
//  metabootParser.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_metaboot_PARSER_H_
#define  _CPPCC_metaboot_PARSER_H_

#include "Parser.h"

namespace cppcc {

namespace cmp {
  class Compiler;
}

namespace metaboot {

class metabootParser
  : public cppcc::syn::Parser
{

public:
  metabootParser 
    (cppcc::log::Logger&          logger
    ,cppcc::com::KeyWordsContainer&   theKeyWords
    ,cppcc::com::LanguageTokenizerSet   theLanguage
    ,cppcc::lex::TokenizerReader    theReader)
  : Parser(logger, theKeyWords, theLanguage, theReader)
  {
  }

  ~metabootParser()
  {
  }

  void compile
    (const char *sour, const char *list);

  void compile
      (const std::string& filename
      ,const std::string& sourceString
    ,bool         isListing);


  void grammar(cppcc::scr::tag::Long& tag);
  void grammarNameDef(cppcc::scr::tag::Long& tag);
  void rule(cppcc::scr::tag::Long& tag);
  void nterm(cppcc::scr::tag::Long& tag);
  void right(cppcc::scr::tag::Long& tag);
  void element(cppcc::scr::tag::Long& tag);
  void action(cppcc::scr::tag::Long& tag);
  void actions(cppcc::scr::tag::Long& tag);
  void identAlt(cppcc::scr::tag::Long& tag);
  void Altpart(cppcc::scr::tag::Long& tag);
  void ntermtermact(cppcc::scr::tag::Long& tag);
  void ntermterm(cppcc::scr::tag::Long& tag);
  void alternative(cppcc::scr::tag::Long& tag);
  void identMiss(cppcc::scr::tag::Long& tag);
  void iteration(cppcc::scr::tag::Long& tag);
  void iterItems(cppcc::scr::tag::Long& tag);
  void altIterItem(cppcc::scr::tag::Long& tag);
  void iterItemact(cppcc::scr::tag::Long& tag);
  void iterItem(cppcc::scr::tag::Long& tag);
  void maybeNterm(cppcc::scr::tag::Long& tag);
};

}
}

#endif

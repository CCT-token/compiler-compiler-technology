/////////////////////////////////////////////////////////////////////
//  metabootGenerator.h
//
//  Change history:
//    2010.06.12    - Initial version
//
/////////////////////////////////////////////////////////////////////

#ifndef  _CPPCC_metaboot_GENERATOR_H_
#define  _CPPCC_metaboot_GENERATOR_H_

#include "Generator.h"

namespace cppcc {
namespace metaboot {

	class metabootGeneratorRuntime
	: public cppcc::gen::GeneratorRuntime
	{
	public:
		metabootGeneratorRuntime(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorRuntime(generator)
	 	{
	  	}

		~metabootGeneratorRuntime()
	   	{
	   	}

	 	//void        decompile(const std::string& filename);
	  	//void        generate(const std::string& filename);

	};

	class metabootGeneratorBinary
	: public cppcc::gen::GeneratorBinary
	{
	public:
		metabootGeneratorBinary(cppcc::gen::Generator&   generator)
	       : cppcc::gen::GeneratorBinary(generator)

		{
	 	}

		~metabootGeneratorBinary()
	   	{
	  	}

		//void        decompile(const std::string& filename);
		void        generate(const std::string& filename);
	};
}
}

#endif

